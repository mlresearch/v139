import numpy as np
import pandas as pd
from scipy.io import mmread
from scipy.stats import ortho_group
from scipy.linalg import block_diag
import scipy.sparse as sparse
import scipy.stats as stats
import matplotlib
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
import matplotlib.pyplot as plt
from sklearn.utils.extmath import randomized_svd
from sklearn.preprocessing import StandardScaler

rng = np.random.RandomState(42)


# generating weight matrices

# weights in [0, 1]

weights_probs = [([1, 0.1, 0.01], [0.85, 0.1, 0.05]),
                 ([1, 0.1, 0.01], [0.5,0.4,0.1]),
                 ([1, 0.1, 0.01], [0.05,0.1,0.85]),
                 ([0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9], [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1])]

def gen_weights_real(rows, cols, weights, probs, rng=np.random.RandomState(42)):
  return np.reshape(rng.choice(weights, rows * cols, p = probs), (rows, cols))

# binary weights 

def gen_weights_cancel_largest_t(A, t):
  rows = A.shape[0]
  cols = A.shape[1]
  tmp = np.abs(A.flatten())
  val = tmp[np.argsort(tmp)[-t]]
  res = np.ones((rows, cols))
  res[np.abs(A) >= val] = 0
  return res

def gen_weights_masked_with_p(rows, cols, p, rng=np.random.RandomState(42)):
  weights = [0, 1]
  probs = [1-p, p]
  return gen_weights_real(rows, cols, weights, probs, rng)

# blocks
def gen_weights_cancel_diag(rows, cols):
  return np.ones((rows, cols)) - np.eye(rows, cols)

def gen_weights_cancel_blcok_diag(rows, cols, t):
  if rows != cols or rows % t != 0:
    return None
  r = int(rows/t)
  block = np.ones((t, t))
  l = []
  for i in range(r):
    l += [block]
  return np.ones((rows, cols)) - block_diag(*l)

def gen_weights_diag_only(rows, cols):
  return np.eye(rows, cols)

def gen_weights_block_diag_only(rows, cols, t):
  if rows != cols or rows % t != 0:
    return None
  r = int(rows/t)
  block = np.ones((t, t))
  l = []
  for i in range(r):
    l += [block]
  return block_diag(*l)

def gen_weights_random_rows_scale(rows, cols, rng=np.random.RandomState(42)):
  W = np.ones((rows, cols))
  for i in range(rows):
    W[i, :] = W[i, : ] * rng.rand()
  return W

def gen_weights_semi_rand(rows, cols, row_frac=0.3, col_frac=0.9, p=0.2, rng=np.random.RandomState(42)):
  W = rng.choice([0, 1], (rows, cols), replace=True, p=[1-p, p])
  r = int(row_frac*rows)
  c = int(col_frac*cols)
  for i in range(r):
    for j in range(c):
      W[i, j] = 1
  return W

def gen_weights_uniform(rows, cols, rng=np.random.RandomState(42)):
  return rng.rand(rows, cols)

# Our algorithms

def svd_docmp_first(A):
  U, D, V = np.linalg.svd(A)
  return U[:,0],(np.diag(D)@V)[0,:]

def svd_docmp_first_fast(A):
  U, D, V = randomized_svd(A, 1)
  return U[:,0],(np.diag(D)@V)[0,:]

def solve_local(W, X, lp='2'):
  if lp=='2':
    return svd_docmp_first(np.multiply(W, X))

def get_coef(W, X, U, lp='2'):
  if lp=='2':
    numerator = np.dot(np.multiply(X[:, j], W[:, j]), U)
    denominator = np.dot(np.multiply(U, W[:, j]), U)
    if denominator==0:
      return None
    return numerator/denominator

def wlra_iter(W, A, T, lp='2'):
  rows, cols = W.shape
  UT = []
  VT = []
  X = np.copy(A)
  for i in range(T):
    U , V  = svd_docmp_first_fast(np.multiply(W, X))
    UT += [U]
    v_list = []
    for j in range(cols):
      numerator = np.dot(np.multiply(X[:, j], W[:, j]), U)
      denominator = np.dot(np.multiply(U, W[:, j]), U)      
      if (denominator==0):
        coef = 0
      else:
        coef = numerator/denominator
      X[:,j] = X[:,j] - coef*U
      v_list += [coef]
    VT += [v_list]
  return np.transpose(np.array(UT)), np.array(VT)

# Others

def nSVD(A,k):
  U, D, V = np.linalg.svd(A)
  return np.dot(U[:,:k], np.dot(np.diag(D)[:k,:k], V[:k,:]))

def nSVD_fast(A,k):
  U, D, V = randomized_svd(A, k)
  return np.dot(U[:,:k], np.dot(np.diag(D)[:k,:k], V[:k,:]))


