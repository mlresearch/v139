import numpy as np
import pandas as pd
from scipy.io import mmread
from scipy.stats import ortho_group
from scipy.linalg import block_diag
import scipy.sparse as sparse
import scipy.stats as stats
import matplotlib
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
import matplotlib.pyplot as plt
from sklearn.utils.extmath import randomized_svd
from sklearn.preprocessing import StandardScaler
from  weight_gen_and_algorithms import *

rng = np.random.RandomState(42)

weights_probs = [([1, 0.1, 0.01], [0.85, 0.1, 0.05]),
                 ([1, 0.1, 0.01], [0.5,0.4,0.1]),
                 ([1, 0.1, 0.01], [0.05,0.1,0.85]),
                 ([0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9], [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1])]


file_path = 'landmark.mtx'
mat = mmread(file_path)
data = mat.todense()
print(data.shape)

scaler = StandardScaler()
data = scaler.fit_transform(data)
rows, cols = 10000, data.shape[1]


# change kprime

# weights setting 1

weights_set = 1
k = 20
kprime_list = [10, 20, 30, 50, 70]

n_iter = 5

errs_wlra_iter = np.zeros((n_iter, len(kprime_list)))
errs_asvd = np.zeros((n_iter, len(kprime_list)))
errs_awsvd = np.zeros((n_iter, len(kprime_list)))

for i in range(n_iter):
  A = data[rng.choice(np.arange(data.shape[0]), rows, replace=False), :][:, rng.choice(np.arange(data.shape[1]), cols, replace=False)]
  W = gen_weights_real(rows, cols, weights_probs[weights_set][0], weights_probs[weights_set][1], rng)
  for j, kprime in enumerate(kprime_list):
    U_,V_ = wlra_iter(W, A, kprime)
    asvd = nSVD_fast(A, kprime)
    awsvd = nSVD_fast(np.multiply(W,A), kprime)
    err_wlra_iter = np.linalg.norm(np.multiply(np.sqrt(W), A - np.dot(U_, V_)), ord='fro')/np.linalg.norm(A, ord='fro')   
    err_asvd = np.linalg.norm(np.multiply(np.sqrt(W), A - asvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_awsvd = np.linalg.norm(np.multiply(np.sqrt(W), A - awsvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    errs_wlra_iter[i, j] = err_wlra_iter
    errs_asvd[i, j] = err_asvd
    errs_awsvd[i, j] = err_awsvd
  print('iteration: ', i, ' done.')

errs_wlra_iter_mean = np.mean(errs_wlra_iter, axis=0)
errs_asvd_mean = np.mean(errs_asvd, axis=0)
errs_awsvd_mean = np.mean(errs_awsvd, axis=0)
errs_wlra_iter_std = np.std(errs_wlra_iter, axis=0)
errs_asvd_std = np.std(errs_asvd, axis=0)
errs_awsvd_std = np.std(errs_awsvd, axis=0)

print('err means:')
print(errs_wlra_iter_mean)
print(errs_asvd_mean)
print(errs_awsvd_mean)
print('err stds:')
print(errs_wlra_iter_std)
print(errs_asvd_std)
print(errs_awsvd_std)


# change kprime

# weights setting 2

k = 10
kprime_list = [10, 20, 30, 50, 70]

n_iter = 5

errs_wlra_iter = np.zeros((n_iter, len(kprime_list)))
errs_asvd = np.zeros((n_iter, len(kprime_list)))
errs_awsvd = np.zeros((n_iter, len(kprime_list)))

for i in range(n_iter):
  A = data[rng.choice(np.arange(data.shape[0]), rows, replace=False), :][:, rng.choice(np.arange(data.shape[1]), cols, replace=False)]
  W = gen_weights_uniform(rows, cols, rng)
  for j, kprime in enumerate(kprime_list):
    U_,V_ = wlra_iter(W, A, kprime)
    asvd = nSVD_fast(A, kprime)
    awsvd = nSVD_fast(np.multiply(W,A), kprime)
    err_wlra_iter = np.linalg.norm(np.multiply(np.sqrt(W), A - np.dot(U_, V_)), ord='fro')/np.linalg.norm(A, ord='fro')   
    err_asvd = np.linalg.norm(np.multiply(np.sqrt(W), A - asvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_awsvd = np.linalg.norm(np.multiply(np.sqrt(W), A - awsvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    errs_wlra_iter[i, j] = err_wlra_iter
    errs_asvd[i, j] = err_asvd
    errs_awsvd[i, j] = err_awsvd
  print('iteration: ', i, ' done.')

errs_wlra_iter_mean = np.mean(errs_wlra_iter, axis=0)
errs_asvd_mean = np.mean(errs_asvd, axis=0)
errs_awsvd_mean = np.mean(errs_awsvd, axis=0)
errs_wlra_iter_std = np.std(errs_wlra_iter, axis=0)
errs_asvd_std = np.std(errs_asvd, axis=0)
errs_awsvd_std = np.std(errs_awsvd, axis=0)

print('err means:')
print(errs_wlra_iter_mean)
print(errs_asvd_mean)
print(errs_awsvd_mean)
print('err stds:')
print(errs_wlra_iter_std)
print(errs_asvd_std)
print(errs_awsvd_std)


# change kprime

# weights setting 3

k = 10
kprime_list = [10, 20, 30, 50, 70]

n_iter = 5

errs_wlra_iter = np.zeros((n_iter, len(kprime_list)))
errs_asvd = np.zeros((n_iter, len(kprime_list)))
errs_awsvd = np.zeros((n_iter, len(kprime_list)))

for i in range(n_iter):
  A = data[rng.choice(np.arange(data.shape[0]), rows, replace=False), :][:, rng.choice(np.arange(data.shape[1]), cols, replace=False)]
  W = gen_weights_semi_rand(rows, cols, 0.9, 0.3, 0.2, rng)
  for j, kprime in enumerate(kprime_list):
    U_,V_ = wlra_iter(W, A, kprime)
    asvd = nSVD_fast(A, kprime)
    awsvd = nSVD_fast(np.multiply(W,A), kprime)
    err_wlra_iter = np.linalg.norm(np.multiply(np.sqrt(W), A - np.dot(U_, V_)), ord='fro')/np.linalg.norm(A, ord='fro')   
    err_asvd = np.linalg.norm(np.multiply(np.sqrt(W), A - asvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_awsvd = np.linalg.norm(np.multiply(np.sqrt(W), A - awsvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    errs_wlra_iter[i, j] = err_wlra_iter
    errs_asvd[i, j] = err_asvd
    errs_awsvd[i, j] = err_awsvd
  print('iteration: ', i, ' done.')

errs_wlra_iter_mean = np.mean(errs_wlra_iter, axis=0)
errs_asvd_mean = np.mean(errs_asvd, axis=0)
errs_awsvd_mean = np.mean(errs_awsvd, axis=0)
errs_wlra_iter_std = np.std(errs_wlra_iter, axis=0)
errs_asvd_std = np.std(errs_asvd, axis=0)
errs_awsvd_std = np.std(errs_awsvd, axis=0)

print('err means:')
print(errs_wlra_iter_mean)
print(errs_asvd_mean)
print(errs_awsvd_mean)
print('err stds:')
print(errs_wlra_iter_std)
print(errs_asvd_std)
print(errs_awsvd_std)