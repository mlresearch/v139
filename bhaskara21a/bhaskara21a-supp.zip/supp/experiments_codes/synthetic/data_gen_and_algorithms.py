import numpy as np
import scipy
from scipy.stats import ortho_group
from scipy.linalg import block_diag
import pandas as pd
import matplotlib
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
import matplotlib.pyplot as plt

rng = np.random.RandomState(42)

# generating weight matrices

# weights in [0, 1]

weights_probs = [([1, 0.1, 0.01], [0.85, 0.1, 0.05]),
                 ([1, 0.1, 0.01], [0.5,0.4,0.1]),
                 ([1, 0.1, 0.01], [0.05,0.1,0.85]),
                 ([0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9], [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1])]

def gen_weights_real(rows, cols, weights, probs, rng=np.random.RandomState(42)):
  return np.reshape(rng.choice(weights, rows * cols, p = probs), (rows, cols))

# binary weights 

def gen_weights_cancel_largest_t(A, t):
  rows = A.shape[0]
  cols = A.shape[1]
  tmp = np.abs(A.flatten())
  val = tmp[np.argsort(tmp)[-t]]
  res = np.ones((rows, cols))
  res[np.abs(A) >= val] = 0
  return res

def gen_weights_masked_with_p(rows, cols, p, rng=np.random.RandomState(42)):
  weights = [0, 1]
  probs = [1-p, p]
  return gen_weights_real(rows, cols, weights, probs, rng)

# blocks
def gen_weights_cancel_diag(rows, cols):
  return np.ones((rows, cols)) - np.eye(rows, cols)

def gen_weights_cancel_blcok_diag(rows, cols, t):
  if rows != cols or rows % t != 0:
    return None
  r = int(rows/t)
  block = np.ones((t, t))
  l = []
  for i in range(r):
    l += [block]
  return np.ones((rows, cols)) - block_diag(*l)

def gen_weights_diag_only(rows, cols):
  return np.eye(rows, cols)

def gen_weights_block_diag_only(rows, cols, t):
  if rows != cols or rows % t != 0:
    return None
  r = int(rows/t)
  block = np.ones((t, t))
  l = []
  for i in range(r):
    l += [block]
  return block_diag(*l)

def gen_weights_semi_rand(rows, cols, row_frac=0.3, col_frac=0.9, p=0.2, rng=np.random.RandomState(42)):
  W = rng.choice([0, 1], (rows, cols), replace=True, p=[1-p, p])
  r = int(row_frac*rows)
  c = int(col_frac*cols)
  for i in range(r):
    for j in range(c):
      W[i, j] = 1
  return W

def gen_weights_uniform(rows, cols, rng=np.random.RandomState(42)):
  return rng.rand(rows, cols)

# generating A s

def generate_UV(rows, cols, k, rng=np.random.RandomState(42)):
  U = ortho_group.rvs(rows, 1)[:, :k].reshape((rows, k))
  V = ortho_group.rvs(cols, 1)[:, :k].reshape((cols, k))
  return U, np.transpose(V)

def generate_lr_matrix(rows, cols, k, max_sing, rng=np.random.RandomState(42)):
  U, VT = generate_UV(rows, cols, k, rng)
  sing = sorted([rng.randint(max_sing) for _ in range(k)])[::-1]
  sing = sing/np.linalg.norm(sing, 2)
  return np.dot(U, np.dot(np.diag(sing), VT))

def generate_lr_matrix_fixed(rows, cols, k, max_sing, rng=np.random.RandomState(42)):
  U, VT = generate_UV(rows, cols, k, rng)
  sing = [max_sing]
  cur = max_sing
  for i in range(1, k):
    sing += [cur * 0.9]
    cur = cur * 0.9
  sing = sing/np.linalg.norm(sing, 2)
  return np.dot(U, np.dot(np.diag(sing), VT))

def output_sings_only(k, max_sing):
  sing = [max_sing]
  cur = max_sing
  for i in range(1, k):
    sing += [cur * 0.9]
    cur = cur * 0.9
  sing = sing/np.linalg.norm(sing, 2)
  return sing
  
def generate_noise(rows, cols, st=1, rng=np.random.RandomState(42)):
  return rng.normal(0, st, (rows, cols))

def generate_matrix(rows, cols, k, st, max_sing, rng=np.random.RandomState(42)):
  M = generate_lr_matrix(rows, cols, k, max_sing, rng)
  N = generate_noise(rows, cols, st, rng)
  return  M+N, M, np.power(np.linalg.norm(M)/np.linalg.norm(N), 2), np.power(np.linalg.norm(M)/np.linalg.norm(M+N), 2)

def generate_matrix_fixed_snr(rows, cols, k, st, max_sing, rng=np.random.RandomState(42)):
  M = generate_lr_matrix_fixed(rows, cols, k, max_sing, rng)
  N = generate_noise(rows, cols, st, rng)
  return  M+N, M, np.power(np.linalg.norm(M)/np.linalg.norm(N), 2), np.power(np.linalg.norm(M)/np.linalg.norm(M+N), 2)



# rwlra code snippets
# downloaded from the supplementary metetrial at : https://papers.nips.cc/paper/2019/hash/90aef91f0d9e7c3be322bd7bae41617d-Abstract.html
# Regularized Weighted Low Rank Approximation(NeurIPS 2019)

import numpy as np
import scipy.sparse as sparse
import scipy.stats as stats
import sklearn.metrics.pairwise as skl


def gen_gaussian(m, n, mu, sigma, rng=np.random.RandomState(42)):
    # generates an m by n matrix of N(mu, sigma^2) variables
    return rng.normal(mu, sigma, (m, n))

def gen_countsketch(r, c, rng=np.random.RandomState(42)):
    S = sparse.dok_matrix((r, c), dtype=np.float32)
    hashed = rng.choice(r, c, replace=True)
    for j in range(c):
        S[hashed[j], j] = 2*rng.randint(2) - 1

    return sparse.csr_matrix(S)

def alternating_minimization(left, right, update_left, update_right,
                                                        num_updates):
    iterates = [(left, right)]
    for i in range(num_updates):
        left = update_left(right)
        right = update_right(left)
        iterates.append((left, right))

    return iterates

def update_right(colweights, A, U, lmda, t, rng=np.random.RandomState(42)):
    n, d = A.shape
    _, k = U.shape
    V = np.full((k, d), 1.00)
    reg = np.identity(k)*(lmda**(0.5))
    zeros = np.zeros((k, 1))
    S = gen_countsketch(t, n, rng)

    for j in range(d):
        SDU = S @ (colweights[j] @ U)
        SDA = S @ (colweights[j] @ A[:, [j]])

        M = np.block([[SDU], [reg]])
        b = np.block([[SDA], [zeros]])

        V[:,j] = np.linalg.lstsq(M, b, rcond = None)[0].T

    return V

def update_left(rowweights, A, V, lmda, t, rng=np.random.RandomState(42)):
    n, d = A.shape
    k, _ = V.shape
    U = np.full((n, k), 1.00)
    reg = np.identity(k)*(lmda**(0.5))
    zeros = np.zeros((k, 1))
    S = gen_countsketch(d, t, rng)

    for i in range(n):
        VDS = (V @ rowweights[i]) @ S
        ADS = (A[[i], : ] @ rowweights[i]) @ S

        M = np.block([[VDS.T], [reg]])
        b = np.block([[ADS.T], [zeros]])

        U[i,:] = np.linalg.lstsq(M, b, rcond = None)[0].T

    return U


def nosketch_update_right(colweights, A, U, lmda, t):
    n, d = A.shape
    _, k = U.shape
    V = np.full((k, d), 1.00)
    reg = np.identity(k)*(lmda**(0.5))
    zeros = np.zeros((k, 1))

    for j in range(d):
        DU = (colweights[j] @ U)
        DA = (colweights[j] @ A[:, [j]])

        M = np.block([[DU], [reg]])
        b = np.block([[DA], [zeros]])

        V[:,j] = np.linalg.lstsq(M, b, rcond = None)[0].T

    return V

def nosketch_update_left(rowweights, A, V, lmda, t):
    n, d = A.shape
    k, _ = V.shape
    U = np.full((n, k), 1.00)
    reg = np.identity(k)*(lmda**(0.5))
    zeros = np.zeros((k, 1))

    for i in range(n):
        VD = (V @ rowweights[i])
        AD = (A[[i], : ] @ rowweights[i])

        M = np.block([[VD.T], [reg]])
        b = np.block([[AD.T], [zeros]])

        U[i,:] = np.linalg.lstsq(M, b, rcond = None)[0].T

    return U


def altmin(colweights, rowweights, A, t, k, lmda, num_updates, sketch, rng=np.random.RandomState(42)):
    n, d = A.shape
    U = A[:, : k]
    V = A[ : k, : ]

    if(sketch):
        return alternating_minimization(U, V, lambda V: update_left(rowweights, A, V, lmda, t, rng), lambda U: update_right(colweights, A, U, lmda, t, rng), num_updates)
    else:
        return alternating_minimization(U, V, lambda V: nosketch_update_left(rowweights, A, V, lmda, t), lambda U: nosketch_update_right(colweights, A, U, lmda, t), num_updates)

def rwlra(W, A, t, k, lmda, outf, sketch, rng=np.random.RandomState(42)):
    n, d = A.shape
    num_updates = 25

    col_start = time.time()
    colweights = [sparse.csr_matrix(np.diag(W[:, j])) for j in range(d)]
    col_end = time.time()
    rowweights = [sparse.csr_matrix(np.diag(W[i, : ])) for i in range(n)]
    row_end = time.time()

    results = altmin(colweights, rowweights, A, t, k, lmda, num_updates, sketch, rng)
    print(len(results[-1 : ]))
    for (U,V) in results[-1 : ]:
        print("Altmin objective value is ", (np.linalg.norm(W*(U@V - A), "fro")**2) + lmda * (np.linalg.norm(U, "fro")**2) + lmda * (np.linalg.norm(V, "fro"))**2)
        if(sketch):
            print("Used sketching")
        else:
            print("Did not sketch")

def rwlra_getmatrix(W, A, t, k, lmda, sketch, rng=np.random.RandomState(42)):
    n, d = A.shape
    num_updates = 25

    colweights = [sparse.csr_matrix(np.diag(W[:, j])) for j in range(d)]
    rowweights = [sparse.csr_matrix(np.diag(W[i, : ])) for i in range(n)]

    results = altmin(colweights, rowweights, A, t, k, lmda, num_updates, sketch, rng)
    for (U,V) in results[-1 : ]:
        return U @ V


# Our algorithms

def svd_docmp_first(A):
  U, D, V = np.linalg.svd(A)    
  return U[:,0],(np.diag(D)@V)[0,:]

def solve_local(W, X, lp='2'):
  if lp=='2':
    return svd_docmp_first(np.multiply(W, X))

def get_coef(W, X, U, lp='2'):
  if lp=='2':
    numerator = np.dot(np.multiply(X[:, j], W[:, j]), U)
    denominator = np.dot(np.multiply(U, W[:, j]), U)
    if denominator==0:
      return None
    return numerator/denominator

def wlra_iter(W, A, T, lp='2'):
  rows, cols = W.shape
  UT = []
  VT = []
  X = np.copy(A)
  for i in range(T):
    U , V  = svd_docmp_first(np.multiply(W, X))
    UT += [U]
    v_list = []
    for j in range(cols):
      numerator = np.dot(np.multiply(X[:, j], W[:, j]), U)
      denominator = np.dot(np.multiply(U, W[:, j]), U)      
      if (denominator==0):
        coef = 0
      else:
        coef = numerator/denominator
      X[:,j] = X[:,j] - coef*U
      v_list += [coef]
    VT += [v_list]
  return np.transpose(np.array(UT)), np.array(VT)

# Others

def nSVD(A,k):
  U, D, V = np.linalg.svd(A)
  return np.dot(U[:,:k], np.dot(np.diag(D)[:k,:k], V[:k,:]))