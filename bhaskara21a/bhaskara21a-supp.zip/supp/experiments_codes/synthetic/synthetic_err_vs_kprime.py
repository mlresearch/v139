import numpy as np
import scipy
from scipy.stats import ortho_group
from scipy.linalg import block_diag
import pandas as pd
import matplotlib
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
import matplotlib.pyplot as plt
from  data_gen_and_algorithms import *

rng = np.random.RandomState(42)

weights_probs = [([1, 0.1, 0.01], [0.85, 0.1, 0.05]),
                 ([1, 0.1, 0.01], [0.5,0.4,0.1]),
                 ([1, 0.1, 0.01], [0.05,0.1,0.85]),
                 ([0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9], [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1])]

# change kprime

# weights setting 1

weights_set = 0
rows, cols = 500, 500
k = 5
kprime_list = [5, 10, 15, 20, 25, 30, 35, 40, 50, 60]
st = 0.005
max_sing = 10
lmda_for_wdrf = 0.05
sketch_size_wdrf = 100

n_iter = 10

errs_wlra_iter = np.zeros((n_iter, len(kprime_list)))
errs_asvd = np.zeros((n_iter, len(kprime_list)))
errs_awsvd = np.zeros((n_iter, len(kprime_list)))
errs_arwla_sk = np.zeros((n_iter, len(kprime_list)))

snr_avg = []
big_lambda_avg = []

for i in range(n_iter):
  A, _, snr, big_lambda = generate_matrix_fixed_snr(rows, cols, k, st, max_sing, rng)
  W = gen_weights_real(rows, cols, weights_probs[weights_set][0], weights_probs[weights_set][1], rng)
  snr_avg += [snr]
  big_lambda_avg += [big_lambda]
  for j, kprime in enumerate(kprime_list):
    U_,V_ = wlra_iter(W, A, kprime)
    asvd = nSVD(A, kprime)   
    awsvd = nSVD(np.multiply(W,A), kprime)
    # arwla_sk = rwlra_getmatrix(W, A, kprime, k, lmda_for_wdrf, True)
    arwla_sk = rwlra_getmatrix(W, A, sketch_size_wdrf, kprime, lmda_for_wdrf, True)
    err_wlra_iter = np.linalg.norm(np.multiply(np.sqrt(W), A - np.dot(U_, V_)), ord='fro')/np.linalg.norm(A, ord='fro')   
    err_asvd = np.linalg.norm(np.multiply(np.sqrt(W), A - asvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_awsvd = np.linalg.norm(np.multiply(np.sqrt(W), A - awsvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_arwla_sk = np.linalg.norm(np.multiply(np.sqrt(W), A - arwla_sk), ord='fro')/np.linalg.norm(A, ord='fro')
    errs_wlra_iter[i, j] = err_wlra_iter
    errs_asvd[i, j] = err_asvd
    errs_awsvd[i, j] = err_awsvd
    errs_arwla_sk[i, j] = err_arwla_sk
  print('iteration: ', i, ' done.')

snr_mean = np.mean(snr_avg)
big_lambda_mean = np.mean(big_lambda_avg)
snr_std = np.std(snr_avg)
big_lambda_std = np.std(big_lambda_avg)

errs_wlra_iter_mean = np.mean(errs_wlra_iter, axis=0)
errs_asvd_mean = np.mean(errs_asvd, axis=0)
errs_awsvd_mean = np.mean(errs_awsvd, axis=0)
errs_arwla_sk_mean = np.mean(errs_arwla_sk, axis=0)
errs_wlra_iter_std = np.std(errs_wlra_iter, axis=0)
errs_asvd_std = np.std(errs_asvd, axis=0)
errs_awsvd_std = np.std(errs_awsvd, axis=0)
errs_arwla_sk_std = np.std(errs_arwla_sk, axis=0)

print('snr: ', snr_mean, snr_std)
print('big_lambda: ', big_lambda_mean, big_lambda_std)

print('err means:')
print(errs_wlra_iter_mean)
print(errs_asvd_mean)
print(errs_awsvd_mean)
print(errs_arwla_sk_mean)
print('err stds:')
print(errs_wlra_iter_std)
print(errs_asvd_std)
print(errs_awsvd_std)
print(errs_arwla_sk_std)


# change kprime

# weights setting 2

weights_set = 2
rows, cols = 500, 500
k = 5
kprime_list = [5, 10, 15, 20, 25, 30, 35, 40, 50, 60]
st = 0.005
max_sing = 10
lmda_for_wdrf = 0.01
sketch_size_wdrf = 100

n_iter = 10

errs_wlra_iter = np.zeros((n_iter, len(kprime_list)))
errs_asvd = np.zeros((n_iter, len(kprime_list)))
errs_awsvd = np.zeros((n_iter, len(kprime_list)))
errs_arwla_sk = np.zeros((n_iter, len(kprime_list)))

for i in range(n_iter):
  A, _, _, _ = generate_matrix_fixed_snr(rows, cols, k, st, max_sing, rng)
  W = gen_weights_real(rows, cols, weights_probs[weights_set][0], weights_probs[weights_set][1], rng)
  for j, kprime in enumerate(kprime_list):
    U_,V_ = wlra_iter(W, A, kprime)
    asvd = nSVD(A, kprime)   
    awsvd = nSVD(np.multiply(W,A), kprime)
    # arwla_sk = rwlra_getmatrix(W, A, kprime, k, lmda_for_wdrf, True)
    arwla_sk = rwlra_getmatrix(W, A, sketch_size_wdrf, kprime, lmda_for_wdrf, True)
    err_wlra_iter = np.linalg.norm(np.multiply(np.sqrt(W), A - np.dot(U_, V_)), ord='fro')/np.linalg.norm(A, ord='fro')     
    err_asvd = np.linalg.norm(np.multiply(np.sqrt(W), A - asvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_awsvd = np.linalg.norm(np.multiply(np.sqrt(W), A - awsvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_arwla_sk = np.linalg.norm(np.multiply(np.sqrt(W), A - arwla_sk), ord='fro')/np.linalg.norm(A, ord='fro')
    errs_wlra_iter[i, j] = err_wlra_iter
    errs_asvd[i, j] = err_asvd
    errs_awsvd[i, j] = err_awsvd
    errs_arwla_sk[i, j] = err_arwla_sk
  print('iteration: ', i, ' done.')

errs_wlra_iter_mean = np.mean(errs_wlra_iter, axis=0)
errs_asvd_mean = np.mean(errs_asvd, axis=0)
errs_awsvd_mean = np.mean(errs_awsvd, axis=0)
errs_arwla_sk_mean = np.mean(errs_arwla_sk, axis=0)
errs_wlra_iter_std = np.std(errs_wlra_iter, axis=0)
errs_asvd_std = np.std(errs_asvd, axis=0)
errs_awsvd_std = np.std(errs_awsvd, axis=0)
errs_arwla_sk_std = np.std(errs_arwla_sk, axis=0)

print('err means:')
print(errs_wlra_iter_mean)
print(errs_asvd_mean)
print(errs_awsvd_mean)
print(errs_arwla_sk_mean)
print('err stds:')
print(errs_wlra_iter_std)
print(errs_asvd_std)
print(errs_awsvd_std)
print(errs_arwla_sk_std)


# change kprime

# weights setting 3

weights_set = 3
rows, cols = 500, 500
k = 5
kprime_list = [5, 10, 15, 20, 25, 30, 35, 40, 50, 60]
st = 0.005
max_sing = 10
lmda_for_wdrf = 0.01
sketch_size_wdrf = 100

n_iter = 10

errs_wlra_iter = np.zeros((n_iter, len(kprime_list)))
errs_asvd = np.zeros((n_iter, len(kprime_list)))
errs_awsvd = np.zeros((n_iter, len(kprime_list)))
errs_arwla_sk = np.zeros((n_iter, len(kprime_list)))

for i in range(n_iter):
  A, _, _, _ = generate_matrix_fixed_snr(rows, cols, k, st, max_sing, rng)
  W = gen_weights_uniform(rows, cols, rng)
  for j, kprime in enumerate(kprime_list):
    U_,V_ = wlra_iter(W, A, kprime)
    asvd = nSVD(A, kprime)   
    awsvd = nSVD(np.multiply(W,A), kprime)
    # arwla_sk = rwlra_getmatrix(W, A, kprime, k, lmda_for_wdrf, True)
    arwla_sk = rwlra_getmatrix(W, A, sketch_size_wdrf, kprime, lmda_for_wdrf, True)
    err_wlra_iter = np.linalg.norm(np.multiply(np.sqrt(W), A - np.dot(U_, V_)), ord='fro')/np.linalg.norm(A, ord='fro')     
    err_asvd = np.linalg.norm(np.multiply(np.sqrt(W), A - asvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_awsvd = np.linalg.norm(np.multiply(np.sqrt(W), A - awsvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_arwla_sk = np.linalg.norm(np.multiply(np.sqrt(W), A - arwla_sk), ord='fro')/np.linalg.norm(A, ord='fro')
    errs_wlra_iter[i, j] = err_wlra_iter
    errs_asvd[i, j] = err_asvd
    errs_awsvd[i, j] = err_awsvd
    errs_arwla_sk[i, j] = err_arwla_sk
  print('iteration: ', i, ' done.')

errs_wlra_iter_mean = np.mean(errs_wlra_iter, axis=0)
errs_asvd_mean = np.mean(errs_asvd, axis=0)
errs_awsvd_mean = np.mean(errs_awsvd, axis=0)
errs_arwla_sk_mean = np.mean(errs_arwla_sk, axis=0)
errs_wlra_iter_std = np.std(errs_wlra_iter, axis=0)
errs_asvd_std = np.std(errs_asvd, axis=0)
errs_awsvd_std = np.std(errs_awsvd, axis=0)
errs_arwla_sk_std = np.std(errs_arwla_sk, axis=0)

print('err means:')
print(errs_wlra_iter_mean)
print(errs_asvd_mean)
print(errs_awsvd_mean)
print(errs_arwla_sk_mean)
print('err stds:')
print(errs_wlra_iter_std)
print(errs_asvd_std)
print(errs_awsvd_std)
print(errs_arwla_sk_std)


# change kprime

# weights setting 4

p = 0.7
rows, cols = 500, 500
k = 5
kprime_list = [5, 10, 15, 20, 25, 30, 35, 40, 50, 60]
st = 0.005
max_sing = 10
lmda_for_wdrf = 0.05
sketch_size_wdrf = 100

n_iter = 10

errs_wlra_iter = np.zeros((n_iter, len(kprime_list)))
errs_asvd = np.zeros((n_iter, len(kprime_list)))
errs_awsvd = np.zeros((n_iter, len(kprime_list)))
errs_arwla_sk = np.zeros((n_iter, len(kprime_list)))

for i in range(n_iter):
  A, _, _, _ = generate_matrix_fixed_snr(rows, cols, k, st, max_sing, rng)
  W = gen_weights_masked_with_p(rows, cols, p, rng)
  for j, kprime in enumerate(kprime_list):
    U_,V_ = wlra_iter(W, A, kprime)
    asvd = nSVD(A, kprime)   
    awsvd = nSVD(np.multiply(W,A), kprime)
    # arwla_sk = rwlra_getmatrix(W, A, kprime, k, lmda_for_wdrf, True)
    arwla_sk = rwlra_getmatrix(W, A, sketch_size_wdrf, kprime, lmda_for_wdrf, True)
    err_wlra_iter = np.linalg.norm(np.multiply(np.sqrt(W), A - np.dot(U_, V_)), ord='fro')/np.linalg.norm(A, ord='fro')     
    err_asvd = np.linalg.norm(np.multiply(np.sqrt(W), A - asvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_awsvd = np.linalg.norm(np.multiply(np.sqrt(W), A - awsvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_arwla_sk = np.linalg.norm(np.multiply(np.sqrt(W), A - arwla_sk), ord='fro')/np.linalg.norm(A, ord='fro')
    errs_wlra_iter[i, j] = err_wlra_iter
    errs_asvd[i, j] = err_asvd
    errs_awsvd[i, j] = err_awsvd
    errs_arwla_sk[i, j] = err_arwla_sk
  print('iteration: ', i, ' done.')

errs_wlra_iter_mean = np.mean(errs_wlra_iter, axis=0)
errs_asvd_mean = np.mean(errs_asvd, axis=0)
errs_awsvd_mean = np.mean(errs_awsvd, axis=0)
errs_arwla_sk_mean = np.mean(errs_arwla_sk, axis=0)
errs_wlra_iter_std = np.std(errs_wlra_iter, axis=0)
errs_asvd_std = np.std(errs_asvd, axis=0)
errs_awsvd_std = np.std(errs_awsvd, axis=0)
errs_arwla_sk_std = np.std(errs_arwla_sk, axis=0)

print('err means:')
print(errs_wlra_iter_mean)
print(errs_asvd_mean)
print(errs_awsvd_mean)
print(errs_arwla_sk_mean)
print('err stds:')
print(errs_wlra_iter_std)
print(errs_asvd_std)
print(errs_awsvd_std)
print(errs_arwla_sk_std)


# change kprime

# weights setting 5

t = 50000
rows, cols = 500, 500
k = 5
kprime_list = [5, 10, 15, 20, 25, 30, 35, 40, 50, 60]
st = 0.005
max_sing = 10
lmda_for_wdrf = 0.05
sketch_size_wdrf = 100

n_iter = 10

errs_wlra_iter = np.zeros((n_iter, len(kprime_list)))
errs_asvd = np.zeros((n_iter, len(kprime_list)))
errs_awsvd = np.zeros((n_iter, len(kprime_list)))
errs_arwla_sk = np.zeros((n_iter, len(kprime_list)))

for i in range(n_iter):
  A, _, _, _ = generate_matrix_fixed_snr(rows, cols, k, st, max_sing, rng)
  W = gen_weights_cancel_largest_t(A, t)
  for j, kprime in enumerate(kprime_list):
    U_,V_ = wlra_iter(W, A, kprime)
    asvd = nSVD(A, kprime)   
    awsvd = nSVD(np.multiply(W,A), kprime)
    # arwla_sk = rwlra_getmatrix(W, A, kprime, k, lmda_for_wdrf, True)
    arwla_sk = rwlra_getmatrix(W, A, sketch_size_wdrf, kprime, lmda_for_wdrf, True)
    err_wlra_iter = np.linalg.norm(np.multiply(np.sqrt(W), A - np.dot(U_, V_)), ord='fro')/np.linalg.norm(A, ord='fro')     
    err_asvd = np.linalg.norm(np.multiply(np.sqrt(W), A - asvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_awsvd = np.linalg.norm(np.multiply(np.sqrt(W), A - awsvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_arwla_sk = np.linalg.norm(np.multiply(np.sqrt(W), A - arwla_sk), ord='fro')/np.linalg.norm(A, ord='fro')
    errs_wlra_iter[i, j] = err_wlra_iter
    errs_asvd[i, j] = err_asvd
    errs_awsvd[i, j] = err_awsvd
    errs_arwla_sk[i, j] = err_arwla_sk
  print('iteration: ', i, ' done.')

errs_wlra_iter_mean = np.mean(errs_wlra_iter, axis=0)
errs_asvd_mean = np.mean(errs_asvd, axis=0)
errs_awsvd_mean = np.mean(errs_awsvd, axis=0)
errs_arwla_sk_mean = np.mean(errs_arwla_sk, axis=0)
errs_wlra_iter_std = np.std(errs_wlra_iter, axis=0)
errs_asvd_std = np.std(errs_asvd, axis=0)
errs_awsvd_std = np.std(errs_awsvd, axis=0)
errs_arwla_sk_std = np.std(errs_arwla_sk, axis=0)

print('err means:')
print(errs_wlra_iter_mean)
print(errs_asvd_mean)
print(errs_awsvd_mean)
print(errs_arwla_sk_mean)
print('err stds:')
print(errs_wlra_iter_std)
print(errs_asvd_std)
print(errs_awsvd_std)
print(errs_arwla_sk_std)


# change kprime

# weights setting 6

t = 100
rows, cols = 500, 500
k = 5
kprime_list = [5, 10, 15, 20, 25, 30, 35, 40, 50, 60]
st = 0.005
max_sing = 10
lmda_for_wdrf = 0.05
sketch_size_wdrf = 100

n_iter = 10

errs_wlra_iter = np.zeros((n_iter, len(kprime_list)))
errs_asvd = np.zeros((n_iter, len(kprime_list)))
errs_awsvd = np.zeros((n_iter, len(kprime_list)))
errs_arwla_sk = np.zeros((n_iter, len(kprime_list)))

for i in range(n_iter):
  A, _, _, _ = generate_matrix_fixed_snr(rows, cols, k, st, max_sing, rng)
  W = gen_weights_cancel_blcok_diag(rows, cols, t)
  for j, kprime in enumerate(kprime_list):
    U_,V_ = wlra_iter(W, A, kprime)
    asvd = nSVD(A, kprime)   
    awsvd = nSVD(np.multiply(W,A), kprime)
    # arwla_sk = rwlra_getmatrix(W, A, kprime, k, lmda_for_wdrf, True)
    arwla_sk = rwlra_getmatrix(W, A, sketch_size_wdrf, kprime, lmda_for_wdrf, True)
    err_wlra_iter = np.linalg.norm(np.multiply(np.sqrt(W), A - np.dot(U_, V_)), ord='fro')/np.linalg.norm(A, ord='fro')     
    err_asvd = np.linalg.norm(np.multiply(np.sqrt(W), A - asvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_awsvd = np.linalg.norm(np.multiply(np.sqrt(W), A - awsvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_arwla_sk = np.linalg.norm(np.multiply(np.sqrt(W), A - arwla_sk), ord='fro')/np.linalg.norm(A, ord='fro')
    errs_wlra_iter[i, j] = err_wlra_iter
    errs_asvd[i, j] = err_asvd
    errs_awsvd[i, j] = err_awsvd
    errs_arwla_sk[i, j] = err_arwla_sk
  print('iteration: ', i, ' done.')

errs_wlra_iter_mean = np.mean(errs_wlra_iter, axis=0)
errs_asvd_mean = np.mean(errs_asvd, axis=0)
errs_awsvd_mean = np.mean(errs_awsvd, axis=0)
errs_arwla_sk_mean = np.mean(errs_arwla_sk, axis=0)
errs_wlra_iter_std = np.std(errs_wlra_iter, axis=0)
errs_asvd_std = np.std(errs_asvd, axis=0)
errs_awsvd_std = np.std(errs_awsvd, axis=0)
errs_arwla_sk_std = np.std(errs_arwla_sk, axis=0)

print('err means:')
print(errs_wlra_iter_mean)
print(errs_asvd_mean)
print(errs_awsvd_mean)
print(errs_arwla_sk_mean)
print('err stds:')
print(errs_wlra_iter_std)
print(errs_asvd_std)
print(errs_awsvd_std)
print(errs_arwla_sk_std)


# change kprime

# weights setting 7

rows, cols = 500, 500
k = 5
kprime_list = [5, 10, 15, 20, 25, 30, 35, 40, 50, 60]
st = 0.005
max_sing = 10
lmda_for_wdrf = 0.01
sketch_size_wdrf = 100

n_iter = 10

sings = output_sings_only(k, max_sing)
f_norm = np.sum(np.power(sings, 2))
noise_norm = rows*cols*np.power(st, 2)
snr_list = np.divide(f_norm, noise_norm)
print(snr_list)

errs_wlra_iter = np.zeros((n_iter, len(kprime_list)))
errs_asvd = np.zeros((n_iter, len(kprime_list)))
errs_awsvd = np.zeros((n_iter, len(kprime_list)))
errs_arwla_sk = np.zeros((n_iter, len(kprime_list)))

for i in range(n_iter):
  A, _, _, _ = generate_matrix_fixed_snr(rows, cols, k, st, max_sing, rng)
  W = gen_weights_semi_rand(rows, cols, 0.3, 0.2, 0.1, rng)
  for j, kprime in enumerate(kprime_list):
    U_,V_ = wlra_iter(W, A, kprime)
    asvd = nSVD(A, kprime)   
    awsvd = nSVD(np.multiply(W,A), kprime)
    # arwla_sk = rwlra_getmatrix(W, A, kprime, k, lmda_for_wdrf, True)
    arwla_sk = rwlra_getmatrix(W, A, sketch_size_wdrf, kprime, lmda_for_wdrf, True)
    err_wlra_iter = np.linalg.norm(np.multiply(np.sqrt(W), A - np.dot(U_, V_)), ord='fro')/np.linalg.norm(A, ord='fro')     
    err_asvd = np.linalg.norm(np.multiply(np.sqrt(W), A - asvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_awsvd = np.linalg.norm(np.multiply(np.sqrt(W), A - awsvd), ord='fro')/np.linalg.norm(A, ord='fro')    
    err_arwla_sk = np.linalg.norm(np.multiply(np.sqrt(W), A - arwla_sk), ord='fro')/np.linalg.norm(A, ord='fro')
    errs_wlra_iter[i, j] = err_wlra_iter
    errs_asvd[i, j] = err_asvd
    errs_awsvd[i, j] = err_awsvd
    errs_arwla_sk[i, j] = err_arwla_sk
  print('iteration: ', i, ' done.')

errs_wlra_iter_mean = np.mean(errs_wlra_iter, axis=0)
errs_asvd_mean = np.mean(errs_asvd, axis=0)
errs_awsvd_mean = np.mean(errs_awsvd, axis=0)
errs_arwla_sk_mean = np.mean(errs_arwla_sk, axis=0)
errs_wlra_iter_std = np.std(errs_wlra_iter, axis=0)
errs_asvd_std = np.std(errs_asvd, axis=0)
errs_awsvd_std = np.std(errs_awsvd, axis=0)
errs_arwla_sk_std = np.std(errs_arwla_sk, axis=0)

print('err means:')
print(errs_wlra_iter_mean)
print(errs_asvd_mean)
print(errs_awsvd_mean)
print(errs_arwla_sk_mean)
print('err stds:')
print(errs_wlra_iter_std)
print(errs_asvd_std)
print(errs_awsvd_std)
print(errs_arwla_sk_std)