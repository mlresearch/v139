Requirements:
	Python 3
	Numpy
	Scipy
	Sckit-learn
	Pandas

Synthetic dataset experiments:
	synthetic_err_vs_kprime.py
	synthetic_err_vs_snr.py

Real dataset experiments in real directory:
	real_data_1.py (NIPS Conference Papers 1987-2015 Dataset)
	real_data_2.py (Landmark Dataset)
	real_data_3.py (Symmetric Stiffness Matrix, Frame Building Dataset)
	real_data_4.py (Blog Feedback DataSet)


Please download the following datasets into the real directory to run real dataset experiments:
	https://archive.ics.uci.edu/ml/datasets/NIPS+Conference+Papers+1987-2015
	https://sparse.tamu.edu/Pereyra/landmark
	https://sparse.tamu.edu/HB/bcsstk08
	https://archive.ics.uci.edu/ml/datasets/BlogFeedback
	

To run an experiment, run the command:
	python [filename.py]