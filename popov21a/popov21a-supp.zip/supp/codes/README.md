# Grad-TTS

Grad-TTS model with SDE diffusion based on U-Net.

## Installation

Firstly, install all Python package requirements:

```bash
pip install -r requirements.txt
```

Secondly, build `monotonic_align` code (Cython):

```bash
cd model/monotonic_align; python setup.py build_ext --inplace; cd ../..
```

Note: code is tested on Python==3.6.9.

## Inference

You can download Grad-TTS and HiFi-GAN checkpoints from the following link: https://drive.google.com/drive/folders/1grsfccJbmEuSBGQExQKr3cVxNV0xEOZ7?usp=sharing. Put them into `checkpts` folder.

1. Create text file with sentences you want to synthesize like `filelists/synthesis.txt`.
2. Run script `inference.py` by providing path to the text file, path to the Grad-TTS checkpoint and number of iterations to be used for reverse diffusion (default: 10):
    ```bash
    python inference.py -f <your-text-file> -c checkpts/grad-tts.pt -t <number-of-timesteps>
    ```
3. Check out folder called `out` for generated files.

You can also perform interactive inference by running Jupyter Notebook `inference.ipynb`.

## Training

1. Make filelists of your audio data like ones included into `filelists` folder. Note, that you need to extract mel-spectrograms and save them on disk as `numpy` files.
2. Set experiment configuration in `params.py` file.
3. Run training script:
    ```bash
    python train.py
    ```
4. To track your training process run tensorboard server on any available port:
    ```bash
    tensorboard --logdir=YOUR_LOG_DIR --port=8888
    ```
    During training all logging information and checkpoints are stored in `YOUR_LOG_DIR`, which you can specify in `params.py` before training.
