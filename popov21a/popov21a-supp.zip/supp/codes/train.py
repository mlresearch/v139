import numpy as np
from tqdm import tqdm

import torch
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

import params
from model import GradTTS
from data import TextMelDataset, TextMelBatchCollate
from utils import plot_tensor, save_plot
from text.symbols import symbols


train_filelist_path = params.train_filelist_path
valid_filelist_path = params.valid_filelist_path
cmudict_path = params.cmudict_path
add_blank = params.add_blank

log_dir = params.log_dir
n_epochs = params.n_epochs
batch_size = params.batch_size
out_size = params.out_size
learning_rate = params.learning_rate
random_seed = params.seed

nsymbols = len(symbols) + 1 if add_blank else len(symbols)
n_enc_channels = params.n_enc_channels
filter_channels = params.filter_channels
filter_channels_dp = params.filter_channels_dp
n_enc_layers = params.n_enc_layers
enc_kernel = params.enc_kernel
enc_dropout = params.enc_dropout
n_heads = params.n_heads
window_size = params.window_size

n_feats = params.n_feats

dec_dim = params.dec_dim
beta_min = params.beta_min
beta_max = params.beta_max


if __name__ == "__main__":
    torch.manual_seed(random_seed)
    np.random.seed(random_seed)

    print('Initializing logger...')
    logger = SummaryWriter(log_dir=log_dir)

    print('Initializing data loaders...')
    train_dataset = TextMelDataset(train_filelist_path, cmudict_path, add_blank)
    batch_collate = TextMelBatchCollate()
    loader = DataLoader(dataset=train_dataset, batch_size=batch_size,
                        collate_fn=batch_collate, drop_last=True,
                        num_workers=4, shuffle=False)
    test_dataset = TextMelDataset(valid_filelist_path, cmudict_path, add_blank)

    print('Initializing model...')
    model = GradTTS(nsymbols, n_enc_channels, filter_channels, filter_channels_dp, 
                    n_heads, n_enc_layers, enc_kernel, enc_dropout, window_size, 
                    n_feats, dec_dim, beta_min, beta_max).cuda()
    print('Encoder + aligner:')
    print(model.encoder)
    print('Number of encoder parameters = %.2fm\n' % (model.encoder.nparams/1e6))

    print('Decoder:')
    print(model.decoder)
    print('Number of decoder parameters = %.2fm\n' % (model.decoder.nparams/1e6))

    print('Initializing optimizer...')
    optimizer = torch.optim.Adam(params=model.parameters(), lr=learning_rate)

    print('Logging test batch...')
    test_batch = test_dataset.sample_test_batch(size=params.test_size)
    for i, item in enumerate(test_batch):
        mel = item['y']
        logger.add_image(f'image_{i}/ground_truth', plot_tensor(mel.squeeze()),
                         global_step=0, dataformats='HWC')
        save_plot(mel.squeeze(), f'{log_dir}/original_{i}.png')

    print('Start training...')
    iteration = 0
    for epoch in range(1, n_epochs + 1):
        print(f'Epoch: {epoch} [iteration: {iteration}]')
        model.train()
        dur_losses = []
        prior_losses = []
        diff_losses = []
        for batch in tqdm(loader, total=len(train_dataset)//batch_size):
            model.zero_grad()
            x, x_lengths = batch['x'].cuda(), batch['x_lengths'].cuda()
            y, y_lengths = batch['y'].cuda(), batch['y_lengths'].cuda()
            dur_loss, prior_loss, diff_loss = model.compute_loss(x, x_lengths, 
                                                                 y, y_lengths,
                                                                 out_size=out_size)
            loss = sum([dur_loss, prior_loss, diff_loss])
            loss.backward()

            enc_grad_norm = torch.nn.utils.clip_grad_norm_(model.encoder.parameters(), 
                                                           max_norm=1)
            dec_grad_norm = torch.nn.utils.clip_grad_norm_(model.decoder.parameters(), 
                                                           max_norm=1)
            optimizer.step()

            logger.add_scalar('training/duration_loss', dur_loss.item(), 
                              global_step=iteration)
            logger.add_scalar('training/prior_loss', prior_loss.item(), 
                              global_step=iteration)
            logger.add_scalar('training/diffusion_loss', diff_loss.item(), 
                              global_step=iteration)
            logger.add_scalar('training/encoder_grad_norm', enc_grad_norm, 
                              global_step=iteration)
            logger.add_scalar('training/decoder_grad_norm', dec_grad_norm, 
                              global_step=iteration)
            dur_losses.append(dur_loss.item())
            prior_losses.append(prior_loss.item())
            diff_losses.append(diff_loss.item())
            iteration += 1

        msg = 'Epoch %d: duration loss = %.3f ' % (epoch, np.mean(dur_losses))
        msg += '| prior loss = %.3f ' % np.mean(prior_losses)
        msg += '| diffusion loss = %.3f\n' % np.mean(diff_losses)
        print(msg)
        with open(f'{log_dir}/train.log', 'a') as f:
            f.write(msg)

        if epoch % params.save_every > 0:
            continue

        model.eval()
        print('Synthesis...\n')
        with torch.no_grad():
            for i, item in enumerate(test_batch):
                x = item['x'].to(torch.long).unsqueeze(0).cuda()
                x_lengths = torch.LongTensor([x.shape[-1]]).cuda()
                y_enc, y_dec, attn = model(x, x_lengths, n_timesteps=1000)
                logger.add_image(f'image_{i}/generated_enc',
                                 plot_tensor(y_enc.squeeze().cpu()),
                                 global_step=iteration, dataformats='HWC')
                logger.add_image(f'image_{i}/generated_dec',
                                 plot_tensor(y_dec.squeeze().cpu()),
                                 global_step=iteration, dataformats='HWC')
                logger.add_image(f'image_{i}/alignment',
                                 plot_tensor(attn.squeeze().cpu()),
                                 global_step=iteration, dataformats='HWC')
                save_plot(y_enc.squeeze().cpu(), 
                          f'{log_dir}/generated_enc_{i}.png')
                save_plot(y_dec.squeeze().cpu(), 
                          f'{log_dir}/generated_dec_{i}.png')
                save_plot(attn.squeeze().cpu(), 
                          f'{log_dir}/alignment_{i}.png')

        ckpt = model.state_dict()
        torch.save(ckpt, f=f"{log_dir}/grad_{epoch}.pt")
