#!/bin/bash

DIR="$( cd "$( dirname "${BASH_SOURCE[ 0]}" )" && pwd )"

export PYTHONPATH=$PYTHONPATH:$DIR:$DIR/external_lib/spinningup/
export LOF_PKG_PATH=$DIR
export TUNE_RESULT_DIR=$DIR/experiments/
