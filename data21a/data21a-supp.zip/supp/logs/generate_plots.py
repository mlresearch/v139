import numpy as np
import matplotlib
import matplotlib.pyplot as plt

num_runs = 5

train_flag = 2 # 1 for train_loss, 2 for test_accu

#uncomment the first algo_names below when generating figures (both test and training) for the BaruchAttack, (attack_index = 5)

#uncomment the second algo_names below when generating figures for test (all the attacks except for BaruchAttack (attack_index = 5)) and training (only for revAttack_avg_withoutScaling attack (attack_index = 4))

#uncomment the third algo_names below when generating figures for training (for all the attacks except for revAttack_avg_withoutScaling attack (attack_index = 4) and BaruchAttack (attack_index = 5))

#algo_names = ['', 'byz_RME_', 'byz_TrimMean_', 'byz_Median_', 'byz_Krum_', 'byz_Bulyan_']

algo_names = ['', 'byz_RME_', 'byz_TrimMean_', 'byz_Median_', 'byz_Krum_']

#algo_names = ['', 'byz_RME_', 'byz_TrimMean_', 'byz_Median_']

num_algos = len(algo_names)

attack_names = ['allonesAttack','gradientShiftAttack','randomLocalGradient','revAttack_avg_withScaling','revAttack_avg_withoutScaling','BaruchAttack']

attack_index = 5 # attack_index takes values in {0,1,2,3,4,5}.
# 0 is for allonesAttack
# 1 is for gradientShiftAttack
# 2 is for randomLocalGradient
# 3 is for revAttack_avg_withScaling
# 4 is for revAttack_avg_withoutScaling
# 5 is for BaruchAttack

num_attacks = len(attack_names)

file_suffix = ""
y_label = ""
if train_flag == 1:
    file_suffix = "_train_loss"
    y_label = "Training Loss"
else:
    file_suffix = "_test_accu"
    y_label = "Test Accuracy"


input_files_dict = {}
output_files_dict = {}

for i in range(num_algos):
    input_files_dict[algo_names[i]] = [None] * num_runs


middle_text = "FL_W200_Adv25_"

for algo_index in range(num_algos):
    output_files_dict[algo_names[algo_index]] = algo_names[algo_index] + middle_text + attack_names[attack_index] + "_avg-run" + file_suffix + ".txt"
    for run in range(num_runs):
        input_files_dict[algo_names[algo_index]][run] = algo_names[algo_index] + middle_text + attack_names[attack_index] + "_run" + str(int(run+1)) + file_suffix + ".txt"

output_figure_file = "W200_Adv25_" + attack_names[attack_index] + "_avg-run"+ file_suffix + ".png"

f_dict = {}
for algo_index in range(num_algos):
    f_inner = []
    for run_index in range(num_runs):
        fl = open(attack_names[attack_index]+"/"+input_files_dict[algo_names[algo_index]][run_index])
        f_inner.append(fl.readlines())
        fl.close()
    f_dict[algo_names[algo_index]] = f_inner

no_lines_each_file = 40 #len(f_dict[algo_names[0]][0])

avg_numbers_dict = {}
for algo_index in range(num_algos):
    avg_numbers_dict[algo_names[algo_index]] = np.zeros(no_lines_each_file)
    for j in range(no_lines_each_file):
        for i in range(num_runs):
            avg_numbers_dict[algo_names[algo_index]][j] += float(f_dict[algo_names[algo_index]][i][j])
        avg_numbers_dict[algo_names[algo_index]][j] = avg_numbers_dict[algo_names[algo_index]][j]/num_runs

avg_file_dict = {}
for algo_index in range(num_algos):
    with open("average_runs_files/"+output_files_dict[algo_names[algo_index]],"w") as avg_file:
        for j in range(no_lines_each_file):
            avg_file.write(str(avg_numbers_dict[algo_names[algo_index]][j])+"\n")
        avg_file.close()

legend_names = [None] * num_algos
for i in range(num_algos):
    legend_names[i] = "SGD_" + algo_names[i] + "7L"
legend_names[0] = "SGD_NoByz_7L"
plot_colors = ["-b", "-r", "-k", "-g", "-m", "-c"]
arr = np.zeros(no_lines_each_file)

plt.figure()
for i in range(num_algos):
    for j in range(no_lines_each_file):
        arr[j] = avg_numbers_dict[algo_names[i]][j]
    plt.plot(range(1,no_lines_each_file+1),arr,plot_colors[i],label=legend_names[i])
plt.grid(linestyle = "--")
plt.xlabel("Num of Epochs",fontsize=13)
plt.ylabel(y_label,fontsize=13)
plt.legend(prop={"size":13})
plt.savefig(output_figure_file)

