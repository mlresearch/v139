# Copyright note: If anyone uses any part of the code or takes it and modifies it, then they should     acknowledge the source. 

import numpy as np
from numpy import linalg as LA
import scipy.stats as st
#from scipy.linalg import null_space
from numpy.linalg import matrix_rank
from sympy import *
import math
import matplotlib
import matplotlib.pyplot as plt
import copy
import random
import time
import sys
import argparse
import mnist

# Load MNIST data
mndata = mnist.MNIST('data')
X_train, Y_train = mndata.load_training()
X_test, Y_test = mndata.load_testing() 

X_train = np.asarray(X_train)/255
X_test = np.asarray(X_test)/255

X_train = np.asarray(X_train)
X_test = np.asarray(X_test)

Y_train = np.asarray(Y_train)
Y_test = np.asarray(Y_test)


num_train = np.shape(X_train)[0]
num_features = np.shape(X_train)[1]
num_test = np.shape(X_test)[0]
num_classes = len(set(Y_train))

het_dist = [0.8, 0.1, 0.1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0] 

# Global parameters
num_hidden = 25
num_epochs = 40
num_workers = 200
num_sample_worker = 1000 #this is the number of samples per worker/client
num_test_workers = 1 
num_sample_worker_test = int(num_test/num_test_workers)
batch_size = 128 
num_batch = int(num_sample_worker/batch_size) # We will perform H = num_batch local iterations
lr = 0.08
decay_factor = 0.96 

num_workers_sampled = int(num_workers)
num_adv = int(num_workers_sampled/8)
scaling_factor = 50 # this will be used in some of the attacks

run_index = 1 #run_index takes values in {1,2,3,4,5}, which means we take average over 5 runs

attack_index = 2 # It takes values in {0,1,2,3,4,5}. 
attack_name = ['allonesAttack','gradientShiftAttack','randomLocalGradient','revAttack_avg_withScaling','revAttack_avg_withoutScaling','BaruchAttack']
# 0 is for allonesAttack
# 1 is for gradientShiftAttack
# 2 is for randomLocalGradient
# 3 is for revAttack_avg_withScaling
# 4 is for revAttack_avg_withoutScaling
# 5 is for BaruchAttack


# # # Non-iid data on workers
def nonuniformSampling():
    dataset_label_train = []
    train_datasets = []
    test_datasets = []
    for i in range(num_classes):
        idx_train = np.where(Y_train==i)[0]
        X_idx_train = X_train[idx_train,:]
        Y_idx_train = np.array(Y_train)[idx_train.astype(int)]
        dataset_label_train.append([X_idx_train,Y_idx_train])

    for i in range(num_workers):
        random.shuffle(het_dist) 
        sample_sizes_train = [int(k * num_sample_worker) for k in het_dist] # Sample sizes per label
        for j,x in enumerate(sample_sizes_train):
            random_indices = random.sample( range(dataset_label_train[j][0].shape[0]) , int(x) )
            x1_temp = dataset_label_train[j][0][random_indices]
            y1_temp = dataset_label_train[j][1][random_indices]
            if j==0:
                x1 = x1_temp
                y1 = y1_temp
            else:                
                x1 = np.vstack((x1,x1_temp))
                y1 = np.hstack((y1,y1_temp))   
        s = np.arange(np.shape(x1)[0])
        np.random.shuffle(s)          
        x1 = np.array(x1)[s.astype(int)]
        y1 = np.array(y1)[s.astype(int)]               
        train_datasets.append([x1,y1])   
    
    s_test = np.arange(num_test)
    np.random.shuffle(s_test)
    X_test_s = np.array(X_test)[s_test.astype(int)]
    Y_test_s = np.array(Y_test)[s_test.astype(int)]
    
    test_datasets.append([X_test, Y_test])
    
    return train_datasets, test_datasets



def initialize(num_inputs,num_classes,num_hidden):
    """initialize the parameters"""
    params = { #parameters when no adversary and no decoding
        "W1": np.random.randn(num_hidden, num_inputs) * np.sqrt(1. / num_inputs),
        "b1": np.zeros((num_hidden, 1)) * np.sqrt(1. / num_inputs),
        "W2": np.random.randn(num_classes, num_hidden) * np.sqrt(1. / num_hidden),
        "b2": np.zeros((num_classes, 1)) * np.sqrt(1. / num_hidden)
    }
    byz_params = copy.deepcopy(params) #parameters for byz_RME (our method)
    byz_trimmean_params = copy.deepcopy(params) 
    byz_median_params = copy.deepcopy(params)
    byz_krum_params = copy.deepcopy(params)
    
    return params, byz_params, byz_trimmean_params, byz_median_params, byz_krum_params 


def ReLU(z):
    """
    ReLU activation function.
    inputs: z
    outputs: max(z,0)
    """
    r = z.clip(min=0)
    return r



def oneHotEncode(Y):
    E = np.zeros((num_classes,np.shape(np.asarray(Y))[0])) #(10*num_batch)
    for i in range(np.shape(E)[1]):
        E[Y[i]][i] = 1
    return E


def compute_loss(Y, Y_hat):
    """
    compute loss function
    """
    E = oneHotEncode(Y)
    L_sum = np.sum(np.multiply(E, np.log(Y_hat)))
    m = Y.shape[0]
    L = (-1*L_sum)/m 
    return L

def feed_forward(X, params):
    """
    feed forward network: 2 - layer neural net

    inputs:
        params: dictionay a dictionary contains all the weights and biases

    return:
        cache: dictionay a dictionary contains all the fully connected units and activations
    """
    cache = {}
    
    # Z1 = W1.dot(x) + b1
    cache["Z1"] = np.matmul(params["W1"], X.transpose()) + params["b1"]

    # # A1 = ReLU(Z1)
    cache["A1"] = ReLU(cache["Z1"])    

    # Z2 = W2.dot(A1) + b2
    cache["Z2"] = np.matmul(params["W2"], cache["A1"]) + params["b2"]

    # A2 = softmax(Z2)
    cache["A2"] = np.exp(cache["Z2"]) / np.sum(np.exp(cache["Z2"]), axis=0)

    return cache


def back_propagate(X, Y, params, cache, m_batch):
    """
    back propagation

    inputs:
        params: dictionay a dictionary contains all the weights and biases
        cache: dictionay a dictionary contains all the fully connected units and activations

    return:
        grads: dictionay a dictionary contains the gradients of corresponding weights and biases
    """
    # error at last layer
    E = oneHotEncode(Y)
    dZ2 = cache["A2"] - E   

    # gradients at last layer (Py2 need 1. to transform to float)
    dW2 = (1. / m_batch) * np.matmul(dZ2, cache["A1"].T)
    db2 = (1. / m_batch) * np.sum(dZ2, axis=1, keepdims=True)

    # back propgate through first layer
    dA1 = np.matmul(params["W2"].T, dZ2)
    dA1_copy = copy.deepcopy(dA1) #ReLU
    dA1_copy[cache["Z1"]<0] = 0 #ReLU
    dZ1 = dA1_copy              #ReLU

    # gradients at first layer (Py2 need 1. to transform to float)
    dW1 = (1. / m_batch) * np.matmul(dZ1, X)
    db1 = (1. / m_batch) * np.sum(dZ1, axis=1, keepdims=True)

    grads = {"dW1": dW1, "db1": db1, "dW2": dW2, "db2": db2}
    return grads


def eval(params, x_data, y_data):
    """ implement the evaluation function
    input: param -- parameters dictionary
           x_data -- x_train or x_test (size, 784)
           y_data -- y_train or y_test (size,)
    output: loss and accuracy
    """
    cache = feed_forward(x_data, params)
    loss = compute_loss(y_data, cache["A2"])
    result = np.argmax(np.array(cache["A2"]).T,axis=1)
    accuracy = sum(result == y_data)/float(len(y_data))
    return loss, accuracy


def mini_batch_gradient(params, x_batch, y_batch):
    """implement the function to compute the mini batch gradient
    input: params -- parameters dictionary
           x_batch -- a batch of x (size, 784)
           y_batch -- a batch of y (size,)
    output: grads, batch_loss
    """
    batch_size = x_batch.shape[0]
    cache = feed_forward(x_batch, params)
    grads = back_propagate(x_batch, y_batch, params, cache, batch_size)
    return grads

def RobustMeanEstimation(G,d):
    # This implements the RAGE algorithm given in the paper with the tweaks as described in Appendix G
    w = (1/num_workers) * np.ones(num_workers)
    mean = np.zeros(d)
    while(np.linalg.norm(w,0) > num_workers-num_adv):
        mean = G.dot(w)
        covariance = np.zeros((d,d))
        for i in range(num_workers):
            covariance += w[i] * np.outer( G[:,i]-mean, G[:,i]-mean )
        U, S, U_trans = np.linalg.svd(covariance, full_matrices=True)
        eigenvalue, eigenvector = S[0], U[:,0]
        tau = np.zeros(num_workers)
        tau_max = 0
        for i in range(num_workers):
            tau[i] = (np.dot(eigenvector, G[:,i]-mean))**2
            if w[i] > 0 and tau_max < tau[i]:
                tau_max = tau[i]
        for i in range(num_workers):
            w[i] = (1-(tau[i]/tau_max)) * w[i]
        w_norm1 = np.linalg.norm(w,1)
        w = w/w_norm1
    
    new_w = np.zeros(num_workers)
    
    for i in range(num_workers):
        if w[i] > 0:
            new_w[i] = 1
    norm_0_new_w = np.linalg.norm(new_w,0)
    new_w = (1/norm_0_new_w) * new_w
    
    return new_w


def robustGradientAggregation(list_gradients,byz_indices):
    #this is our method
    name = ["dW1","db1","dW2","db2"]
    filtered_grads = []
    weight_vec = (1/num_workers) * np.ones(num_workers)
    for i in range(4):
        no_rows = list_gradients[0][name[i]].shape[0]
        no_cols = list_gradients[0][name[i]].shape[1]
        d = no_rows * no_cols
        Grad_matrix = np.random.randn(d,num_workers)
        
        # the for loop below is for converting the gradients from matrix form to vector form
        for x in range(num_workers):
            Grad_matrix[:,x] = np.copy(np.ravel(list_gradients[x][name[i]]))
        mean_hat = np.zeros(d)
        num_random_indices = 1024
        if i == 0:
            arr_random_indices = np.array([0]*(d - num_random_indices) + [1]*num_random_indices) #coordinates on which we will apply the RME algorithm
            np.random.shuffle(arr_random_indices)
            random_indices = np.arange(num_random_indices)
            ct = 0
            for j in range(d):
                if arr_random_indices[j] == 1:
                    random_indices[ct] = j
                    ct += 1
            G = np.random.randn(num_random_indices,num_workers) 
            # G is a matrix whose i'th column contains the randomly selected 1024 coordinates from the i'th gradient (same random coordinates from all the gradients).
            # We call the RME filtering only once for robust gradient aggregation step each time. Whichever gradients the RME algorithm decides to discard (dictated by the weight_vec below), we will discard those gradients and take the average of the remaining ones.

            for j in range(num_random_indices):
                G[j,:] = Grad_matrix[random_indices[j],:]
            
            weight_vec = RobustMeanEstimation(G,num_random_indices) # Calling the RME algorithm

            mean_hat = np.copy(Grad_matrix.dot(weight_vec))
            mean_hat = mean_hat.reshape(no_rows,no_cols)   # reshape full_mean_hat from a vector to a matrix
        else:
            mean_hat = np.copy(Grad_matrix.dot(weight_vec))
            mean_hat = mean_hat.reshape(no_rows,no_cols)   # reshape full_mean_hat from a vector to a matrix
        filtered_grads.append(mean_hat)

    return filtered_grads[0], filtered_grads[1], filtered_grads[2], filtered_grads[3]

   
def Median(list_gradients,byz_indices):
    # This is for computing the coordinate-wise median of the received gradients
    name = ["dW1","db1","dW2","db2"]
    median_grads = []

    for i in range(4):
        no_rows = list_gradients[0][name[i]].shape[0]
        no_cols = list_gradients[0][name[i]].shape[1]
        d = no_rows * no_cols
        Grad_matrix = np.random.randn(d,num_workers)

        for x in range(num_workers):
            Grad_matrix[:,x] = np.copy(np.ravel(list_gradients[x][name[i]]))
#------------------- Begining of computing the coordinate-wise median ------------------
        median = np.zeros(d)
        for j in range(d):
            component_list = np.copy(Grad_matrix[j,:])
            component_list.sort()
            median[j] = component_list[int(num_workers/2+1)]
        median = median.reshape(no_rows,no_cols)   # reshape full_mean_hat from a vector to a matrix
        median_grads.append(median)
#------------------- End of computing the coordinate-wise median ------------------

    return median_grads[0], median_grads[1], median_grads[2], median_grads[3]


def TrimmedMean(list_gradients,byz_indices):
    #This is for computing the coordinate-wise trimmed-mean of the received gradients
    name = ["dW1","db1","dW2","db2"]
    trimmean_grads = []

    for i in range(4):
        no_rows = list_gradients[0][name[i]].shape[0]
        no_cols = list_gradients[0][name[i]].shape[1]
        d = no_rows * no_cols
        Grad_matrix = np.random.randn(d,num_workers)

        for x in range(num_workers):
            Grad_matrix[:,x] = np.copy(np.ravel(list_gradients[x][name[i]]))
#------------------- Begining of computing the trimmed mean ------------------
        trimmean = np.zeros(d)
        start = num_adv
        end = num_workers - num_adv
        for j in range(d):
            component_list = np.copy(Grad_matrix[j,:])
            component_list.sort()
            for k in range(start,end):
                trimmean[j] += component_list[k]
            trimmean[j] = trimmean[j]/(end-start)
        trimmean = trimmean.reshape(no_rows,no_cols)   # reshape full_mean_hat from a vector to a matrix
        trimmean_grads.append(trimmean)
#------------------- End of computing the trimmed mean ------------------

    return trimmean_grads[0], trimmean_grads[1], trimmean_grads[2], trimmean_grads[3]


def KrumDecoding(n,grad_matrix):
    #This implements the Krum decoding funciton
    pairwise_dist = np.zeros((n,n))
    for i in range(n):
        for j in range(n):
            pairwise_dist[i][j] = np.linalg.norm(grad_matrix[:,i] - grad_matrix[:,j])
        pairwise_dist[i].sort()

    score = np.zeros(n)
    for i in range(n):
        for j in range(n-num_adv-1):
            score[i] += pairwise_dist[i][j]

    optimal_index = 0
    optimal_score = 100000000000000000
    for i in range(n):
        if (optimal_score > score[i]):
            optimal_score = score[i]
            optimal_index = int(i)

    return optimal_index, grad_matrix[:,optimal_index]


def Krum(list_gradients,byz_indices):
    #This function coverts the gradients from matrix form to the vector form and then call the Krum decoding function 
    name = ["dW1","db1","dW2","db2"]

    dim = 0
    no_rows = np.zeros(4)
    no_cols = np.zeros(4)
    for i in range(4):
        no_rows[i] = list_gradients[0][name[i]].shape[0]
        no_cols[i] = list_gradients[0][name[i]].shape[1]
        dim += no_rows[i] * no_cols[i]
    dim = int(dim)
    Grad_matrix = np.random.randn(int(dim),num_workers)

    start_index = 0    
    for i in range(4):
        d = int(no_rows[i] * no_cols[i])
        end_index = int(start_index + d)
        for x in range(num_workers):
            Grad_matrix[start_index:end_index,x] = np.copy(np.ravel(list_gradients[x][name[i]]))
        start_index += d


    optimal_index, optimal_grad = KrumDecoding(num_workers,Grad_matrix) #Note that optimal_grad is equal to the concatenation of list_gradients[optimal_index][x] for x\in{dW1,db1,dW2,db2}

    return list_gradients[optimal_index]["dW1"], list_gradients[optimal_index]["db1"], list_gradients[optimal_index]["dW2"], list_gradients[optimal_index]["db2"]


    
def corruptGradients(list_gradients,byz_indices):
    # This function corrupts the gradients according the attack_index
    name = ["dW1","db1","dW2","db2"]
    for i in range(4):
        no_rows = list_gradients[0][name[i]].shape[0]
        no_cols = list_gradients[0][name[i]].shape[1]

        byz_grad = np.zeros((no_rows,no_cols))
        for x in range(num_workers):
            if byz_indices[x] == 1:
                byz_grad += list_gradients[x][name[i]]
        if num_adv > 0:
            byz_grad = byz_grad/num_adv

        #--------------- Beginning of computing the Baurch et al. attack -----------------
        s = int(num_workers/2+1) - num_adv # = (100+1)-25 = 76
        z_max = st.norm.ppf ((num_workers-num_adv-s) / (num_workers-num_adv) )
        sigma_square = np.zeros((no_rows,no_cols))
        baruch_err_vec = np.zeros((no_rows,no_cols))
        for x in range(num_workers):
            if byz_indices[x] == 1:
                sigma_square += np.square(list_gradients[x][name[i]] - byz_grad)
        sigma = np.sqrt(sigma_square/num_adv)
        baruch_err_vec = byz_grad - z_max * sigma
        #--------------- End of computing the Baurch et al. attack -----------------
        
        # this offset of for the GradientShiftAttack
        offset = 50 * np.random.randn(no_rows,no_cols) 
        for x in range(num_workers):
            if byz_indices[x] == 1:

                # 0 is for allonesAttack
                if attack_index == 0:
                    list_gradients[x][name[i]] = np.ones((no_rows,no_cols))
                
                # 1 is for gradientShiftAttack
                if attack_index == 1:
                    list_gradients[x][name[i]] += offset
                
                # 2 is for randomLocalGradient
                if attack_index == 2:
                    list_gradients[x][name[i]] = np.random.randn(no_rows,no_cols)
                
                # 3 is for revAttack_avg_withScaling
                if attack_index == 3:
                    list_gradients[x][name[i]] = -scaling_factor * byz_grad
                
                # 4 is for revAttack_avg_withoutScaling
                if attack_index == 4:
                    list_gradients[x][name[i]] = -byz_grad
                
                # 5 is for BaruchAttack
                if attack_index == 5:
                    list_gradients[x][name[i]] = baruch_err_vec

    
    return list_gradients


def computingTrainLossTestAccu(epoch,params,train_datasets,test_datasets,epoch_train_loss_list,epoch_test_accu_list):
    workers_train_loss = []
    workers_test_accu = []
    for x in range(num_workers):
        train_loss, train_accu = eval(params,train_datasets[x][0],train_datasets[x][1]) #we will only use train_loss and won't use train_accu
        workers_train_loss.append(train_loss)
    test_loss, test_accu = eval(params,test_datasets[0][0],test_datasets[0][1]) #we will only use test_accu and won't use test_loss
    workers_test_accu.append(test_accu)
    avg_train_loss = sum(workers_train_loss)/len(workers_train_loss)
    avg_test_accu = sum(workers_test_accu)/len(workers_test_accu)
    epoch_train_loss_list.append(avg_train_loss) #Store training loss after epoch
    epoch_test_accu_list.append(avg_test_accu) #Store training loss after epoch
    message = 'Epoch %d, Train Loss %.2f, Test Accu %.4f' % (epoch+1, avg_train_loss, avg_test_accu)

    return message


def learningRateDecay(flag,epoch,learning_rate,prev,prev_minus_1,thres,decay_factor):
    if (prev-prev_minus_1) < thres:
        learning_rate *= decay_factor
        print(flag," Learning rate decay happened ",learning_rate)
    
    return learning_rate


def trainDistributed(params, byz_params, byz_trimmean_params, byz_median_params, byz_krum_params, hyp, train_datasets,test_datasets):
    num_epochs = hyp['num_epochs']
    batch_size = hyp['batch_size']

    learning_rate = hyp['learning_rate'] # this is when there is no attack and no decoding
    learning_rate_byz = hyp['learning_rate'] # this is when there is attack and RME decoding
    learning_rate_byz_trimmean = hyp['learning_rate'] # this is when there is attack and trimmed-mean decoding
    learning_rate_byz_median = hyp['learning_rate'] # this is when there is attack and median decoding
    learning_rate_byz_krum = hyp['learning_rate'] # this is when there is attack and Krum decoding

    epoch_train_loss_list, epoch_test_accu_list = [],[]
    byz_epoch_train_loss_list, byz_epoch_test_accu_list = [],[]
    byz_trimmean_epoch_train_loss_list, byz_trimmean_epoch_test_accu_list = [],[]
    byz_median_epoch_train_loss_list, byz_median_epoch_test_accu_list = [],[]
    byz_krum_epoch_train_loss_list, byz_krum_epoch_test_accu_list = [],[]
    
    for epoch in range(num_epochs):
        print("Attack_name = ",attack_name[attack_index]," and run_index = ",run_index)

        rand_indices = np.random.choice(num_sample_worker,num_sample_worker,replace=False)
        
        params_list = [None]*num_workers
        for i in range(num_workers):
            params_list[i] = copy.deepcopy(params)
        
        # the following is for updating the learning rates for each of the defense mechanisms
        if epoch > 2:
            learning_rate = learningRateDecay("NoByz",epoch,learning_rate,epoch_test_accu_list[epoch-1],epoch_test_accu_list[epoch-2], 0.001, hyp['decay_factor'])
            learning_rate_byz = learningRateDecay("ByzRME",epoch,learning_rate_byz,byz_epoch_test_accu_list[epoch-1],byz_epoch_test_accu_list[epoch-2], 0.001, hyp['decay_factor'])
            learning_rate_byz_trimmean = learningRateDecay("ByzTrimmean",epoch,learning_rate_byz_trimmean,byz_trimmean_epoch_test_accu_list[epoch-1],byz_trimmean_epoch_test_accu_list[epoch-2], 0.001, hyp['decay_factor'])
            learning_rate_byz_median = learningRateDecay("ByzMedian",epoch,learning_rate_byz_median,byz_median_epoch_test_accu_list[epoch-1],byz_median_epoch_test_accu_list[epoch-2], 0.001, hyp['decay_factor'])
            learning_rate_byz_krum = learningRateDecay("ByzKrum",epoch,learning_rate_byz_krum,byz_krum_epoch_test_accu_list[epoch-1],byz_krum_epoch_test_accu_list[epoch-2], 0.001, hyp['decay_factor'])

 
        byz_indices = np.array([0]*(num_workers - num_adv) + [1]*num_adv) #corrupt workers' indices
        np.random.shuffle(byz_indices) #In each epoch, randomly shuffle the corrupt workers
        
        # The following two for loops are for updating the local parameters through local iterations
        for batch in range(num_batch): # num_batch is equal to the number of local iterations
            for x in range(num_workers):        
                index = rand_indices[batch_size*batch:batch_size*(batch+1)] #Pick random batch
                x_batch = train_datasets[x][0][index]
                y_batch = train_datasets[x][1][index]
                grads = mini_batch_gradient(params_list[x], x_batch, y_batch) #Compue gradient for the batch
                params_list[x]["W1"] -= learning_rate * grads["dW1"]
                params_list[x]["b1"] -= learning_rate * grads["db1"]
                params_list[x]["W2"] -= learning_rate * grads["dW2"]
                params_list[x]["b2"] -= learning_rate * grads["db2"]

        accu_grad = [None] * num_workers
        for i in range(num_workers):
            accu_grad[i] = {"dW1":None, "db1":None, "dW2":None, "db2":None}
        
        # The for loop below computes the accummulated gradients over the H = num_batch local iterations
        for i in range(num_workers):
            accu_grad[i]["dW1"] = copy.deepcopy((params["W1"] - params_list[i]["W1"])/learning_rate)
            accu_grad[i]["db1"] = copy.deepcopy((params["b1"] - params_list[i]["b1"])/learning_rate)
            accu_grad[i]["dW2"] = copy.deepcopy((params["W2"] - params_list[i]["W2"])/learning_rate)
            accu_grad[i]["db2"] = copy.deepcopy((params["b2"] - params_list[i]["b2"])/learning_rate)
        byz_accu_grad = copy.deepcopy(accu_grad)
        byz_accu_grad = corruptGradients(byz_accu_grad,byz_indices) 

        ##---------- BEGINNING OF updating the parameter vector when all workers are honest and no decoding ----------------
        sum_w1, sum_b1, sum_w2, sum_b2 = 0,0,0,0
        for x in range(num_workers):
            sum_w1 += params_list[x]["W1"]
            sum_b1 += params_list[x]["b1"]
            sum_w2 += params_list[x]["W2"]
            sum_b2 += params_list[x]["b2"]
        params["W1"] = sum_w1/num_workers
        params["b1"] = sum_b1/num_workers
        params["W2"] = sum_w2/num_workers
        params["b2"] = sum_b2/num_workers
        ##---------- END OF updating the parameter vector when all workers are honest and no decoding ----------------
        
##---------- BEGINNING OF updating the parameter vector when some workers are corrupt and RME decoding ----------------
        w1,b1,w2,b2 = robustGradientAggregation(byz_accu_grad,byz_indices)
        byz_params["W1"] -= learning_rate_byz * w1
        byz_params["b1"] -= learning_rate_byz * b1
        byz_params["W2"] -= learning_rate_byz * w2
        byz_params["b2"] -= learning_rate_byz * b2
        ##---------- END OF updating the parameter vector when all some workers are corrupt and RME decoding ----------------

##---------- BEGINNING OF updating the parameter vector when some workers are corrupt and with trimmed mean decoding ----------------
        w1,b1,w2,b2 = TrimmedMean(byz_accu_grad,byz_indices)
        byz_trimmean_params["W1"] -= learning_rate_byz_trimmean * w1
        byz_trimmean_params["b1"] -= learning_rate_byz_trimmean * b1
        byz_trimmean_params["W2"] -= learning_rate_byz_trimmean * w2
        byz_trimmean_params["b2"] -= learning_rate_byz_trimmean * b2
##---------- END OF updating the parameter vector when some workers are corrupt and with trimmed mean decoding ----------------

##---------- BEGINNING OF updating the parameter vector when some workers are corrupt and with median decoding ----------------
        w1,b1,w2,b2 = Median(byz_accu_grad,byz_indices)
        byz_median_params["W1"] -= learning_rate_byz_median * w1
        byz_median_params["b1"] -= learning_rate_byz_median * b1
        byz_median_params["W2"] -= learning_rate_byz_median * w2
        byz_median_params["b2"] -= learning_rate_byz_median * b2
##---------- END OF updating the parameter vector when some workers are corrupt and with median decoding ----------------
##---------- BEGINNING OF updating the parameter vector when some workers are corrupt and with krum decoding ----------------
        w1,b1,w2,b2 = Krum(byz_accu_grad,byz_indices)
        byz_krum_params["W1"] -= learning_rate_byz_krum * w1
        byz_krum_params["b1"] -= learning_rate_byz_krum * b1
        byz_krum_params["W2"] -= learning_rate_byz_krum * w2
        byz_krum_params["b2"] -= learning_rate_byz_krum * b2
##---------- END OF updating the parameter vector when some workers are corrupt and with krum decoding ----------------
        
        message = "NoByz_NoDec_" + computingTrainLossTestAccu(epoch,params,train_datasets,test_datasets,epoch_train_loss_list,epoch_test_accu_list)
        print(message)

        message = "Byz_RME_" + computingTrainLossTestAccu(epoch,byz_params,train_datasets,test_datasets,byz_epoch_train_loss_list,byz_epoch_test_accu_list)
        print(message)

        message = "Byz_TrimMean_" + computingTrainLossTestAccu(epoch,byz_trimmean_params,train_datasets,test_datasets,byz_trimmean_epoch_train_loss_list,byz_trimmean_epoch_test_accu_list)
        print(message)

        message = "Byz_Median_" + computingTrainLossTestAccu(epoch,byz_median_params,train_datasets,test_datasets,byz_median_epoch_train_loss_list,byz_median_epoch_test_accu_list)
        print(message)

        message = "Byz_Krum_" + computingTrainLossTestAccu(epoch,byz_krum_params,train_datasets,test_datasets,byz_krum_epoch_train_loss_list,byz_krum_epoch_test_accu_list)
        print(message)


        print("\n")
    
    return_list, byz_return_list, byz_trimmean_return_list, byz_median_return_list, byz_krum_return_list = [], [], [], [], []
    
    return_list.append(epoch_train_loss_list)
    return_list.append(epoch_test_accu_list)

    byz_return_list.append(byz_epoch_train_loss_list)
    byz_return_list.append(byz_epoch_test_accu_list)

    byz_trimmean_return_list.append(byz_trimmean_epoch_train_loss_list)
    byz_trimmean_return_list.append(byz_trimmean_epoch_test_accu_list)

    byz_median_return_list.append(byz_median_epoch_train_loss_list)
    byz_median_return_list.append(byz_median_epoch_test_accu_list)

    byz_krum_return_list.append(byz_krum_epoch_train_loss_list)
    byz_krum_return_list.append(byz_krum_epoch_test_accu_list)


    return return_list, byz_return_list, byz_trimmean_return_list, byz_median_return_list, byz_krum_return_list



def logvals(plt_name,avg_train_loss_list,test_accu_list):
    filename_prefix = "./logs/"+attack_name[attack_index]+"/"+plt_name+"_"+attack_name[attack_index]+"_run"+str(run_index)+"_"
    with open(filename_prefix+"train_loss.txt","w") as fp:
        for x in avg_train_loss_list:
            fp.write(str(x)+"\n")

    with open(filename_prefix+"test_accu.txt","w") as fp:
        for x in test_accu_list:
            fp.write(str(x)+"\n")  


def main(): 

    # Name to save for file
    plt_name = "FL_W"+str(num_workers)+"_Adv"+str(num_adv)
    byz_plt_name = "byz_RME_FL_W"+str(num_workers)+"_Adv"+str(num_adv)
    byz_trimmean_plt_name = "byz_TrimMean_FL_W"+str(num_workers)+"_Adv"+str(num_adv)
    byz_median_plt_name = "byz_Median_FL_W"+str(num_workers)+"_Adv"+str(num_adv)
    byz_krum_plt_name = "byz_Krum_FL_W"+str(num_workers)+"_Adv"+str(num_adv)

    ## SAMPLING FOR DATSETS
    train_datasets,test_datasets = nonuniformSampling()

    hyp = {'num_epochs':num_epochs, 'batch_size':batch_size, 'learning_decay':False,  'learning_rate':lr, 'decay_factor':decay_factor}

    # setting the random seed
    np.random.seed(11)

    # initialize the parameters
    params, byz_params, byz_trimmean_params, byz_median_params, byz_krum_params = initialize(num_features,num_classes,num_hidden)

    # train the model
    avg_return_list, byz_avg_return_list, byz_trimmean_avg_return_list, byz_median_avg_return_list, byz_krum_avg_return_list = trainDistributed(params,byz_params,byz_trimmean_params,byz_median_params,byz_krum_params,hyp,train_datasets, test_datasets)
    
    # Log the loss and accuracy
    logvals(plt_name, avg_return_list[0],avg_return_list[1])
    logvals(byz_plt_name, byz_avg_return_list[0], byz_avg_return_list[1])
    logvals(byz_trimmean_plt_name, byz_trimmean_avg_return_list[0], byz_trimmean_avg_return_list[1])
    logvals(byz_median_plt_name, byz_median_avg_return_list[0], byz_median_avg_return_list[1])
    logvals(byz_krum_plt_name, byz_krum_avg_return_list[0], byz_krum_avg_return_list[1])


if __name__ == "__main__":
    main()






