%% Holder continuous function
function y = holder_1(x,s)

amp = 1.0;     
y = amp*x.^s;


