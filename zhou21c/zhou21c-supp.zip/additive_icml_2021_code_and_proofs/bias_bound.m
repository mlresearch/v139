%% Bias Rate Bound test
%function simulation_2

s = 3.5; % smoothness \beta in paper
k = floor(s) - 1; % \ell in paper
a = 10 : 0.5 : 14; 
n = round(2.^a); % sample size n
dim = 256; % d in paper
n_trial = 1e4; % No. of trials
sg = 1.0;
sg_1 = 1.0;
N = 1e2; % N in paper

%%
for i=1:length(n)
    i
    CV = eye(dim)./n(i);
    theta_0 = 0.5;
    theta = theta_0 + (rand(1,dim)*2-1)*0.1; %  \theta value 
    true_p(i) = sum(holder_1(theta,s));
    Y_obv = mymvnrnd(theta, sg^2*CV, n(i));
    Y = mymvnrnd(theta,sg^2*CV,n_trial);
    sg_adp = mean(var(Y_obv));
    Pg(:,i) = sum(holder_1(Y,s),2);
    Bt(:,i) = Pg(:,i);
    adp_Bt(:,i) = Pg(:,i);
    
    % compute iterative bootstrap
    for t = 1:n_trial
        bt_output = zeros(N, dim);
        for h=1:N
            for j=1:k
                [bt_add, bt_pd] = iter_boostrap(j,Y(t,:),sg/sqrt(n(i)));
                 bt_output(h,:) = bt_output(h,:) + ...
                                (-1)^j.*holder_1(bt_add,s-j).*s.*bt_pd;
            end
        end
        Bt(t,i) = Bt(t,i) + sum(mean(bt_output,1));
    end
    
    % compute adaptive iterative bootstrap
    for t = 1:n_trial
        adpbt_output = zeros(N, dim);
        for h=1:N
            for j=1:k
                [adpbt_add, adpbt_pd] = iter_boostrap(j,Y(t,:),sqrt(sg_adp));
                 adpbt_output(h,:) = adpbt_output(h,:) + ...
                                (-1)^j.*holder_1(adpbt_add,s-j).*s.*adpbt_pd;
            end
        end
        adp_Bt(t,i) = adp_Bt(t,i) + sum(mean(adpbt_output,1));
    end
    
    % plug-in bias, var, and mse
    bias_Pg(i) = abs(mean(Pg(:,i))-true_p(i));
    var_Pg(i) = var(Pg(:,i));
    mse_Pg(i) = mean((Pg(:,i)-true_p(i)).^2);
    est_Pg(i) = mean(Pg(:,i));
     
    % iterative boostrap, IB bias, var, mse
    bias_Bt(i) = abs(mean(Bt(:,i))-true_p(i));
    var_Bt(i) = var(Bt(:,i));
    mse_Bt(i) = mean((Bt(:,i) - true_p(i)).^2);    
    
    % adaptive ADP-IB, bias, var, mse
    bias_adp(i) = abs(mean(adp_Bt(:,i))-true_p(i));
    var_adp(i) = var(adp_Bt(:,i));
    mse_adp(i) = mean((adp_Bt(:,i) - true_p(i)).^2);
    
end

%% bias plot s3

figure; box on;
loglog(n, bias_Pg, 'b-+','linewidth',2); hold on; grid on;
loglog(n, bias_Bt,'r-o','linewidth',2); hold on; grid on;
loglog(n, bias_adp, 'k-+','linewidth',2);

%normal_rate = dim + 1/(n^0.5);
bound_bias_1 = theta_0*dim./(n);
bound_bias_2 = theta_0*dim./(n.^(s/2));
plot(n, bound_bias_1,'r--','linewidth',2);
plot(n, bound_bias_2,'g--','linewidth',2);

set(gca,'fontsize',20);

set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('|Bias|');
legend('Plug-in','IB','Adaptive','0.5*d/n','0.5*d/n^{3.5/2}','location', 'northwest')
set(gca,'yminorgrid','off','xminorgrid','off');
set(gca,'xtick',[1e3 2*1e3 4*1e3 8*1e3 16*1e3],'xlim',[900 16400]);

%set(gca,'ytick',[1e-4 1e-3 1e-2 1e-1], 'ylim',[1e-4 2*1e-1]);

text(1024,0.1, 'h(\theta) = \theta^{3.5}, Bias','color','r','fontsize',20,'fontweight','bold');

%% variance plot 
figure; box on;
loglog(n, var_Bt,'r-o','linewidth',2); hold on; grid on;
loglog(n, var_Pg, 'b-+','linewidth',2); 
loglog(n, var_adp, 'k-+','linewidth',2); 

minimax_2 = (1.1*3.5*0.5^2.5)^2.*dim./n;
plot(n, minimax_2,'k--','linewidth',2);
set(gca,'fontsize',20);

set(gca,'fontsize',20);
xlabel('Dimension (d)');
ylabel('Variance');

legend('IB','Plug-in','Adaptive','C*d/n^{}','location', 'northwest')
set(gca,'yminorgrid','off','xminorgrid','off');
set(gca,'xtick',[1e3 2*1e3 4*1e3 8*1e3 16*1e3],'xlim',[900 16400]);
%set(gca,'ytick',[0.0001 0.001 0.01],'ylim',[0.0001 0.01]);
text(64,0.001, 'h(\theta) = \theta^{3.5}, Var','color','r','fontsize',20,'fontweight','bold');
