% bias bound data
s = 3.5; 
theta_0 = 0.5;
k = floor(s) - 1; % \ell in paper
a = 10 : 0.5 : 14;
n = round(2.^a);
dim = 256;
sg = 1.0;
sg_1 = 1.0;
N = 10;

%% s = 3.5, n_trial = 1e4, N = 10

n_trial = 1e4;
N = 10;

bp_t05s35N1e1 = [0.3790    0.2694    0.1983    0.1391    0.0980  ...
                 0.0681    0.0496    0.0347    0.0224];

bb_t05s35N1e1 = [0.0035    0.0012    0.0023    0.0020    0.0025 ...
                  0.0021    0.0018    0.0001    0.0014];

ba_t05s35N1e1 = [0.0021    0.0002    0.0052    0.0019    0.0018 ...
                  0.0009    0.0009    0.0001    0.0018];

vp_t05s35N1e1 = [0.1046    0.0737    0.0547    0.0381    0.0265 ...
                  0.0202    0.0136    0.0096    0.0064];

vb_t05s35N1e1 = [0.1187    0.0835    0.0607    0.0423    0.0291 ...
                  0.0226    0.0150    0.0106    0.0071];

va_t05s35N1e1 = [0.1184    0.0835    0.0615    0.0422    0.0296 ...
                  0.0222    0.0151    0.0107    0.0072];

mp_t05s35N1e1 = [0.2482    0.1462    0.0940    0.0575    0.0361 ...
                  0.0248    0.0161    0.0108    0.0069];

mb_t05s35N1e1 = [0.1187    0.0835    0.0607    0.0423    0.0291 ...
                  0.0226    0.0150    0.0106    0.0071];

ma_t05s35N1e1 = [0.1184    0.0835    0.0615    0.0422    0.0296 ...
                  0.0222    0.0151    0.0107    0.0072];
              
figure; box on;
loglog(n, bp_t05s35N1e1, 'b-+','linewidth',2); hold on; grid on;
loglog(n, bb_t05s35N1e1,'r-o','linewidth',2); hold on; grid on;
loglog(n, ba_t05s35N1e1, 'k-+','linewidth',2);

bound_bias_1 = theta_0*dim./(n);
bound_bias_2 = theta_0*dim./(n.^(s/2));
bound_bias_3 = ones(size(n)).*theta_0*1./(n_trial*N).^(1/2);
plot(n, bound_bias_1,'r--','linewidth',2);
plot(n, bound_bias_2,'b--','linewidth',2);
plot(n, bound_bias_3,'k--','linewidth',2);


set(gca,'fontsize',20);

set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('|Bias|');
legend('Plug-in','IB','Adaptive','0.5*d/n','0.5*d/n^{3.5/2}','location', 'northwest')
set(gca,'yminorgrid','off','xminorgrid','off');
set(gca,'xtick',[1e3 2*1e3 4*1e3 8*1e3 16*1e3],'xlim',[900 16400]);
%set(gca,'ytick',[1e-4 1e-3 1e-2 1e-1], 'ylim',[1e-4 2*1e-1]);

text(1024,0.1, 'h(\theta) = \theta^{3.5}, Bias','color','r','fontsize',20,'fontweight','bold');

%% variance plot N = 10
figure; box on;
loglog(n, vp_t05s35N1e1,'b-o','linewidth',2); hold on; grid on;
loglog(n, vb_t05s35N1e1, 'r-+','linewidth',2); 
loglog(n, va_t05s35N1e1, 'k-+','linewidth',2); 

minimax_2 = (3.5*0.5^2.5)^2.*dim./n;
plot(n, minimax_2,'k--','linewidth',2);
set(gca,'fontsize',20);

set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('Variance');

legend('Plug-in','IB','Adaptive','C*d/n^{}','location', 'northwest')
set(gca,'yminorgrid','off','xminorgrid','off');
%set(gca,'xtick',[32 64 128 256 512 710],'xlim',[32 710]);
%set(gca,'ytick',[0.0001 0.001 0.01],'ylim',[0.0001 0.01]);

text(1e3,0.1, 'h(\theta) = \theta^{3.5}, d = 256, N = 10, Var','color','r','fontsize',20,'fontweight','bold');




%% s = 3.5, n_trial = 1e4, N = 1e2
n_trial = 1e4;
N = 1e2;

bp_t05s35N1e2 = [0.3824    0.2741    0.1932    0.1397    0.0955 ...
                 0.0686    0.0469    0.0339    0.0241];

bb_t05s35N1e2 = [0.0022    0.0009    0.0001    0.0021    0.0003 ...
                 0.0011    0.0021    0.0010    0.00004];

ba_t05s35N1e2 = [0.0006    0.00004   0.0004    0.0020    0.00004 ...
                 0.0008    0.0024    0.0009    0.0001];

vp_t05s35N1e2 = [0.1062    0.0777    0.0548    0.0390    0.0248 ...
                 0.0196    0.0139    0.0099    0.0066];

vb_t05s35N1e2 = [0.1064    0.0779    0.0551    0.0392    0.0250 ...
                 0.0198    0.0141    0.0100    0.0067];

va_t05s35N1e2 = [0.1063    0.0779    0.0551    0.0393    0.0249 ...
                 0.0198    0.0141    0.0100    0.0066];

mp_t05s35N1e2 = [0.2524    0.1528    0.0921    0.0585    0.0339 ...
                 0.0243    0.0161    0.0111    0.0072];

mb_t05s35N1e2 = [0.1064    0.0779    0.0551    0.0392    0.0250 ...
                 0.0198    0.0141    0.0100    0.0067];

ma_t05s35N1e2 = [0.1063    0.0779    0.0551    0.0393    0.0249 ...
                 0.0198    0.0141    0.0100    0.0066];
              
              
figure; box on;
loglog(n, bp_t05s35N1e2, 'b-+','linewidth',2); hold on; grid on;
loglog(n, bb_t05s35N1e2,'r-o','linewidth',2); hold on; grid on;
loglog(n, ba_t05s35N1e2, 'k-+','linewidth',2);

bound_bias_1 = theta_0*dim./(n);
bound_bias_2 = theta_0*dim./(n.^(s/2));
bound_bias_3 = ones(size(n)).*theta_0*1./(N*n_trial).^(1/2);
plot(n, bound_bias_1,'r--','linewidth',2);
plot(n, bound_bias_2,'b--','linewidth',2);
plot(n, bound_bias_3,'k--','linewidth',2);


set(gca,'fontsize',20);

set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('|Bias|');
legend('Plug-in','IB','Adaptive','0.5*d/n','0.5*d/n^{3.5/2}','1/N^{1/2}','location', 'northwest')
set(gca,'yminorgrid','off','xminorgrid','off');
set(gca,'xtick',[1e3 2*1e3 4*1e3 8*1e3 16*1e3],'xlim',[900 16400]);
%set(gca,'ytick',[1e-4 1e-3 1e-2 1e-1], 'ylim',[1e-4 2*1e-1]);

text(1024,0.1, 'h(\theta) = \theta^{3.5}, Bias','color','r','fontsize',20,'fontweight','bold');

%% variance plot N = 1e2
figure; box on;
loglog(n, vp_t05s35N1e2,'b-o','linewidth',2); hold on; grid on;
loglog(n, vb_t05s35N1e2, 'r-+','linewidth',2); 
loglog(n, va_t05s35N1e2, 'k-+','linewidth',2); 

minimax_2 = (3.5*0.5^2.5)^2.*dim./n;
plot(n, minimax_2,'k--','linewidth',2);
set(gca,'fontsize',20);

set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('Variance');

legend('Plug-in','IB','Adaptive','C*d/n^{}','location', 'northwest')
set(gca,'yminorgrid','off','xminorgrid','off');
%set(gca,'xtick',[32 64 128 256 512 710],'xlim',[32 710]);
%set(gca,'ytick',[0.0001 0.001 0.01],'ylim',[0.0001 0.01]);

text(1e3,0.1, 'h(\theta) = \theta^{3.5}, d = 256, N = 1e2, Var','color','r','fontsize',20,'fontweight','bold');



%% s = 3.5, n_trial = 1e4, N = 1e3
n_trial = 1e4;
N = 1e3;

bp_t05s35N1e3 = [0.3948    0.2765    0.1958    0.1380    0.0992 ...
                 0.0687    0.0503    0.0337    0.0233];

bb_t05s35N1e3 = [0.0007    0.0020    0.0006    0.0009    0.0010 ...
                 0.0003    0.0017    0.0003    0.0007];

ba_t05s35N1e3 = [0.0011    0.0011    0.0006    0.0010    0.0013 ...
                 0.0004    0.0015    0.0004    0.0007];

vp_t05s35N1e3 = [0.1175    0.0811    0.0562    0.0401    0.0277 ...
                 0.0196    0.0137    0.0094    0.0066];

vb_t05s35N1e3 = [0.1161    0.0805    0.0559    0.0400    0.0277 ...
                 0.0196    0.0137    0.0094    0.0066];

va_t05s35N1e3 = [0.1162    0.0805    0.0559    0.0401    0.0276 ...  
                 0.0196    0.0137    0.0094    0.0066];

mp_t05s35N1e3 = [0.2734    0.1575    0.0945    0.0592    0.0376 ...
                 0.0244    0.0162    0.0105    0.0071];

mb_t05s35N1e3 = [0.1161    0.0805    0.0559    0.0400    0.0277 ...
                 0.0196    0.0137    0.0094    0.0066];

ma_t05s35N1e3 = [0.1162    0.0805    0.0559    0.0401    0.0276 ...
                 0.0196    0.0137    0.0094    0.0066];
              
              
figure; box on;
loglog(n, bp_t05s35N1e3, 'b-+','linewidth',2); hold on; grid on;
loglog(n, bb_t05s35N1e3,'r-o','linewidth',2); hold on; grid on;
loglog(n, ba_t05s35N1e3, 'k-+','linewidth',2);

bound_bias_1 = theta_0*dim./(n);
bound_bias_2 = theta_0*dim./(n.^(s/2));
bound_bias_3 = ones(size(n)).*theta_0*1./(N*n_trial).^(1/2);
plot(n, bound_bias_1,'r--','linewidth',2);
plot(n, bound_bias_2,'b--','linewidth',2);
plot(n, bound_bias_3,'k--','linewidth',2);


set(gca,'fontsize',20);

set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('|Bias|');
legend('Plug-in','IB','Adaptive','0.5*d/n','0.5*d/n^{3.5/2}','1/N^{1/2}','location', 'northwest')
set(gca,'yminorgrid','off','xminorgrid','off');
set(gca,'xtick',[1e3 2*1e3 4*1e3 8*1e3 16*1e3],'xlim',[900 16400]);
%set(gca,'ytick',[1e-4 1e-3 1e-2 1e-1], 'ylim',[1e-4 2*1e-1]);

text(1e3,0.1, 'h(\theta) = \theta^{3.5}, Bias','color','r','fontsize',20,'fontweight','bold');

%% variance plot N = 1e2
figure; box on;
loglog(n, vp_t05s35N1e3,'b-o','linewidth',2); hold on; grid on;
loglog(n, vb_t05s35N1e3, 'r-+','linewidth',2); 
loglog(n, va_t05s35N1e3, 'k-+','linewidth',2); 

minimax_2 = (3.5*0.5^2.5)^2.*dim./n;
plot(n, minimax_2,'k--','linewidth',2);
set(gca,'fontsize',20);

set(gca,'fontsize',20);
xlabel('Sample Size (n)');
ylabel('Variance');

legend('Plug-in','IB','Adaptive','C*d/n^{}','location', 'northwest')
set(gca,'yminorgrid','off','xminorgrid','off');
%set(gca,'xtick',[32 64 128 256 512 710],'xlim',[32 710]);
%set(gca,'ytick',[0.0001 0.001 0.01],'ylim',[0.0001 0.01]);

text(1e3,0.1, 'h(\theta) = \theta^{3.5}, d = 256, N = 1e3, Var','color','r','fontsize',20,'fontweight','bold');

              


