%% iterative boostrap simulation
s = 3.5;  % smoothness, \beta in paper
k = floor(s) - 1; % \ell in paper
n = 1e3;  % sample size n
b = 0.5:0.05:0.95; % \alpha value in paper
dim = round(n.^b); % dimension d
n_trial = 1e3; % No. of trials
N = 1e2; % sample average parameter N in paper
sg = 1.0; % \sigma value

%%
for i=1:length(dim)
    i
    CV = eye(dim(i))/n;
    theta_0 = 0.5;
    theta = theta_0 + (rand(1,dim(i))*2-1)*0.1; %  \theta value 
    true_p(i) = sum(holder_1(theta,s));
    Y_obv = mymvnrnd(theta, sg^2*CV, n);
    Y = mymvnrnd(theta,sg^2*CV,n_trial);
    sg_adp = mean(var(Y_obv));
    Pg(:,i) = sum(holder_1(Y,s),2);
    Bt(:,i) = Pg(:,i);
    adp_Bt(:,i) = Pg(:,i);
    
    % compute iterative bootstrap
    for t = 1:n_trial
        bt_output = zeros(N, dim(i));
        for h=1:N
            for j=1:k
                [bt_add, bt_pd] = iter_boostrap(j,Y(t,:),sg/sqrt(n));
                 bt_output(h,:) = bt_output(h,:) + ...
                                (-1)^j.*holder_1(bt_add,s-j).*s.*bt_pd;
            end
        end
        Bt(t,i) = Bt(t,i) + sum(mean(bt_output,1));
    end
    
    % compute adaptive iterative bootstrap
    for t = 1:n_trial
        adpbt_output = zeros(N, dim(i));
        for h=1:N
            for j=1:k
                [adpbt_add, adpbt_pd] = iter_boostrap(j,Y(t,:),sqrt(sg_adp));
                 adpbt_output(h,:) = adpbt_output(h,:) + ...
                                (-1)^j.*holder_1(adpbt_add,s-j).*s.*adpbt_pd;
            end
        end
        adp_Bt(t,i) = adp_Bt(t,i) + sum(mean(adpbt_output,1));
    end
    
    % plug-in bias, var, and mse
    bias_Pg(i) = abs(mean(Pg(:,i))-true_p(i));
    var_Pg(i) = var(Pg(:,i));
    mse_Pg(i) = mean((Pg(:,i)-true_p(i)).^2);
    est_Pg(i) = mean(Pg(:,i));
     
    % iterative boostrap, IB bias, var, mse
    bias_Bt(i) = abs(mean(Bt(:,i))-true_p(i));
    var_Bt(i) = var(Bt(:,i));
    mse_Bt(i) = mean((Bt(:,i) - true_p(i)).^2);    
    
    % adaptive ADP-IB, bias, var, mse
    bias_adp(i) = abs(mean(adp_Bt(:,i))-true_p(i));
    var_adp(i) = var(adp_Bt(:,i));
    mse_adp(i) = mean((adp_Bt(:,i) - true_p(i)).^2);
end

%% bias plot s3

figure; box on;
loglog(dim, bias_Bt,'r-o','linewidth',2); hold on; grid on;
loglog(dim, bias_Pg, 'b-+','linewidth',2);
loglog(dim, bias_adp, 'k-+','linewidth',2);


D = min(dim)-1:max(dim)+1;
bound_bias = theta_0 * D./(n.^(s/2));
bound_bias_2 = theta_0 * D./n;

plot(D, bound_bias,'m--','linewidth',2);
plot(D, bound_bias_2,'k--','linewidth',2);

set(gca,'fontsize',20);

set(gca,'fontsize',20);
xlabel('Dimension (d)');
ylabel('|Bias|');
legend('IB','Plug-in','Adaptive','0.5*d/n^{3.5/2}','0.5*d/n','location', 'northwest')
set(gca,'yminorgrid','off','xminorgrid','off');
%set(gca,'xtick',[32 64 128 256 512 1024 1600],'xlim',[32 1600]);
%set(gca,'ytick',[1e-4 1e-3 1e-2 1e-1], 'ylim',[1e-4 2*1e-1]);

text(64,0.1, 'h(\theta) = \theta^{3.5}, Bias','color','r','fontsize',20,'fontweight','bold');

%% variance plot 
figure; box on;
loglog(dim, var_Bt,'r-o','linewidth',2); hold on; grid on;
loglog(dim, var_Pg, 'b-+','linewidth',2); 
loglog(dim, var_adp, 'k-+','linewidth',2); 


D = min(dim)-1:max(dim)+1;
minimax_2 = (s*(theta_0^(s-1)))^2.*D./n;
plot(D, minimax_2,'k--','linewidth',2);
set(gca,'fontsize',20);

set(gca,'fontsize',20);
xlabel('Dimension (d)');
ylabel('Variance');

legend('IB','Plug-in','Adaptive','C*d/n','location', 'northwest')
set(gca,'yminorgrid','off','xminorgrid','off');
%set(gca,'xtick',[32 64 128 256 512 1024 1600],'xlim',[32 1600]);
%set(gca,'ytick',[0.0001 0.001 0.01],'ylim',[0.0001 0.01]);

text(64,0.1, 'h(\theta) = \theta^{3.5}, Var','color','r','fontsize',20,'fontweight','bold');

%% MSE plot
figure; box on;
loglog(dim, mse_Bt,'r-o','linewidth',2); hold on; grid on;
loglog(dim, mse_Pg, 'b-+','linewidth',2); 
loglog(dim, mse_adp, 'k-+','linewidth',2); 


D = min(dim)-1:max(dim)+1;
minimax_2 = (1.0*s*(theta_0^(s-1)))^2.*D./n; % \|\nabla f(\theta)\|^2/n
loglog(D, minimax_2,'k--','linewidth',2);

set(gca,'fontsize',20);
xlabel('Dimension (d)');
ylabel('MSE');

legend('IB','Plug-in','Adaptive','C*d/n','location', 'northwest')
set(gca,'yminorgrid','off','xminorgrid','off');


%set(gca,'xtick',[32 64 128 256 512 1024 1600],'xlim',[32 1600]);
%set(gca,'ytick',[1e-4 1e-3 1e-2],'ylim',[0.0001 0.03]);
text(64,0.1, 'h(\theta) = \theta^{3.5}, MSE','color','r','fontsize',20,'fontweight','bold');
















