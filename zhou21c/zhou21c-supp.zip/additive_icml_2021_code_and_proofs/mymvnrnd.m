function Z = mymvnrnd(MU,COV,n)

p = length(MU);

Z = randn(n,p)*COV^0.5+ones(n,1)*MU;



