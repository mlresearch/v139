function [output, pd] = iter_boostrap(k,para,nl)
    dim = length(para);
    boost = randn(dim,k)*nl;
    pd = prod(boost,2)';
    uni = rand(k,1);
    add = boost*uni;
    output = para+add';
end
