function out = gpr_mu_predictor(gpr,x)
% Copyright (c) by Jonas Umlauft (TUM) under BSD License 
% Last modified: Armin Lederer 2021-06
    n = size(x,2);
    out = zeros(1,n);
    for i=1:n
        out(i) = gpr.predict(x(:,i));
    end
end

