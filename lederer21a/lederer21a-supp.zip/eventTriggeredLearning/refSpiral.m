function out = refSpiral(t)
% Copyright (c) by Jonas Umlauft (TUM) under BSD License 
% Last modified: Armin Lederer 2021-06
    Trise = 100;
    stepness = 0.1;
    rin = 1; 
    rout = 10;
    out = (rin+(rout-rin)*sigmf(t,[stepness,Trise])) .*sin(0.5*t);
end