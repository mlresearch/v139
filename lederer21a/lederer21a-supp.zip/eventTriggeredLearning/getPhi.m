function phi = getPhi(t,x,p,reffun,r_min)
%getPhi Computes Phi=sigma(x)/r(x)
%   where x sigma is GP standard deviation and r = [lambda 1](x-xd)
% In:
%   t           1 x N   time
%   x           E x N   state
%   p
%    .lamd      E-1 x 1 filtering gain
%    .brsfun    @fun    uniform error bound
%   reffun      @fun    reference trajectory
%   r_min       1 x 1   scaling factor for desired performance
% Out:
%      phi      N x 1   ratio sigma/r
%
% Copyright (c) by Jonas Umlauft (TUM) under BSD License 
% Last modified: Armin Lederer 2021-06

[sigx,sig0] = p.brsfun(x);
[nDof,Nx] = size(sigx);
E = size(x,1);
degr = E/nDof;
phi=zeros(nDof,Nx);
if ~iscell(reffun), reffun = {reffun}; end
for ndof = 1:nDof
    xd = reffun{ndof}(t);
    r = sqrt(sum((x((ndof-1)*degr+1:ndof*degr,:)-xd(1:end-1,:)).^2,1));
    phi(ndof,:) = min((norm(p.lamd)*2*sigx(ndof,:)-r),...
        r-norm(p.lamd)*2*sig0(ndof,:)*r_min);

end
end

