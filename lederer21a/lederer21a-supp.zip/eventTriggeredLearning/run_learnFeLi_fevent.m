% Copyright (c) by Jonas Umlauft (TUM) under BSD License 
% Last modified: Armin Lederer 2021-06
clear;clc;  rng default; close all;
addpath(genpath('./mtools'));

rng(1);

plot_inter = 0;   plot2tex = 1;
setname = 'fevent_distributedGP'; % fevent_fullGP % fevent_distributedGP

%% Set Parameters
disp('Setting parameters...')
% Basic Parameters
Tsim = 200;         % Simulation time
sn = 1e-3;         % Observation noise (std deviation)
E = 2;             % State space dimension
x0 = [7; -5];       % initial State
r_min = 1e-3;      % precision bound
dt = 1e-3;           % Time triggered update interval

% Reference trajectory

reffun = @(t) refGeneral(t,E+1,@(tau) refSpiral(tau));    % Cricle
nDof = 1;

% Controller gains and beta value
pFeLi.lam = ones(E-1,1);
pFeLi.kc = 10;
A = [0,1; -pFeLi.kc*pFeLi.lam, -pFeLi.kc];
P = are(A,zeros(size(A)),eye(2));
pFeLi.lamd=P(:,end);

% Define system dynamics
pdyn.f = @(x) 1-sin(x(1,:)) + 0.5*sigmf(x(2,:),[0.1 0]);
pdyn.g = @(x) 1;
pFeLi.g = pdyn.g;

% GP learning parameters
odeopt = odeset('RelTol',1e-9,'AbsTol',1e-7);


% Visualization
Nte = 1e4; XteMin = -11; XteMax = 11;
Ndte = floor(nthroot(Nte,E)); % Nte = Ndte^E;
Xte = ndgridj(XteMin, XteMax,Ndte*ones(E,1)) ;


%% Learn fGP
disp('Setup LoG-GP...')
if contains(setname,'distributed')
    gpr = moe_log_gp(E,100,10000, [XteMin, XteMax]); 
else
    gpr = moe_log_gp(E,10000,1, [XteMin, XteMax]); 
end
for ndof = 1:nDof
    gpr.Lf(ndof) = max(sqrt(sum(gradestj(@(x) nth_element({ndof,1:size(x,2)},pdyn.f,x),Xte).^2,1)));
end
%additional parameters
gpr.divMethod  = 2; %1: median, 2: mean, 3: mean(max, min)
gpr.wo = 100; %overlapping factor
%squared exponential SE hyperparameters
gpr.sigmaF = 5;
gpr.sigmaN = sn;
gpr.lengthS = 0.5*ones(E,1); %for ARD_SE a xSize x 1 vector // for SE a scalar
gpr.delta = 0.05;
gpr.tau = 1e-10;
%% Simulating Adaptive Controller
disp('Simulating Controller...')
% Initialization
X = x0; T = 0; Xtr = []; Ytr = [];  Tevent = []; t = 0; Phi = 0; tpred= [];
tStart = tic;
eventfun = @(t,x) 1;%always sample in the first time step
pFeLi.f = @(x) 0;%no prior model
ctrl = @(t,x) ctrlFeLi(t,x,pFeLi,reffun);
    while T(end) < Tsim
        u = ctrl(T(end),X(:,end));
        dyn = @(t,x) dynAffine(t,x,u,pdyn);
        [t,x] = ode45(dyn,[T(end) T(end)+dt],X(:,end),odeopt);
        X = [X,x(end,:)'];
        T = [T, t(end)];
        multTrig=0;
        
        tic;
        Phi = [Phi, eventfun(T(end),X(:,end))];
        tpred = [tpred, toc];
        while eventfun(T(end),X(:,end))>=0 %sample a little earlier due to discretization
            % add data until the triggering condition is not satisfied
            disp(['Event triggered, added at t = ',num2str(t(end))]);
            if(multTrig>0)
                warning('Triggered multiple times during the same time instance.');
            end
            Tevent = [Tevent T(end)];
            Xtr = [Xtr X(:,end)];
            Ytr = [Ytr pdyn.f(X(:,end)) + sn*randn(1)];
            gpr.update(Xtr(:,end),Ytr(:,end));
            pFeLi.f = @(x) gpr_mu_predictor(gpr,x);
            pFeLi.brsfun = @(x) gpr_brs_predictor(gpr,x);
            eventfun = @(t,x) eventPhi(t,x,reffun,pFeLi,5); %default trigger condition
            ctrl = @(t,x) ctrlFeLi(t,x,pFeLi,reffun);
            multTrig = multTrig + 1;
        end
        eventfun = @(t,x) eventPhi(t,x,reffun,pFeLi,2);%early trigger condition
    end
comptime = toc(tStart);
MemoryUsed = monitor_memory_whos();
%% Viualization and Saving
disp('Plotting results and saving...')
disp(['Collected a total of ', num2str(size(Xtr,2)),' training points.']);
disp(['Computation Time: ', num2str(comptime),'s,  Memory Used: ', num2str(MemoryUsed),'MB']);
vis_learnFeLi_f;
disp('Pau');



