% Copyright (c) by Jonas Umlauft (TUM) under BSD License 
% Last modified: Armin Lederer 2021-06

% Plot trajectories
figure;  hold on;
xd = reffun(T); xlabel('x1'); ylabel('x2');
plot(X(1,:),X(2,:),'r');
plot(xd(1,:),xd(2,:),'k--');
plot(Xtr(1,:),Xtr(2,:),'ro');
xlabel('x_1'); ylabel('x_2'); title('system and reference trajectories');


% Plot tracking error
norme = sqrt(sum((X-xd(1:E,:)).^2,1));
figure;  
semilogy(T,norme);
hold on; 
normeEvent = norme(any(Tevent'==T));
semilogy(unique(Tevent),normeEvent,'ro');
xlabel('t'); ylabel('|e|'); title('tracking error');
disp(['Minimal tracking error ', num2str(min(norme))]);

% Plot ratio between updating/prediction and inter-event time
figure();
relttr = gpr.ttrain./([Tevent(2:end),T(end)]-Tevent);
reltpred = tpred(round(Tevent*1000))./([Tevent(2:end),T(end)]-Tevent);
semilogy(Tevent,relttr);
hold on;
semilogy(Tevent,reltpred);
xlabel('t'); ylabel('ratio'); title('computation-inter-event time ratio');
legend('updates', 'predictions');
disp(['Maximum ratio updates ', num2str(max(relttr))]);
disp(['Maximum ratio predictions ', num2str(max(reltpred))]);



