function  [value,isterminal,direction]  = eventPhi(t,x,reffun,p,r_min)
%EVENTPHI ode event to stop simulation if variance of GP is too large, 
%   more formally, the event is triggered if
%            Phi = sigma/r  >   kc/beta; 
%   The event is also triggered if |r|<r_min
% IN: 
%   t        1 x 1       time
%   x        E x 1       state
%   reffun   @fun        reference function 
%   p. 
%     kc     1 x 1       control gain
%     lamd   E-1 x 1     filtering gain
%     brsfun @fun        uniform error bound
%   r_min    1 x 1       scaling factor
% OUT: 
%  see ode event documentation
% Copyright (c) by Jonas Umlauft (TUM) under BSD License 
% Last modified: Armin Lederer 2021-06

n = size(x,2);
nDof = 1;
value(1:nDof,:) =  getPhi(t,x,p,reffun,r_min);
isterminal = ones(nDof,n);
direction = zeros(nDof,n);
end

