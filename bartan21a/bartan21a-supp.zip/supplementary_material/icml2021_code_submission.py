# import packages 
import numpy as np
import cvxpy as cp
import time
import sys

uci_dataset_name = sys.argv[1]
m = int(sys.argv[2])
beta = float(sys.argv[3])

######## Load dataset ########
directory = "datasets/"
A = np.load(directory+"A_{}_train.npy".format(uci_dataset_name))
y = np.load(directory+"y_{}_train.npy".format(uci_dataset_name))
A_test = np.load(directory+"A_{}_test.npy".format(uci_dataset_name))
y_test = np.load(directory+"y_{}_test.npy".format(uci_dataset_name))

n, d = A.shape
print('Dataset dimensions:')
print(A.shape, y.shape, A_test.shape, y_test.shape)



######## Solve the convex problem using cvxpy ########
loss_type = 'squared' #'squared' or 'l1_loss'

Z = cp.Variable((2*d,2*d), symmetric=True)
rho = cp.Variable()

yhat = cp.Variable((n,1))
constraints = []

constraints = constraints + [Z >> 0]
constraints = constraints + [cp.diag(Z) == rho]

for j in range(n):
    xj = A[j:j+1,:].T
    constraints = constraints + [yhat[j] == xj.T @ Z[:d,d:] @ xj]

if loss_type == 'squared':
    objective = 0.5 * cp.sum_squares(y-yhat)
elif loss_type == 'l1_loss':
    objective = cp.norm(y-yhat, 1)

objective += (beta * d * rho)

prob = cp.Problem(cp.Minimize(objective), constraints)

start_time = time.time()
scs_max_iters = 100000
prob.solve(warm_start=False, max_iters=scs_max_iters, eps=1e-6)
end_time = time.time()
print("time elapsed: " + str(end_time - start_time))

# Print SDP results
print("Cvxpy solver status:", prob.status)
print("The optimal value of the SDP is", prob.value)



def sampling_method(Z_star, rho_star, num_neurons):
    m = num_neurons
    gamma = np.log(1+np.sqrt(2))
    
    Q = cp.Variable((2*d,2*d), symmetric=True)
    constraints = [Q >> 0] + [cp.diag(Q) == 1]
    objective = cp.norm(Q[:d, d:] - np.sin(gamma*Z_star[:d,d:]/rho_star), "fro")
    prob = cp.Problem(cp.Minimize(objective), constraints)
    prob.solve()

    sampled = np.random.multivariate_normal(mean=np.zeros(2*d), cov=Q.value, size=m).T
    sampled_signs = np.sign(sampled)
    first_layer_weights_u = sampled_signs[:d,:]
    first_layer_weights_v = sampled_signs[d:,:]
    second_layer_weights = np.ones((m,1)) / (m*gamma) * rho_star
    
    return first_layer_weights_u, first_layer_weights_v, second_layer_weights



######## Sample ########
first_layer_u, first_layer_v, second_layer_weights = sampling_method(Z.value, rho.value, m)
y_pred = np.matmul(np.matmul(A, first_layer_u)*np.matmul(A, first_layer_v), second_layer_weights) * np.pi / 2
y_pred_test = np.matmul(np.matmul(A_test, first_layer_u)*np.matmul(A_test, first_layer_v), second_layer_weights) * np.pi / 2

# compute the nonconvex cost and accuracies
reg_term = np.sum(np.abs(second_layer_weights)) * beta * d

if loss_type == 'squared':
	pred_term = 0.5*np.sum((y_pred - y)**2)
	pred_term_test = 0.5*np.sum((y_pred_test - y_test)**2)
elif loss_type == 'l1_loss':
	pred_term = np.sum(np.abs(y_pred - y))
	pred_term_test = np.sum(np.abs(y_pred_test - y_test))

noncvx_cost = pred_term + reg_term
noncvx_cost_test = pred_term_test + reg_term
        
ypred = y_pred > 0.5
ypred_test = y_pred_test > 0.5

training_acc = np.sum(y == ypred) / y.shape[0]
test_acc = np.sum(y_test == ypred_test) / y_test.shape[0]

print('\n===== Results: =====')
print('  cost = {}\n  cost (test) = {}\n  training accuracy = {}\n  test accuracy = {}'.format(noncvx_cost, noncvx_cost_test, training_acc, test_acc))
