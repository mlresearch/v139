**********   Requirements:   **********

- The code requires Python3.
- Datasets: The UCI datasets used are included in the datasets folder (uploaded with the supplementary material).
- The required python packages are: numpy, cvxpy.
- The folder 'datasets' must be in the same directory as the python script.


**********   How to run the python script   **********

The code can be run using the following command:

python3 icml2021_code_submission.py dataset_name m beta

m is the number of neurons and beta is the regularization coefficient.
Dataset options: "breastcancer", "creditapproval" "ionosphere"

A few examples:
python3 icml2021_code_submission.py creditapproval 5000 1.0
python3 icml2021_code_submission.py breastcancer 1000 0.1