library(lpSolve)

true_function_num<-1	#1:Booth, 2:Matyas, 3:McCormick, 4:Styblinski-Tang   
reference_num<-1		   
AF_num<-1			#1:Proposed1, 2:Proposed2
gamma<-0			#0, 10^(-0.5), 10^(-1), 10^(-2), 10^(-3), 10^(-4) 
grid_num<-50		
rounds<-300
repeat_num<-50




######### probability density function of standard normal distribution
st_norm<-function(x,sigma2)
{
(2*pi*sigma2)^(-1/2)*exp(-x^2/(2*sigma2))
}
########################################################################   
   

######### true function #################################################  
if(true_function_num==1)
{
true_function<-function(x,y){
(x+2*y-7)^2+(2*x+y-5)^2
}
}

if(true_function_num==2)
{
true_function<-function(x,y){
0.26*(x^2+y^2)-0.48*x*y
}
}

if(true_function_num==3)
{
true_function<-function(x,y){
sin(x+y)+(x-y)^2-1.5*x+2.5*y+1
}
}

if(true_function_num==4)
{
true_function<-function(x,y){
(x^4-16*x^2+5*x)/2+(y^4-16*y^2+5*y)/2 -4000
}
}
########################################################################   


######### parameter setting ############################################  
if(true_function_num==1 && reference_num==1)
{
h<- 100
alpha<-0.62
sigman<- 10^(-4)
sigmaf<-1300^2
L<- 4
beta<-2
epsilon<-0.65
L1<- -10
U1<- 10
L2<- -10
U2<- 10
}

if(true_function_num==2 && reference_num==1)
{
h<- 5
alpha<-0.53
sigman<- 10^(-4)
sigmaf<-50^2
L<- 4
beta<-2
epsilon<-0.15
L1<- -10
U1<- 10
L2<- -10
U2<- 10
}

if(true_function_num==3 && reference_num==1)
{
h<- 1
alpha<-0.57
sigman<- 10^(-4)
sigmaf<-20^2
L<- 1
beta<-3
epsilon<-0.25
L1<- -1.5
U1<- 4
L2<- -3
U2<- 4
}

if(true_function_num==4 && reference_num==1)
{
h<- -3990
alpha<-0.61
sigman<- 10^(-4)
sigmaf<-2000^2
L<- 3
beta<-2
epsilon<-0.2
L1<- -10
U1<- 10
L2<- -10
U2<- 10
}

if(true_function_num==1 && reference_num==2)
{
h<- 100
alpha<-0.5
sigman<- 10^(-4)
sigmaf<-1300^2
L<- 4
beta<-2
epsilon<-0.65
L1<- -10
U1<- 10
L2<- -10
U2<- 10
}

if(true_function_num==2 && reference_num==2)
{
h<- 5
alpha<-0.53
sigman<- 10^(-4)
sigmaf<-50^2
L<- 4
beta<-2
epsilon<-0.15
L1<- -10
U1<- 10
L2<- -10
U2<- 10
}

if(true_function_num==3 && reference_num==2)
{
h<- 1
alpha<-0.59
sigman<- 10^(-6)
sigmaf<-20^2
L<- 1
beta<-3
epsilon<-0.15
L1<- -1.5
U1<- 4
L2<- -3
U2<- 4
}

if(true_function_num==4 && reference_num==2)
{
h<- -3990
alpha<-0.61
sigman<- 10^(-4)
sigmaf<-2000^2
L<- 3
beta<-2
epsilon<-0.2
L1<- -10
U1<- 10
L2<- -10
U2<- 10
}

########################################################################   





######### reference distribution #######################################  
if(reference_num==1)
{
ref_p<- (numeric(grid_num)+1)/grid_num
}

if(reference_num==2)
{
ref_p<- st_norm(seq(L2,U2,length=grid_num),(numeric(grid_num)+10))/sum(st_norm(seq(L2,U2,length=grid_num),(numeric(grid_num)+10)))
}
########################################################################   



x<- seq(L1,U1,length=grid_num)	#design variable
w<- seq(L2,U2,length=grid_num)	#environmental  variable
result_mat_H_F<-  matrix(numeric(repeat_num*rounds),repeat_num,rounds)
ALLinput<-   cbind(x%x%(w*0+1),(x*0+1)%x%w)
all_input<-ALLinput
all_input_x<- all_input[,1]
all_input_y<- all_input[,2]



######### compute true DRPTR measure ###################################
true_function_mat<- outer(x,w,true_function)
true_function_mat_above<-  (true_function_mat>h)*1

ref_p_above<-as.vector(true_function_mat_above%*%ref_p)


f1<- (numeric(grid_num)+1)%x%c(1,-1)
D<-diag(2*grid_num)
f2<-numeric(2*grid_num)+1
f3<- diag(grid_num)%x% t(c(1,-1))

f.con <- rbind(f1,D,f2,f3,f3)
f.dir <- c("==", 
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
"<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">="
)
f.rhs <- c(numeric((2*grid_num)+1),epsilon,(numeric(grid_num)+1-ref_p),(numeric(grid_num)-ref_p))


c_resu<-numeric(grid_num)
for(i in 1:grid_num)
{
f.obj <-true_function_mat_above[i,]%x%c(1,-1)


resu<-lp ("min", f.obj, f.con, f.dir, f.rhs)
c_resu[i]<- resu$objval
}

true_dist_ptr<-c_resu+ref_p_above

TRUE_P<-  c(1:length(x))[true_dist_ptr>alpha]
TRUE_N<-  c(1:length(x))[true_dist_ptr<=alpha]

########################################################################   


######### definition (function) ########################################
compute_kernel<- function(x,y)
{
sqrt(sigmaf)*exp(-(x-y)^2/L)
}


compute_kernel2<- function(x1,y1,x2,y2)
{
sigmaf*exp(-((x1-x2)^2+(y1-y2)^2)/L)
}


compute_straddle<-function(x)
{
  min(x[2]-alpha,alpha-x[1])
}


compute_pre_P<-function(x)
{
a<-0
	if(length(x)<0.1)
	{
	a<-0
	} else {
	a<-     length(intersect(x,TRUE_P))/length(x)
	}
a
}


compute_rec_P<-function(x)
{
   length(intersect(x,TRUE_P))/length(TRUE_P)
}


compute_pre_N<-function(x)
{
a<-0
	if(length(x)<0.1)
	{
	a<-0
	} else {
	a<-     length(intersect(x,TRUE_N))/length(x)
	}
a
}


compute_rec_N<-function(x)
{
   length(intersect(x,TRUE_N))/length(TRUE_N)
}


compute_accuracy<-function(x,y)
{
(length(intersect(x,TRUE_P) )+length(intersect(y,TRUE_N) ))/(length(TRUE_P)+length(TRUE_N))
}

########################################################################   



######### definition (acquisition function) ########################################
compute_originalMILE<-function(t)
{

new_input<- all_input[t,]
new_cov<- compute_kernel2(all_input_x,all_input_y,new_input[1],new_input[2])-Kvec_invK_tKvec[,t]
new_sqrt<- sqrt(abs(post_var-(new_cov)^2/(post_var[t]+sigman)))
sum(pnorm(sqrt((post_var[t]+sigman))/abs(new_cov)*(post_mean-beta*new_sqrt-h))*(((dist_ptr_lcb<alpha)*(dist_ptr_ucb>alpha))%x%(numeric(grid_num)+1)))
}



compute_MILE<-function(t)
{

new_input<- all_input[t,]
new_cov<- compute_kernel2(all_input_x,all_input_y,new_input[1],new_input[2])-Kvec_invK_tKvec[,t]
new_sqrt<- sqrt(abs(post_var-(new_cov)^2/(post_var[t]+sigman)))
new_coef<-new_cov/sqrt(post_var[t]+sigman)
new_coef[new_coef==0]<-10^(-30)
new_coef<- matrix(new_coef,grid_num,grid_num)

inter<- matrix((h+beta*new_sqrt - post_mean),grid_num,grid_num)/new_coef

result_h<-numeric(grid_num)
for(j in 1:grid_num)
{
	if(dist_ptr_lcb[j]>=alpha)
	{
	result_h[j]<-1
	} else {
	a<-inter[,j]
	b<-new_coef[,j]

	b2<- b[order(a)]
	a2<-sort(a)
	aminus<- c(-Inf,a2) 
	aplus<- c(a2,Inf)
	pro<- pnorm(aplus)-pnorm(aminus)
	result_h2<- numeric(grid_num+1)
	cupro<-pnorm(aplus)
	minnum<- min(c(1:(grid_num+1))[cupro>0.005])
	maxnum<- min(c(1:(grid_num+1))[cupro>0.995])

	c<- a2[1]-0.01
	c1<-  ((post_mean[((j-1)*grid_num+1):(j*grid_num)]+c*b-beta*new_sqrt[((j-1)*grid_num+1):(j*grid_num)])>h)*1
	sumc1refp<-sum(c1*ref_p)
		if(sumc1refp<=alpha)
		{
		result_h2[1]<- -1
		} else {
			if(1<minnum||1>maxnum)
			{
			result_h2[1]<- -1
			} else {
			f.obj <-c1%x%c(1,-1)


			resu<-lp ("min", f.obj, f.con, f.dir, f.rhs)
			result_h2[1]<- resu$objval+sumc1refp

			}
		}


	for(k in 2:grid_num)
	{
	c<- (a2[k]+a2[(k-1)])/2
	c1<-  ((post_mean[((j-1)*grid_num+1):(j*grid_num)]+c*b-beta*new_sqrt[((j-1)*grid_num+1):(j*grid_num)])>h)*1
	sumc1refp<-sum(c1*ref_p)
		if(sumc1refp<=alpha)
		{
		result_h2[k]<- -1
		} else {
		if(k<minnum||k>maxnum)
		{
		result_h2[k]<- -1
		} else {
		f.obj <-c1%x%c(1,-1)


		resu<-lp ("min", f.obj, f.con, f.dir, f.rhs)
		result_h2[k]<- resu$objval+sumc1refp

		}
	}

 
	}
c<- a2[grid_num]+0.01
c1<-  ((post_mean[((j-1)*grid_num+1):(j*grid_num)]+c*b-beta*new_sqrt[((j-1)*grid_num+1):(j*grid_num)])>h)*1

sumc1refp<-sum(c1*ref_p)
if(sumc1refp<=alpha)
{
result_h2[(grid_num+1)]<- -1
} else {
	if((grid_num+1)<minnum||(grid_num+1)>maxnum)
	{
	result_h2[(grid_num+1)]<- -1
	} else {
	f.obj <-c1%x%c(1,-1)


	resu<-lp ("min", f.obj, f.con, f.dir, f.rhs)
	result_h2[(grid_num+1)]<- resu$objval+sumc1refp

	}
}


result_h[j]<- sum((result_h2>alpha)*pro)
}
}
sum(result_h)
}

########################################################################   






for(ww in 1:repeat_num)
{
set.seed(ww)

new_x_num<- sample( c(1:length(x)),1)
new_w_num<- sample( c(1:length(w)),1)

newx<-  x[new_x_num]
neww<- w[new_w_num]

newy<- true_function(newx,neww)+rnorm(1,0,sqrt(sigman))

C_X<-c()
C_W<-c()
C_Y<-c()
C_X_num<-c()
C_W_num<-c()
	for(www in 1: rounds)
	{
	C_X<-c(C_X,newx)
	C_W<-c(C_W,neww)
	C_Y<-c(C_Y,newy)
	C_X_num<-c(C_X_num,new_x_num)
	C_W_num<-c(C_W_num,new_w_num)

	
	K<-outer(C_X,C_X,compute_kernel)*outer(C_W,C_W,compute_kernel)
	C<- K+ sigman*diag(www)
	invC<- solve(C)
	kerv1<- outer(x,C_X,compute_kernel)
	kerv2<- outer(w,C_W,compute_kernel)
	kerV<- kerv1%x%(w*0+1)*(x*0+1)%x%kerv2

	Kvec_invK_tKvec<- kerV%*%invC%*%t(kerV)

	post_mean<-  as.vector(kerV%*%invC%*%C_Y)
	post_var<- abs(sigmaf-rowSums((kerV%*%invC)*kerV))
	
	ucb<- post_mean+beta*sqrt(post_var)
	lcb<- post_mean-beta*sqrt(post_var)

	ucb_mat<- t(matrix(ucb,grid_num,grid_num))
	lcb_mat<- t(matrix(lcb,grid_num,grid_num))

	ucb_mat_above<- (ucb_mat>h)*1
	lcb_mat_above<- (lcb_mat>h)*1

	result_ucb<-numeric(grid_num)
	for(i in 1:grid_num)
	{
	f.obj <-ucb_mat_above[i,]%x%c(1,-1)


	resu<-lp ("min", f.obj, f.con, f.dir, f.rhs)
	result_ucb[i]<- resu$objval
	}

	dist_ptr_ucb<-result_ucb+as.vector(ucb_mat_above%*%ref_p)

	result_lcb<-numeric(grid_num)
	for(i in 1:grid_num)
	{
	f.obj <-lcb_mat_above[i,]%x%c(1,-1)


	resu<-lp ("min", f.obj, f.con, f.dir, f.rhs)
	result_lcb[i]<- resu$objval
	}

	dist_ptr_lcb<-result_lcb+as.vector(lcb_mat_above%*%ref_p)


st<-apply( cbind(dist_ptr_lcb,dist_ptr_ucb),1,compute_straddle)	
EST_P<-   c(1:length(x))[dist_ptr_lcb>=alpha]
EST_N<-   c(1:length(x))[dist_ptr_ucb<alpha]

EST_pre_P<-compute_pre_P(EST_P)
EST_rec_P<-compute_rec_P(EST_P)
if( (EST_pre_P+EST_rec_P)<10^(-10) )
{
result_mat_H_F[ww,www]<-0
} else {
result_mat_H_F[ww,www]<- 2*(EST_pre_P*EST_rec_P)/(EST_pre_P+EST_rec_P)
}




if(AF_num==1)
{
mile<- apply( matrix(c(1:(grid_num*grid_num))),1,compute_MILE) -sum(dist_ptr_lcb>=alpha)
mile2<- apply(cbind(mile,sqrt(post_var)*gamma),1,max)
max_rmile_num<- order(mile2,decreasing=T)[1]
new_x_num<- ceiling(max_rmile_num/grid_num)
new_w_num<- max_rmile_num-(new_x_num-1)*grid_num
}



if(AF_num==2)
{
mile<- apply( matrix(c(1:(grid_num*grid_num))),1,compute_MILE) -sum(dist_ptr_lcb>=alpha)
fMILE<- apply (matrix(c(1:(grid_num*grid_num))),1,compute_originalMILE)-sum(    ((dist_ptr_lcb<alpha)*(dist_ptr_ucb>alpha))%x%(numeric(grid_num)+1)* (lcb   >(h)))
mile2<- apply(cbind(mile,fMILE*gamma),1,max)

max_rmile_num<- order(mile2,decreasing=T)[1]
new_x_num<- ceiling(max_rmile_num/grid_num)
new_w_num<- max_rmile_num-(new_x_num-1)*grid_num
}

newx<-  x[new_x_num]
neww<- w[new_w_num]

newy<- true_function(newx,neww)+rnorm(1,0,sqrt(sigman))

	}

}

write.table(result_mat_H_F,"result_mat_H_F.txt")




