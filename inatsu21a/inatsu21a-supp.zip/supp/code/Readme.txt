#Active Learning for Distributionally Robust Level-Set Estimation

These are R implements used in the experiments in the above paper.

The details of the files in each folder are as follows:


#Figure1
- Correct_PTR.R: Calculate the precision and recall of the PTR (correct) in Figure 1.
- Incorrect_PTR.R: Calculate the precision and recall of the PTR (incorrect) in Figure 1.
- DRPTR.R: Calculate the precision and recall of the DRPTR in Figure 1.
- Target_function.R: Plot the left figure in Figure 1.
- Precision.R: Plot the central figure in Figure 1.
- Recall.R: Plot the right figure in Figure 1.


#Synthetic data experiments
- L1setting.R: Run the synthetic experiments with the L1-norm setting in section 5.1.
- L2setting.R: Run the synthetic experiments with the L2-norm setting in Appendix B.1.

True functions, reference distributions and acquisition functions can be changed by changing the values of true_function_num, reference_num and AF_num, respectively.


#Computation time experiments
- proposed.R: Run the computation time experiments with the L1-norm setting in section 5.2.

True functions and computation methods can be changed by changing the values of true_function_num and computation_method, respectively.

#Infection simulations
- n_infect.txt: The true infection function calculated by the SIR model.
- L1setting.R: Run the infection simulation experiments with the L1-norm setting in section 5.3.
- L2setting.R: Run the infection simulation experiments with the L2-norm setting in Appendix B.1.

Reference distributions and acquisition functions can be changed by changing the values of reference_num and AF_num, respectively.


#Hyperparameter sensitivity in the proposed acquisition function
- L1_Uniform_setting.R: Run the hyperparameter sensitivity experiments with the L1-norm setting in Appendix B.3.

True functions, acquisition function and hyper parameters can be changed by changing the values of true_function_num, AF_num and gamma, respectively.

