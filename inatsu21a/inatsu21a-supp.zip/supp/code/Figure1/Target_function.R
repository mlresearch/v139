library(lpSolve)



h<- 100
epsilon<-0.25
grid_num<-50
alpha<-0.65

L1<- -10
U1<- 10
L2<- -10
U2<- 10


st_pdf<-function(x,mu,sigma2)
{
(2*pi*sigma2)^(-1/2)*exp(-(x-mu)^2/(2*sigma2))
}



########### probability (density) function ##########

ref_p<- (numeric(grid_num)+1)/grid_num #reference (correct) probability



st_pdf<-function(x,mu,sigma2)			#pdf of standard normal distribution
{
(2*pi*sigma2)^(-1/2)*exp(-(x-mu)^2/(2*sigma2))
}


#############function###############
true_function<-function(x,y){
(x+2*y-7)^2+(2*x+y-5)^2
}







x<- seq(L1,U1,length=grid_num)
w<- seq(L2,U2,length=grid_num)

true_function_mat<- outer(x,w,true_function)
true_function_mat_above<-  (true_function_mat>h)*1


ref_p2<-0.5*st_pdf(x,-5,1)+0.5*st_pdf(x,5,1)	#incorrect probability
ref_p2<- ref_p2/sum(ref_p2)

ref_p_above<-as.vector(true_function_mat_above%*%ref_p)
ref_p2_above<-as.vector(true_function_mat_above%*%ref_p2)



f1<- (numeric(grid_num)+1)%x%c(1,-1)
D<-diag(2*grid_num)
f2<-numeric(2*grid_num)+1
f3<- diag(grid_num)%x% t(c(1,-1))

f.con <- rbind(f1,D,f2,f3,f3)
f.dir <- c("==", 
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
"<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">="
)
f.rhs <- c(numeric((2*grid_num)+1),epsilon,(numeric(grid_num)+1-1/grid_num),(numeric(grid_num)-1/grid_num))


result_lp<-numeric(grid_num)
for(i in 1:grid_num)
{
f.obj <-true_function_mat_above[i,]%x%c(1,-1)


resu<-lp ("min", f.obj, f.con, f.dir, f.rhs)
result_lp[i]<- resu$objval
}

true_dist_ptr<-result_lp+ref_p_above



pdf("Target_function.pdf")
plot(x,ref_p_above,ylim=c(0.2,1),col="black",pch=1,main="Target function", ylab="Probability",cex.lab=1.5,cex.axis=1.5,cex.main=1.5)
par(new=TRUE)
plot(x,ref_p2_above,ylim=c(0.2,1),col="blue",pch=2,main="", ylab="",cex.lab=1.5,cex.axis=1.5,cex.main=1.5)
par(new=TRUE)
plot(x,true_dist_ptr,ylim=c(0.2,1),col="red",pch=3,main="", ylab="",cex.lab=1.5,cex.axis=1.5,cex.main=1.5)
abline(h=alpha,lty=2,col="purple",lwd=2)
legend("bottomleft", legend =c("PTR (correct)","PTR (incorrect)","DRPTR",expression(paste("Threshold ",alpha))), col = c("black","blue","red","purple"), pch=c(1,2,3,-1),lty=c(-1,-1,-1,2),cex=1.5,lwd=2)
dev.off()

