
correct_ptr<- scan("Correct_PTR_H_rec.txt")
incorrect_ptr<- scan("Incorrect_PTR_H_rec.txt")
DRPTR<- scan("DRPTR_H_rec.txt")

pdf("Recall.pdf")
plot(c(1:300),correct_ptr,ylim=c(0,1),col="black",pch=1,main="Recall", xlab="Iteration",ylab="Recall",cex.lab=1.5,cex.axis=1.5,cex.main=1.5,type="l")
par(new=TRUE)
plot(c(1:300),incorrect_ptr,ylim=c(0,1),col="blue",pch=1,main="", xlab="",ylab="",cex.lab=1.5,cex.axis=1.5,cex.main=1.5,type="l")
par(new=TRUE)
plot(c(1:300),DRPTR,ylim=c(0,1),col="red",pch=1,main="", xlab="",ylab="",cex.lab=1.5,cex.axis=1.5,cex.main=1.5,type="l")

legend("bottomright", legend =c("PTR (correct)","PTR (incorrect)","DRPTR"), col = c("black","blue","red"), lty=c(1,1,1),cex=1.5)
dev.off()

