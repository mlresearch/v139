library(lpSolve)



############ parameter ############   
h<- 100
sigmaf<-1300^2
sigman<- 10^(-4)
L<- 4
beta<-2
repeat_num<-100
rounds<-300
epsilon<-0.25
grid_num<-50
alpha<-0.65

L1<- -10
U1<- 10
L2<- -10
U2<- 10


st_pdf<-function(x,mu,sigma2)
{
(2*pi*sigma2)^(-1/2)*exp(-(x-mu)^2/(2*sigma2))
}



########### probability (density) function ##########

ref_p<- (numeric(grid_num)+1)/grid_num #reference (correct) probability



st_pdf<-function(x,mu,sigma2)			#pdf of standard normal distribution
{
(2*pi*sigma2)^(-1/2)*exp(-(x-mu)^2/(2*sigma2))
}


#############function###############
true_function<-function(x,y){
(x+2*y-7)^2+(2*x+y-5)^2
}







x<- seq(L1,U1,length=grid_num)
w<- seq(L2,U2,length=grid_num)

true_function_mat<- outer(x,w,true_function)
true_function_mat_above<-  (true_function_mat>h)*1

ref_p2<-0.5*st_pdf(x,-5,1)+0.5*st_pdf(x,5,1)	#incorrect probability
ref_p2<- ref_p2/sum(ref_p2)
ref_p_above<-as.vector(true_function_mat_above%*%ref_p)
ref_p2_above<-as.vector(true_function_mat_above%*%ref_p2)



f1<- (numeric(grid_num)+1)%x%c(1,-1)
D<-diag(2*grid_num)
f2<-numeric(2*grid_num)+1
f3<- diag(grid_num)%x% t(c(1,-1))

f.con <- rbind(f1,D,f2,f3,f3)
f.dir <- c("==", 
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
"<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
"<=","<=","<=","<=","<=","<=","<=","<=","<=","<=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">=",
">=",">=",">=",">=",">=",">=",">=",">=",">=",">="
)
f.rhs <- c(numeric((2*grid_num)+1),epsilon,(numeric(grid_num)+1-1/grid_num),(numeric(grid_num)-1/grid_num))


result_lp<-numeric(grid_num)
for(i in 1:grid_num)
{
f.obj <-true_function_mat_above[i,]%x%c(1,-1)


resu<-lp ("min", f.obj, f.con, f.dir, f.rhs)
result_lp[i]<- resu$objval
}

true_dist_ptr<-result_lp+ref_p_above

#plot(x,ref_p_above,ylim=c(0.2,1),col="black",pch=1)
#par(new=TRUE)
#plot(x,true_dist_ptr,ylim=c(0.2,1),col="red",pch=2)
#par(new=TRUE)
#plot(x,ref_p2_above,ylim=c(0.2,1),col="blue",pch=3)
#abline(h=alpha,lty=2,col="green")




result_lp<- numeric(grid_num)
for(i in 1:grid_num)
{
zerovec<-numeric(grid_num)
zerovec[1:i]<-1
f.obj <-zerovec%x%c(1,-1)
resu<-lp ("min", f.obj, f.con, f.dir, f.rhs)
result_lp[i]<- resu$objval+(1/grid_num)*i
}
alpha_num<- min(c(1:grid_num)[result_lp>alpha])


compute_kernel<- function(x,y)
{
sqrt(sigmaf)*exp(-(x-y)^2/L)
}

compute_kernel2<- function(x1,y1,x2,y2)
{
sigmaf*exp(-((x1-x2)^2+(y1-y2)^2)/L)
}



resultmat_H_pre<-  matrix(numeric(repeat_num*rounds),repeat_num,rounds)
resultmat_H_rec<-  matrix(numeric(repeat_num*rounds),repeat_num,rounds)




compute_straddle<-function(x)
{
  min(x[2]-alpha,alpha-x[1])
}




TRUE_P<-  c(1:length(x))[ref_p_above>alpha]
TRUE_N<-  c(1:length(x))[ref_p_above<=alpha]


compute_pre_P<-function(x)
{
a<-0
	if(length(x)<0.1)
	{
	a<-0
	} else {
	a<-     length(intersect(x,TRUE_P))/length(x)
	}
a
}


compute_rec_P<-function(x)
{
   length(intersect(x,TRUE_P))/length(TRUE_P)
}



compute_pre_N<-function(x)
{
a<-0
	if(length(x)<0.1)
	{
	a<-0
	} else {
	a<-     length(intersect(x,TRUE_N))/length(x)
	}
a
}


compute_rec_N<-function(x)
{
   length(intersect(x,TRUE_N))/length(TRUE_N)
}

compute_accuracy<-function(x,y)
{
(length(intersect(x,TRUE_P) )+length(intersect(y,TRUE_N) ))/(length(TRUE_P)+length(TRUE_N))
}


ALLinput<-   cbind(x%x%(w*0+1),(x*0+1)%x%w)
all_input<-ALLinput
all_input_x<- all_input[,1]
all_input_y<- all_input[,2]


compute_MILE<-function(t)
{

new_input<- all_input[t,]
new_cov<- compute_kernel2(all_input_x,all_input_y,new_input[1],new_input[2])-Kvec_invK_tKvec[,t]
new_sqrt<- sqrt(abs(post_var-(new_cov)^2/(post_var[t]+sigman)))
new_coef<-new_cov/sqrt(post_var[t]+sigman)
new_coef[new_coef==0]<-10^(-30)
new_coef<- matrix(new_coef,grid_num,grid_num)

inter<- matrix((h+beta*new_sqrt - post_mean),grid_num,grid_num)/new_coef

result<-numeric(grid_num)
for(j in 1:grid_num)
{
	
	a<-inter[,j]
	b<-new_coef[,j]

	b2<- b[order(a)]
	a2<-sort(a)
	aminus<- c(-Inf,a2) 
	aplus<- c(a2,Inf)
	pro<- pnorm(aplus)-pnorm(aminus)
	result2<- numeric(grid_num+1)
	cupro<-pnorm(aplus)
	minnum<- min(c(1:(grid_num+1))[cupro>0.005])
	maxnum<- min(c(1:(grid_num+1))[cupro>0.995])

	c<- a2[1]-0.01
	c1<-  ((post_mean[((j-1)*grid_num+1):(j*grid_num)]+c*b-beta*new_sqrt[((j-1)*grid_num+1):(j*grid_num)])>h)*1
	sumc1refp<-sum(c1*ref_p2)
	result2[1]<- sumc1refp


	for(k in 2:grid_num)
	{
	c<- (a2[k]+a2[(k-1)])/2
	c1<-  ((post_mean[((j-1)*grid_num+1):(j*grid_num)]+c*b-beta*new_sqrt[((j-1)*grid_num+1):(j*grid_num)])>h)*1
	sumc1refp<-sum(c1*ref_p)
	result2[k]<- sumc1refp

	c<- a2[grid_num]+0.01
	c1<-  ((post_mean[((j-1)*grid_num+1):(j*grid_num)]+c*b-beta*new_sqrt[((j-1)*grid_num+1):(j*grid_num)])>h)*1

	sumc1refp<-sum(c1*ref_p2)
	result2[(grid_num+1)]<- sumc1refp

	
	}


result[j]<- sum((result2>alpha)*pro)
}

sum(result)
}




compute_fMILE<-function(t)
{

new_input<- all_input[t,]
new_cov<- compute_kernel2(all_input_x,all_input_y,new_input[1],new_input[2])-Kvec_invK_tKvec[,t]
new_sqrt<- sqrt(abs(post_var-(new_cov)^2/(post_var[t]+sigman)))
sum(pnorm(sqrt((post_var[t]+sigman))/abs(new_cov)*(post_mean-beta*new_sqrt-h))*(((dist_ptr_lcb<alpha)*(dist_ptr_ucb>alpha))%x%(numeric(grid_num)+1)))
}




for(ww in 1:repeat_num)
{
set.seed( ww  )

new_x_num<- sample( c(1:length(x)),1)
new_w_num<- sample( c(1:length(w)),1)

newx<-  x[new_x_num]
neww<- w[new_w_num]

newy<- true_function(newx,neww)+rnorm(1,0,sqrt(sigman))

C_X<-c()
C_W<-c()
C_Y<-c()
C_X_num<-c()
C_W_num<-c()
	for(www in 1: rounds)
	{
	C_X<-c(C_X,newx)
	C_W<-c(C_W,neww)
	C_Y<-c(C_Y,newy)
	C_X_num<-c(C_X_num,new_x_num)
	C_W_num<-c(C_W_num,new_w_num)

	
	K<-outer(C_X,C_X,compute_kernel)*outer(C_W,C_W,compute_kernel)
	C<- K+ sigman*diag(www)
	invC<- solve(C)
	kerv1<- outer(x,C_X,compute_kernel)
	kerv2<- outer(w,C_W,compute_kernel)
	kerV<- kerv1%x%(w*0+1)*(x*0+1)%x%kerv2

	Kvec_invK_tKvec<- kerV%*%invC%*%t(kerV)

	post_mean<-  as.vector(kerV%*%invC%*%C_Y)
	post_var<- abs(sigmaf-rowSums((kerV%*%invC)*kerV))
	
	ucb<- post_mean+beta*sqrt(post_var)
	lcb<- post_mean-beta*sqrt(post_var)

	ucb_mat<- t(matrix(ucb,grid_num,grid_num))
	lcb_mat<- t(matrix(lcb,grid_num,grid_num))

	ucb_mat_above<- (ucb_mat>h)*1
	lcb_mat_above<- (lcb_mat>h)*1

	result_ucb<-numeric(grid_num)
	

	dist_ptr_ucb<-as.vector(ucb_mat_above%*%ref_p2)

	result_lcb<-numeric(grid_num)
	

	dist_ptr_lcb<-as.vector(lcb_mat_above%*%ref_p2)


st<-apply( cbind(dist_ptr_lcb,dist_ptr_ucb),1,compute_straddle)	
EST_P<-   c(1:length(x))[dist_ptr_lcb>=(alpha)]
EST_N<-   c(1:length(x))[dist_ptr_ucb<(alpha)]

EST_pre_P<-compute_pre_P(EST_P)
resultmat_H_pre[ww,www]<-EST_pre_P

EST_rec_P<-compute_rec_P(EST_P)
resultmat_H_rec[ww,www]<-EST_rec_P








mile<- apply( matrix(c(1:(grid_num*grid_num))),1,compute_MILE) -sum(dist_ptr_lcb>(alpha))

fMILE<- apply (matrix(c(1:(grid_num*grid_num))),1,compute_fMILE)-sum(    ((dist_ptr_lcb<alpha)*(dist_ptr_ucb>alpha))%x%(numeric(grid_num)+1)* (lcb   >(h)))
mile2<- apply(cbind(mile,fMILE*gamma),1,max)

max_rmile_num<- order(mile2,decreasing=T)[1]





new_x_num<- ceiling(max_rmile_num/grid_num)



new_w_num<- max_rmile_num-(new_x_num-1)*grid_num



newx<-  x[new_x_num]
neww<- w[new_w_num]

newy<- true_function(newx,neww)+rnorm(1,0,sqrt(sigman))

	}

}

write.table(resultmat_H_pre,"resultmat_H_pre.txt")
write.table(resultmat_H_rec,"resultmat_H_rec.txt")


write(colMeans(resultmat_H_pre),"incorrect_PTR_result_H_pre.txt")
write(colMeans(resultmat_H_rec),"incorrect_PTR_result_H_rec.txt")


