This is an example for FS-SCR on CIFAR-10.
ptorch 1.7.0

train with
"sh fs_train.sh"

evaluate with
"sh fs_eval.sh"