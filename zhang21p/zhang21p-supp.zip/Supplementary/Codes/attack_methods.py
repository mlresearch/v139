import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from models import *
from torch.autograd.gradcheck import zero_gradients
from torch.autograd import Variable
import utils
import math

from utils import softCrossEntropy
from utils import one_hot_tensor, label_smoothing
import ot
import pickle
from center import CenterLoss

device = 'cuda' if torch.cuda.is_available() else 'cpu'


class Attack_None(nn.Module):
    def __init__(self, basic_net, f_c, config):
        super(Attack_None, self).__init__()
        self.train_flag = True if 'train' not in config.keys(
        ) else config['train']
        self.basic_net = basic_net
        self.fc = f_c
        #print(config)

    def forward(self, inputs, targets, attack=None, batch_idx=-1):
        if self.train_flag:
            self.basic_net.train()
            self.fc.train()
        else:
            self.basic_net.eval()
            self.fc.eval()
        outputs_f, fea = self.basic_net(inputs)
        outputs = self.fc(outputs_f)
        return outputs, None, fea


class Attack_PGD(nn.Module):
    # Back-propogate
    def __init__(self, basic_net, c_f, config, attack_net=None):
        super(Attack_PGD, self).__init__()
        self.basic_net = basic_net
        self.fc = c_f
        self.attack_net = attack_net
        self.rand = config['random_start']
        self.step_size = config['step_size']
        self.epsilon = config['epsilon']
        self.num_steps = config['num_steps']
        self.loss_func = torch.nn.CrossEntropyLoss(
            reduction='none') if 'loss_func' not in config.keys(
            ) else config['loss_func']
        self.train_flag = True if 'train' not in config.keys(
        ) else config['train']

        self.box_type = 'white' if 'box_type' not in config.keys(
        ) else config['box_type']

        print(config)

    def forward(self,
                inputs,
                targets,
                attack=True,
                targeted_label=-1,
                batch_idx=0):

        if not attack:
            outputs_f = self.basic_net(inputs)[0]
            outputs = self.fc(outputs_f)
            fea_l = self.basic_net(inputs)[1]
            return outputs, None, fea_l

        if self.box_type == 'white':
            aux_net = pickle.loads(pickle.dumps(self.basic_net))
            fc_net = pickle.loads(pickle.dumps(self.fc))
        elif self.box_type == 'black':
            assert self.attack_net is not None, "should provide an additional net in black-box case"
            aux_net = pickle.loads(pickle.dumps(self.basic_net))
            fc_net = pickle.loads(pickle.dumps(self.fc))
        aux_net.eval()
        fc_net.eval()
        logits_pred_nat_f = aux_net(inputs)[0]
        logits_pred_nat = fc_net(logits_pred_nat_f)
        targets_prob = F.softmax(logits_pred_nat.float(), dim=1)

        num_classes = targets_prob.size(1)

        outputs_f = aux_net(inputs)[0]
        outputs = fc_net(outputs_f)
        targets_prob = F.softmax(outputs.float(), dim=1)
        y_tensor_adv = targets
        step_sign = 1.0

        x = inputs.detach()
        if self.rand:
            x = x + torch.zeros_like(x).uniform_(-self.epsilon, self.epsilon)
        x_org = x.detach()
        loss_array = np.zeros((inputs.size(0), self.num_steps))

        for i in range(self.num_steps):
            x.requires_grad_()
            zero_gradients(x)
            if x.grad is not None:
                x.grad.data.fill_(0)
            aux_net.eval()
            logits = fc_net(aux_net(x)[0])
            loss = self.loss_func(logits, y_tensor_adv)
            loss = loss.mean()
            aux_net.zero_grad()
            loss.backward()

            x_adv = x.data + step_sign * self.step_size * torch.sign(
                x.grad.data)
            x_adv = torch.min(torch.max(x_adv, inputs - self.epsilon),
                              inputs + self.epsilon)
            x_adv = torch.clamp(x_adv, -1.0, 1.0)
            x = Variable(x_adv)

        if self.train_flag:
            self.basic_net.train()
            self.fc.train()
        else:
            self.basic_net.eval()
            self.fc.eval()

        logits_pert = self.fc(self.basic_net(x.detach())[0])
        fea_latent = self.fc(self.basic_net(x.detach())[1])

        return logits_pert, targets_prob.detach(), fea_latent

def get_normalized_vector(d):
    d_abs_max = torch.max(
        torch.abs(d.view(d.size(0), -1)), 1, keepdim=True)[0].view(
            d.size(0), 1)
    #print(d_abs_max.size())
    #print(d.size())
    d = d / (1e-12 + d_abs_max)
    d = d / torch.sqrt(1e-6 + torch.sum(
        torch.pow(d, 2.0), tuple(range(1, len(d.size()))), keepdim=True))
    # print(torch.norm(d.view(d.size(0), -1), dim=1))
    return d

class Attack_FeaScatter(nn.Module):
    def __init__(self, basic_net, f_c, config, attack_net=None):
        super(Attack_FeaScatter, self).__init__()
        self.basic_net = basic_net
        self.fc = f_c
        self.attack_net = attack_net
        self.rand = config['random_start']
        self.step_size = config['step_size']
        self.epsilon = config['epsilon']
        self.num_steps = config['num_steps']
        self.train_flag = True if 'train' not in config.keys(
        ) else config['train']
        self.box_type = 'white' if 'box_type' not in config.keys(
        ) else config['box_type']
        self.ls_factor = 0.1 if 'ls_factor' not in config.keys(
        ) else config['ls_factor']
        print(config)

    def forward(self,
                inputs,
                targets,
                criterion_cent,
                optimizer_centloss,
                W_c,
                attack=True,
                targeted_label=-1,
                batch_idx=0):

        if not attack:
            outputs_f, _ = self.basic_net(inputs)
            outputs = self.fc(outputs_f)
            return outputs, None
        if self.box_type == 'white':
            aux_net = pickle.loads(pickle.dumps(self.basic_net))
            fc_net = pickle.loads(pickle.dumps(self.fc))
        elif self.box_type == 'black':
            assert self.attack_net is not None, "should provide an additional net in black-box case"
            aux_net = pickle.loads(pickle.dumps(self.basic_net))
            fc_net = pickle.loads(pickle.dumps(self.fc))

        aux_net.eval()
        fc_net.eval()
        batch_size = inputs.size(0)
        m = batch_size
        n = batch_size

        #logits_f = aux_net(inputs)[0]
        #logits = fc_net(logits_f)
        #num_classes = logits.size(1)
        #f_fea = aux_net(inputs)[1]
        #dim_fea= f_fea.size()[1]
        #print(dim_fea, '...................')


        #outputs_f = aux_net(inputs)[0]
        #outputs = fc_net(outputs_f)
        #targets_prob = F.softmax(outputs.float(), dim=1)
        #y_tensor_adv = targets
        step_sign = 1.0

        x = inputs.detach()

        x_org = x.detach()
        x = x + torch.zeros_like(x).uniform_(-self.epsilon, self.epsilon)

        if self.train_flag:
            self.basic_net.train()
        else:
            self.basic_net.eval()

        logits_pred_nat_f, fea_nat = aux_net(inputs)
        logits_pred_nat = fc_net(logits_pred_nat_f)

        num_classes = logits_pred_nat.size(1)
        y_gt = one_hot_tensor(targets, num_classes, device)

        loss_ce = softCrossEntropy()

        iter_num = self.num_steps
        #criterion_cent = CenterLoss(num_classes=num_classes, feat_dim=dim_fea, use_gpu=True)
        #optimizer_centloss = torch.optim.SGD(criterion_cent.parameters(), lr=0.5)

        for i in range(iter_num):
            x.requires_grad_()
            zero_gradients(x)
            x_2 = x
            if x.grad is not None:
                x.grad.data.fill_(0)

            logits_pred_f, fea = aux_net(x)
            logits_pred = fc_net(logits_pred_f)

            ot_loss = ot.sinkhorn_loss_joint_IPOT(1, 0.00, logits_pred_nat,
                                                  logits_pred, None, None,
                                                  0.01, m, n)

            aux_net.zero_grad()
            adv_loss = ot_loss
            adv_loss.backward(retain_graph=True)
            x_adv = x.data + self.step_size * torch.sign(x.grad.data)
            x_adv = torch.min(torch.max(x_adv, inputs - self.epsilon),
                              inputs + self.epsilon)
            x_adv = torch.clamp(x_adv, -1.0, 1.0)
            x = Variable(x_adv)

            for ii in range(3):
                logits_pred_f_2, fea_2 = aux_net(x_2)
                logits_pred_2 = fc_net(logits_pred_f_2)
                fea_sum_2 = logits_pred_2-logits_pred_nat
                loss_cent = criterion_cent(fea_sum_2, targets)

                aux_net.zero_grad()
                adv_loss_2 = loss_cent
                adv_loss_2.backward(retain_graph=True)
                x_adv_2 = x_2.data + 0.4 * self.step_size * torch.sign(x_2.grad.data)
                x_adv_2 = torch.min(torch.max(x_adv_2, inputs - self.epsilon),
                              inputs + self.epsilon)
                x_adv_2 = torch.clamp(x_adv_2, -1.0, 1.0)
                x_2 = Variable(x_adv_2)
                x_2.requires_grad_()
                zero_gradients(x_2)


            logits_pred_f, fea = self.basic_net(x)
            logits_pred = self.fc(logits_pred_f)


            logits_pred_2, fea_2 = self.basic_net(x_2)
            logits_pred_out_2 = self.fc(logits_pred_2)
            self.basic_net.zero_grad()
            logits_pred_2.requires_grad_()
            zero_gradients(logits_pred_2)

            logits_pred_org, fea_org = self.basic_net(x_org)
            logits_pred_out_org = self.fc(logits_pred_org)
            self.basic_net.zero_grad()
            logits_pred_org.requires_grad_()
            zero_gradients(logits_pred_org)


            y_sm = utils.label_smoothing(y_gt, y_gt.size(1), self.ls_factor)

            #logits_pred1, fea1 = self.basic_net(x_1)
            adv_loss = loss_ce(logits_pred, y_sm.detach())
            #loss_g = loss_ce(logits_pred_out, y_sm.detach())
            #nature_loss = loss_ce(logits_pred_out, y_sm.detach())
            #print(type(fea), '.............')
            #gradients = torch.autograd.grad(loss_g, logits_pred_2,
            #               create_graph = True, retain_graph=True, only_inputs=True, allow_unused=True)[0]
            #gradients = gradients.view(gradients.size(0), -1)
            #print(gradients, '.............')
            #loss_cent = criterion_cent(gradients, targets)

            #fea_sum = torch.cat( (fea,fea_2) ,dim = 0)
            #fea_sum = fea-fea_2

            fea_sum = logits_pred_out_2-logits_pred_out_org
            #fea_sum = get_normalized_vector(fea_sum)
            #fea_sum = torch.sign(fea_sum)
            #targets_sum = torch.cat( (targets,targets) ,dim = 0)
            targets_sum = targets
            
            loss_cent = criterion_cent(fea_sum, targets_sum)
            #print(adv_loss, 0.002*loss_cent)
            #adv_loss = loss_ce(logits_pred, y_sm.detach())

            optimizer_centloss.zero_grad()
            #loss_cent.backward(retain_graph=True)

            # multiple (1./alpha) in order to remove the effect of alpha on updating centers

            #optimizer_centloss.step()
            

            adv_loss_sum = adv_loss +  0.01  * loss_cent
        return logits_pred, adv_loss_sum
