export PYTHONPATH=./:$PYTHONPATH
model_dir=./models/feature_scatter_cifar10/
CUDA_VISIBLE_DEVICES=1 python fs_eval.py \
    --model_dir=$model_dir \
    --init_model_pass=130 \
    --attack=True \
    --attack_method_list=pgd-cw \
    --dataset=cifar10 \
    --batch_size_test=80 \
    --resume
