"""
This is a Pytorch implementation of the paper "BASGD: Buffered Asynchronous SGD for Byzantine Learning".
"""

import os
import shutil
import time
import argparse

import numpy
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
import torch.utils.data
import torch.utils.data.distributed
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import torch.distributed as dist
import datetime

from models import *

parser = argparse.ArgumentParser(description='PyTorch CIFAR10 Training')
parser.add_argument('--epochs', default=160, type=int, metavar='N',
                    help='number of total epochs to run')
parser.add_argument('--q', default=0, type=int, metavar='N',
                    help='number of Byzantine workers')
parser.add_argument('--lr', '--learning-rate', default=0.1, type=float,
                    metavar='LR', help='initial learning rate')
parser.add_argument('--print_all', default=False, type=bool,
                    metavar='N', help='whether print results on each worker')
parser.add_argument('--B', default=-1, type=int, metavar='N',
                    help='number of buffers')

global robust_mode, byzt_mode, momentum, num_delayed_worker, atk_num, reassignment_interval
robust_mode = 'trmean'
byzt_mode = 'ranDisturbAtk'
momentum = 0
num_delayed_worker = 999
atk_num = 3
reassignment_interval = 1

global straggler_num, straggler_degree
straggler_num = 3
straggler_degree = 4  # 1/4 slower


def byzt(g, rank, q, epoch, mode):
    if rank < atk_num:
        if mode == '10gAtk':
            return torch.mul(g, -10)
        elif mode == 'ranDisturbAtk':
            return torch.add(g, torch.randn_like(g).mul_(0.2*torch.norm(g, 2)))
        elif mode == 'noAtk':
            return g
    else:
        return g


def robust(g_history, world_size, q, d_matrix, current_buffer, mode):
    if mode == 'median':
        length = len(g_history)
        half_length = int((length - 1) / 2)
        g_list = []
        for i in range(len(g_history)):
            g_list.append(g_history[i])
        g_list, _ = torch.sort(torch.stack(g_list), dim=0)
        g = torch.mean(g_list[half_length: length-half_length], dim=0)
        return g

    elif mode == 'trmean':
        length = len(g_history)
        g_list = []
        for i in range(len(g_history)):
            g_list.append(g_history[i])
        g_list, _ = torch.sort(torch.stack(g_list), dim=0)
        g = torch.mean(g_list[q:length-q], dim=0)
        return g

    elif mode == 'krum':
        length = len(g_history)

        # compute distance matrix
        distance = []
        for i in range(length):
            distance.append(torch.FloatTensor([0]*length).cuda())
        for i in range(length):
            for j in range(i+1, length):
                distance_ij = torch.norm(g_history[i].sub(g_history[j]), 2)
                distance_ij.mul_(distance_ij)
                distance[i][j] = distance_ij
                distance[j][i] = distance_ij

        # compute krum score
        score = [0] * length
        for i in range(length):
            score[i] = torch.sum(torch.topk(distance[i], length-q-2, 0, largest=False, sorted=False)[0])
        i_star = torch.topk(torch.FloatTensor(score).cuda(), 1, 0, largest=False, sorted=False)[1]
        return g_history[i_star]

    elif mode == 'asynSGD':
        return g_history[current_buffer]

    else:
        print('robust_mode undefined!')
        sys.exit(2)


def reassign(is_active, correspondence):
    i = 0
    for worker in range(len(is_active)):
        if is_active[worker] == 1:
            correspondence[i] = worker
            i = i + 1
    for worker in range(len(is_active)):
        if is_active[worker] == 0:
            correspondence[i] = worker
            i = i + 1
    is_active = [0]*len(is_active)
    return is_active, correspondence


def coordinate(rank, world_size):
    args = parser.parse_args()
    current_lr = args.lr
    q = args.q
    print_all = args.print_all
    buffer_num = args.B
    if buffer_num == -1:
        buffer_num = world_size
    if buffer_num > world_size:
        print('Warning: buffer_num is larger than world size!')
        sys.exit(1)
    adjust = [80, 120]
    model = resnet20()
    model = model.cuda()
    model_flat = flatten_all(model)
    w_flat = flatten(model)
    g_flat = torch.zeros_like(w_flat)
    u_flat = torch.zeros_like(w_flat)
    g_history = []
    t_record = []
    for i in range(buffer_num):
        g_history.append(torch.zeros_like(w_flat))
        t_record.append(0)
    dist.broadcast(model_flat, world_size)
    cudnn.benchmark = True

    # Data loading code
    train_transform = transforms.Compose(
        [transforms.RandomCrop(32, padding=4),
         transforms.RandomHorizontalFlip(),
         transforms.ToTensor(),
         transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))])

    trainset = datasets.CIFAR10(root='./data', train=True, download=False, transform=train_transform)
    train_loader = torch.utils.data.DataLoader(trainset, batch_size=25 * world_size, pin_memory=True, shuffle=False,
                                               num_workers=2)

    datetime.datetime.now().strftime('%m%d%H%M')
    now_time2 = datetime.datetime.now() + datetime.timedelta(hours=8)
    if momentum == 0:
        output_path = datetime.datetime.strftime(now_time2, 'Byzt_resnet20_NewAlg_n'+str(world_size)
                                                 + 'b' + str(buffer_num) + 'q' + str(q)
                                                 + '_lr_' + str(current_lr)+'_'+robust_mode+'_'+byzt_mode+'_%m%d%H%M%S')
    else:
        output_path = datetime.datetime.strftime(now_time2, 'Byzt_resnet20_NewAlgM_n' + str(world_size)
                                                 + 'b' + str(buffer_num) + 'q' + str(q)
                                                 + '_lr_' + str(current_lr)+'_'+robust_mode+'_'+byzt_mode+'_%m%d%H%M%S')
    os.mkdir(output_path)
    time_int = datetime.datetime.strftime(now_time2, '%m%d%H%M%S')
    print("--------now_time:"+datetime.datetime.strftime(now_time2, '%m%d_%H%M%S')+"--------")
    dist.broadcast(torch.tensor(int(time_int)), world_size)
    time_stamp = 0
    num_b = [0] * buffer_num
    is_active = [0] * world_size
    correspondence = [0] * world_size
    for i in range(len(correspondence)):
        correspondence[i] = i
    received_buffer = 0
    d_matrix = torch.ones(len(g_history), len(g_history))
    d_matrix.mul_(99999999)

    t_last = time.time()
    total_time = time.time()
    for epoch in range(args.epochs):

        print('server\'s epoch: '+str(epoch))

        # adjust learning rate

        if epoch in adjust:
            current_lr = current_lr * 0.1

        for i in range(len(train_loader)*world_size):
            g_flat.zero_()
            if robust_mode != 'asynSGD':
                if time.time() - t_last > reassignment_interval:
                    is_active, correspondence = reassign(is_active, correspondence)
                    received_buffer = 0
                    num_b = [0] * buffer_num
                    t_last = time.time()

            src = dist.recv(g_flat)

            if robust_mode != 'asynSGD':
                buffer = correspondence[src] % len(g_history)
                is_active[src] = 1
                if num_b[buffer] == 0:
                    received_buffer += 1
                    num_b[buffer] += 1
                    g_history[buffer].copy_(g_flat)
                else:
                    num_b[buffer] += 1
                    g_history[buffer].mul_((num_b[buffer] - 1)/num_b[buffer])
                    g_flat.div_(num_b[buffer])
                    g_history[buffer].add_(g_flat)

                if received_buffer == buffer_num:
                    u_flat.mul_(momentum)
                    u_flat.add_(robust(g_history, world_size, q, d_matrix=d_matrix,
                                       current_buffer=buffer, mode=robust_mode))
                    w_flat.add_(-current_lr, u_flat)
                    time_stamp += 1
                    received_buffer = 0
                    num_b = [0] * buffer_num
                    is_active = [0] * world_size
                    t_last = time.time()

                # send new parameters back
                dist.send(w_flat, src)

            else:
                u_flat.mul_(momentum)
                u_flat.add_(g_flat)
                w_flat.add_(-current_lr, u_flat)
                dist.send(w_flat, src)

    total_time = time.time() - total_time
    print('training finished.')
    # test saved models
    if print_all:
        output_file = open(output_path + '/average_result.txt', "w")
    else:
        output_file = open(output_path + '.txt', "w")
    dist.barrier()
    time_cost = torch.zeros(1)
    loss = torch.zeros(1)
    prec1 = torch.zeros(1)
    for epoch in range(args.epochs):
        time_cost.zero_()
        loss.zero_()
        prec1.zero_()
        dist.recv(time_cost, world_size-1)
        dist.recv(loss, world_size-1)
        dist.recv(prec1, world_size-1)
        output_file.write('%d %3f %3f %3f\n' % (epoch, time_cost.numpy(), loss.numpy(), prec1.numpy()))
        output_file.flush()
    output_file.write('total_time %3f\n' % total_time)
    output_file.flush()
    # close output file, stop
    output_file.close()


def run(rank, world_size):
    args = parser.parse_args()
    current_lr = args.lr
    print_all = args.print_all
    q = args.q
    buffer_num = args.B
    if buffer_num == -1:
        buffer_num = world_size
    if buffer_num > world_size:
        print('Warning: buffer_num is larger than world size!')
        sys.exit(1)
    print('Start node: %d  Total: %3d' % (rank, world_size))
    model = resnet20()
    model = model.cuda()
    model_flat = flatten_all(model)
    dist.broadcast(model_flat, world_size)
    unflatten_all(model, model_flat)
    criterion = nn.CrossEntropyLoss().cuda()

    cudnn.benchmark = True

    # Data loading code
    train_transform = transforms.Compose(
        [transforms.RandomCrop(32, padding=4),
         transforms.RandomHorizontalFlip(),
         transforms.ToTensor(),
         transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))])

    val_transform = transforms.Compose(
        [transforms.ToTensor(),
         transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))])
    trainset = datasets.CIFAR10(root='./data', train=True, download=False, transform=train_transform)
    train_sampler = torch.utils.data.distributed.DistributedSampler(trainset, num_replicas=world_size, rank=rank)
    train_loader = torch.utils.data.DataLoader(trainset, batch_size=25, pin_memory=True, shuffle=False,
                                               num_workers=2, sampler=train_sampler)
    datetime.datetime.now().strftime('%m%d%H%M')
    now_time2 = datetime.datetime.now() + datetime.timedelta(hours=8)
    if momentum == 0:
        output_path = datetime.datetime.strftime(now_time2, 'Byzt_resnet20_NewAlg_n'+str(world_size)
                                                 + 'b' + str(buffer_num) + 'q' + str(q)
                                                 + '_lr_' + str(current_lr)+'_'+robust_mode+'_'+byzt_mode+'_')
    else:
        output_path = datetime.datetime.strftime(now_time2, 'Byzt_resnet20_NewAlgM_n' + str(world_size)
                                                 + 'b' + str(buffer_num) + 'q' + str(q)
                                                 + '_lr_' + str(current_lr) + '_'+robust_mode+'_' + byzt_mode + '_')
    time_int = torch.tensor(0)
    dist.broadcast(time_int, world_size)
    ts = str(time_int.numpy())
    if time_int < 1000000000:
        ts = '0' + ts
    output_path = output_path+ts+'/worker_'+str(rank)
    os.mkdir(output_path, 0o777)
    t1 = time.time()
    time_cost = []
    for epoch in range(args.epochs):
        # train for one epoch
        train_sampler.set_epoch(0)
        train(train_loader, model, criterion, epoch, rank, world_size, q)

        # save model for testing
        state = {
            'model': model.state_dict(),
        }
        torch.save(state, output_path+'/'+str(epoch)+'.pth')
        time_cost.append(time.time()-t1)

    # test saved models
    valset = datasets.CIFAR10(root='./data', train=False, download=False, transform=val_transform)
    val_loader = torch.utils.data.DataLoader(valset, batch_size=100, pin_memory=True, shuffle=False, num_workers=2)
    if print_all:
        output_file = open(output_path+'.txt', "w")

    dist.barrier()
    for epoch in range(args.epochs):
        checkpoint = torch.load(output_path+'/'+str(epoch)+'.pth')
        model.load_state_dict(checkpoint['model'])
        time_cost_t = torch.tensor([time_cost[epoch]])
        loss, _ = validate(train_loader, model, criterion)
        loss_t = torch.tensor([loss])
        _, prec1 = validate(val_loader, model, criterion)
        if rank == world_size - 1:
            dist.send(time_cost_t, world_size)
            dist.send(loss_t, world_size)
            dist.send(prec1.cpu(), world_size)
        if print_all:
            output_file.write('%d %3f %3f %3f\n' % (epoch, time_cost[epoch], loss, prec1))
            output_file.flush()
        os.remove(output_path+'/'+str(epoch)+'.pth')
    os.removedirs(output_path)


def train(train_loader, model, criterion, epoch, rank, world_size, q):
    wd = 0.0001
    # switch to train mode
    model.train()
    w_flat = flatten(model)
    g_flat = torch.zeros_like(w_flat)
    for i, (input, target) in enumerate(train_loader):
        t1 = time.time()
        input_var = torch.autograd.Variable(input.cuda())
        target = target.cuda()
        target_var = torch.autograd.Variable(target)

        # compute output
        output = model(input_var)
        loss = criterion(output, target_var)

        # compute gradient and do SGD step
        model.zero_grad()
        loss.backward()
        flatten_g(model, g_flat)
        g_flat.add_(wd, w_flat)
        # communicate
        t2 = time.time()
        delayed_degree = numpy.random.normal(loc=0.0, scale=1.0, size=None) + 1
        if atk_num <= rank < atk_num + straggler_num:
            delayed_degree += straggler_degree - 1
        if rank < num_delayed_worker:
            while (time.time() - t1) < delayed_degree * (t2 - t1):
                time.sleep(0.005)
        dist.send(byzt(g_flat, rank, q, epoch, mode=byzt_mode), world_size)
        dist.recv(w_flat, world_size)
        unflatten(model, w_flat)


def validate(val_loader, model, criterion):
    losses = AverageMeter()
    top1 = AverageMeter()

    # switch to evaluate mode
    model.eval()

    for i, (input, target) in enumerate(val_loader):
        input_var = torch.autograd.Variable(input.cuda())
        target = target.cuda()
        target_var = torch.autograd.Variable(target)

        # compute output
        with torch.no_grad():
            output = model(input_var)
            loss = criterion(output, target_var)

        # measure accuracy and record loss
        prec1 = accuracy(output.data, target, topk=(1,))
        losses.update(loss.data.item(), input.size(0))
        top1.update(prec1[0], input.size(0))

    return losses.avg, top1.avg


class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def accuracy(output, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    maxk = max(topk)
    batch_size = target.size(0)

    _, pred = output.topk(maxk, 1, True, True)
    pred = pred.t()
    correct = pred.eq(target.view(1, -1).expand_as(pred))

    res = []
    for k in topk:
        correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
        res.append(correct_k.mul_(100.0 / batch_size))
    return res


def flatten_all(model):
    vec = []
    for param in model.parameters():
        vec.append(param.data.view(-1))
    for b in model.buffers():
        vec.append(b.data.float().view(-1))
    return torch.cat(vec)


def unflatten_all(model, vec):
    pointer = 0
    for param in model.parameters():
        num_param = torch.prod(torch.LongTensor(list(param.size())))
        param.data = vec[pointer:pointer + num_param].view(param.size())
        pointer += num_param
    for b in model.buffers():
        num_param = torch.prod(torch.LongTensor(list(b.size())))
        b.data = vec[pointer:pointer + num_param].view(b.size())
        pointer += num_param


def flatten(model):
    vec = []
    for param in model.parameters():
        vec.append(param.data.view(-1))
    return torch.cat(vec)


def unflatten(model, vec):
    pointer = 0
    for param in model.parameters():
        num_param = torch.prod(torch.LongTensor(list(param.size())))
        param.data = vec[pointer:pointer + num_param].view(param.size())
        pointer += num_param


def flatten_g(model, vec):
    pointer = 0
    for param in model.parameters():
        num_param = torch.prod(torch.LongTensor(list(param.size())))
        vec[pointer:pointer + num_param] = param.grad.data.view(-1)
        pointer += num_param


def unflatten_g(model, vec):
    pointer = 0
    for param in model.parameters():
        num_param = torch.prod(torch.LongTensor(list(param.size())))
        param.grad.data = vec[pointer:pointer + num_param].view(param.size())
        pointer += num_param


if __name__ == '__main__':
    dist.init_process_group('mpi')
    rank = dist.get_rank()
    world_size = dist.get_world_size()

    if rank == world_size - 1:
        coordinate(rank, world_size - 1)
    else:
        run(rank, world_size - 1)
