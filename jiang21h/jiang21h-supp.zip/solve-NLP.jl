using JuMP
using KNITRO

# optimize the step-function h with $n-1$ pieces, with when prediction accuracy is c.
# it will return the competitive ratio, and n-1 discretized points.
function lp(n,c)
    n = n - 1
    # set KNITRO to be the solver
    lpRatio = Model(KNITRO.Optimizer)

    # initial variables
    @variable(lpRatio, ratio >= 0, start = 1)
    @objective(lpRatio, Max, ratio)
    @variable(lpRatio, x[0:n] >= 0)
    @variable(lpRatio, 0 <= t[0:n] <= 1)
    @NLobjective(lpRatio, Max, ratio)
    fix(x[n],1;  force = true)
    fix(x[0],c;  force = true)
    fix(t[n],1;  force = true)
    @NLconstraints(lpRatio,
    begin
        [i = 0:n-1] , x[i+1] <= x[i]
        [i = 0:n-1] , t[i+1] >= t[i]
        [a = 0:n-1] , ratio <= (
            t[a] * log(1/t[a])
            + 1/x[a] * (
                sum(
                x[i]*(-t[i] * log(t[i]) + t[i] + t[i-1] * log(t[i-1]) - t[i-1])
                for i = a+1:n)
            )
        )
    end
    )
    status = optimize!(lpRatio)
    println("Objective value: ", objective_value(lpRatio), value.(x) , value.(t))
    return objective_value(lpRatio)
end
