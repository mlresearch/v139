using JuMP
# using Ipopt
# using NLopt
using KNITRO
using Plots

function lp1(c)
    # set Ipopt to be the solver
    lpRatio = Model(KNITRO.Optimizer)

    # set step size
    # step = 1//n
    # initial variables
    @variable(lpRatio, ratio >= 0, start = 1)
    @objective(lpRatio, Max, ratio)
    # @variable(lpRatio, f[0:n] >= 0)
    # @variable(lpRatio, fr[0:n] >= 0)
    @variable(lpRatio, a >= 0)
    @variable(lpRatio, 0 <= ta <= 1)
    @variable(lpRatio, 0 <= tc <= 1)
    @NLobjective(lpRatio, Max, ratio)
    @NLconstraints(lpRatio,
    begin
        a <= c
        ta >= tc
        # a >= 1
        ratio <= (
               tc * log(1/tc)
               + a/c * (ta - tc - tc * log(ta/tc))
               + 1/c * (1-ta)
               + (-ta/c + a*ta/c - a*tc/c) * log(1/ta)
        )
        ratio <= (
                ta * log(1/ta)
                + 1/a * (1 - ta - ta * log(1/ta))
        )
    end
    )
    status = optimize!(lpRatio)
    println("Objective value: ", objective_value(lpRatio),";",value(tc),";",value(a),";", value(ta))
    return objective_value(lpRatio)
end

function lp2(n,c)
    # set KNITRO to be the solver
    lpRatio = Model(KNITRO.Optimizer)

    # set step size
    step = 1//n
    # initial variables
    @variable(lpRatio, ratio >= 0, start = 1)
    @objective(lpRatio, Max, ratio)
    # @variable(lpRatio, f[0:n] >= 0)
    # @variable(lpRatio, fr[0:n] >= 0)
    @variable(lpRatio, x[0:n] >= 0)
    @variable(lpRatio, 0 <= t[0:n] <= 1)
    @NLobjective(lpRatio, Max, ratio)
    fix(x[n],1;  force = true)
    fix(x[0],c;  force = true)
    fix(t[n],1;  force = true)
    @NLconstraints(lpRatio,
    begin
        [i = 0:n-1] , x[i+1] <= x[i]
        [i = 0:n-1] , t[i+1] >= t[i]
        [a = 0:n-1] , ratio <= (
            t[a] * log(1/t[a])
            + 1/x[a] * (
                sum(
                log(t[i]/t[i-1])*(
                    sum((t[j]-t[j-1])*x[j] for j = a+1:i-1
                )
                - t[i-1]*x[i])
                + x[i] * (t[i] - t[i-1])
                for i = a+1:n)
            )
        )
    end
    )
    # print(lpRatio)
    status = optimize!(lpRatio)
    println("Objective value: ", objective_value(lpRatio), value.(x) , value.(t))
    return objective_value(lpRatio)
end
function lp(n,c)
    # set KNITRO to be the solver
    lpRatio = Model(KNITRO.Optimizer)

    # initial variables
    @variable(lpRatio, ratio >= 0, start = 1)
    @objective(lpRatio, Max, ratio)
    # @variable(lpRatio, f[0:n] >= 0)
    # @variable(lpRatio, fr[0:n] >= 0)
    @variable(lpRatio, x[0:n] >= 0)
    @variable(lpRatio, 0 <= t[0:n] <= 1)
    @NLobjective(lpRatio, Max, ratio)
    fix(x[n],1;  force = true)
    fix(x[0],c;  force = true)
    fix(t[n],1;  force = true)
    @NLconstraints(lpRatio,
    begin
        [i = 0:n-1] , x[i+1] <= x[i]
        [i = 0:n-1] , t[i+1] >= t[i]
        [a = 0:n-1] , ratio <= (
            t[a] * log(1/t[a])
            + 1/x[a] * (
                sum(
                x[i]*(-t[i] * log(t[i]) + t[i] + t[i-1] * log(t[i-1]) - t[i-1])
                for i = a+1:n)
            )
        )
    end
    )
    # print(lpRatio)
    status = optimize!(lpRatio)
    println("Objective value: ", objective_value(lpRatio), value.(x) , value.(t))
    return objective_value(lpRatio)
end
function test()
    res100 = []
    for c = 1:100 
        push!(res100, lp(100,0.9+c/10))
    end
    res1 = []
    for c = 1:100 
        push!(res1, lp(1,0.9+c/10))
    end
    res2 = []
    for c = 1:100 
        push!(res2, lp(2,0.9+c/10))
    end
    plot(1:100 , res100)
    plot!(1:100 , res1)
    plot!(1:100 , res2) 
end