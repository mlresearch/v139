# using Plots
function findtc(n,c)
    step = c/10
    ratio = 0
    tci = 0
    rtc = 0
    rta = 0
    ratioc = 0
    for tci in 1:n
        tc = tci/n
        temp = (tc * log(1/tc)
                + 1/c * (1 - tc - tc * log(1/tc)))
        if temp > ratioc
            ratioc = temp
        end
        for a in 1:step:c
            for tai in tci:n
                ta = tai/n
                tempc = (tc * log(1/tc)
                       + a/c * (ta - tc - tc * log(ta/tc))
                       + 1/c * (1-ta)
                       + (-ta/c + a*ta/c - a*tc/c) * log(1/ta))
                tempa = (ta * log(1/ta)
                        + 1/a * (1 - ta - ta * log(1/ta)))
                temp = min(tempa , tempc)
                # println(tempa,tempc)
                if temp> ratio
                    ratio = temp
                    rtc = tc
                    rta = ta
                end
            end
        end
    end

    # println(ratio)
    # println(rtc)
    # println(rta)
    return ratio,ratioc
end
# a = []
# b = []
# for c in 1:100
#     res = findtc(1000,c)
#     push!(a , res[1])
#     push!(b , res[2])
# end
# plot(1:100,a)
# plot!(1:100,b)
