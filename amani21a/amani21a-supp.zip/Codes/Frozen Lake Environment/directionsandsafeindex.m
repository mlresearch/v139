function [Statesdirections,safeindex,isGood] = directionsandsafeindex(d,unsafestates,Grid,S)
safeindex=zeros(S,1);
Statesdirections=zeros(S,4);
isGood=zeros(S,1);

for ii=1:Grid
    for jj=1:Grid
        s = (ii-1)*Grid+jj;
        minusone=(length(find(s-1==unsafestates))>0);
        plusone=(length(find(s+1==unsafestates))>0);
        minusGrid=(length(find(s-Grid==unsafestates))>0);
        plusGrid=(length(find(s+Grid==unsafestates))>0);
        if (ii==1 && jj==1)
            N = [2,3];
            Nprime = [1,4];
            Statesdirections(s,2)=1;
            Statesdirections(s,3)=1;
        elseif (ii==1 && 2<=jj && jj<=Grid-1)
            N = [1,2,3];
            Nprime = [4];
            Statesdirections(s,1)=1;
            Statesdirections(s,2)=1;
            Statesdirections(s,3)=1;
        elseif (ii==1 && jj==Grid)
            N = [1,3];
            Nprime = [2,4];
            Statesdirections(s,1)=1;
            Statesdirections(s,3)=1;
        elseif (ii==Grid && jj==1)
            N = [2,4];
            Nprime = [1,3];
            Statesdirections(s,2)=1;
            Statesdirections(s,4)=1;
        elseif (ii==Grid && 2<=jj && jj<=Grid-1)
            N = [1,2,4];
            Nprime = [3];
            Statesdirections(s,1)=1;
            Statesdirections(s,2)=1;
            Statesdirections(s,4)=1;
        elseif (ii==Grid && jj==Grid)
            N = [1,4];
            Nprime = [2,3];
            Statesdirections(s,1)=1;
            Statesdirections(s,4)=1;
        elseif (2<=ii && ii<=Grid-1 && jj==1)
            N = [2,3,4];
            Nprime = [1];
            Statesdirections(s,2)=1;
            Statesdirections(s,3)=1;
            Statesdirections(s,4)=1;
        elseif (2<=ii && ii<=Grid-1 && jj==Grid)
            N = [1,3,4];
            Nprime = [2];
            Statesdirections(s,1)=1;
            Statesdirections(s,3)=1;
            Statesdirections(s,4)=1;
        else
            N = [1,2,3,4];
            Nprime = [];
            Statesdirections(s,1)=1;
            Statesdirections(s,2)=1;
            Statesdirections(s,3)=1;
            Statesdirections(s,4)=1;
        end
        clear safeindexcandidate
        ss=1;
        if length(find(N==1))>0 && 1-minusone && 1-plusGrid && 1-minusGrid
            safeindexcandidate(ss,1)=1;
            isGood(s,1)=1;
            ss=ss+1;
        end
        if length(find(N==2))>0 && 1-plusone && 1-plusGrid && 1-minusGrid
            safeindexcandidate(ss,1)=2;
            isGood(s,1)=1;
            ss=ss+1;
        end
        if length(find(N==3))>0 && 1-plusGrid && 1-plusone && 1-minusone
            safeindexcandidate(ss,1)=3;
            isGood(s,1)=1;
            ss=ss+1;
        end
        if length(find(N==4))>0 && 1-minusGrid && 1-plusone && 1-minusone
            safeindexcandidate(ss,1)=4;
            isGood(s,1)=1;
            ss=ss+1;
        end

        if isGood(s,1)==1
           safeindex(s,1)=safeindexcandidate(randi(ss-1),1);
        end
        ss=1;
        clear safeindexcandidate
        if isGood(s,1)==0
            if length(find(N==1))>0 && 1-minusone
                safeindexcandidate(ss,1)=1;
                ss=ss+1;
            end
            if length(find(N==2))>0 && 1-plusone
                safeindexcandidate(ss,1)=2;
                ss=ss+1;
            end
            if length(find(N==3))>0 && 1-plusGrid
                safeindexcandidate(ss,1)=3;
                ss=ss+1;
            end
            if length(find(N==4))>0 && 1-minusGrid
                safeindexcandidate(ss,1)=4;
                ss=ss+1;
            end
            safeindex(s,1)=safeindexcandidate(randi(ss-1),1);
        end 
        
    end
        
        
        
        
end
