function rewardd = rewardfunction(s,index,Statesdirections,Grid,unsafestates,rr)
M = [-1;1;Grid;-Grid];
N = find(Statesdirections(s,:)==1);
for i=1:length(N)
        if prod(s+M(N(i)))~=unsafestates
            reward(i,1) = rr(s+M(N(i)));
        else
            reward(i,1)=0;
        end
        
end
indexofbestaction=N(find(reward==max(reward)));
if (length(find(indexofbestaction==index))>0)
    rewardd = 2;
else
    rewardd = 0;
end