clear all
N=4;                                                    %  # of data types, hence legend entries
unsafecolor = rand;
goalcolor = rand;
startcolor= rand;
restcolor= rand;
D = restcolor*ones(10,10);
D(1,1)=startcolor;
D(10,4)=goalcolor;
unsafestates=[21,33,41,46,53,57,61,66,73,81];
for i=1:10
    
    m=mod(unsafestates(i),10);
    if m==0
        ii=unsafestates(i)/10;
        jj = unsafestates(i);
    else
        ii=floor(unsafestates(i)/10)+1;
        jj=m;        
    end
    D(ii,jj) = unsafecolor;
end
cmap = jet(N); 
colormap(cmap)

markerColor = mat2cell(cmap,ones(1,N),3);
L = plot(ones(N), 'LineStyle','none','marker','s','visible','off');      
set(L,{'MarkerFaceColor'},markerColor,{'MarkerEdgeColor'},markerColor);   
legend('Safe','Goal','Unsafe','Start')  
hold on
imagesc(D)                                           

% L = line(ones(N),ones(N), 'LineWidth',2);               % generate line 
% set(L,{'color'},mat2cell(cmap,ones(1,N),3));            % set the colors according to cmap
% legend('Safe','Goal','Unsafe','Start')    



