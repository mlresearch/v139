
function [phi,tauu,kappa,isGood] = Actionset(d,unsafestates,gamma,tau,Grid,S,mu)
phi=zeros(d,S,4);
tauu = zeros(S,1);
kappa = zeros(S,1);
[Statesdirections,safeindex,isGood] = directionsandsafeindex(d,unsafestates,Grid,S);
 gg=tau-0.001;
 
for s=1:S
    clear b N
    N = find(Statesdirections(s,:)==1);
    L = length(N);
    for i=1:L
        b = zeros(S,1);
        if N(i)==1
            b(s-1,1)=isGood(s,1)*0.8+(1-isGood(s,1))*(1-gg);
            if length(find(N==3))>0
                if length(find(N==4))>0
                    b(s+Grid,1)=isGood(s,1)*0.1+(1-isGood(s,1))*gg/2;
                    b(s-Grid,1)=isGood(s,1)*0.1+(1-isGood(s,1))*gg/2;
                else
                    b(s+Grid,1)=isGood(s,1)*0.2+(1-isGood(s,1))*gg;
                end
            elseif length(find(N==4))>0
                b(s-Grid,1)=isGood(s,1)*0.2+(1-isGood(s,1))*gg;
            end
        elseif N(i)==2
            b(s+1,1)=isGood(s,1)*0.8+(1-isGood(s,1))*(1-gg);
            if length(find(N==3))>0
                if length(find(N==4))>0
                    b(s+Grid,1)=isGood(s,1)*0.1+(1-isGood(s,1))*gg/2;
                    b(s-Grid,1)=isGood(s,1)*0.1+(1-isGood(s,1))*gg/2;
                else
                    b(s+Grid,1)=isGood(s,1)*0.2+(1-isGood(s,1))*gg;
                end
            elseif length(find(N==4))>0
                b(s-Grid,1)=isGood(s,1)*0.2+(1-isGood(s,1))*gg;
            end
        elseif N(i)==3
            b(s+Grid,1)=isGood(s,1)*0.8+(1-isGood(s,1))*(1-gg);
            if length(find(N==1))>0
                if length(find(N==2))>0
                    b(s+1,1)=isGood(s,1)*0.1+(1-isGood(s,1))*gg/2;
                    b(s-1,1)=isGood(s,1)*0.1+(1-isGood(s,1))*gg/2;
                else
                    b(s-1,1)=isGood(s,1)*0.2+(1-isGood(s,1))*gg;
                end
            elseif length(find(N==2))>0
                b(s+1,1)=isGood(s,1)*0.2+(1-isGood(s,1))*gg;
            end
        elseif N(i)==4
            b(s-Grid,1)=isGood(s,1)*0.8+(1-isGood(s,1))*(1-gg);
            if length(find(N==1))>0
                if length(find(N==2))>0
                    b(s+1,1)=isGood(s,1)*0.1+(1-isGood(s,1))*gg/2;
                    b(s-1,1)=isGood(s,1)*0.1+(1-isGood(s,1))*gg/2;
                else
                    b(s-1,1)=isGood(s,1)*0.2+(1-isGood(s,1))*gg;
                end
            elseif length(find(N==2))>0
                b(s+1,1)=isGood(s,1)*0.2+(1-isGood(s,1))*gg;
            end
        end
        A(:,:)=mu(:,:)';
        phi(:,s,N(i))=pinv(A)*b;
    end
    tauu(s,1) = gamma'*phi(:,s,safeindex(s,1));
    kappa(s,1) = (2+tau-tauu(s,1))/(tau-tauu(s,1));
        
end
 