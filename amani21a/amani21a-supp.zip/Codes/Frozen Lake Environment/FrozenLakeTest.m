clc
clear all
K = 10;
H=1000;
Grid = 10;
S = Grid^2;
goalstate = 94;
unsafestates=[21,33,41,46,53,57,61,66,73,81];


d=S;
sigmaa = 0;
lambda = 1;


mu = zeros(d,S);

numberofunsafestates = length(unsafestates);
safestates = [1:S];
 
safestates(unsafestates)=[];
 
rr=rewardvector(Grid,goalstate);

betaa = 2;

tau = 0.1;
Number = 20;
for j=1:Number
    mu(:,unsafestates) = rand(d,numberofunsafestates)/S;
    mu(:,unsafestates)=mu(:,unsafestates);
    for i=1:d
        mu(i,safestates) = randfixedsum(S-numberofunsafestates,1,1-sum(mu(i,unsafestates)),0,1);
    end
    gamma = sum(mu(:,unsafestates)')';
    
    [Statesdirections,safeindex(:,j),isGood] = directionsandsafeindex(d,unsafestates,Grid,S);
    [phi,tauu,kappa,isGood] = Actionset(d,unsafestates,gamma,tau,Grid,S,mu);
    [success(:,j),failure(:,j),terminationtimestep(:,j),reward(:,:,j),cummrew(:,j),ssss(j,1),Deltaa(j,1),state(:,:,j)] = RSLUCB_QVI(d,S,H,K,kappa,sigmaa,lambda,gamma,tau,tauu,mu,phi,betaa,Statesdirections,rr,goalstate,unsafestates,safeindex(:,j),Grid);
end
