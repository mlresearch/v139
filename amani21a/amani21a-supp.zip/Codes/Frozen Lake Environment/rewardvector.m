function r=rewardvector(Grid,goalstate)
    m=mod(goalstate,Grid);
    if m==0
        ii=goalstate/Grid;
        jj = Grid;
    else
        ii=floor(goalstate/Grid)+1;
        jj=m;        
    end
    for i=1:Grid
        for j=1:Grid
            s = (i-1)*Grid+j; 
            rr(s,1) = abs(i-ii)+abs(j-jj);
        end
    end
    
    r = ((max(rr) - rr))/max(rr); 