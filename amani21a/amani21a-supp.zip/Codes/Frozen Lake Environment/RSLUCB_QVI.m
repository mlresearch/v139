function [success,failure,terminationtimestep,reward,cummrew,ssss,Deltaa,state] = RSLUCB_QVI(d,S,H,K,kappa,sigmaa,lambda,gamma,tau,tauu,mu,phi,betaa,Statesdirections,rr,goalstate,unsafestates,safeindex,Grid)
    
    
ssss =0;
selectedphi = zeros(d,H,K);
reward = zeros(H,K);
safetymeasure = zeros(H,K);
state = zeros(H+1,K);
reww=zeros(H,K);
cummrew = zeros(K,1);
success = zeros(K,1);
failure = zeros(K,1);
terminationtimestep = zeros(K,1);
A = zeros(d,d,H);
bb = zeros(d,H);
Aperb = zeros(d,d,S);
rb = zeros(d,S);

Q = zeros(S,H+1,K,4);
Cons = zeros(S,K,4);
% dist = zeros(4,K);



    
    for s=1:S
        Aperb(:,:,s) = lambda*(eye(d)-phi(:,s,safeindex(s,1))*phi(:,s,safeindex(s,1))'/(norm(phi(:,s,safeindex(s,1)))^2));
        for h=1:H
           A(:,:,h) = lambda*eye(d); 
        end
    end    

for k=1:K
    state(1,k) = 1;
    for s=1:S
        clear N
        N=find(Statesdirections(s,:)==1);
        for j=N
            Cons(s,k,j) = consvalue(phi(:,s,safeindex(s,1)),phi(:,s,j),rb(:,s),Aperb(:,:,s),betaa,tau,tauu(s,1));
        end
    end       

    for h=H:-1:1
        if k>1
            for j=1:k-1
                clear M dist f AA b Aeq beq bbb pp Qmax
                M = find(Statesdirections(state(h+1,j),:)==1);
                for kk=1:length(M)
                    bbb(kk,1) = Cons(state(h+1,j),k,M(kk));
                    f(kk,1) = -Q(state(h+1,j),h+1,k,M(kk));
                end
                AA = [eye(length(M));-eye(length(M));bbb'];
                b = [ones(length(M),1);zeros(length(M),1);tau];
                Aeq = ones(1,length(M));
                beq=1;
                [dist,Qmax] = linprog(f,AA,b,Aeq,beq);
                bb(:,h) = bb(:,h)+ selectedphi(:,h,j)*(reward(h,j)+Qmax);
            end
            A(:,:,h)= A(:,:,h) + selectedphi(:,h,k-1)*selectedphi(:,h,k-1)';
        end
         for s=1:S
            clear N
            N=find(Statesdirections(s,:)==1);
            for j=N
                Q(s,h,k,j) = min(Qfunc(phi(:,s,j),bb(:,h),A(:,:,h),betaa,kappa(s,1)),2*H);
            end
        end               
    end
            
        
    for h=1:H  
        clear M dist f AA b Aeq beq bbb pp
        M = find(Statesdirections(state(h,k),:)==1);
        for kk=1:length(M)
            bbb(kk,1) = Cons(state(h,k),k,M(kk));
            f(kk,1) = -Q(state(h,k),h,k,M(kk));
        end
        AA = [eye(length(M));-eye(length(M));bbb'];
        b = [ones(length(M),1);zeros(length(M),1);tau];
        Aeq = ones(1,length(M));
        beq=1;
        dist = linprog(f,AA,b,Aeq,beq);
        
        indexofselectedaction(h,k) = randsample(length(M),1,true,round(dist,8));
        selectedphi(:,h,k) = phi(:,state(h,k),M(indexofselectedaction(h,k)));
        
        state(h+1,k) = randsample(S,1,true,round(selectedphi(:,h,k)'*mu(:,:),8));
        reward(h,k) = rewardfunction(state(h,k),M(indexofselectedaction(h,k)),Statesdirections,Grid,unsafestates,rr);
        safetymeasure(h,k) = selectedphi(:,h,k)'*gamma+normrnd(0,sigmaa);
        if state(h+1,k)==goalstate && failure (k,1) == 0 && success(k,1)~=1
            success (k,1) = 1;
            terminationtimestep(k,1) = h;
        elseif ~prod(state(h+1,k)~=unsafestates) && success (k,1) == 0 && failure(k,1)~=1
            failure (k,1) = 1;
            terminationtimestep(k,1) = h;
        end
        for ii=1:length(M)
            pp(ii,1)=gamma'*phi(:,state(h,k),M(ii));
        end
        if (tau - dist'*pp<0)
            ssss =ssss +1;
         Deltaa = tau - dist'*pp;
        end
        
        
        
        
        for s=1:S
            xperp =  selectedphi(:,h,k) - (selectedphi(:,h,k)'*phi(:,s,safeindex(s,1)))*phi(:,s,safeindex(s,1))/(norm(phi(:,s,safeindex(s,1)))^2);
            zperp = safetymeasure(h,k)-(selectedphi(:,h,k)'*phi(:,s,safeindex(s,1)))*tauu(s,1)/(norm(phi(:,s,safeindex(s,1)))^2);
            Aperb(:,:,s) = Aperb(:,:,s)+xperp*xperp';
            rb(:,s) = rb(:,s)+xperp*zperp;
            

        end
    end
    
    
end






cummrew(1,1)=0;
for i=1:K
    episodereward(i,1)= sum(reward(:,i));
end
cummrew(1,1)=0;
for i=1:K
    cummrew(i+1,1)=cummrew(i,1)+episodereward(i,1);
end

cummrew(1,:)=[];
if ssss==0
    Deltaa = 0;
end


