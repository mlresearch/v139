
plot(cummreww1./[1:K]')
hold on
plot(cummreww11./[1:K]')
hold on
plot(cummreww111./[1:K]')
hold on
plot(cummreww1111./[1:K]')
hold on
plot(cummreww./[1:K]')
hold on
plot(cummreww2./[1:K]')

xlabel('$k$, Episode','Interpreter','latex')
ylabel('Per-episode reward','Interpreter','latex')
leg1=legend('LSVI-UCB with reward r-0.8c, # of violations=8605','LSVI-UCB with reward r-0.85c, # of violations=7006','LSVI-UCB with reward r-0.9c, # of violations=2494','LSVI-UCB with reward r-0.95c, # of violations=516', 'LSVI-UCB with knowldege of safe sets, # of violations=0', 'SLUCB-QVI, # of violations=0')