function [reww,cummrew,ssss,Deltaa,state] =  SLUCB_QVI(d,S,H,K,kappa,sigmaa,lambda,gamma,theta,tau,tauu,Nofs,mu,phi,betaa,maxRew)
ssss =0;
phi_safek=zeros(d,Nofs+1,S,H,K);
selectedphi = zeros(d,H,K);
reward = zeros(H,K);
safetymeasure = zeros(H,K);
state = zeros(H,K);

A = zeros(d,d,H,K);
bb = zeros(d,H,K);
Aperb = zeros(d,d,S,H,K);
rb = zeros(d,S,H,K);

Q = zeros(Nofs+1,S,H,K);



for h=1:H
    A(:,:,h,1) = lambda*eye(d);
    for s=1:S
        Aperb(:,:,s,h,1) = lambda*(eye(d)-phi(:,1,s)*phi(:,1,s)'/(norm(phi(:,1,s))^2));
    end    
end
% state(1,1) = 1;

state(1,1) = randi(S);
% state(1,:) = ones(1,K);


for k=1:K    
        for s=1:S
            for i=1:Nofs+1  
                Q(i,s,H+1,k) = 0;
            end
        end      
  
    for h=H:-1:1
        if k>1
            for j=1:k-1
                bb(:,h,k) = bb(:,h,k)+ selectedphi(:,h,j)*(reward(h,j)+max(Q(:,state(h+1,j),h+1,k)));
            end
        end
            
        for s=1:S
            phi_safek(:,1,s,h,k)=phi(:,1,s);       
            Q(1,s,h,k) = min(Qfunc(phi_safek(:,1,s,h,k),bb(:,h,k),A(:,:,h,k),betaa,kappa(s)),H*maxRew);
            for i=2:Nofs+1
                alpha = coeff(phi(:,1,s),phi(:,i,s),rb(:,s,h,k),Aperb(:,:,s,h,k),betaa,tau,tauu(s));
                phi_safek(:,i,s,h,k)=alpha*phi(:,i,s)+(1-alpha)*phi(:,1,s);
                Q(i,s,h,k) = Qfunc(phi_safek(:,i,s,h,k),bb(:,h,k),A(:,:,h,k),betaa,kappa(s));
            end
        end      
    end
    
    
    for h=1:H
        index = min(find(Q(:,state(h,k),h,k)==max(Q(:,state(h,k),h,k))));
        selectedphi(:,h,k) = phi_safek(:,index,state(h,k),h,k);
        state(h+1,k) = randsample(S,1,true,selectedphi(:,h,k)'*mu(:,:,h));
         reward(h,k) = selectedphi(:,h,k)'*theta(:,h);
        safetymeasure(h,k) = selectedphi(:,h,k)'*gamma+normrnd(0,sigmaa);
        if (round(tau - selectedphi(:,h,k)'*gamma,8)<0)
        ssss =ssss +1;
        Deltaa(ssss,1) = round(tau - selectedphi(:,h,k)'*gamma,8);
        end
        A(:,:,h,k+1) = A(:,:,h,k) + selectedphi(:,h,k)*selectedphi(:,h,k)';
        
        for s=1:S
            xperp =  selectedphi(:,h,k) - (selectedphi(:,h,k)'*phi(:,1,s))*phi(:,1,s)/(norm(phi(:,1,s))^2);
            zperp = safetymeasure(h,k)-(selectedphi(:,h,k)'*phi(:,1,s))*tauu(s)/(norm(phi(:,1,s))^2);
            Aperb(:,:,s,h,k+1) = Aperb(:,:,s,h,k)+xperp*xperp';
            rb(:,s,h,k+1) = rb(:,s,h,k)+xperp*zperp;
        end
        
    end
     state(1,k+1)=state(H+1,k);
end


for i=1:K
    reww(i,1) = sum(reward(:,i)); 
end
cummrew(1,1)=0;
for i=1:K
    cummrew(i+1,1)=cummrew(i,1)+reww(i,1);
end

cummrew(1,:)=[];
if ssss==0
    Deltaa = 0;
end
state(H+1,:)=[];
state(:,K+1)=[];

