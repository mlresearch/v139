function alpha=coeff(xzero,xi,rb,Aperb,betaa,c,czero)
xiprtp = xi-(xi'*xzero)*xzero/(norm(xzero)^2);
M = ((xzero'*xi)*czero/(norm(xzero)^2))+(xiprtp'*pinv(Aperb)*rb)+(betaa*sqrt(xiprtp'*pinv(Aperb)*xiprtp));
if M>c
    alpha=(c-czero)/(M-czero);
else
    alpha = 1;
end