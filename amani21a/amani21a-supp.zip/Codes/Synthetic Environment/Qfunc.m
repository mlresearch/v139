function a = Qfunc(phi,bb,A,betaa,kappa)
a = phi'*pinv(A)*bb+kappa*betaa*sqrt(phi'*pinv(A)*phi);
    
