function [reww,cummrew,ssss,Deltaa] = Baseline(d,S,H,K,lambda,lambdaprime,gamma,theta,tau,Nofs,mu,phi_safe,betaa,maxRew)
ssss =0;
thetaprime = theta-lambdaprime*gamma;
selectedphi = zeros(d,H,K);
reward = zeros(H,K);
state = zeros(H,K);

A = zeros(d,d,H,K);
bb = zeros(d,H,K);

Q = zeros(Nofs+1,S,H,K);



for h=1:H
    A(:,:,h,1) = lambda*eye(d);
end
state(1,1) = randi(S);
% state(1,1) = 1;


for k=1:K 
    for s=1:S
            for i=1:Nofs+1  
                Q(i,s,H+1,k) = 0;
            end
        end    
    for h=H:-1:1
        if k>1
            for j=1:k-1
                bb(:,h,k) = bb(:,h,k)+ selectedphi(:,h,j)*(selectedphi(:,h,j)'*thetaprime(:,h)+max(Q(:,state(h+1,j),h+1,k)));
            end
        end
        for s=1:S
            for i=1:Nofs+1         
                Q(i,s,h,k) = min(Qfunc(phi_safe(:,i,s),bb(:,h,k),A(:,:,h,k),betaa,1),maxRew*H);
            end
        end      
    end
    
    for h=1:H
        index = min(find(Q(:,state(h,k),h,k)==max(Q(:,state(h,k),h,k))));
        selectedphi(:,h,k) = phi_safe(:,index,state(h,k));
        state(h+1,k) = randsample(S,1,true,selectedphi(:,h,k)'*mu(:,:,h));
        reward(h,k) = selectedphi(:,h,k)'*theta(:,h);
        if (round(tau - selectedphi(:,h,k)'*gamma,8)<0)
        ssss =ssss +1;
        Deltaa(ssss,1) = round(tau - selectedphi(:,h,k)'*gamma,8);
        end
        A(:,:,h,k+1) = A(:,:,h,k) + selectedphi(:,h,k)*selectedphi(:,h,k)';
     
        
    end
    state(1,k+1)=state(H+1,k);
end


for i=1:K
    reww(i,1) = sum(reward(:,i)); 
end
cummrew(1,1)=0;
for i=1:K
    cummrew(i+1,1)=cummrew(i,1)+reww(i,1);
end
if ssss==0
    Deltaa = 0;
end

cummrew(1,:)=[];
