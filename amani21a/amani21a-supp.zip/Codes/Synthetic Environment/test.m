clc
clear all
K = 10000;
H=3;
S =10;
d = 5;
sigmaa = 0.01;
lambda = 1;
lambdaprime=1;
tau = 0.5;
Nofs = 99;
mu = zeros(d,S,H);
phi=zeros(d,Nofs+1,S);
phi_safe=zeros(d,Nofs+1,S);
lambdaprime1=0.8;
lambdaprime11=0.85;
lambdaprime111=0.9;
lambdaprime1111=0.95;
Number = 20;

alpha=1;
kappa = 100*ones(S,1);

while(alpha==1)
    for h=1:H

        for i=1:d
            mu(i,:,h) = randfixedsum(S,1,1,0,1);
        end
    end
    gamma = normrnd(0,1,d,1);
    theta = normrnd(0,1,d,H);
    for h=1:H
        keke(h)=norm(theta(:,h));
    end


    for s=1:S
        phi(:,1,s)=randfixedsum(d,1,1,0,1);
        while(gamma'*phi(:,1,s)>=tau || length(find(theta'*phi(:,1,s)<0))>0)
        phi(:,1,s)=randfixedsum(d,1,1,0,1);
         1
        end
        phi_safe(:,1,s)=phi(:,1,s);
        tauu(s) = gamma'*phi_safe(:,1,s);
        kappa(s)=(2*H/(tau-tauu(s)))+1;
        for i=2:Nofs+1
            phi(:,i,s)=randfixedsum(d,1,1,0,1);
            if (gamma'*phi(:,i,s)<=tau)
                phi_safe(:,i,s)=phi(:,i,s);
            else
            alpha = (tau-gamma'*phi(:,i,s))/(gamma'*phi(:,1,s)-gamma'*phi(:,i,s));
            phi_safe(:,i,s)=alpha*phi(:,1,s)+(1-alpha)*phi(:,i,s);        
            end
            Delta(i,s) = round(tau-gamma'*phi_safe(:,i,s),8);
        end
        
    end
    maxRew = max(keke);
    betaa = max(max(keke),norm(gamma));
end

for i=1:Number
[reww(:,i),cummrew(:,i),numberr(i,1),Deltaa] =  LSVI_UCB(d,S,H,K,lambda,gamma,theta,tau,Nofs,mu,phi_safe,betaa,maxRew);
[reww1(:,i),cummrew1(:,i),numberr1(i,1),Deltaa1] = Baseline(d,S,H,K,lambda,lambdaprime1,gamma,theta,tau,Nofs,mu,phi,betaa,maxRew);
[reww11(:,i),cummrew11(:,i),numberr11(i,1),Deltaa11] = Baseline(d,S,H,K,lambda,lambdaprime11,gamma,theta,tau,Nofs,mu,phi,betaa,maxRew);
[reww111(:,i),cummrew111(:,i),numberr111(i,1),Deltaa111] = Baseline(d,S,H,K,lambda,lambdaprime111,gamma,theta,tau,Nofs,mu,phi,betaa,maxRew);
[reww1111(:,i),cummrew1111(:,i),numberr1111(i,1),Deltaa1111] = Baseline(d,S,H,K,lambda,lambdaprime1111,gamma,theta,tau,Nofs,mu,phi,betaa,maxRew);
[reww2(:,i),cummrew2(:,i),numberr2(i,1),Deltaa2] =  SLUCB_QVI(d,S,H,K,kappa,sigmaa,lambda,gamma,theta,tau,tauu,Nofs,mu,phi,betaa,maxRew);
end

for k=1:K
 cummreww(k,1) = sum(cummrew(k,:))/Number;
 cummreww1(k,1) = sum(cummrew1(k,:))/Number;
 cummreww11(k,1) = sum(cummrew11(k,:))/Number;
 cummreww111(k,1) = sum(cummrew111(k,:))/Number;
 cummreww1111(k,1) = sum(cummrew1111(k,:))/Number;
 cummreww2(k,1) = sum(cummrew2(k,:))/Number;
end
