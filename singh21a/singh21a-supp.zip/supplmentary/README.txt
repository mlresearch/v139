In this package, we provide:

1. The supplementary PDF acting as appendix to the main text.

2. Two GIFs showing game-play of SWB-A2C in 3D Food Chase game. 

3. Two GIFs showing belief tracking in 2D Branching Sprites.

In the GIFs, the first row shows the observations, actions of the agent, the policy distribution over actions, reward received and value estimate. In the bottom row, we show position particles for all active object files. Furthermore, we show rendered object-segments of each object file. We average the segments over particles to illustrate multiple hypotheses of object states especially when the objects are invisible in the observation.