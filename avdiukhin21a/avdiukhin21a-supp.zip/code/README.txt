Files:
* FedLearning.ipynb - results for MNIST, Fashion-MNIST and convolutional model for CIFAR-10. Comment computed results to recompute them from scratch.
* FL_Experiments_results.ipynb - results for CIFAR-10 on ResNet-34. Also includes results not published in the paper. Set recompute = True in cell 4 to recompute results from scratch.
* Results - precomputed results for FL_Experiments_results.ipynb.