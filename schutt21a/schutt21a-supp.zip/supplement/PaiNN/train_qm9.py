import os
import argparse
import pytorch_lightning as pl
from pytorch_lightning.loggers import TensorBoardLogger

import schnetpack as spk
from schnetpack.datasets import QM9

from painn.model import AtomisticModel
from painn.data import AtomsDataModule
from painn.painn import PaiNN
from painn.outputs import Dipole, Polarizability
from time import time
import torch.nn.functional as F

import logging

logging.basicConfig(level=os.environ.get("LOGLEVEL", "INFO"))


def prepare_data(datadir, property, num_train, num_val, batch_size):
    if not os.path.exists(datadir):
        os.makedirs(datadir)

    logging.info(f"Load data")
    data = spk.datasets.QM9(
        dbpath=os.path.join(datadir, 'qm9.db'),
        load_only=[property],
        remove_uncharacterized=True,
    )
    data = AtomsDataModule(data, num_train, num_val, batch_size, split_file=os.path.join(datadir, 'split.npz'))

    logging.info(f"Extract data statistics")
    data.setup(stage="fit")
    train_loader = data.train_dataloader()
    atomref = data.dataset.get_atomref(property)
    mean, stddev = train_loader.get_statistics(
        property, True, atomref
    )
    logging.info(f"Calculated stats. Mean: {mean}, Std.dev.: {stddev}")
    return data, atomref, mean, stddev


def build_model(property, atomref, mean, stddev):
    logging.info(f"Build model")
    painn = PaiNN()

    if property == QM9.mu:
        outputs = Dipole(n_in=painn.n_atom_basis, n_hidden=painn.n_atom_basis, predict_magnitude=True,
                         property=property)
    elif property == QM9.r2:
        outputs = spk.atomistic.ElectronicSpatialExtent(n_in=painn.n_atom_basis, property=property)
    else:
        outputs = spk.atomistic.Atomwise(
            n_in=painn.n_atom_basis,
            mean=mean.get(property, None),
            stddev=stddev.get(property, None),
            atomref=atomref.get(property, None),
            property=property,
            activation=F.silu
        )

    return painn, [outputs]


def train_and_eval(traindir, property, num_train, num_val, batch_size,
                   lr, lr_decay, decay_patience, stop_patience, timing):
    datadir = os.path.join(traindir, 'data')
    data, atomref, mean, stddev = prepare_data(datadir, property, num_train, num_val, batch_size)

    representation, outputs = build_model(property, atomref, mean, stddev)

    # define metrics
    losses = [{
        "metric": pl.metrics.MeanSquaredError(),
        "prediction": property,
        "target": property,
        "loss_weight": 1.
    }]

    validation_metrics = [{
        "metric": pl.metrics.MeanSquaredError(),
        "prediction": property,
        "target": property,
    }, {
        "metric": pl.metrics.MeanAbsoluteError(),
        "prediction": property,
        "target": property,
    }]

    model = AtomisticModel(
        representation=representation,
        outputs=outputs,
        losses=losses,
        validation_metrics=validation_metrics,
        lr=lr,
        lr_decay=lr_decay,
        lr_patience=decay_patience,
    )

    if timing:
        loader = data.test_dataloader()
        for batch in loader:
            break
        batch = {k: v.cuda() for k, v in batch.items()}
        model.cuda()
        model.test_step(batch, 0)

        its = 100
        start = time()
        for i in range(its):
            model.test_step(batch, 0)
        duration = (time() - start) / its
        logging.info("Inference time:", duration)
        return

    # Training
    callbacks = [
        pl.callbacks.LearningRateMonitor(),
        pl.callbacks.EarlyStopping(
            monitor="training/ema_val_loss",
            patience=stop_patience, min_delta=1e-6,
        ),
        pl.callbacks.ModelCheckpoint(
            filename="{epoch}-{val_loss:.6f}",
            save_top_k=1,
            verbose=False,
            monitor='training/val_loss',
            mode='min',
        )
    ]

    tb_logger = TensorBoardLogger(save_dir=traindir, name="", default_hp_metric=False)

    trainer = pl.Trainer(
        gpus=1,
        callbacks=callbacks,
        progress_bar_refresh_rate=1,
        logger=tb_logger,
        max_epochs=100000,
        default_root_dir=traindir,
    )

    logging.info("Start training.")
    trainer.fit(model, data)
    logging.info("Training done.")

    # Eval
    logging.info("Start eval.")
    trainer.test()
    logging.info("Eval done.")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("traindir", help="Directory for data, logging and checkpoints")
    parser.add_argument(
        "property", help="QM9 property",
        choices=["dipole_moment",
                "isotropic_polarizability",
                "homo",
                "lumo",
                "gap",
                "electronic_spatial_extent",
                "zpve",
                "energy_U0",
                "energy_U",
                "enthalpy_H",
                "free_energy", "heat_capacity"]
    )
    parser.add_argument("--num_train", help="Number of training examples", default=110000, type=int)
    parser.add_argument("--num_val", help="Number of validation examples", default=10000, type=int)
    parser.add_argument("--batch_size", help="Batch size", default=100, type=int)
    parser.add_argument("--lr", help="Learning rate", default=5e-4, type=float)
    parser.add_argument("--lr_decay", help="Learning rate decay", default=0.5, type=float)
    parser.add_argument("--decay_patience", help="Decay patiene", default=5, type=int)
    parser.add_argument("--stop_patience", help="Early stopping patiene", default=30, type=int)
    parser.add_argument("--timing", help="Just get timing", action="store_true")

    args = parser.parse_args()

    train_and_eval(
        args.traindir,
        args.property,
        num_train=args.num_train,
        num_val=args.num_val,
        batch_size=args.batch_size,
        lr=args.lr,
        lr_decay=args.lr_decay,
        decay_patience=args.decay_patience,
        stop_patience=args.stop_patience,
        timing=args.timing,
    )
