# Example code for PaiNN

### Install requirements

`pip install -r requirements.txt`


### Call training script

`python train_qm9.py <traindir> <property>` 

For a list of available properties and options call 

`python train_qm9.py --help`


### Observe training progress

`tensorboard --logdir=<traindir>`

