
library(pROC)

ShapeData <- function(mDat, feat.submission.synId) {
  IsContinuous <- function(x) {
    n <- length(x)
    thr <- round(3*n/4)
    aux <- FALSE
    u <- length(unique(x))
    if (u > thr) {
      aux <- TRUE
    }
    aux
  }
  CollapseData <- function(x, labelName, covNames, subjectIdName, featNames) {
    ids <- as.character(unique(x[, subjectIdName]))
    nids <- length(ids)
    nfeat <- length(featNames)
    nvar <- length(c(subjectIdName, labelName, covNames))
    out <- data.frame(matrix(NA, nids, nfeat + nvar))
    colnames(out) <- c(subjectIdName, labelName, covNames, featNames)
    rownames(out) <- ids
    for (i in seq(nids)) {
      sdat <- x[which(x[, subjectIdName] == ids[i]),]
      out[i, subjectIdName] <- ids[i]
      out[i, labelName] <- as.character(sdat[1, labelName])
      out[i, covNames] <- sdat[1, covNames]
      out[i, (nvar + 1):(nfeat + nvar)] <- apply(sdat[, featNames], 2, median, na.rm = TRUE)
    }
    out
  } 
  KeepContinuousFeatures <- function(dat, feature.names) {
    feats <- dat[, feature.names]
    ## remove discrete features
    keep <- which(apply(feats, 2, IsContinuous)) 
    feats <- feats[, keep]
    data.frame(dat[, 1:3], feats)
  }
  RankQuantileTransformation <- function(dat, featNames) {
    NormalTrans <- function(x) {
      n <- sum(!is.na(x))
      r <- rank(x, na.last = "keep")
      qnorm((r - 0.5)/n)
    }
    nfeat <- length(featNames)
    for (j in seq(nfeat)) {
      dat[, featNames[j]] <- NormalTrans(dat[, featNames[j]])
    }   
    dat
  }

  feats <- read.csv(synGet(feat.submission.synId)$path, header = TRUE)
  rids <- intersect(feats$recordId, mDat$recordId)
  mdat <- mDat[match(rids, mDat$recordId),]
  feats <- feats[match(rids, feats$recordId), -1]
  dat <- data.frame(mdat, feats)
  cdat <- CollapseData(x = dat,
                       labelName = "professional.diagnosis", 
                       covNames = "age",
                       subjectIdName = "healthCode",
                       featNames = colnames(feats))
  cdat <- KeepContinuousFeatures(cdat, colnames(feats))
  cdat <- RankQuantileTransformation(cdat, c("age", colnames(cdat)[-c(1:3)]))
  
  cdat
}



RunMPowerExperimentsD <- function(datasets,
                                  nruns,
                                  label.name,
                                  neg.class.name = "FALSE", 
                                  pos.class.name = "TRUE") {
  GetDiscretizedAge <- function(dat, n.levels, level.names = NULL, breaks = NULL) {
    if (is.null(breaks)) {
      if (!is.null(level.names)) {
        out <- cut(dat$age, breaks = n.levels, labels = level.names)
      }
      else {
        levelNames <- paste("age", seq(n.levels), sep = "")
        out <- cut(dat$age, breaks = n.levels, labels = level.names)
      }
    }
    else {
      if (!is.null(level.names)) {
        out <- cut(dat$age, breaks = breaks, labels = level.names)
      }
      else {
        nlevels <- length(breaks) + 1
        levelNames <- paste("age", seq(n.levels), sep = "")
        out <- cut(dat$age, breaks = breaks, labels = level.names)
      }
    }
    out
  }
  nsets <- length(datasets)
  submission.names <- names(datasets)
  AUC.ca <- matrix(NA, nruns, nsets)
  colnames(AUC.ca) <- submission.names
  AUC.lr <- AUC.ca
  
  confounder.name <- "age"
  for (j in seq(nsets)) {
    cat("submission ", submission.names[j], "\n")
    dat <- datasets[[j]]
    
    age <- dat$age
    
    dat$age <- GetDiscretizedAge(dat, 
                                 n.levels = 3, 
                                 level.names = c("YoungAge", "MiddleAge", "SeniorAge"), 
                                 breaks = c(-100, 0.2657860, 1.158272, 100))
    feature.names <- names(dat)[-c(1:3)]
    residual.names <- paste(feature.names, "r", sep = "_")
    counterfactual.names <- paste(feature.names, "c", sep = "_")
    for (i in seq(nruns)) {
      cat(i, "\n")
      aux <- DataSplitIndexes(dat)
      idx.train <- aux$idx.train
      idx.test <- aux$idx.test
      aux.r <- ResidualizationAdjustment(dat, feature.names, confounder.name)
      aux.c <- CausalityAwareAdjustment(dat, idx.train = idx.train, idx.test = idx.test, label.name, feature.names, confounder.name)
      dat2 <- data.frame(dat, aux.r, aux.c)
      ## residualization
      aux1 <- GetGlmAuc(dat2,
                        idx.train,
                        idx.test,
                        label.name,
                        feature.names = residual.names,
                        neg.class.name, 
                        pos.class.name)
      AUC.lr[i, j] <- aux1$auc.test
      ## causality-aware
      aux2 <- GetGlmAuc(dat2,
                        idx.train,
                        idx.test,
                        label.name,
                        feature.names = counterfactual.names,
                        neg.class.name, 
                        pos.class.name)
      AUC.ca[i, j] <- aux2$auc.test  
    }
  }
  
  list(AUC.lr = AUC.lr, AUC.ca = AUC.ca)
}





DataSplitIndexes <- function(dat) {
  n <- nrow(dat)
  idx.train <- sample(seq(n), ceiling(n/2), replace = FALSE)
  idx.test <- setdiff(seq(n), idx.train)
  
  list(idx.train = idx.train, idx.test = idx.test)
}



CausalityAwareAdjustment <- function(dat, 
                                     idx.train, 
                                     idx.test, 
                                     label.name, 
                                     feature.names, 
                                     confounder.name) {
  dat.train <- dat[idx.train,]
  dat.test <- dat[idx.test,]
  n.feat <- length(feature.names)
  X.c <- matrix(NA, nrow(dat), n.feat)
  colnames(X.c) <- paste(feature.names, "_c", sep = "")
  
  rhs.formula <- paste(" ~ ", label.name, " + ", paste(confounder.name, collapse = " + "), sep = "")
  
  train.model.matrix <- model.matrix(as.formula(paste("~", label.name, sep = "")), 
                                     data = dat.train)
  test.model.matrix <- model.matrix(as.formula(paste("~", confounder.name, sep = "")), 
                                    data = dat.test)[, -1, drop = FALSE] ## remove the intercept column
  
  for (i in seq(n.feat)) {
    my.formula <- as.formula(paste(feature.names[i], rhs.formula, sep = ""))
    fit <- lm(my.formula, data = dat.train)
    err.train <- fit$residuals
    coeffs.1 <- fit$coefficients[c(1, 2)]
    ## get only the confounder coefficient
    coeffs.2 <- fit$coefficients[-c(1, 2)] 
    ## compute the train and test counterfactual features
    X.c.train <- as.numeric(train.model.matrix %*% coeffs.1) + err.train
    X.c.test <- dat.test[, feature.names[i]] - as.numeric(test.model.matrix %*% coeffs.2)
    aux.X.c <- rep(NA, nrow(dat))
    aux.X.c[idx.train] <- X.c.train
    aux.X.c[idx.test] <- X.c.test
    X.c[, i] <- aux.X.c
  }
  
  X.c
}


ResidualizationAdjustment <- function(dat, 
                                      feature.names, 
                                      confounder.name) {
  n.feat <- length(feature.names)
  X.r <- matrix(NA, nrow(dat), n.feat)
  colnames(X.r) <- paste(feature.names, "_r", sep = "")
  rhs.formula <- paste(" ~ ", paste(confounder.name, collapse = " + "), sep = "")
  
  for (i in seq(n.feat)) {
    my.formula <- as.formula(paste(feature.names[i], rhs.formula, sep = ""))
    fit <- lm(my.formula, data = dat)
    X.r[, i] <- fit$residuals
  }
  ## replace the original features by 
  ## the residualized features
  X.r
}



GetGlmAuc <- function(dat,
                      idx.train, 
                      idx.test, 
                      label.name, 
                      feature.names,
                      neg.class.name, 
                      pos.class.name) {
  dat <- dat[, c(label.name, feature.names)]
  dat[, label.name] <- factor(as.character(dat[, label.name]), 
                              levels = c(neg.class.name, pos.class.name)) 
  my.formula <- as.formula(paste(label.name, " ~ ", paste(feature.names, collapse = " + ")))
  fit <- glm(my.formula, data = dat[idx.train,], family = "binomial")
  pred.probs <- predict(fit, dat[idx.test, -1, drop = FALSE], type = "response")
  roc.obj <- roc(dat[idx.test, 1], pred.probs, direction = "<", 
                 levels = c(neg.class.name, pos.class.name))    
  auc.test <- pROC::auc(roc.obj)[1]
  
  list(auc.test = auc.test, 
       pred.probs.test = pred.probs, 
       roc.obj = roc.obj, 
       fit = fit)
}



################################################
################################################
################################################

## See https://www.synapse.org/#!Synapse:syn4993293/wiki/247859 
## for details on how to get access to the data

require(synapser)
synLogin()

## get subject and record ids from the training data
ids <- synTableQuery("SELECT * FROM syn10146553")$asDataFrame()
ids <- ids[, c("healthCode", "recordId")]

## get demographic data
demo <- synTableQuery("SELECT * FROM syn10146552")$asDataFrame()
names(demo) <- make.names(names(demo))
demo <- demo[, c("healthCode", "age", "professional.diagnosis")]

## generate the metadata object
mDat <- merge(ids, demo, by = "healthCode")
mDat <- na.omit(mDat)

## synIds for the feature set submissions
synIds <- c("syn10949406", "syn10942871", "syn11016798",
            "syn11027900", "syn11025141", "syn10958921",
            "syn10993705", "syn11027707", "syn10994144",
            "syn11013303", "syn11021065", "syn11027802",
            "syn10985094", "syn11023450", "syn11012618",
            "syn11024201", "syn10953880", "syn11027700",
            "syn11074660", "syn11017412", "syn10930833",
            "syn11025907", "syn11027273", "syn11025059",
            "syn10933121", "syn11023846", "syn11025858",
            "syn10985088", "syn11026462", "syn11026135",
            "syn10910686", "syn10951625", "syn11027683",
            "syn11024460", "syn10930815", "syn11026483")

## submission names
submission.names <- c("9638887", "9638742", "9640917",
                      "9641372", "9641265", "9640188",
                      "9640183", "9641368", "9640187",
                      "9641073", "9641021", "9641369",
                      "9641212", "9641175", "9641075",
                      "9643006", "9638996", "9643007",
                      "9642868", "9640926", "9640590",
                      "9641296", "9641352", "9641325",
                      "9639092", "9641224", "9641326",
                      "9641211", "9641314", "9642572",
                      "9641435", "9638987", "9641360",
                      "9641275", "9640591", "9641315")


nsets <- length(synIds)
datasets <- vector(mode = "list", length = nsets)
names(datasets) <- submission.names

for (i in seq(nsets)) {
  cat(i, "\n")
  aux <- try(ShapeData(mDat, feat.submission.synId = synIds[i]), silent = TRUE)
  if (!inherits(aux, "try-error")) {
    datasets[[i]] <- ShapeData(mDat, feat.submission.synId = synIds[i])
  }
}


#save(datasets, file = "mpower_datasets_list.RData", compress = TRUE)
#load("mpower_datasets_list.RData")


lapply(datasets, ncol)

idx.drop <- which(unlist(lapply(datasets, is.null)))

datasets <- datasets[-idx.drop]

idx.drop <- which(unlist(lapply(datasets, ncol)) == 3)

datasets <- datasets[-idx.drop]


## remove submission "9641211" which used metadata rather the the
## accelerometer data to extract features
datasets <- datasets[-which(names(datasets) == "9641211")]



set.seed(123456789)
ex <- RunMPowerExperimentsD(datasets,
                            nruns = 100,
                            label.name = "professional.diagnosis",
                            neg.class.name = "FALSE", 
                            pos.class.name = "TRUE")

#save(ex, file = "mpower_example_output.RData", compress = TRUE)
load("mpower_example_output.RData")

###########################
## Figure 8
###########################

par(mar = c(6, 3.5, 0.5, 0.5), mgp = c(2, 0.75, 0))
boxplot(ex$AUC.lr, ylim = c(0.4, 0.95), border = rgb(1, 0, 0, 0.5), las = 2, cex = 0.1, ylab = "AUROC", cex.lab = 1.6, cex.axis = 1.0)
boxplot(ex$AUC.ca, ylim = c(0.4, 0.95), border = rgb(0, 0, 1, 0.5), add = TRUE, las = 2, cex = 0.1, cex.axis = 1.0)
mtext(side = 1, text = "feature sets submitted to the challenge", line = 4.5, cex = 1.5)
legend("bottomleft", legend = c("residualization", "causality-aware"), text.col = c("red", "blue"), bty = "n", cex = 1.7)











