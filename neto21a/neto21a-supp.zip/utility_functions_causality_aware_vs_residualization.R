
######################
## dependencies
######################

library(MASS)
library(ppcor)

######################################################
## synthetic data experiment functions
######################################################

## generate data from linear regression models
## (correctlty specified case)
SimDataL <- function(n,
                    n_feat = 3,
                    mu_A1,
                    mu_A2,
                    Sig_A,
                    Sig_E,
                    mu_Y = 0,
                    beta_Y_A1 = 1,
                    beta_Y_A2 = 1,
                    sigma2_Y = 1,
                    mu_X = rep(0, n_feat),
                    beta_X_A1 = rep(1, n_feat),
                    beta_X_A2 = rep(1, n_feat),
                    beta_X_Y = rep(1, n_feat),
                    sigma2_X = rep(1, n_feat)) {
  A <- mvrnorm(n, mu = c(mu_A1, mu_A2), Sigma = Sig_A)
  colnames(A) <- c("A1", "A2")
  Y <- mu_Y + beta_Y_A1 * A[, "A1"] + beta_Y_A2 * A[, "A2"] + rnorm(n, 0, sqrt(sigma2_Y))
  X <- matrix(NA, n, n_feat)
  colnames(X) <- paste("X", seq(n_feat), sep = "")
  errE <- mvrnorm(n, mu = rep(0, n_feat), Sigma = Sig_E)
  for (i in seq(n_feat)) {
    X[, i] <- mu_X[i] + beta_X_A1[i] * A[, "A1"] + beta_X_A2[i] * A[, "A2"] + beta_X_Y[i] * Y + errE[, i]
  }
  dat <- data.frame(Y, A, X)  
  dat <- data.frame(scale(dat))
  
  dat
}


## generate data from non-linear additive models
## (correctlty specified case)
SimDataNL <- function(n,
                    n_feat = 3,
                    mu_A1,
                    mu_A2,
                    Sig_A,
                    Sig_E,
                    mu_Y = 0,
                    beta_Y_A1 = 1,
                    beta_Y_A2 = 1,
                    sigma2_Y = 1,
                    mu_X = rep(0, n_feat),
                    beta_X_A1 = rep(1, n_feat),
                    beta_X_A2 = rep(1, n_feat),
                    beta_X_Y = rep(1, n_feat),
                    sigma2_X = rep(1, n_feat)) {
  A <- mvrnorm(n, mu = c(mu_A1, mu_A2), Sigma = Sig_A)
  colnames(A) <- c("A1", "A2")
  Y <- mu_Y + beta_Y_A1 * A[, "A1"]^2 + beta_Y_A2 * A[, "A2"]^2 + rnorm(n, 0, sqrt(sigma2_Y))
  X <- matrix(NA, n, n_feat)
  colnames(X) <- paste("X", seq(n_feat), sep = "")
  errE <- mvrnorm(n, mu = rep(0, n_feat), Sigma = Sig_E)
  for (i in seq(n_feat)) {
    X[, i] <- mu_X[i] + beta_X_A1[i] * A[, "A1"]^2 + beta_X_A2[i] * A[, "A2"]^2 + beta_X_Y[i] * Y^2 + errE[, i]
  }
  dat <- data.frame(Y, A, X)  
  dat <- data.frame(scale(dat))
  
  dat
}


## implement the residualization adjustment
ResidualFeatures <- function(dat, feature_names, confounder_names) {
  n_feat <- length(feature_names)
  X_r <- matrix(NA, nrow(dat), n_feat)
  colnames(X_r) <- paste(feature_names, "_r", sep = "")
  rhs_formula <- paste(" ~ -1 + ", paste(confounder_names, collapse = " + "), sep = "")
  for (i in seq(n_feat)) {
    my_formula <- as.formula(paste(feature_names[i], rhs_formula, sep = ""))
    fit <- lm(my_formula, data = dat)
    X_r[, i] <- fit$residuals
  }
  
  X_r
}


## implements the causality-aware adjustment
CausalityAwareFeatures <- function(dat, i_train, i_test, response_name, feature_names, confounder_names) {
  dat_train <- dat[i_train,]
  dat_test <- dat[i_test,]
  n_feat <- length(feature_names)
  X_c <- matrix(NA, nrow(dat), n_feat)
  colnames(X_c) <- paste(feature_names, "_c", sep = "")
  rhs_formula <- paste(" ~ -1 + ", response_name, " + ", paste(confounder_names, collapse = " + "), sep = "")
  for (i in seq(n_feat)) {
    my_formula <- as.formula(paste(feature_names[i], rhs_formula, sep = ""))
    fit <- lm(my_formula, data = dat_train)
    err_train <- fit$residuals
    theta_XY_hat_train <- fit$coefficients[response_name]
    X_c_train <- theta_XY_hat_train * dat_train[, response_name] + err_train
    theta_XA_hat_train <- fit$coefficients[confounder_names]
    X_c_test <- dat_test[, feature_names[i]] - as.matrix(dat_test[, confounder_names]) %*% theta_XA_hat_train
    aux_X_c <- rep(NA, nrow(dat))
    aux_X_c[i_train] <- X_c_train
    aux_X_c[i_test] <- X_c_test
    X_c[, i] <- aux_X_c
  }
  
  X_c
}


## compute covariances
ComputeCovariances <- function(dat, response_name = "Y", feature_names) {
  as.vector(cov(x = dat[, feature_names], y = dat[, response_name]))
}


## compute MSE
LinearRegresssionMSE <- function(dat,
                                 i_train,
                                 i_test,
                                 response_name,
                                 feature_names) {
  dat_train <- dat[i_train,]
  dat_test <- dat[i_test,]
  my_formula <- as.formula(paste(response_name, " ~ ", paste(feature_names, collapse = "+"), sep = ""))
  fit <- lm(my_formula, data = dat_train)
  y_test_hat <- predict(fit, newdata = dat_test[, feature_names, drop = FALSE])
  y_test <- dat_test[, response_name]
  mse <- mean((y_test_hat - y_test)^2)
  
  list(mse = mse, yhat = y_test_hat)
}


## generate correlation matrix
CreateCorrelationMatrix <- function(rho, p) {
  aux1 <- matrix(rep(1:p, p), p, p)
  aux2 <- matrix(rep(1:p, each = p), p, p) 
  rho^abs(aux1 - aux2)
}


## check conditional independence patterns to evaluate
## if the adjustment is working as expected
CheckPCorPatterns <- function(Yhat, Y, A1, A2) {
  CorTests <- function(R, A, Y, labelName, confName, scoreName) {
    dat <- data.frame(Y, A, R)
    names(dat) <- c(labelName, confName, scoreName)
    cors <- matrix(NA, 6, 1)
    colnames(cors) <- "estimate"
    rownames(cors) <- c(paste("cor(", scoreName, " , ", labelName, ")", sep = ""),
                        paste("cor(", scoreName, " , ", confName, ")", sep = ""),
                        paste("cor(", labelName, " , ", confName, ")", sep = ""),
                        paste("cor(", paste(scoreName, labelName, sep = " , "), " | ", confName, ")", sep = ""),
                        paste("cor(", paste(scoreName, confName, sep = " , "), " | ", labelName, ")", sep = ""),
                        paste("cor(", paste(labelName, confName, sep = " , "), " | ", scoreName, ")", sep = ""))
    pvals <- cors
    colnames(pvals) <- "pval"
    aux1 <- cor.test(dat[, scoreName], dat[, labelName], method = "spearman", exact = FALSE)
    aux2 <- cor.test(dat[, scoreName], dat[, confName], method = "spearman", exact = FALSE)
    aux3 <- cor.test(dat[, labelName], dat[, confName], method = "spearman", exact = FALSE)
    aux4 <- pcor.test(dat[, scoreName], dat[, labelName], dat[, confName], method = "spearman")
    aux5 <- pcor.test(dat[, scoreName], dat[, confName], dat[, labelName], method = "spearman")
    aux6 <- pcor.test(dat[, labelName], dat[, confName], dat[, scoreName], method = "spearman")
    cors[1, 1] <- aux1$estimate
    cors[2, 1] <- aux2$estimate
    cors[3, 1] <- aux3$estimate
    cors[4, 1] <- aux4$estimate
    cors[5, 1] <- aux5$estimate
    cors[6, 1] <- aux6$estimate
    pvals[1, 1] <- aux1$p.value
    pvals[2, 1] <- aux2$p.value
    pvals[3, 1] <- aux3$p.value
    pvals[4, 1] <- aux4$p.value
    pvals[5, 1] <- aux5$p.value
    pvals[6, 1] <- aux6$p.value
    list(cors = cors, pvals = pvals)
  }
  aux_A1 <- CorTests(R = Yhat, 
                     Y = Y,
                     A = A1,
                     labelName = "Y", 
                     confName = "A1", 
                     scoreName = "Yhat")
  cors_A1 <- c(unlist(aux_A1[[1]])[, 1], unlist(aux_A1[[2]])[, 1])
  aux_A2 <- CorTests(R = Yhat, 
                     Y = Y,
                     A = A2,
                     labelName = "Y", 
                     confName = "A2", 
                     scoreName = "Yhat")
  cors_A2 <- c(unlist(aux_A2[[1]])[, 1], unlist(aux_A2[[2]])[, 1])  
  
  list(cors_A1 = cors_A1, cors_A2 = cors_A2)
}


## run the linear regression experiements
RunSyntheticDataExperiments <- function(n, 
                                        n_runs, 
                                        n_feat = 3, 
                                        my_seed, 
                                        correctly_specified = TRUE) {
  RegrModelFits <- function(dat,
                            response_name,
                            feature_names,
                            confounder_names,
                            i_train,
                            i_test) {
    aux_r <- ResidualFeatures(dat, feature_names, confounder_names)
    
    aux_c <- CausalityAwareFeatures(dat, i_train = i_train, i_test = i_test, response_name, feature_names, confounder_names)
    
    dat <- data.frame(dat, aux_r, aux_c)
    
    cov_X_Y_confounded <- ComputeCovariances(dat, 
                                             response_name = "Y", 
                                             feature_names = feature_names)
    cov_Xr_Y <- ComputeCovariances(dat, 
                                   response_name = "Y", 
                                   feature_names = residual_names)
    cov_Xc_Y <- ComputeCovariances(dat, 
                                   response_name = "Y", 
                                   feature_names = counterfactual_names)
    
    #####################################
    ## linear regression
    #####################################
    
    ## no adjustement
    aux1 <- LinearRegresssionMSE(dat,
                                 i_train,
                                 i_test,
                                 response_name = "Y",
                                 feature_names = feature_names)
    MSE_lr.1 <- aux1$mse
    pcors1 <- CheckPCorPatterns(Yhat = aux1$yhat, 
                                Y = dat$Y[i_test],
                                A1 = dat$A1[i_test],
                                A2 = dat$A2[i_test])
    pcors_Yhat_A1.1.6 <- pcors1$cors_A1[1:6]
    pcors_Yhat_A1.7.12 <- pcors1$cors_A1[7:12]
    pcors_Yhat_A2.1.6 <- pcors1$cors_A2[1:6]
    pcors_Yhat_A2.7.12 <- pcors1$cors_A2[7:12]
    
    ## residualization
    aux2 <- LinearRegresssionMSE(dat,
                                 i_train,
                                 i_test,
                                 response_name = "Y",
                                 feature_name = residual_names) 
    MSE_lr.2 <- aux2$mse
    pcors2 <- CheckPCorPatterns(Yhat = aux2$yhat, 
                                Y = dat$Y[i_test],
                                A1 = dat$A1[i_test],
                                A2 = dat$A2[i_test])
    pcors_Yhat_A1_r.1.6 <- pcors2$cors_A1[1:6]
    pcors_Yhat_A1_r.7.12 <- pcors2$cors_A1[7:12]
    pcors_Yhat_A2_r.1.6 <- pcors2$cors_A2[1:6]
    pcors_Yhat_A2_r.7.12 <- pcors2$cors_A2[7:12]
    
    ## causality-aware
    aux3 <- LinearRegresssionMSE(dat,
                                 i_train,
                                 i_test,
                                 response_name = "Y",
                                 feature_name = counterfactual_names) 
    MSE_lr.3 <- aux3$mse
    pcors3 <- CheckPCorPatterns(Yhat = aux3$yhat, 
                                Y = dat$Y[i_test],
                                A1 = dat$A1[i_test],
                                A2 = dat$A2[i_test])
    pcors_Yhat_A1_c.1.6 <- pcors3$cors_A1[1:6]
    pcors_Yhat_A1_c.7.12 <- pcors3$cors_A1[7:12]
    pcors_Yhat_A2_c.1.6 <- pcors3$cors_A2[1:6]
    pcors_Yhat_A2_c.7.12 <- pcors3$cors_A2[7:12]
    
    list(cov_X_Y_confounded = cov_X_Y_confounded,
         cov_Xr_Y = cov_Xr_Y,
         cov_Xc_Y = cov_Xc_Y,
         MSE_lr.1 = MSE_lr.1,
         MSE_lr.2 = MSE_lr.2,
         MSE_lr.3 = MSE_lr.3,
         pcors_Yhat_A1.1.6 = pcors_Yhat_A1.1.6,
         pcors_Yhat_A1.7.12 = pcors_Yhat_A1.7.12,
         pcors_Yhat_A2.1.6 = pcors_Yhat_A2.1.6,
         pcors_Yhat_A2.7.12 = pcors_Yhat_A2.7.12,
         pcors_Yhat_A1_r.1.6 = pcors_Yhat_A1_r.1.6,
         pcors_Yhat_A1_r.7.12 = pcors_Yhat_A1_r.7.12,
         pcors_Yhat_A2_r.1.6 = pcors_Yhat_A2_r.1.6,
         pcors_Yhat_A2_r.7.12 = pcors_Yhat_A2_r.7.12,
         pcors_Yhat_A1_c.1.6 = pcors_Yhat_A1_c.1.6,
         pcors_Yhat_A1_c.7.12 = pcors_Yhat_A1_c.7.12,
         pcors_Yhat_A2_c.1.6 = pcors_Yhat_A2_c.1.6,
         pcors_Yhat_A2_c.7.12 = pcors_Yhat_A2_c.7.12)
  }
  feature_names <- paste("X", seq(n_feat), sep = "")
  residual_names <- paste(feature_names, "r", sep = "_")
  counterfactual_names <- paste(feature_names, "c", sep = "_")
  confounder_names <- c("A1", "A2")
  response_name <- "Y"
  
  MSE_lr <- matrix(NA, n_runs, 3)
  colnames(MSE_lr) <- c("no adjustment", "residualization", "causality-aware")
  cov_X_Y_confounded <- matrix(NA, n_runs, n_feat, dimnames = list(NULL, feature_names))
  cov_Xr_Y <- matrix(NA, n_runs, n_feat, dimnames = list(NULL, residual_names))
  cov_Xc_Y <- matrix(NA, n_runs, n_feat, dimnames = list(NULL, counterfactual_names))
  colnms <- c("cor(Yhat,Y)", "cor(Yhat,A)", "cor(A,Y)", "cor(Yhat,Y|A)", "cor(Yhat,A|Y)", "cor(A,Y|Yhat)",
              "pval(Yhat,Y)", "pval(Yhat,A)", "pval(A,Y)", "pval(Yhat,Y|A)", "pval(Yhat,A|Y)", "pval(A,Y|Yhat)")
  pcors_Yhat_A1 <- matrix(NA, n_runs, 12, dimnames = list(NULL, colnms))
  pcors_Yhat_A2 <- pcors_Yhat_A1
  pcors_Yhat_A1_r <- pcors_Yhat_A1
  pcors_Yhat_A2_r <- pcors_Yhat_A1
  pcors_Yhat_A1_c <- pcors_Yhat_A1
  pcors_Yhat_A2_c <- pcors_Yhat_A1
  
  i_train <- seq(n)
  i_test <- seq(n+1, 2*n, by = 1)
  set.seed(my_seed)
  my_seeds <- sample(seq(1e+4, 1e+5), n_runs, replace = FALSE)
  
  for (i in seq(n_runs)) {
    cat(i, "\n")
    set.seed(my_seeds[i])
    mu_A1 <- runif(1, -3, 3) 
    mu_A2 <- runif(1, -3, 3)
    mu_Y <- runif(1, -3, 3) 
    mu_X <- runif(n_feat, -3, 3)
    beta_Y_A1 <- runif(1, -3, 3)
    beta_Y_A2 <- runif(1, -3, 3)
    beta_X_A1 <- runif(n_feat, -3, 3)
    beta_X_A2 <- runif(n_feat, -3, 3)
    beta_X_Y <- runif(n_feat, -3, 3)
    sigma2_Y <- runif(1, 1, 3) 
    sigma2_X <- runif(n_feat, 1, 3)
    rho <- runif(1, -0.8, 0.8)
    Sig_A <- matrix(c(1, rho, rho, 1), 2, 2, byrow = TRUE)
    rho <- runif(1, -0.8, 0.8)
    Sig_E <- CreateCorrelationMatrix(rho = rho, p = n_feat)
    
    if (correctly_specified) {
      dat <- SimDataL(2*n, n_feat, mu_A1, mu_A2, Sig_A, Sig_E, mu_Y,
                      beta_Y_A1, beta_Y_A2, sigma2_Y, mu_X, beta_X_A1,
                      beta_X_A2, beta_X_Y, sigma2_X)
    }
    else {
      dat <- SimDataNL(2*n, n_feat, mu_A1, mu_A2, Sig_A, Sig_E, mu_Y,
                       beta_Y_A1, beta_Y_A2, sigma2_Y, mu_X, beta_X_A1,
                       beta_X_A2, beta_X_Y, sigma2_X)
    }
    
    fit <- try(RegrModelFits(dat,
                             response_name,
                             feature_names,
                             confounder_names,
                             i_train,
                             i_test), silent = TRUE)
    if (!inherits(fit, "try-error")) {
      cov_X_Y_confounded[i,] <- fit$cov_X_Y_confounded
      cov_Xr_Y[i,] <- fit$cov_Xr_Y
      cov_Xc_Y[i,] <- fit$cov_Xc_Y
      
      MSE_lr[i, 1] <- fit$MSE_lr.1
      MSE_lr[i, 2] <- fit$MSE_lr.2
      MSE_lr[i, 3] <- fit$MSE_lr.3
      
      pcors_Yhat_A1[i, 1:6] <- fit$pcors_Yhat_A1.1.6
      pcors_Yhat_A1[i, 7:12] <- fit$pcors_Yhat_A1.7.12
      pcors_Yhat_A2[i, 1:6] <- fit$pcors_Yhat_A2.1.6
      pcors_Yhat_A2[i, 7:12] <- fit$pcors_Yhat_A2.7.12
      
      pcors_Yhat_A1_r[i, 1:6] <- fit$pcors_Yhat_A1_r.1.6
      pcors_Yhat_A1_r[i, 7:12] <- fit$pcors_Yhat_A1_r.7.12
      pcors_Yhat_A2_r[i, 1:6] <- fit$pcors_Yhat_A2_r.1.6
      pcors_Yhat_A2_r[i, 7:12] <- fit$pcors_Yhat_A2_r.7.12
      
      pcors_Yhat_A1_c[i, 1:6] <- fit$pcors_Yhat_A1_c.1.6
      pcors_Yhat_A1_c[i, 7:12] <- fit$pcors_Yhat_A1_c.7.12
      pcors_Yhat_A2_c[i, 1:6] <- fit$pcors_Yhat_A2_c.1.6
      pcors_Yhat_A2_c[i, 7:12] <- fit$pcors_Yhat_A2_c.7.12
    }
  }
  
  list(MSE = MSE_lr,
       cov_X_Y_confounded = cov_X_Y_confounded,
       cov_Xr_Y = cov_Xr_Y,
       cov_Xc_Y = cov_Xc_Y,
       pcors_Yhat_A1 = pcors_Yhat_A1,
       pcors_Yhat_A2 = pcors_Yhat_A2,
       pcors_Yhat_A1_r = pcors_Yhat_A1_r,
       pcors_Yhat_A2_r = pcors_Yhat_A2_r,
       pcors_Yhat_A1_c = pcors_Yhat_A1_c,
       pcors_Yhat_A2_c = pcors_Yhat_A2_c)
}




## simulate bivariate bernoulli random variables
SampleBivariateBernoulli <- function(n, p.00, p.01, p.10, p.11, binVarNames = NULL) {
  aux <- sample(c("0,0", "0,1", "1,0", "1,1"), n, replace = TRUE, prob = c(p.00, p.01, p.10, p.11))
  out <- matrix(NA, n, 2)
  idx.00 <- which(aux == "0,0")
  out[idx.00, 1] <- 0
  out[idx.00, 2] <- 0
  idx.01 <- which(aux == "0,1")
  out[idx.01, 1] <- 0
  out[idx.01, 2] <- 1
  idx.10 <- which(aux == "1,0")
  out[idx.10, 1] <- 1
  out[idx.10, 2] <- 0
  idx.11 <- which(aux == "1,1")
  out[idx.11, 1] <- 1
  out[idx.11, 2] <- 1
  colnames(out) <- binVarNames
  
  out
}


## generate correctly specified classification data
SimClassificationDataL <- function(n,
                     n_feat = 3,
                     p_11,
                     p_10,
                     p_01,
                     p_00,
                     Sig_E,
                     mu_Y = 0,
                     beta_Y_A1 = 1,
                     beta_Y_A2 = 1,
                     mu_X = rep(0, n_feat),
                     beta_X_A1 = rep(1, n_feat),
                     beta_X_A2 = rep(1, n_feat),
                     beta_X_Y = rep(1, n_feat),
                     sigma2_X = rep(1, n_feat)) {
  A <- SampleBivariateBernoulli(n, p_00, p_01, p_10, p_11, binVarNames = c("A1", "A2"))
  linpred <- as.vector(mu_Y + beta_Y_A1 * A[, "A1"] + beta_Y_A2 * A[, "A2"])
  probs <- 1/(1 + exp(-linpred))
  aux <- runif(n, 0, 1)
  Y <- ifelse(aux < probs, 1, 0)
  X <- matrix(NA, n, n_feat)
  colnames(X) <- paste("X", seq(n_feat), sep = "")
  errE <- mvrnorm(n, mu = rep(0, n_feat), Sigma = Sig_E)
  for (i in seq(n_feat)) {
    X[, i] <- mu_X[i] + beta_X_A1[i] * A[, "A1"] + beta_X_A2[i] * A[, "A2"] + beta_X_Y[i] * Y + errE[, i]
  }
  dat <- data.frame(Y, A, X)
  dat <- data.frame(scale(dat))
  
  dat
}


## generate mispecified classification data
SimClassificationDataNL <- function(n,
                                   n_feat = 3,
                                   p_11,
                                   p_10,
                                   p_01,
                                   p_00,
                                   Sig_E,
                                   mu_Y = 0,
                                   beta_Y_A1 = 1,
                                   beta_Y_A2 = 1,
                                   mu_X = rep(0, n_feat),
                                   beta_X_A1 = rep(1, n_feat),
                                   beta_X_A2 = rep(1, n_feat),
                                   beta_X_Y = rep(1, n_feat),
                                   beta_X_Y_A1 = rep(1, n_feat),
                                   beta_X_Y_A2 = rep(1, n_feat),
                                   sigma2_X = rep(1, n_feat)) {
  A <- SampleBivariateBernoulli(n, p_00, p_01, p_10, p_11, binVarNames = c("A1", "A2"))
  linpred <- as.vector(mu_Y + beta_Y_A1 * A[, "A1"] + beta_Y_A2 * A[, "A2"])
  probs <- 1/(1 + exp(-linpred))
  aux <- runif(n, 0, 1)
  Y <- ifelse(aux < probs, 1, 0)
  X <- matrix(NA, n, n_feat)
  colnames(X) <- paste("X", seq(n_feat), sep = "")
  errE <- mvrnorm(n, mu = rep(0, n_feat), Sigma = Sig_E)
  for (i in seq(n_feat)) {
    X[, i] <- mu_X[i] + beta_X_A1[i] * A[, "A1"] + beta_X_A2[i] * A[, "A2"] + beta_X_Y[i] * Y + beta_X_Y_A1[i] * Y * A[, "A1"] + beta_X_Y_A2[i] * Y * A[, "A2"] + errE[, i]
  }
  dat <- data.frame(Y, A, X)
  dat <- data.frame(scale(dat))
  
  dat
}


## run the linear regression experiements
RunSyntheticDataClassificationExperiments <- function(n, 
                                                      n_runs, 
                                                      n_feat = 3, 
                                                      my_seed, 
                                                      correctly_specified = TRUE) {
  ClassModelFits <- function(dat,
                             response_name,
                             feature_names,
                             confounder_names,
                             i_train,
                             i_test) {
    aux_r <- ResidualFeatures(dat, feature_names, confounder_names)
    
    aux_c <- CausalityAwareFeatures(dat, i_train = i_train, i_test = i_test, response_name, feature_names, confounder_names)
    
    dat <- data.frame(dat, aux_r, aux_c)
    
    cov_X_Y_confounded <- ComputeCovariances(dat, 
                                             response_name = "Y", 
                                             feature_names = feature_names)
    cov_Xr_Y <- ComputeCovariances(dat, 
                                   response_name = "Y", 
                                   feature_names = residual_names)
    cov_Xc_Y <- ComputeCovariances(dat, 
                                   response_name = "Y", 
                                   feature_names = counterfactual_names)
    
    
    ## creates new dataset, dat2, with Y set to factor for
    ## logistic regression classification (we use dat2 for
    ## the logistic regression data fit and "dat", where Y is
    ## numeric for covariance computations)
    
    clevels <- as.character(sort(unique(dat$Y)))
    dat2 <- dat
    dat2$Y <- as.character(dat2$Y)
    neg_class_name <- clevels[1]
    pos_class_name <- clevels[2]
    
    aux1 <- GetGlmAcc(dat2,
                      i_train,
                      i_test,
                      label_name = "Y",
                      feature_names = feature_names,
                      neg_class_name, 
                      pos_class_name)
    ACC_lr.1 <- aux1$acc_test
    pcors1 <- CheckPCorPatterns(Yhat = aux1$pred_probs_test, 
                                Y = dat$Y[i_test],
                                A1 = dat$A1[i_test],
                                A2 = dat$A2[i_test])
    pcors_Yhat_A1.1.6 <- pcors1$cors_A1[1:6]
    pcors_Yhat_A1.7.12 <- pcors1$cors_A1[7:12]
    pcors_Yhat_A2.1.6 <- pcors1$cors_A2[1:6]
    pcors_Yhat_A2.7.12 <- pcors1$cors_A2[7:12]
    
    ## residualization
    aux2 <- GetGlmAcc(dat2,
                      i_train,
                      i_test,
                      label_name = "Y",
                      feature_names = residual_names,
                      neg_class_name, 
                      pos_class_name)
    ACC_lr.2 <- aux2$acc_test
    pcors2 <- CheckPCorPatterns(Yhat = aux2$pred_probs_test, 
                                Y = dat$Y[i_test],
                                A1 = dat$A1[i_test],
                                A2 = dat$A2[i_test])
    pcors_Yhat_A1_r.1.6 <- pcors2$cors_A1[1:6]
    pcors_Yhat_A1_r.7.12 <- pcors2$cors_A1[7:12]
    pcors_Yhat_A2_r.1.6 <- pcors2$cors_A2[1:6]
    pcors_Yhat_A2_r.7.12 <- pcors2$cors_A2[7:12]
    
    ## causality-aware
    aux3 <- GetGlmAcc(dat2,
                      i_train,
                      i_test,
                      label_name = "Y",
                      feature_names = counterfactual_names,
                      neg_class_name, 
                      pos_class_name)
    ACC_lr.3 <- aux3$acc_test
    pcors3 <- CheckPCorPatterns(Yhat = aux3$pred_probs_test, 
                                Y = dat$Y[i_test],
                                A1 = dat$A1[i_test],
                                A2 = dat$A2[i_test])
    pcors_Yhat_A1_c.1.6 <- pcors3$cors_A1[1:6]
    pcors_Yhat_A1_c.7.12 <- pcors3$cors_A1[7:12]
    pcors_Yhat_A2_c.1.6 <- pcors3$cors_A2[1:6]
    pcors_Yhat_A2_c.7.12 <- pcors3$cors_A2[7:12]
    
    list(cov_X_Y_confounded = cov_X_Y_confounded,
         cov_Xr_Y = cov_Xr_Y,
         cov_Xc_Y = cov_Xc_Y,
         ACC_lr.1 = ACC_lr.1,
         ACC_lr.2 = ACC_lr.2,
         ACC_lr.3 = ACC_lr.3,
         pcors_Yhat_A1.1.6 = pcors_Yhat_A1.1.6,
         pcors_Yhat_A1.7.12 = pcors_Yhat_A1.7.12,
         pcors_Yhat_A2.1.6 = pcors_Yhat_A2.1.6,
         pcors_Yhat_A2.7.12 = pcors_Yhat_A2.7.12,
         pcors_Yhat_A1_r.1.6 = pcors_Yhat_A1_r.1.6,
         pcors_Yhat_A1_r.7.12 = pcors_Yhat_A1_r.7.12,
         pcors_Yhat_A2_r.1.6 = pcors_Yhat_A2_r.1.6,
         pcors_Yhat_A2_r.7.12 = pcors_Yhat_A2_r.7.12,
         pcors_Yhat_A1_c.1.6 = pcors_Yhat_A1_c.1.6,
         pcors_Yhat_A1_c.7.12 = pcors_Yhat_A1_c.7.12,
         pcors_Yhat_A2_c.1.6 = pcors_Yhat_A2_c.1.6,
         pcors_Yhat_A2_c.7.12 = pcors_Yhat_A2_c.7.12)
  }
  feature_names <- paste("X", seq(n_feat), sep = "")
  residual_names <- paste(feature_names, "r", sep = "_")
  counterfactual_names <- paste(feature_names, "c", sep = "_")
  confounder_names <- c("A1", "A2")
  response_name <- "Y"
  
  ACC_lr <- matrix(NA, n_runs, 3)
  colnames(ACC_lr) <- c("no adjustment", "residualization", "causality-aware")
  cov_X_Y_confounded <- matrix(NA, n_runs, n_feat, dimnames = list(NULL, feature_names))
  cov_Xr_Y <- matrix(NA, n_runs, n_feat, dimnames = list(NULL, residual_names))
  cov_Xc_Y <- matrix(NA, n_runs, n_feat, dimnames = list(NULL, counterfactual_names))
  colnms <- c("cor(Yhat,Y)", "cor(Yhat,A)", "cor(A,Y)", "cor(Yhat,Y|A)", "cor(Yhat,A|Y)", "cor(A,Y|Yhat)",
              "pval(Yhat,Y)", "pval(Yhat,A)", "pval(A,Y)", "pval(Yhat,Y|A)", "pval(Yhat,A|Y)", "pval(A,Y|Yhat)")
  pcors_Yhat_A1 <- matrix(NA, n_runs, 12, dimnames = list(NULL, colnms))
  pcors_Yhat_A2 <- pcors_Yhat_A1
  pcors_Yhat_A1_r <- pcors_Yhat_A1
  pcors_Yhat_A2_r <- pcors_Yhat_A1
  pcors_Yhat_A1_c <- pcors_Yhat_A1
  pcors_Yhat_A2_c <- pcors_Yhat_A1
  
  i_train <- seq(n)
  i_test <- seq(n+1, 2*n, by = 1)
  set.seed(my_seed)
  my_seeds <- sample(seq(1e+4, 1e+5), n_runs, replace = FALSE)
  
  for (i in seq(n_runs)) {
    cat(i, "\n")
    set.seed(my_seeds[i])
    ## randomly sample probabilities for bivariate bernoulli
    aux <- sort(sample(seq(100), 3, replace = FALSE))
    p_11 <- aux[1]/100
    p_10 <- (aux[2] - aux[1])/100
    p_01 <- (aux[3] - aux[2])/100
    p_00 <- (100 - aux[3])/100
    
    mu_Y <- runif(1, -3, 3) 
    mu_X <- runif(n_feat, -3, 3)
    beta_Y_A1 <- runif(1, -3, 3)
    beta_Y_A2 <- runif(1, -3, 3)
    beta_X_A1 <- runif(n_feat, -3, 3)
    beta_X_A2 <- runif(n_feat, -3, 3)
    beta_X_Y <- runif(n_feat, -3, 3)
    beta_X_Y_A1 <- runif(n_feat, -3, 3)
    beta_X_Y_A2 <- runif(n_feat, -3, 3)
    sigma2_X <- runif(n_feat, 1, 3)
    rho <- runif(1, -0.8, 0.8)
    Sig_E <- CreateCorrelationMatrix(rho = rho, p = n_feat)
    
    if (correctly_specified) {
      dat <- SimClassificationDataL(2*n, n_feat, p_11, p_10, p_01, p_00, Sig_E,
                                    mu_Y, beta_Y_A1, beta_Y_A2, mu_X, beta_X_A1, beta_X_A2,
                                    beta_X_Y, sigma2_X)
    }
    else {
      dat <- SimClassificationDataNL(2*n, n_feat, p_11, p_10, p_01, p_00, Sig_E,
                                     mu_Y, beta_Y_A1, beta_Y_A2, mu_X, 
                                     beta_X_A1 = rep(0, n_feat), 
                                     beta_X_A2 = rep(0, n_feat),
                                     beta_X_Y = rep(0, n_feat), 
                                     beta_X_Y_A1, beta_X_Y_A2, sigma2_X)
    }
    
    fit <- try(ClassModelFits(dat,
                              response_name,
                              feature_names,
                              confounder_names,
                              i_train,
                              i_test), silent = TRUE)
    if (!inherits(fit, "try-error")) {
      cov_X_Y_confounded[i,] <- fit$cov_X_Y_confounded
      cov_Xr_Y[i,] <- fit$cov_Xr_Y
      cov_Xc_Y[i,] <- fit$cov_Xc_Y
      
      ACC_lr[i, 1] <- fit$ACC_lr.1
      ACC_lr[i, 2] <- fit$ACC_lr.2
      ACC_lr[i, 3] <- fit$ACC_lr.3
      
      pcors_Yhat_A1[i, 1:6] <- fit$pcors_Yhat_A1.1.6
      pcors_Yhat_A1[i, 7:12] <- fit$pcors_Yhat_A1.7.12
      pcors_Yhat_A2[i, 1:6] <- fit$pcors_Yhat_A2.1.6
      pcors_Yhat_A2[i, 7:12] <- fit$pcors_Yhat_A2.7.12
      
      pcors_Yhat_A1_r[i, 1:6] <- fit$pcors_Yhat_A1_r.1.6
      pcors_Yhat_A1_r[i, 7:12] <- fit$pcors_Yhat_A1_r.7.12
      pcors_Yhat_A2_r[i, 1:6] <- fit$pcors_Yhat_A2_r.1.6
      pcors_Yhat_A2_r[i, 7:12] <- fit$pcors_Yhat_A2_r.7.12
      
      pcors_Yhat_A1_c[i, 1:6] <- fit$pcors_Yhat_A1_c.1.6
      pcors_Yhat_A1_c[i, 7:12] <- fit$pcors_Yhat_A1_c.7.12
      pcors_Yhat_A2_c[i, 1:6] <- fit$pcors_Yhat_A2_c.1.6
      pcors_Yhat_A2_c[i, 7:12] <- fit$pcors_Yhat_A2_c.7.12
    }
  }
  
  list(ACC = ACC_lr,
       cov_X_Y_confounded = cov_X_Y_confounded,
       cov_Xr_Y = cov_Xr_Y,
       cov_Xc_Y = cov_Xc_Y,
       pcors_Yhat_A1 = pcors_Yhat_A1,
       pcors_Yhat_A2 = pcors_Yhat_A2,
       pcors_Yhat_A1_r = pcors_Yhat_A1_r,
       pcors_Yhat_A2_r = pcors_Yhat_A2_r,
       pcors_Yhat_A1_c = pcors_Yhat_A1_c,
       pcors_Yhat_A2_c = pcors_Yhat_A2_c)
}




## fit logistic regression classifier and
## compute accuracy
GetGlmAcc <- function(dat,
                      i_train,
                      i_test, 
                      label_name, 
                      feature_names,
                      neg_class_name, 
                      pos_class_name) {
  ComputeBinaryAccuracy <- function(y_test, pred_probs, thr = 0.5) {
    y_hat <- ifelse(pred_probs >= thr, 1, 0)
    y_test <- as.numeric(y_test) - 1
    sum(y_hat == y_test)/length(y_hat)
  }
  dat <- dat[, c(label_name, feature_names)]
  dat[, label_name] <- factor(as.character(dat[, label_name]), 
                             levels = c(neg_class_name, pos_class_name)) 
  my_formula <- as.formula(paste(label_name, " ~ ", paste(feature_names, collapse = " + ")))
  fit <- glm(my_formula, data = dat[i_train,], family = "binomial")
  pred_probs_test <- predict(fit, dat[i_test, -1, drop = FALSE], type = "response")
  acc_test <- ComputeBinaryAccuracy(y_test = dat[i_test, 1], pred_probs = pred_probs_test, thr = 0.5)
  
  list(acc_test = acc_test, 
       pred_probs_test = pred_probs_test)
}



