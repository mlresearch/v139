
###################################################
## load dependencies and utility functions
###################################################

source("utility_functions_causality_aware_vs_residualization.R")


###################################################
## run the analyses
###################################################

n <- 100 ## sample size
n_runs <- 1000 ## number of replications


## regression task (correctly specified case)
correct.outputs <- vector(mode = "list", length = 10)
for (i in seq(10)) {
  correct.outputs[[i]] <- RunSyntheticDataExperiments(n = n, n_runs = n_runs, n_feat = i, my_seed = 123456789, correctly_specified = TRUE)
}


## regression task (mispecified case)
mispecified.outputs <- vector(mode = "list", length = 10)
for (i in seq(10)) {
  mispecified.outputs[[i]] <- RunSyntheticDataExperiments(n = n, n_runs = n_runs, n_feat = i, my_seed = 123456789, correctly_specified = FALSE)
}


## classification task (correctly specified case)
correct.outputs.class <- vector(mode = "list", length = 10)
for (i in seq(10)) {
  correct.outputs.class[[i]] <- RunSyntheticDataClassificationExperiments(n = n, n_runs = n_runs, n_feat = i, my_seed = 123456789, correctly_specified = TRUE)
}


## classification task (mispecified case)
mispecified.outputs.class <- vector(mode = "list", length = 10)
for (i in seq(10)) {
  mispecified.outputs.class[[i]] <- RunSyntheticDataClassificationExperiments(n = n, n_runs = n_runs, n_feat = i, my_seed = 123456789, correctly_specified = FALSE)
}


#save(correct.outputs, mispecified.outputs, correct.outputs.class, mispecified.outputs.class, 
#     file = "outputs_all_simulations_n100.RData", compress = TRUE)


###################################################
## generate paper figures
###################################################


#load("outputs_all_simulations_n100.RData")
n_runs <- 1000

############################################
## Supplementary Figure S1 (regression task)
############################################

## we use the results based on 2 features
cs1 <- correct.outputs[[2]]
ms1 <- mispecified.outputs[[2]]

cp <- 1
myline <- 0.1
mylim1 <- c(0, 1.8)
mylim2 <- c(0, 2.5)
cp2 <- 1


par(mfrow = c(2, 3), mar = c(3, 3.5, 1.2, 0.5), mgp = c(1.75, 0.5, 0))
####
plot(abs(cs1$cov_Xr_Y[, "X1_r"]), abs(cs1$cov_Xc_Y[, "X1_c"]), ylim = mylim2, xlim = mylim2,
     xlab = expression(paste("|", hat(Cov), "(", X['r,1'],",Y)|")),
     ylab = expression(paste("|", hat(Cov), "(", X['c,1'],",Y)|")),
     main = "correct", cex = cp2)
abline(a = 0, b = 1, col = "red")
mtext(side = 3, at = 0, text = "(a)", cex = cp, line = myline)
####
plot(abs(cs1$cov_Xr_Y[, "X2_r"]), abs(cs1$cov_Xc_Y[, "X2_c"]), ylim = mylim2, xlim = mylim2,
     xlab = expression(paste("|", hat(Cov), "(", X['r,2'],",Y)|")),
     ylab = expression(paste("|", hat(Cov), "(", X['c,2'],",Y)|")),
     main = "correct", cex = cp2)
abline(a = 0, b = 1, col = "red")
mtext(side = 3, at = 0, text = "(b)", cex = cp, line = myline)
####
plot(cs1$MSE[, "residualization"], cs1$MSE[, "causality-aware"], ylim = mylim1, xlim = mylim1,
     xlab = expression(MSE[r]),
     ylab = expression(MSE[c]),
     main = "correct", cex = cp2)
abline(a = 0, b = 1, col = "red")
mtext(side = 3, at = 0, text = "(c)", cex = cp, line = myline)
####
plot(abs(ms1$cov_Xr_Y[, "X1_r"]), abs(ms1$cov_Xc_Y[, "X1_c"]), ylim = mylim2, xlim = mylim2,
     xlab = expression(paste("|", hat(Cov), "(", X['r,1'],",Y)|")),
     ylab = expression(paste("|", hat(Cov), "(", X['c,1'],",Y)|")),
     main = "mispecified", cex = cp2)
abline(a = 0, b = 1, col = "red")
mtext(side = 3, at = 0, text = "(d)", cex = cp, line = myline)
####
plot(abs(ms1$cov_Xr_Y[, "X2_r"]), abs(ms1$cov_Xc_Y[, "X2_c"]), ylim = mylim2, xlim = mylim2,
     xlab = expression(paste("|", hat(Cov), "(", X['r,2'],",Y)|")),
     ylab = expression(paste("|", hat(Cov), "(", X['c,2'],",Y)|")),
     main = "mispecified", cex = cp2)
abline(a = 0, b = 1, col = "red")
mtext(side = 3, at = 0, text = "(e)", cex = cp, line = myline)
####
plot(ms1$MSE[, "residualization"], ms1$MSE[, "causality-aware"], ylim = mylim1, xlim = mylim1,
     xlab = expression(MSE[r]),
     ylab = expression(MSE[c]),
     main = "mispecified", cex = cp2)
abline(a = 0, b = 1, col = "red")
mtext(side = 3, at = 0, text = "(f)", cex = cp, line = myline)



#################################################
## Supplementary Figure S2 (classification task)
#################################################

## we use the results based on 2 features
cs1 <- correct.outputs.class[[2]]
ms1 <- mispecified.outputs.class[[2]]

mylim1 <- c(0.45, 1.0)
mylim2 <- c(0, 1.0)
cp <- 1
myline <- 0.1

par(mfrow = c(2, 3), mar = c(3, 3.5, 1.2, 0.5), mgp = c(1.75, 0.5, 0))
####
plot(abs(cs1$cov_Xr_Y[, "X1_r"]), abs(cs1$cov_Xc_Y[, "X1_c"]), ylim = mylim2, xlim = mylim2,
     xlab = expression(paste("|", hat(Cov), "(", X['r,1'],",Y)|")),
     ylab = expression(paste("|", hat(Cov), "(", X['c,1'],",Y)|")),
     main = "correct")
abline(a = 0, b = 1, col = "red")
mtext(side = 3, at = 0, text = "(a)", cex = cp, line = myline)
####
plot(abs(cs1$cov_Xr_Y[, "X2_r"]), abs(cs1$cov_Xc_Y[, "X2_c"]), ylim = mylim2, xlim = mylim2,
     xlab = expression(paste("|", hat(Cov), "(", X['r,2'],",Y)|")),
     ylab = expression(paste("|", hat(Cov), "(", X['c,2'],",Y)|")),
     main = "correct")
abline(a = 0, b = 1, col = "red")
mtext(side = 3, at = 0, text = "(b)", cex = cp, line = myline)
####
plot(cs1$ACC[, "residualization"], cs1$ACC[, "causality-aware"], ylim = mylim1, xlim = mylim1,
     xlab = expression(ACC[r]),
     ylab = expression(ACC[c]),
     main = "correct")
abline(a = 0, b = 1, col = "red")
mtext(side = 3, at = 0.5, text = "(c)", cex = cp, line = myline)
####
plot(abs(ms1$cov_Xr_Y[, "X1_r"]), abs(ms1$cov_Xc_Y[, "X1_c"]), ylim = mylim2, xlim = mylim2,
     xlab = expression(paste("|", hat(Cov), "(", X['r,1'],",Y)|")),
     ylab = expression(paste("|", hat(Cov), "(", X['c,1'],",Y)|")),
     main = "mispecified")
abline(a = 0, b = 1, col = "red")
mtext(side = 3, at = 0, text = "(d)", cex = cp, line = myline)
####
plot(abs(ms1$cov_Xr_Y[, "X2_r"]), abs(ms1$cov_Xc_Y[, "X2_c"]), ylim = mylim2, xlim = mylim2,
     xlab = expression(paste("|", hat(Cov), "(", X['r,2'],",Y)|")),
     ylab = expression(paste("|", hat(Cov), "(", X['c,2'],",Y)|")),
     main = "mispecified")
abline(a = 0, b = 1, col = "red")
mtext(side = 3, at = 0, text = "(e)", cex = cp, line = myline)
####
plot(ms1$ACC[, "residualization"], ms1$ACC[, "causality-aware"], ylim = mylim1, xlim = mylim1,
     xlab = expression(ACC[r]),
     ylab = expression(ACC[c]),
     main = "mispecified")
abline(a = 0, b = 1, col = "red")
mtext(side = 3, at = 0.5, text = "(f)", cex = cp, line = myline)


###########################################################
## Supplementary Figure S3 (increasing number of features)
###########################################################

delta.MSE.c <- matrix(NA, n_runs, 10)
colnames(delta.MSE.c) <- as.character(seq(10))
for (i in seq(10)) {
  delta.MSE.c[, i] <- correct.outputs[[i]]$MSE[, "residualization"] - correct.outputs[[i]]$MSE[, "causality-aware"]
}

delta.MSE.m <- matrix(NA, n_runs, 10)
colnames(delta.MSE.m) <- as.character(seq(10))
for (i in seq(10)) {
  delta.MSE.m[, i] <- mispecified.outputs[[i]]$MSE[, "residualization"] - mispecified.outputs[[i]]$MSE[, "causality-aware"]
}

delta.ACC.c <- matrix(NA, n_runs, 10)
colnames(delta.ACC.c) <- as.character(seq(10))
for (i in seq(10)) {
  delta.ACC.c[, i] <- correct.outputs.class[[i]]$ACC[, "causality-aware"] - correct.outputs.class[[i]]$ACC[, "residualization"]
}

delta.ACC.m <- matrix(NA, n_runs, 10)
colnames(delta.ACC.m) <- as.character(seq(10))
for (i in seq(10)) {
  delta.ACC.m[, i] <- mispecified.outputs.class[[i]]$ACC[, "causality-aware"] - mispecified.outputs.class[[i]]$ACC[, "residualization"]
}


cp <- 1.2
myline <- 0.1
mylwd <- 2

par(mfrow = c(2, 2), mar = c(3, 3, 1, 0.5), mgp = c(1.75, 0.75, 0))
boxplot(delta.MSE.c, xlab = "number of inputs", 
        main = "regression (correct)",
        ylab = expression(paste(Delta, MSE) == MSE[r] - MSE[c]))
abline(h = 0, col = "red", lwd = mylwd)
mtext(side = 3, at = 0.2, text = "(a)", cex = cp, line = myline)
####
boxplot(delta.MSE.m, xlab = "number of inputs", 
        main = "regression (mispecified)",
        ylab = expression(paste(Delta, MSE) == MSE[r] - MSE[c]))
abline(h = 0, col = "red", lwd = mylwd)
mtext(side = 3, at = 0.2, text = "(b)", cex = cp, line = myline)
####
boxplot(delta.ACC.c, xlab = "number of inputs", 
        main = "classification (correct)",
        ylab = expression(paste(Delta, ACC) == ACC[c] - ACC[r]), outline = TRUE)
abline(h = 0, col = "red", lwd = mylwd)
mtext(side = 3, at = 0.2, text = "(c)", cex = cp, line = myline)
####
boxplot(delta.ACC.m, xlab = "number of inputs", 
        main = "classification (mispecified)",
        ylab = expression(paste(Delta, ACC) == ACC[c] - ACC[r]), outline = TRUE)
abline(h = 0, col = "red", lwd = mylwd)
mtext(side = 3, at = 0.2, text = "(d)", cex = cp, line = myline)

