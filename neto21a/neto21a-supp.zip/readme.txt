
We provide the R code to reproduce all the experimental 
results in the paper.

1. The script "utility_functions_causality_aware_vs_residualization.R" 
loads the R packages dependencies and all utility functions needed 
for the analyses.

2. The script "run_analyses_and_generate_figures_n10000.R" runs the experiments,
save the outputs, and generate Figures 5, 6, and 7 in the main text. 

3. The script "run_analyses_and_generate_figures_n100.R" runs the experiments,
save the outputs, and generate the Supplementary Figures S1, S2, and S3. 

4. The script "run_real_data_examples.R" runs the real data experiments,
save the outputs, and generates Figure 8 in the main text. 