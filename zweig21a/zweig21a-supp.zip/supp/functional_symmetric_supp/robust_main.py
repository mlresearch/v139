import matplotlib.pyplot as plt
import numpy as np
from numpy.linalg import norm
import copy

import torch
import torchvision
import torchvision.transforms as transforms

import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

from model import Symmetric, DeepSets, KNN, KK
from sample import generate_data, generate_narrow_data
from train import train
from evaluate import generalization_error, cross_validate
import argparse

torch.manual_seed(50)
np.random.seed(50)

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def train(model, x, y, iterations, lamb = 0.1, lr=0.0005, batch_size = 64):
    model.train()
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)

    x = x.to(device)
    y = y.to(device)

    losses = []
    
    for i in range(iterations):
        
        index = np.random.choice(x.shape[0], batch_size, replace=False)
        index = torch.from_numpy(index).to(device)

        outputs = model(x[index])

        optimizer.zero_grad()
        loss = criterion(outputs, y[index])
        loss += model.regularize(lamb)
        loss.backward()
        optimizer.step()

        losses.append(loss.item())
    
    model.eval()
    return losses

def robust_mean(x, eps = 0.2):
    batch_size, N, input_dim = x.shape
    N_fake = int(eps * N)
    N_real = N - N_fake
    return np.mean(x[:, :N_real, :], axis = 1)

robust_mean.__name__ = "robust_mean"

def generate_corrupted_data(N, batch_size, input_dim, objective, bias_first = False, eps = 0.2):
    
    N_fake = np.random.binomial(10, eps)
    N_real = N - N_fake

    m_real = 1 * np.random.normal(size = (batch_size, 1, input_dim))
    fake_offset = 2.0 * np.random.normal(size = (batch_size, 1, input_dim))
    m_fake = m_real + fake_offset

    x_real = 1.5 * np.random.normal(size = (batch_size, N_real, input_dim)) + m_real
    x_fake = 1.5 * np.random.normal(size = (batch_size, N_fake, input_dim)) + m_fake

    x = np.concatenate([x_real, x_fake], axis = 1)
    

#     blind_mean = np.mean(x, axis = 1, keepdims = True)
#     print(norm(blind_mean - m_real))
    
    bias = np.ones((batch_size, N, 1))
    x = np.concatenate([x, bias], axis = 2)
        
    y = m_real[:,0,:]
    
    
    x = torch.from_numpy(x).float()
    y = torch.from_numpy(y).float()
    
    x = x.to(device)
    y = y.to(device)
    
    return (x,y)
        
        
        

def corrupted_generalization_error(N_list, batch_size, input_dim, model, objective, bias_first):
    errors = []
    for N in N_list:
        x,y = generate_corrupted_data(N, batch_size, input_dim, objective, bias_first)
        outputs = model(x)
        
        error = nn.MSELoss()(outputs, y)
        #error = torch.mean(torch.norm(outputs - y, dim = 1)).item()
        
        errors.append(error)
    return np.array(errors)


#https://github.com/mrwojo/geometric_median
from scipy.optimize import minimize
from scipy.spatial.distance import cdist        
def minimize_method(points, options={}):
    """
    Geometric median as a convex optimization problem.
    """

    # objective function
    def aggregate_distance(x):
        return cdist([x], points).sum()

    # initial guess: centroid
    centroid = points.mean(axis=0)

    optimize_result = minimize(aggregate_distance, centroid, method='COBYLA')

    return optimize_result.x

from scipy.special import erfc

#Adapted from https://github.com/hoonose/robust-filter/blob/master/filterCode/filterGaussianMean.m
def robust_estimator(x, eps, tau, cher = 2.5):

    N, d = x.shape
    
    empirical_mean = np.mean(x, axis = 0)
    threshold = eps*np.log(1/eps)
    x_normal = (x - empirical_mean[np.newaxis, :])/np.sqrt(N)

    U, s, _ = np.linalg.svd(x_normal.T)
    
    lamb = s[0] ** 2
    v = U[:,0]

#     if lamb < 1 + 3 * threshold:
    if lamb < threshold:
        return empirical_mean
    else:
        delta = 2*eps
        proj = x.dot(v)
        rank = np.abs(proj - np.median(proj))
                
        x_sorted = x[rank.argsort()]
        rank = rank[rank.argsort()]
        for i in range(N):
            T = rank[i] - delta
            
#             print((erfc(T / np.sqrt(2))))
#             print(cher * N * (erfc(T / np.sqrt(2)) / 2 + eps/(d*np.log(d*eps/tau))))
#             print((N - i - 1))
                        
            if (N - i - 1) > cher * N * (erfc(T / np.sqrt(2)) / 2 + eps/(d*np.log(d*eps/tau))):
                break
        if i == 0 or i == N-1:
            return empirical_mean
        else:
            return robust_estimator(x_sorted[:i], eps, tau, cher)

def baselines(N_list, input_dim, sample_size, cher, tau):

    error_mean_list = []
    error_std_list = []
    
    for N in N_list:
    
        x, y = generate_corrupted_data(N, sample_size, input_dim, robust_mean)
        x = x.cpu().data.numpy()
        y = y.cpu().data.numpy()
        x = x[:,:,:-1] #remove bias

        error = np.zeros((x.shape[0], 3))

        for i in range(x.shape[0]):
            
            y_hat = np.mean(x[i], axis = 0)
#            error[i,0] = norm(y[i]-y_hat)
            error[i,0] = np.mean((y[i] - y_hat) ** 2)


            y_hat = minimize_method(x[i])
            error[i,1] = np.mean((y[i] - y_hat) ** 2)
#            error[i,1] = norm(y[i]-y_hat)

            y_hat = robust_estimator(x[i], eps = 0.2, tau = tau, cher = cher)
            error[i,2] = np.mean((y[i] - y_hat) ** 2)
#            error[i,2] = norm(y[i]-y_hat)

        error_mean_list.append(np.mean(error, axis = 0))
        error_std_list.append(np.std(error, axis = 0))

    error_mean_list = np.stack(error_mean_list, axis = 0)
    error_std_list = np.stack(error_std_list, axis = 0)
    
    return error_mean_list, error_std_list


def compare_models(model_index, N_max, N_list, hidden_dim, iterations, batch_size, input_dim, objective, 
                   verbose = True, log_plot = False, kernel_buff = False, squared = False, runs = 10):
        
    bias_first = "neuron" in objective.__name__
    
    k = 10 if kernel_buff else 1

    f1 = Symmetric(input_dim, hidden_dim, hidden_dim, input_dim, squared = squared)
    f2 = KNN(input_dim, k * hidden_dim, hidden_dim, input_dim, squared = squared)
    f3 = KK(input_dim, k * hidden_dim, k * hidden_dim, input_dim, squared = squared)

    f1 = f1.to(device)
    f2 = f2.to(device)
    f3 = f3.to(device)

    f1.__name__ = "S1"
    f2.__name__ = "S2"
    f3.__name__ = "S3"

    models = [f1, f2, f3]
    models = [models[model_index]]
    lambs = [0., 1e-6, 1e-4, 1e-2]

    for model in models:
        print(model.__name__)
        x, y = generate_corrupted_data(N_max, batch_size, input_dim, objective, bias_first)
                
        cv_models = cross_validate(model, x, y, iterations, lambs, verbose)
        
        validation_errors = np.zeros_like(lambs)
        for i, cv_model in enumerate(cv_models):
            validation_errors[i] = corrupted_generalization_error([N_max], 1000, input_dim, cv_model,
                                                        objective, bias_first)[0]
        
        i = np.argmin(validation_errors)
        lamb = lambs[i]
            
        run_errors = np.zeros((runs, len(N_list)))
        for i in range(runs):
            print(i)
            x, y = generate_corrupted_data(N_max, batch_size, input_dim, objective, bias_first)
            model_copy = copy.deepcopy(model)
            model_copy.reinit()
            model_copy.to(device)

            train(model_copy, x, y, iterations, lamb)
            errors = corrupted_generalization_error(N_list, 1000, input_dim, model_copy, objective, bias_first)
            run_errors[i] = np.array(errors)
        
        mean_error = np.mean(run_errors, axis = 0)
        std_error = np.std(run_errors, axis = 0)
        if verbose:
            print("performance of ", model.__name__, " on ", objective.__name__)
            print("lamb =", lamb)
            print(mean_error)
            print(std_error)
            
            
#         save_str = model.__name__ + "_" + objective.__name__ + "_" + str(input_dim)
#         save_str += "_" + str(kernel_buff) + "_" + str(squared)
#         save_dir = "saved_data_2022/"
            
#         np.save(save_dir + save_str + "_mean", mean_error)
#         np.save(save_dir + save_str + "_std", std_error)

        


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='symmetric')

    parser.add_argument('--model_index', type=int, default=0, help='')
    parser.add_argument('--iterations', type=int, default=30000, help='')
    parser.add_argument('--runs', type=int, default=10, help='')
    parser.add_argument('--batch_size', type=int, default=5000)
    parser.add_argument('--cher', type=float, default=2.5)
    parser.add_argument('--tau', type=float, default=0.1)
    parser.add_argument('--N_max', type=int, default=10)
    parser.add_argument('--input_dim', type=int, default=10)
    parser.add_argument('--N_list', type=str, default="10,20,30,40,50")
    parser.add_argument('--hidden_dim', type=int, default=100)
    
    args = parser.parse_args()
        

    input_dim = args.input_dim
    N_max = args.N_max
    N_list = [int(x) for x in args.N_list.split(",")]

#    iterations = 30000
#    batch_size = 5000

    hidden_dim = args.hidden_dim
    squared = False

    if args.model_index == 3:
        means, stds = baselines(N_list, input_dim, args.batch_size, args.cher, args.tau)
        for i in range(3):
            print(means[:,i])
            print(stds[:,i])
    else:
        compare_models(args.model_index, N_max, N_list, hidden_dim, args.iterations, args.batch_size, input_dim, robust_mean, log_plot = True, kernel_buff = True, squared = squared, runs = args.runs)
