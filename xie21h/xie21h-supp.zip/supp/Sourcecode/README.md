# Positive-Negative-Momentum

The PyTorch Implementation of PNM and AdaPNM.


# The environment is as bellow:

Python 3.7.3 

PyTorch >= 1.6.0


# Usage

#You may use it as a standard PyTorch optimizer.

```python
import pnm_optim

PNM_optimizer = PNM(net.parameters(), lr=lr, betas=(0.9, 1.), weight_decay=weight_decay)
AdaPNM_optimizer = AdaPNM(net.parameters(), lr=lr, betas=(0.9, 0.999, 1.), eps=1e-08, weight_decay=weight_decay, amsgrad=True)
```
