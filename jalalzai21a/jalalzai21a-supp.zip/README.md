# ICML 2021: Feature Clustering for Support Identification in Extreme Regions

This is the supplementary material for the article "Feature Clustering for Support Identification in Extreme Regions".

## Description 

- main_long.pdf : contains long version of the article with proofs, lemmas, theorems and additional experimental results
- code/         : folder with the code of the experimental results, the code is written in Python 3

## Folder code/

Folders
- dataset/ : contains the swiss head dataset in .csv format for additional experiments
- geometry/: code to draw the evolution of the ratio/volume of the different manifolds
- results/ : contains the results of the numerical experiments for Anomaly Detection in Extreme Regions and Feature Clustering of Extremes

Dependecies in Python 3
- requirements.txt : dependencies

Python scripts
- utils.py  : tool functions
- damex.py  : script for DAMEX algorithm
- mexico.py : script for MEXICO algorithm
- simus.py  : script to with functions to perform simulations

Python notebooks to run and save experiments
- AD_benchmark_extreme.ipynb         : notebook to perform experiments for Anomaly Detection (AD) task
- CLUSTERING_benchmark_extreme.ipynb : notebook to perform experiments for Clustering task
- swiss_heads.ipynb                  : notebook for additional experiments on Swiss Head Army dataset
- dimReduction_CLassification.ipynb  : notebook to compare influence of dimension reduction for classication task
- distances_mexico.ipynb             : notebook for experiments on contraction mapping
Python notebooks to load and analyze the results
- AD_analysis_results.ipynb         : notebook to analyze results for Anomaly Detection (AD) task
- CLUSTERING_analysis_results.ipynb : notebook to analyze results for Clustering task

