# Scrit with functions to perform experiments and save the results

# Import libraries
import time
import numpy as np
import pandas as pd
import random 
import matplotlib.pyplot as plt

# Preprocessing
from utils import *
from sklearn.model_selection  import train_test_split 

# Methods in competition: Mexico, Damex, iForest, SphKmeans
from mexico import Mexico
from damex import Damex_alone
from sklearn.cluster import KMeans
from sklearn.ensemble import IsolationForest
from nltk.cluster.kmeans import KMeansClusterer
from nltk.cluster.util import cosine_distance

# Metric to compare models
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.metrics import homogeneity_completeness_v_measure

# Functions implemented
# run_ad_single
# run_ad_bench
# run_clust_single
# run_clust_bench

def run_ad_single(seed,X,y,with_dykstra,tau_mex,reg_mex,m_clusters,verbose,**arguments):
    ''' Perform comparison of IF,Damex,Mexico by computing ROC_AUC scores and PR_scores
    Params:
    @seed               (int): random seed
    @X          (n x p array): data
    @y          (n x 1 array): binary array, y=1 for normal data, y=0 for anomaly
    @with_dysktra      (bool): whether to do POCS or Dykstra
    @tau_mex (float in (0,1)): threshold mexican ball
    @reg_mex      (float > 0): regularization parameter Mexico
    @m_cluster         (<= p): number of cluster for Mexico
    @verbose           (bool): to show all steps of Mexico optimization (for debug)
    Returns:
    @roc_auc_mex  : ROC_AUC score of Mexico
    @roc_auc_damex: ROC_AUC score of Damex
    @roc_auc_if   : ROC_AUC score of iForest
    @pr_mex       : PR score of Mexico
    @pr_damex     : PR score of Damex
    @pr_if        : PR score of iForest
    '''
    # Set the random seed for reproducibility
    np.random.seed(seed)
    # X_train contains (3/4) of normal data
    X_train, X_test, y_train, y_test = train_test_split(X[y==1], y[y==1], test_size=1/3)

    X_test = np.vstack((X_test, X[y==0])) # X_test contains (1/4) of normal data and all the anomaly data
    y_test = np.hstack((y_test, y[y==0])) 
    
    # Preprocessing Pareto scaling
    R = order(X_train)
    V_train = transform_(R, X_train)
    V_test  = transform_(R, X_test)
    # Index of extreme values
    is_extreme_train = np.linalg.norm(V_train, axis=1, ord=np.inf) >= np.sqrt(V_train.shape[0])
    is_extreme_test = np.linalg.norm(V_test, axis=1, ord=np.inf) >= np.sqrt(V_train.shape[0])
    
    ############### Mexico Part ###############
    # Train only on Extreme Data
    speedy = Mexico(V_train[is_extreme_train], m=m_clusters)
    speedy.optimize(tau=tau_mex,with_dykstra=with_dykstra,iter_max=3e2, 𝜆=reg_mex,verbose=verbose,**arguments)
    # Compute distance for anomaly detection on extreme test data
    dist = np.linalg.norm(V_test[is_extreme_test], axis=1, ord=1) - np.dot(V_test[is_extreme_test],
                                                                           speedy.W).max(axis=1)
    # Compute ROC_AUC score for Mexico
    roc_mex = roc_auc_score(y_score=1/dist, y_true=y_test[is_extreme_test])
    pr_mex = average_precision_score(y_score=1/dist, y_true=y_test[is_extreme_test])

    ############### DAMEX Part ###############
    # Hyperparameters
    epsilon = 0.01
    k_pow_exp = 2
    k_pow = 1./k_pow_exp
    # Instance of Damex
    damex = Damex_alone(epsilon=epsilon, k_pow=k_pow,
                        with_norm=True, with_transform=False,
                        with_rectangles=True,n_threshold_extreme=None, pruning_faces_coef=0.1)
    # Fit Damex only on extreme data
    damex.fit(V_train[is_extreme_train])
    # Prediction Damex on extreme data
    scoring = np.zeros(V_test.shape[0])
    scoring[is_extreme_test] = damex.predict(V_test[is_extreme_test])
    # Score of Damex only on extreme data
    score_damex = -scoring[is_extreme_test]
    # Compute ROC_AUC score for IsolationForest
    roc_damex = roc_auc_score(y_score=score_damex,y_true=y_test[is_extreme_test])
    pr_damex = average_precision_score(y_score=score_damex, y_true=y_test[is_extreme_test])

    ############### Isolation Forest Part ###############
    # Create IF for extreme data
    IF_extreme = IsolationForest(n_jobs=-1,random_state=seed)
    # Fit each model on corresponding data
    IF_extreme.fit(X_train,y_train)
    # Predict score on extreme data 
    score_if = IF_extreme.score_samples(X_test[is_extreme_test])
    # Compute ROC_AUC score for IsolationForest
    roc_if = roc_auc_score(y_score=score_if,y_true=y_test[is_extreme_test])
    pr_if = average_precision_score(y_score=score_if, y_true=y_test[is_extreme_test])
    
    return roc_mex,roc_damex,roc_if,pr_mex,pr_damex,pr_if

def run_ad_bench(name,with_dykstra,N,tau_mex,reg_mex,m_clusters,verbose=False,**arguments):
    ''' Perform benchmark of IF,Damex,Mexico by computing ROC_AUC scores and PR_scores
    and save the results in the folder results/
    Params:
    @name               (str): 'SA','SF','http','smtp','shuttle','forest', dataset name
    @N                  (int): number of simulations (different seed)
    @tau_mex (float in (0,1)): threshold mexican ball
    @reg_mex      (float > 0): regularization parameter Mexico
    @m_clusters         (<= p): number of cluster for Mexico
    @verbose           (bool): to show all steps of Mexico optimization (for debug)
    Returns:
    None, directly save results in folder
    '''
    # Load dataset
    X_dat,y_dat = load_dataset(name,rng=0)
    # Initialize results
    roc_mex_list = []
    roc_damex_list = []
    roc_if_list = []
    pr_mex_list = []
    pr_damex_list = []
    pr_if_list = []
    for s in range(N):
        if s%10==0:
            print('seed =',s)
        # Compare methods for this current seed
        roc_mex,roc_damex,roc_if,pr_mex,pr_damex,pr_if  =  run_ad_single(seed=s,with_dykstra=with_dykstra,
                                                                         X=X_dat,y=y_dat,
                                                                         tau_mex=tau_mex,reg_mex=reg_mex,
                                                                         m_clusters=m_clusters,verbose=verbose,
                                                                         **arguments)
        # Add ROC scores
        roc_mex_list.append(roc_mex)
        roc_damex_list.append(roc_damex)
        roc_if_list.append(roc_if)
        
        # Add PR scores
        pr_mex_list.append(pr_mex)
        pr_damex_list.append(pr_damex)
        pr_if_list.append(pr_if)
    if with_dykstra:
        # Save results
        np.save(file='results/roc_mex_dyk_'+name,arr=roc_mex_list)
        np.save(file='results/roc_damex_dyk_'+name,arr=roc_damex_list)
        np.save(file='results/roc_if_dyk_'+name,arr=roc_if_list)

        np.save(file='results/pr_mex_dyk_'+name,arr=pr_mex_list)
        np.save(file='results/pr_damex_dyk_'+name,arr=pr_damex_list)
        np.save(file='results/pr_if_dyk_'+name,arr=pr_if_list)
    else:
        # Save results
        np.save(file='results/roc_mex_'+name,arr=roc_mex_list)
        np.save(file='results/roc_damex_'+name,arr=roc_damex_list)
        np.save(file='results/roc_if_'+name,arr=roc_if_list)

        np.save(file='results/pr_mex_'+name,arr=pr_mex_list)
        np.save(file='results/pr_damex_'+name,arr=pr_damex_list)
        np.save(file='results/pr_if_'+name,arr=pr_if_list)

    return None

def run_clust_single(seed,ORD,n_train,n_test,p,tau_mex,eps_mex,reg_mex,
                     verbose=False,show_clusters=False,**arguments):
    ''' Perform comparison of Kmeans, KmeansSpherical and Mexico for Clustering task
    Params:
    @seed               (int): random seed
    @ORD                (int): '1','2','np.inf'
    @n_train            (int): number of train samples
    @n_test             (int): number of test samples
    @p                  (int): dimension of the problem
    @tau_mex (float in (0,1)): threshold mexican ball
    @reg_mex      (float > 0): regularization parameter Mexico
    @verbose           (bool): to show all steps of Mexico optimization (for debug)
    @show_clusters     (bool): to show the clusters created (for debug)
    Returns
    @res_regular_kmeans (3x1array)
    @res_sphere_kmeans  (3x1array)
    @res_mexico         (3x1array)
    '''
    # Set the random seed for reproducibility
    np.random.seed(seed)
    rng = random.Random()
    rng.seed(seed)
    clusters = make_partition(p)
    NUM_CLUSTERS = len(clusters)
    if show_clusters:
        print('Number of clusters:',NUM_CLUSTERS)
        print(clusters)
    #Generating simulated data
    #print(time.ctime(), "Generating simulated data")
    X_train = asym_logistic(n=n_train, p=p, clusters =clusters)
    X_test  = asym_logistic(n=n_test , p=p, clusters =clusters)
    #Standardizing the data (Pareto scaling)
    #print(time.ctime(), "std data")
    R = order(X_train)
    V_train = transform_(R, X_train)
    V_test  = transform_(R, X_test)
    # Angular representation for SphericalKmeans
    #print(time.ctime(), "Angular representation for SphericalKmeans")
    theta_train = V_train / np.linalg.norm(V_train, ord=ORD, axis=1 ).reshape(-1,1)
    theta_test  = V_test / np.linalg.norm(V_test, ord=ORD, axis=1 ).reshape(-1,1)
    #Selecting the extreme sample
    #print(time.ctime(), "Selecting the extreme sample")
    is_extreme_train = np.linalg.norm(V_train, ord=ORD, axis=1)  >= np.sqrt(n_train)
    is_extreme_test  = np.linalg.norm(V_test,  ord=ORD, axis=1)  >= np.sqrt(n_train)
    #print('Extremes train/test:',sum(is_extreme_train),'/',sum(is_extreme_test))
    # Labels are set based on the position of the argmax of each sample
    ## Note that labels exist only for the extreme samples
    y_train_ext = [np.where([np.argmax(V_train[is_extreme_train], axis=1)[j] in clusters[i] \
                             for i in range(len(clusters))])[0][0] \
                             for j in range(len(V_train[is_extreme_train]))]
    y_test_ext = [np.where([np.argmax(V_test[is_extreme_test], axis=1)[j] in clusters[i] \
                            for i in range(len(clusters))])[0][0] \
                            for j in range(len(V_test[is_extreme_test]))]
    ### Mexico-POCS part ###
    speedy_pocs  = Mexico(V=V_train[is_extreme_train], m=NUM_CLUSTERS)
    speedy_pocs.optimize(tau=tau_mex,with_dykstra=False,iter_max=3e2,eps=eps_mex,
                         𝜆=reg_mex,verbose=verbose,**arguments)
    pred_mex_pocs_test = np.argmax(V_test[is_extreme_test].dot(speedy_pocs.W), axis=1)
    res_mexico_pocs = homogeneity_completeness_v_measure(labels_true=y_test_ext, 
                                                         labels_pred=pred_mex_pocs_test)
    
    ### Mexico-DYK part ###
    speedy_dyk  = Mexico(V=V_train[is_extreme_train], m=NUM_CLUSTERS)
    speedy_dyk.optimize(tau=tau_mex,with_dykstra=True,iter_max=3e2,eps=eps_mex,
                        𝜆=reg_mex,verbose=verbose,**arguments)
    pred_mex_dyk_test = np.argmax(V_test[is_extreme_test].dot(speedy_dyk.W), axis=1)
    res_mexico_dyk = homogeneity_completeness_v_measure(labels_true=y_test_ext, 
                                                        labels_pred=pred_mex_dyk_test)
    
    ### Kmeans Part ###
    pred_kmeans_test = []
    kmeans = KMeans(n_clusters=NUM_CLUSTERS,random_state=seed).fit(X_train[is_extreme_train])
    for sample in X_test[is_extreme_test]:
        pred_kmeans_test.append(kmeans.predict(sample.reshape(1,-1))[0]) 
    res_kmeans = homogeneity_completeness_v_measure(labels_true=y_test_ext,
                                                    labels_pred=pred_kmeans_test)
    
    ### SphericalKmeans Part ###
    pred_sphere_kmeans_test = []
    sphere_kmeans = KMeansClusterer(NUM_CLUSTERS,
                                    distance=cosine_distance, repeats=10,
                                    avoid_empty_clusters=True, rng = rng)
    pred_kmeans_train = sphere_kmeans.cluster(theta_train[is_extreme_train], True)
    for sample in theta_test[is_extreme_test]:
        pred_sphere_kmeans_test.append(sphere_kmeans.classify(sample)) 
    res_sphere_kmeans = homogeneity_completeness_v_measure(labels_true=y_test_ext,
                                                           labels_pred=pred_sphere_kmeans_test)

    return res_kmeans, res_sphere_kmeans, res_mexico_pocs, res_mexico_dyk

def run_clust_bench(N,ORD,n_train,n_test,p,tau_mex,eps_mex,reg_mex,**arguments):
    ''' Perform benchmark of Kmeans, KmeansSpherical and Mexico for Clustering task
    Params:
    @N                  (int): number of simulations (different seed)
    @ORD                (int): '1','2','np.inf'
    @n_train            (int): number of train samples
    @n_test             (int): number of test samples
    @p                  (int): dimension of the problem
    @tau_mex (float in (0,1)): threshold mexican ball
    @reg_mex      (float > 0): regularization parameter Mexico
    Returns
    None, directly save results in folder
    '''
    # Initialize results
    res_kmeans_list = []
    res_sphere_kmeans_list = []
    res_mexico_pocs_list = []
    res_mexico_dyk_list = []
    # Loop over different seeds
    for s in range(N):
        if s%10==0:
            print(time.ctime())
            print('seed =',s)
        res_kmeans, res_sphere_kmeans, res_mexico_pocs, res_mexico_dyk = run_clust_single(seed=s,ORD=ORD,n_train=n_train,
                                                                              n_test=n_test,p=p,tau_mex=tau_mex,
                                                                              eps_mex=eps_mex,reg_mex=reg_mex,**arguments)
        # Append results
        res_kmeans_list.append(res_kmeans)
        res_sphere_kmeans_list.append(res_sphere_kmeans)
        res_mexico_pocs_list.append(res_mexico_pocs)
        res_mexico_dyk_list.append(res_mexico_dyk)
    # Save results
    np.save('results/res_clust_kmeans_p'+str(p),arr=res_kmeans_list)
    np.save('results/res_clust_sphere_kmeans_p'+str(p),arr=res_sphere_kmeans_list)
    np.save('results/res_clust_mexico_pocs_p'+str(p),arr=res_mexico_pocs_list)
    np.save('results/res_clust_mexico_dyk_p'+str(p),arr=res_mexico_dyk_list)
    return None
    