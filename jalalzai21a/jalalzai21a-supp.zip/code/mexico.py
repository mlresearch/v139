# Implementation of the algorithm MEXICO 

from utils import *

class Mexico:
    def __init__(self,V,m=None):
        ''' Initialize attributes of Mexico
        Params:
        @V  (numpy array data nxp ): data matrix V of size n x p
        @W  (numpy array data pxm ): mixture matrix W of size p x m
        @Z  (numpy array data mxn ): relaxation (latent) matrix Z of size m x n
        @m                    (int): number of clusters we want to find
        '''
        self.V = V          # data matrix V of size n x p
        self.n,self.p = self.V.shape 
        self.m = self.p          # number of clusters we want to find
        if m!=None:
            self.m=m
        # initialization of the mixture matrix W and relaxation matrix Z
        self.W = np.random.dirichlet(alpha=np.ones(self.p), size=(self.m)).T
        self.Z = np.random.dirichlet(alpha=np.ones(self.m), size=(self.n)).T
        
    def f(self,W_Z,m,𝜆):
        ''' Penalized objective function f(W,Z) = Trace(VWZ) - 𝜆*sum <W^i,W^j>
        Params:
        @W  (numpy array data pxm): mixture matrix W of size p x m
        @Z  (numpy array data mxn): relaxation (latent) matrix Z of size m x n
        @𝜆                 (float): regularization parameter
        Returns: f(W,Z) = Trace(VWZ)- 𝜆*sum_{i<j} <W^i,W^j>
        '''
        W,Z = unvectorize(self.V,W_Z,m)
        A = np.dot(W.T,W)
        data_fitting_term = np.trace(np.dot(self.V,np.dot(W,Z)))
        reg_term = sum(sum(A[i,i+1:]) for i in range(len(A)))
        return  data_fitting_term/Z.shape[1] - 𝜆*reg_term

    def grad_f(self,W_Z,m,𝜆):
        ''' Gradient of the penalized objective function
        Params:
        @W  (numpy array data pxm ): mixture matrix W of size p x m
        @Z  (numpy array data mxn ): relaxation (latent) matrix Z of size m x n
        @𝜆 (float)       : regularization parameter
        Returns: vec(gradW_f,gradZ_f)
        '''
        W,Z = unvectorize(self.V,W_Z,m)
        sum_all_col = np.sum(W, axis=1)
        W_tmp = np.array([ sum_all_col - W[:,j] for j in range(W.shape[1])]).T
        gradW_f = np.transpose(np.dot(Z,self.V))/Z.shape[1] - 𝜆*W_tmp
        gradZ_f = np.transpose(np.dot(self.V,W))/Z.shape[1]
        return vectorize(gradW_f,gradZ_f)
    
    def optimize(self,tau,with_dykstra,iter_max=3e2,eps=5e-3, 𝜆=1e2,verbose=False,**arguments):
        ''' Perform optimization of the objective function by projected gradient ascent on the simplex
        Params:
        @tau     (float): threshold for the Mexican ball
        @iter_max  (int): maximum number of iterations to perform
        @eps     (float): precision for the stopping condition (when obj.function does not move much)
        @𝜆       (float): positive regularization parameter
        @verbose  (bool): display information
        '''
        # Barycenter of the simplex
        B = np.ones((self.p, 1)) / self.p
        # L2 distance between the barycenter and a simplex node
        radius_inscrit = 1/np.sqrt(self.p*(self.p-1))
        # Initialization starting point
        W = np.random.dirichlet(alpha=np.ones(self.p), size=(self.m)).T
        Z = np.random.dirichlet(alpha=np.ones(self.m), size=(self.n)).T
        i = 0
        stop_criterion = False
        # Initialization results
        f_val_prev = self.f(W_Z=vectorize(W,Z),m=self.m,𝜆=𝜆)
        # Main loop for optimization
        while ((i < iter_max) and not stop_criterion):
            ######################### Perform Line search for W #########################
            # function to minimize fw
            fw = lambda w: -self.f(W_Z=vectorize(w.reshape(W.shape),Z),m=self.m,𝜆=𝜆)
            # gradient function grad_w_f
            gfw = lambda w: -self.grad_f(W_Z=vectorize(w.reshape(W.shape),Z),m=self.m,𝜆=𝜆)[:np.prod(W.shape)]
            alphaW,_,_,_,_,_ = line_search_wolfe2(f=fw,myfprime=gfw,xk=W.ravel(),pk=-gfw(W))
            if not alphaW:
                alphaW = 1e-10
            if verbose*(i%10==0):
                print('Iteration ',i)
                print('step alphaW :',alphaW)
            #########################  Update W ######################### 
            # gradient w.r.t W at current point (it is the ascent direction)
            gradW = self.grad_f(W_Z=vectorize(W, Z),m=self.m,𝜆=𝜆)[:np.prod(W.shape)].reshape(W.shape)
            # projected gradient ascent with the step size alphaW found by line search
            if with_dykstra:
                W_next = proj_mex(M=W + alphaW * gradW,tau=None,with_dykstra=with_dykstra,**arguments)
                #print('W_next =\n',W_next)
            else:
                W_next = projsplx(W + alphaW * gradW)
                W_next = proj_mex(M=W_next,tau=tau,with_dykstra=False)
            # check we have indeed increased the objective value 
            if verbose*(i%10==0):
                print('fw(W) =',-round(fw(W),5),'|fw(W_next) = ',-round(fw(W_next),5))
            #########################  Update Z #########################
            # function to minimize fz
            fz = lambda z: -self.f(W_Z=vectorize(W_next,z.reshape(Z.shape)),m=self.m,𝜆=𝜆)
            # gradient w.r.t Z at current point (it is the ascent direction)
            gradZ = self.grad_f(W_Z=vectorize(W_next,Z),m=self.m,𝜆=𝜆)[np.prod(W.shape):].reshape(Z.shape)
            Z_next = projsplx(Z + gradZ) # step=1 because function is linear in Z
            # check we have indeed increased the objective value 
            if verbose*(i%10==0):
                print('fz(Z) =',-round(fz(Z),5),'|fz(Z_next) = ',-round(fz(Z_next),5))
            ######################### Move to the new iterates #########################
            W = W_next
            Z = Z_next
            ######################### Update stopping criterion #########################
            f_val_next = self.f(W_Z=vectorize(W,Z),m=self.m,𝜆=𝜆)
            diff = np.abs(f_val_next-f_val_prev)
            stop_criterion = (diff <= eps)
            if verbose*(i%100==0):
                print('STOP criterion:',stop_criterion)
            f_val_prev = f_val_next
            # increase counter
            i += 1
            ######################### Display information #########################
            if verbose*(i%50==0):
                print('Iteration: {} | f_val: {} | gap: {}'.format(i,round(f_val_next,5),round(diff,5))) 
        ######################### Set the attributes of the estimator #########################
        if verbose:
            print('Optimization Done')
        self.W = W_next
        self.Z = Z_next
        return None
    
    def get_info_W(self):
        print('\nMixture Matrix W is of rank ',np.linalg.matrix_rank(self.W))
        print(np.round(self.W,decimals=3))
        
    def get_info_Z(self):
        print('\nRelaxation Matrix Z (confidence belonging to each cluster found)')
        print(np.round(self.Z,decimals=3))
        
    def score(self):
        V_tilde = np.dot(self.V,self.W)
        V_norm = np.linalg.norm(x=self.V,ord=1,axis=1)
        V_tilde_norm = np.linalg.norm(x=V_tilde,ord=1,axis=1) 
        return sum(V_norm-V_tilde_norm)/self.V.shape[0]
    
    def get_clusters(self):
        clust, val = np.nonzero(self.W.T)
        return [list(val[clust==c]) for c in range(self.m)]

    def plot_W(self,show_grid=True):
        p,m = self.W.shape
        plt.figure(figsize=(12, 13))
        ax = plt.gca()
        ax.set_xticks(range(m))
        ax.set_yticks(range(p))
        ax.tick_params(axis='both', which='both', length=0)
        if show_grid:
            x_coor = np.arange(m)+.5
            y_coor = np.arange(p)+.5
            for x in x_coor:
                ax.axvline(x=x,color='black',linestyle='--',alpha=.5)
            for y in y_coor:
                ax.axhline(y=y,color='black',linestyle='--',alpha=.5)
        im = ax.imshow(self.W, cmap=plt.cm.binary, interpolation='None', origin='upper')
        divider = make_axes_locatable(ax)
        ax.set_aspect('auto')
        cax = divider.append_axes("right", size="5%", pad=0.05)
        plt.colorbar(im, cax=cax)
        plt.title('Mixture Matrix W')
        plt.show()
        
    def predict(self,new_sample):
        return None
    