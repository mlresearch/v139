# Tool functions and preprocessing of the real dataset

# Import libraries
import numpy as np
import matplotlib.pyplot as plt
from sklearn.utils import shuffle as sh
from mpl_toolkits.axes_grid1 import make_axes_locatable
from scipy.optimize.linesearch import line_search_wolfe2
# Real dataset
from sklearn.datasets import fetch_kddcup99,fetch_openml,fetch_covtype

# Tool functions
def vectorize(W, Z):
    return np.concatenate((W.ravel(), Z.ravel()))

def unvectorize(V,W_Z,m):
    n, p = V.shape
    W = W_Z[:p * m].reshape((p, m))
    Z = W_Z[p * m:].reshape((m, n))
    return W, Z

# Tool functions for projections
def proj(x, z=1):
    ''' Project a vector on the simplex, for more information check
    Large-scale Multiclass Support Vector Machine Training via Euclidean Projection onto the Simplex
    Mathieu Blondel, Akinori Fujino, and Naonori Ueda.
    ICPR 2014.
    http://www.mblondel.org/publications/mblondel-icpr2014.pdf
    Params
    @x  (numpy array): vector to projet
    Returns
    @w  (numpy array): projected vector on simplex
    '''
    n_features = x.shape[0]
    u = np.sort(x)[::-1]
    cssv = np.cumsum(u) - z
    ind = np.arange(n_features) + 1
    cond = u - cssv / ind > 0
    rho = ind[cond][-1]
    theta = cssv[cond][-1] / float(rho)
    w = np.maximum(x - theta, 0)
    return w

def project_inf_ball(x, r):
    ''' project positive vector x on the infinite ball of radius r > 0
    Params:
    @x  (numpy array): vector to projet
    @r        (float): radius r > 0 of the ball
    '''
    if np.max(x) >= r:
        x[x >= r] = r
    return x

def is_on_ball(x, radius, eps, order):
    """
    assess if x is on the ord ball up to precision eps
    Params:
    @x (array)       : vector to assess
    @radius (float)  : radius of the ball
    @eps (float)     : width of margins
    @order (int)     : order of unit ball to consider (np.inf is possible)
    """
    output = np.abs(np.linalg.norm(x, ord=order) - radius) <= eps
    return output

def dykstra(r, proj1, proj2, radius1, radius2, ord1=1, ord2=np.inf, iter_max_dykstra=100, eps=1e-2): #**args
    """ dykstra's alternating projection algorithm
    which purpose is to project onto the intersection of 2 convex balls B1 and B2.
    (quick read:https://en.wikipedia.org/wiki/Dykstra%27s_projection_algorithm)
    Params:
    @r (array)       : vector to be projected on B1 inter B2
    @proj1 (func)    : function to project on B1 (simplex)
    @proj2 (func)    : function to project on B2 (infinite ball)
    @radius1 (float) : radius of B1
    @radius2 (float) : radius of B2
    @iter_max (int)  : maximum number of alternations
    """
    i = 0
    dist = 10*eps
    is_C1 = is_on_ball(r, radius1, eps, ord1)
    is_C2 = is_on_ball(r, radius2, eps, ord2)
    x_tmp = r.copy()
    p = np.zeros_like(r)
    q = np.zeros_like(r)
    while bool((i<=iter_max_dykstra) * (1 - is_C1 * is_C2) * (1 - (dist < eps)) ):
        #print(i)
        i+= 1
        y = proj2(x_tmp + p, radius2)
        p = x_tmp + p - y
        x_new = proj1(y + q, radius1)
        q = y + q - x_new
        is_C1 = is_on_ball(x_new, radius1, eps, ord1)
        is_C2 = is_on_ball(x_new, radius2, eps, ord2)
        dist  = np.linalg.norm(x_new - x_tmp, ord=2)
        x_tmp = x_new.copy()
    return x_tmp

def mexican_ball(x, tau, w_dykstra=False, **arguments):
    ''' Project vector x on mexican ball with percentage tau in [0,1] '''
    if w_dykstra:
        proj_1 = arguments["proj1"]
        proj_2 = arguments["proj2"]
        radius_1 = arguments["radius1"]
        radius_2 = arguments["radius2"]
        try:
            iter_max_dykstra = arguments["iter_max_dykstra"]
        except KeyError:
            iter_max_dykstra=100
        try:
            eps = arguments["eps"]
        except KeyError:
            eps=1e-6
        return dykstra(x, proj_1, proj_2, radius_1, radius_2, ord1=1, ord2=np.inf,
                       iter_max_dykstra=iter_max_dykstra, eps=1e-6 )
    else:
        p = len(x)
        b = np.ones(p) / p
        bx = x - b
        d = np.sqrt((p-1)/p)
        U = (1/d)*(np.eye(p)-b)
        l = np.argwhere(bx.dot(U)>tau)
        if l.size>1:
            print('Game over')
            print('l=',l)
        elif l.size==1:
            j = l[0,0]
            x_new = b + (tau/d)* (np.linalg.norm(bx,ord=2)/np.abs(bx.dot(U[:,j]))) * bx
        else:
            x_new = x
        return x_new

def proj_mex(M,tau,with_dykstra,**arguments):
    ''' Project each column of the matrix M on the Mexican ball '''
    def g(x):
        return mexican_ball(x, tau, w_dykstra=with_dykstra, **arguments)
    return np.apply_along_axis(func1d=g,axis=0,arr=M)


def projsplx(M):
    ''' Project each column of the matrix M on the simplex '''
    return np.apply_along_axis(func1d=proj,axis=0,arr=M)

# Tool functions to generate datasets
def generate_data_w_cluster_labels(n,p,clusters):
    ''' Generate dataset of n binary samples in dimension p with
    extreme values drawn according to clusters specified by the user
    Params:
    @n (int)        : number of samples
    @p (int)        : dimension of the samples
    @clusters (list): list of the features that excite together
    Returns: V (array n x p) dataset
    '''
    y = []
    mask = np.random.choice(a=np.arange(len(clusters)),size=n)
    y.append(mask.ravel())
    V = np.zeros((n,p))
    for i in range(n):
        V[i,clusters[mask[i]]]=1
    return V, np.array(y)

def PS(alpha):
    if alpha == 1:
        return 1
    else:
        U = np.random.uniform(0, np.pi)
        W = np.random.exponential()
        x1 = np.sin((1-alpha) * U) / W
        x2 = (1 - alpha) / alpha
        return np.power(x1, x2) * (np.sin(alpha*U) / np.power(np.sin(U), 1/alpha))

def log_evd(alpha, d):
    S = PS(alpha)
    W = np.random.exponential(size=d)
    return np.array([np.power(S/W[i], alpha) for i in range(d)])


def asym_logistic(n,p,clusters):
    ''' Generate dataset of n samples in dimension p with
    extreme values drawn according to clusters specified by the user, logistic real data
    Params:
    @n (int)        : number of samples
    @p (int)        : dimension of the samples
    @clusters (list): list of the features that excite together
    Returns: V (array n x p) dataset
    '''
    X = np.zeros((n, p))
    theta = np.ones((n, p))
    for j in range(p):
        cpt = 0
        for K in clusters:
            if j in K:
                cpt += 1
        if cpt == 0:
            cpt = 1.
        theta[:, j] = 1./cpt
    for i in range(n):
        for K in clusters:
            K_dim = len(K)
            Z = log_evd(0.1, K_dim)
            cpt = -1
            for j in K:
                cpt += 1
                X[i, j] = max(X[i, j], Z[cpt])
    return X*theta

def order(X):
    ''' Return the order statistic of each sample in X, features by features '''
    return np.sort(X, axis=0)

def transform_(R, X):
    ''' Common transformation of each marginal in standard Pareto
    Params:
    @R (n x p array): order of training data
    @x (n x p array): data
    Returns
    @V (n x p array): transformed data (Pareto scaling)
    '''
    n, p = np.shape(X)
    n_R = np.shape(R)[0]
    F = np.zeros((n, p))
    for j in range(p):
        F[:, j] = np.searchsorted(R[:, j], X[:, j]) / float(n_R + 1)
    V = 1. / (1-F)
    return V

def split_rand(list_in, no_distrib=True):
    ''' Split a list randomly in two parts '''
    if no_distrib:
        k = np.random.randint(2, len(list_in))
    else:
        scale = 1 # this will work for now
        k = int(np.abs( 2 + np.random.normal(loc=3, scale=scale)))
    left_partition = list_in[:k]
    right_partition = list_in[k:]
    return left_partition, right_partition

# not perfect (in the last elements of the list) but does the job for now
def make_partition(p, shuffle=True, no_distrib=True):
    output = []
    input_list = list(np.arange(p))
    np.random.shuffle(input_list)
    left_p, right_p = split_rand(input_list, no_distrib=False)
    output.append(left_p)
    while len(right_p) >= 3:
        left_p, right_p = split_rand(right_p, no_distrib=False)
        if len(right_p) == 1:
            output.append(left_p + right_p)
            return output
        else:
            output.append(left_p)
    output.append(right_p)
    return output

# Tool functions to evaluate DAMEX
def remove_doublon(x_faces):
    x_new_faces = np.array([x_faces[0, :]])
    list_faces = [list(np.nonzero(x_faces[0, :])[0])]
    for face in x_faces[1:, :]:
        size_face = np.sum(face)
        size_new_faces = np.sum(x_new_faces, axis=1)
        s_1 = set(np.nonzero(np.sum(x_new_faces * face,
                                    axis=1) == size_face)[0])
        s_2 = set(np.nonzero(size_new_faces == size_face)[0])
        if len(s_1 & s_2) == 0:
            x_new_faces = np.concatenate((x_new_faces, np.array([face])))
            list_faces.append(list(np.nonzero(face)[0]))

    return x_new_faces, list_faces

def mass_faces(x_damex):
    n_extr = len(x_damex)
    x_damex_faces, damex_faces = remove_doublon(x_damex)
    n_faces = len(x_damex_faces)
    size_damex = np.sum(x_damex, axis=1)
    size_damex_faces = np.sum(x_damex_faces, axis=1)
    intersect = np.dot(x_damex, x_damex_faces.T)
    mass = np.zeros(n_faces)
    for k, size_face in enumerate(size_damex_faces):
        ind = np.nonzero(size_damex == size_face)[0]
        mass[k] = np.sum(intersect[ind, k] == size_face)/float(n_extr)

    return mass

def load_dataset(name,rng):
    ''' Load  dataset with a subset
    Params:
    @name (str): 'SA','SF','http','smtp','shuttle','forest
    Returns
    @X (n x p array)
    @y (n x 1 array): binary array, y=1 for normal data, y=0 for anomaly
    '''
    kdd_names = ['SA','SF','http','smtp']

    if name in kdd_names:
        # Load dataset KDDCUP99
        dataset = fetch_kddcup99(subset=name, shuffle=True, percent10=True,random_state=rng)
        X = dataset.data
        y = dataset.target
        # Convert target y to binary (y=1)=normal, (y=0)=anomaly
        y = (y ==  b'normal.').astype(int) # (y=1) True=normal, (y=0) False=anomaly
        if name == 'SA':
            # Drop the columns with string
            X = np.delete(arr=X,obj=[1,2,3],axis=1)
        if name == 'SF':
            # Drop the column with string
            X = np.delete(arr=X,obj=[1],axis=1)

    elif name == 'shuttle':
        # Load dataset Shuttle
        dataset = fetch_openml(name='shuttle')
        X = dataset.data
        y = dataset.target
        sh(X, y)
        # we remove data with label 4 (many anomalies of that class)
        s = (y != '4')
        X = X[s, :]
        y = y[s]
        y = (y == '1').astype(int) # normal data are class 1

    elif name =='forest':
        # Load dataset ForestCover
        dataset = fetch_covtype(shuffle=True,random_state=rng)
        X = dataset.data
        y = dataset.target
        s = (y == 2) + (y == 4)
        X = X[s, :]
        y = y[s]
        y = (y == 2).astype(int) #normal data are class 2
    return X,y
