from new_alg import *

sparsity_array = [10, 20]
t = len(sparsity_array)
print(t)
alphsize = 500
bsize = 500
repetitions = 2
search_range = 2
beta = 0.4

# partition size even for sparsity 10, 10*\sqrt 500/0.4  greater than alphabet size 500, so no need to partition.


filename = 'data_new/exp_1.txt'

distance_est = [0] * t
distance_emp = [0] * t
distance_oracle = [0] * t
distance_aj = [0] * t
time_taken = [0] * t

for i in range(t):
    sparsity = sparsity_array[i]
    total_batches = int(0.5 * sparsity / (beta * beta * (1 - beta)))
    print(total_batches)
    num_bad_batches = int(total_batches * beta)
    print(num_bad_batches)
    g = total_batches - num_bad_batches
    tar_dis_unnorm = uniform.rvs(size=alphsize, loc=0, scale=1)
    tar_dis = tar_dis_unnorm / np.linalg.norm(tar_dis_unnorm, ord=1)
    tar_dis = tar_dis.tolist()

    aa = ab = ac = ad = ajo = 0
    # try various linear combination of a random unstructured distribution and tar_dis as adversary
    for j in range(search_range):
        print("search_range\n", j)
        (na, nb, nc, nd, njo) = (0.0, 0.0, 0.0, 0.0, 0.0)
        SKIP = 0
        SKIP_JO = 0

        for ii in range(repetitions):
            adv_dis_unnorm = uniform.rvs(size=alphsize, loc=0, scale=1)
            adv_dis_unnorm = (1 - 1 / (pow(1.5, j))) * tar_dis_unnorm + adv_dis_unnorm / (pow(1.5, j))
            adv_dis = adv_dis_unnorm / np.linalg.norm(adv_dis_unnorm, ord=1)
            adv_dis = adv_dis.tolist()

            batches = generate_batches(alphsize, bsize, total_batches, num_bad_batches, tar_dis, adv_dis)
            counts = [np.bincount(batches[i], minlength=alphsize) for i in range(total_batches)]
            counts = np.array(counts)
            batch_frequencies = 1. / float(bsize) * counts
            if SKIP == 0:
                start = time.time()
                remaining_batch_indices_new = run_filtering_for_AK_distance(batch_frequencies, bsize, sparsity,
                                                                            num_bad_batches)
                p_est = np.average(batch_frequencies, weights=remaining_batch_indices_new, axis=0)
                end = time.time()
                (na, nd) = np.add((na, nd), (AK(sparsity, p_est, tar_dis), end - start))

            if SKIP_JO == 0:
                remaining_batch_indices_JO = robust_distribution_estimator_JO(alphsize, total_batches, num_bad_batches,
                                                                              bsize, counts)
                p_JO = np.average(counts, weights=remaining_batch_indices_JO, axis=0)
                p_JO = p_JO / bsize
                njo = np.add(njo, AK(sparsity, p_JO, tar_dis))

            if ii == 0 and na < aa:
                SKIP = 1
            if ii == 0 and njo < ajo:
                SKIP_JO = 1
        (na, nd, njo) = (na / repetitions, nd / repetitions, njo / repetitions)
        (aa, ad, ajo) = (np.maximum(na, aa), np.maximum(nd, ad), np.maximum(njo, ajo))
        print(aa, ad, ajo)
    # (distance_est[i], distance_emp[i], distance_oracle[i], time_taken[i]) = (aa,ab,ac,ad)
    # try various linear combination of a randomly generated k-piecewise histogram and tar_dis as adversary

    for j in range(search_range):
        (na, nb, nc, nd, njo) = (0.0, 0.0, 0.0, 0.0, 0.0)
        SKIP = 0
        SKIP_JO = 0
        for ii in range(repetitions):
            adv_dis_unnorm = generate_piecewise_histograms(alphsize, sparsity)
            adv_dis_unnorm = (1 - 1 / (pow(1.5, j))) * tar_dis_unnorm + adv_dis_unnorm / (pow(1.5, j))
            adv_dis = adv_dis_unnorm / np.linalg.norm(adv_dis_unnorm, ord=1)
            adv_dis = adv_dis.tolist()

            batches = generate_batches(alphsize, bsize, total_batches, num_bad_batches, tar_dis, adv_dis)
            counts = [np.bincount(batches[i], minlength=alphsize) for i in range(total_batches)]
            counts = np.array(counts)
            batch_frequencies = 1. / float(bsize) * counts
            if SKIP == 0:
                start = time.time()
                remaining_batch_indices_new = run_filtering_for_AK_distance(batch_frequencies, bsize, sparsity,
                                                                            num_bad_batches)
                p_est = np.average(batch_frequencies, weights=remaining_batch_indices_new, axis=0)
                end = time.time()
                (na, nd) = np.add((na, nd), (AK(sparsity, p_est, tar_dis), end - start))

            if SKIP_JO == 0:
                remaining_batch_indices_JO = robust_distribution_estimator_JO(alphsize, total_batches, num_bad_batches,
                                                                              bsize, counts)
                p_JO = np.average(counts, weights=remaining_batch_indices_JO, axis=0)
                p_JO = p_JO / bsize
                njo = np.add(njo, AK(sparsity, p_JO, tar_dis))

            if ii == 0 and na < aa:
                SKIP = 1
            if ii == 0 and njo < ajo:
                SKIP_JO = 1

            if j == 0:
                all_batches_ind = np.ones(total_batches)
                Batch_ind_oracle = np.zeros(total_batches)
                Batch_ind_oracle[:g] = [1] * g
                p_oracle = np.average(batch_frequencies, weights=Batch_ind_oracle, axis=0)
                p_emp = np.average(batch_frequencies, weights=all_batches_ind, axis=0)
                (nb, nc) = np.add((nb, nc), (AK(sparsity, p_emp, tar_dis), AK(sparsity, p_oracle, tar_dis)))
        (na, nb, nc, nd, njo) = (
            na / repetitions, nb / repetitions, nc / repetitions, nd / repetitions, njo / repetitions)
        (aa, ab, ac, ad, ajo) = (
            np.maximum(na, aa), np.maximum(nb, ab), np.maximum(nc, ac), np.maximum(nd, ad), np.maximum(njo, ajo))
        print(aa, ab, ac, ad, ajo)
    (distance_est[i], distance_emp[i], distance_oracle[i], time_taken[i], distance_aj[i]) = (aa, ab, ac, ad, ajo)

with open(filename, 'w') as filehandle:
    for items in distance_est:
        filehandle.write('%s\n' % items)

    filehandle.write('\n')
    for items in distance_emp:
        filehandle.write('%s\n' % items)

    filehandle.write('\n')
    for items in distance_oracle:
        filehandle.write('%s\n' % items)

    filehandle.write('\n')
    for items in distance_aj:
        filehandle.write('%s\n' % items)

    filehandle.write('\n')
    for items in time_taken:
        filehandle.write('%s\n' % items)
