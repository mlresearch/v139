from new_alg import *

bsize = 500
repetitions = 2
beta = 0.4

filename = 'data_new/exp_betamix_dist.txt'


sparsity = 10

error = beta / np.sqrt(bsize)

MAX_Partition_size = np.power(2, int(np.log2(sparsity / error)))


total_batches = int(sparsity / (beta * beta * (1 - beta)))
print(total_batches)
num_bad_batches = int(total_batches * beta)
print(num_bad_batches)
g = total_batches - num_bad_batches

for ii in range(repetitions):

    # good samples from 0.7beta(17,4)+0.3 beta(3,10)
    g_samples_mixture_1_count = np.random.binomial(g * bsize, 0.7)
    g_samples_mixture_2_count = g * bsize - g_samples_mixture_1_count
    g_samples_mixture_1 = np.random.beta(17, 4, g_samples_mixture_1_count)
    g_samples_mixture_2 = np.random.beta(3, 10, g_samples_mixture_2_count)
    g_samples = np.concatenate((g_samples_mixture_1, g_samples_mixture_2), axis=0)
    np.random.shuffle(g_samples)
    g_batches = np.split(g_samples, g)

    adv_samples = np.random.beta(2, 2, num_bad_batches * bsize, )
    adv_batches = np.split(adv_samples, num_bad_batches)
    all_batches = np.concatenate((g_batches, adv_batches), axis=0)

    print(all_batches.shape)
    counts = create_partitioned_count(all_batches, MAX_Partition_size)

    batch_frequencies = 1. / float(bsize) * counts

    start = time.time()
    remaining_batches_our_alg = run_filtering_for_AK_distance(batch_frequencies, bsize, sparsity, num_bad_batches)
    end = time.time()

    remaining_batches_JO = robust_distribution_estimator_JO(MAX_Partition_size, total_batches, num_bad_batches, bsize,
                                                            counts)

    all_batches_ind = np.ones(total_batches)
    Batch_ind_oracle = np.zeros(total_batches)
    Batch_ind_oracle[:g] = [1] * g

    filename = 'data_new/exp_betamix_dist_our_estimator%d.txt' % ii
    with open(filename, 'w') as filehandle:
        for i in range(total_batches):
            if remaining_batches_our_alg[i] == 1:
                for j in range(bsize):
                    filehandle.write('%s\n' % all_batches[i][j])

    filename = 'data_new/exp_betamix_dist_emp%d.txt' % ii
    with open(filename, 'w') as filehandle:
        for i in range(total_batches):
            for j in range(bsize):
                filehandle.write('%s\n' % all_batches[i][j])

    filename = 'data_new/exp_betamix_dist_oracle%d.txt' % ii
    with open(filename, 'w') as filehandle:
        for i in range(g):
            for j in range(bsize):
                filehandle.write('%s\n' % all_batches[i][j])

    filename = 'data_new/exp_betamix_dist_JO%d.txt' % ii
    with open(filename, 'w') as filehandle:
        for i in range(total_batches):
            if remaining_batches_JO[i] == 1:
                for j in range(bsize):
                    filehandle.write('%s\n' % all_batches[i][j])
