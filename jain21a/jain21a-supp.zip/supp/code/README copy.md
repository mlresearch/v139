# Code for "Robust Density Estimation from Batches:
The Best Things in Life are (Nearly) Free"


## Contents
- `new-alg.py`: implementation of the main algorithm in this paper and [JO20/JO19]
- `exp_1.py`:  Code to run experiment 1 in the main paper
- `exp_2.py`: Code to run experiment 2 in the main paper
- `exp_3_gaussian_mixture.py`: Code to run experiment for gaussian mixture in the Appendix (only the filtering part)
- `exp_3_beta_mixture.py`: Code to run experiment for beta mixture in the Appendix (only the filtering part)

Note: For the experiments in the appendix on learning continuous distribution, we with the help of Vaishakh Ravindrakumar ran SURF [HJOR20] algorithm
on the filtered data. The code for the SURF is not included here and can be found in the Neurips submission of [HJOR20].
We used the code available on Github at https://github.com/secanth/federated by the authors of [CLM20] to compute AK distance.
