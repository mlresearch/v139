import numpy as np
import time
import cvxpy as cp
from scipy.stats import uniform
from scipy.stats import multinomial
import random
import math
from cutnorm import compute_cutnorm


# We use the code available on Github at https://github.com/secanth/federated by
# the authors of  [CLM20] to compute AK distance


def AK(K, p1, p2):
    diff = p1 - p2
    domain_size = len(diff)
    memo = {}
    best_vecs = {}

    # solves subproblem starting at index i, with l allowed sign changes, with first sign equal to s
    def helper(l, i, s):
        if (l, i, s) in memo:
            return memo[(l, i, s)], best_vecs[(l, i, s)]
        elif i >= domain_size:
            return 0, np.array([])
        elif l == 0:
            return s * np.sum(diff[i:]), s * np.ones(domain_size - i)
        else:
            best_val = -np.inf
            best_vec = None
            for j in range(i, domain_size):
                pre_val, pre_vec = helper(l - 1, j, -s)
                val = pre_val + s * np.sum(diff[i:j])
                if val > best_val:
                    best_val = val
                    best_vec = np.concatenate((s * np.ones(j - i), pre_vec))
            memo[(l, i, s)] = best_val
            best_vecs[(l, i, s)] = best_vec
            return best_val, best_vec

    val1, vec1 = helper(K, 0, 1)
    val2, vec2 = helper(K, 0, -1)
    if val1 > val2:
        return val1 / 2.
    else:
        return val2 / 2.


# generate collection of all batches for given discrete target and adversarial distribution
def generate_batches(alphsize, bsize, total_batches, num_bad_batches, tar_dis, adv_dis):
    alphabet = np.arange(alphsize)
    num_good_batches = total_batches - num_bad_batches
    g_samples = np.random.choice(alphabet, size=num_good_batches * bsize, p=tar_dis)
    g_batches = np.split(g_samples, num_good_batches)
    adv_samples = np.random.choice(alphabet, size=num_bad_batches * bsize, p=adv_dis)
    adv_batches = np.split(adv_samples, num_bad_batches)
    all_batches = np.concatenate((g_batches, adv_batches), axis=0)
    return all_batches


# generate collection of count vectors directly for given discrete target and adversarial distribution
def generate_counts(bsize, total_batches, num_bad_batches, tar_dis, adv_dis):
    num_good_batches = total_batches - num_bad_batches
    g_counts = multinomial(bsize, tar_dis).rvs(num_good_batches).astype(float)
    adv_counts = multinomial(bsize, adv_dis).rvs(num_bad_batches).astype(float)
    all_counts = np.concatenate((g_counts, adv_counts), axis=0)
    return all_counts


# This solves the following: SDP max <M,D>: M\ge 0, M_ii\le 1, \sum M_ii\le 2k in the paper,
# to find filter M
def Sdp(D, sparsity):
    size, _ = D.shape
    start = time.time()
    print("entering SDP, size:", size)
    M = cp.Variable((size, size), symmetric=True)
    # PSD constrain on M
    constraints = [M >> 0]
    A = []
    b = []
    # encoding the constrain M_ii \le 1
    for i in range(size):
        x = np.zeros(size)
        x[i] = 1.0
        y = np.diag(x)
        A.append(y)
        b.append(1)

    # encoding the constrains \sim M_ii \le 2k
    A.append(np.diag(np.ones(size)))
    b.append(2 * sparsity)

    constraints += [
        cp.trace(A[i] @ M) <= b[i] for i in range(size + 1)
    ]

    prob = cp.Problem(cp.Maximize(cp.trace(D @ M)),
                      constraints)
    prob.solve(eps=1e-4)
    end = time.time()
    print("finished", end - start)
    return prob.value, M.value


# We use the function estimate_parameters to estimate the right parameters to set for the algorithm.
# We estimate the usual value of max <M,D>, where D is the covariance matrix of all good batches
# generated using the uniform distribution. We set parameters to 3 times this value to avoid deleting
# batches when there is no corruption. The factor of 3 has been chosen heuristically
def estimate_corruption_bar(partition_size, sparsity, bsize, total_batches):
    uni_dis = np.ones(partition_size) / partition_size
    uni_counts = multinomial(bsize, uni_dis).rvs(total_batches).astype(float)
    batch_frequencies = 1. / float(bsize) * uni_counts
    mean = np.average(batch_frequencies, axis=0)
    # centered batch_frequencies
    centered = batch_frequencies - mean
    emp_cov = np.cov(centered, rowvar=False, bias=True)
    multinomial_covariance = 1. / bsize * (np.diag(mean) - np.outer(mean, mean))
    cov_diff = emp_cov - multinomial_covariance
    usual_value, _ = Sdp(cov_diff, sparsity)
    print(usual_value)
    return 3 * usual_value


# Deletes the batches with probability proportional to their scores,
# until the total scores of remaining outliers is half the original
def remove_outlier_batches(scores, remaining_batch_indices):
    scores_normalized = scores / np.sum(scores)
    q = scores_normalized.tolist()
    size = np.count_nonzero(scores_normalized)
    delete_index_array = np.random.choice(np.arange(scores.size), size=size, replace=False, p=q)
    deleted_mass = 0
    # delete_index_array = np.argsort(-scores_normalized)
    for delete_index in delete_index_array:
        deleted_mass += scores_normalized[int(delete_index)]
        remaining_batch_indices[int(delete_index)] = 0
        if deleted_mass >= 0.5:
            break
    return remaining_batch_indices


def filtering_for_sparse_binary_vectors(batch_frequencies, remaining_batch_indices, sparsity, bsize, num_bad_batches):
    total_batches, partition_size = batch_frequencies.shape
    corruption_bar = estimate_corruption_bar(partition_size, sparsity, bsize, total_batches)
    # Try to reduce the corruption below corruption bar.
    while True:
        mean = np.average(batch_frequencies, weights=remaining_batch_indices, axis=0)
        # centered batch_frequencies
        centered = batch_frequencies - mean
        emp_cov = np.cov(centered, rowvar=False, bias=True, fweights=remaining_batch_indices)
        multinomial_covariance = 1. / float(bsize) * (np.diag(mean) - np.outer(mean, mean))
        cov_diff = emp_cov - multinomial_covariance
        total_corruption, M = Sdp(cov_diff, sparsity)
        if total_corruption <= corruption_bar:
            break
        print("deleting for partition size", partition_size, "\n")
        scores = np.einsum("ij,ij->i", np.matmul(centered, M), centered) - np.vdot(M, multinomial_covariance)
        print(scores)
        # outlier batches have among the highest score.
        # factor 1.5 chosen heuristically to ensure number of batches deleted < 1.5 * num_bad_batches
        max_outliers_num = int(1.5 * num_bad_batches)
        # collect indices of possible outlier batches whose scores are among the top "max_outliers_num" highest scores
        outlier_batches_indices = list(np.argpartition(scores, -max_outliers_num)[-max_outliers_num:])

        # To avoid deleting non-outlier batches, we zero the score of a batch
        # if its score not among the top scorers.
        # We also zero the score of the batches already deleted.
        for index in range(total_batches):
            if index not in outlier_batches_indices or remaining_batch_indices[index] == 0 or scores[index] < 0:
                scores[index] = 0

        # check if their are still outliers
        if np.sum(scores) <= 0:
            break
        # delete outlier batches
        remaining_batch_indices = remove_outlier_batches(scores, remaining_batch_indices)

    return remaining_batch_indices


# Take batches of samples as input.
# Partition domain in t intervals, each interval with equal samples.
# And returns the count vectors for batches corresponding to these new partitions
# n\times \bar \mu_b^j in the paper
def create_partitioned_count(batches, t):
    row, col = batches.shape
    total_samples = row * col
    all_samples = []
    for i in range(row):
        for j in range(col):
            # uniform random variable appended at the end to make samples distinct
            all_samples.append([i, batches[i][j], random.uniform(0, 1)])
    all_samples = np.array(all_samples)
    indices = np.lexsort((all_samples[:, 2], all_samples[:, 1]))
    new_counts = np.zeros((row, t))
    count = 0
    for index in indices:
        index_1 = int(all_samples[index][0])
        index_2 = int(count * t / total_samples)
        count += 1
        new_counts[index_1][index_2] += 1
    return new_counts


# takes batch frequencies w.r.t. the largest partition size as the input
# runs filtering for different size partition
# for sparse binary vectors w.r.t. these partitions.
def run_filtering_for_AK_distance(batch_frequencies, bsize, sparsity, num_bad_batches):
    total_batches, alphsize = batch_frequencies.shape
    remaining_batch_indices = np.ones(total_batches)
    # To indicate the batches still left after filtering
    max_partition_size = alphsize
    partition_size = 2 * sparsity
    # Applying filtering for different partition size
    while partition_size < max_partition_size:
        elements_each_partition = math.ceil(alphsize / partition_size)
        multiplier = np.zeros((alphsize, partition_size))
        for i in range(partition_size):
            j = i * elements_each_partition
            while j < alphsize and j < (i + 1) * elements_each_partition:
                multiplier[j][i] = 1
                j += 1
        batch_frequencies_new = np.matmul(batch_frequencies, multiplier)
        remaining_batch_indices = filtering_for_sparse_binary_vectors(batch_frequencies_new, remaining_batch_indices,
                                                                      sparsity, bsize, num_bad_batches)
        partition_size = 2 * partition_size
    return remaining_batch_indices


def generate_piecewise_histograms(alphsize, pieces):
    hist_heights_unnorm = uniform.rvs(size=pieces, loc=0, scale=1)
    dist_unnorm = []
    for i in range(alphsize):
        index = int(np.floor(i * pieces / alphsize))
        dist_unnorm.append(hist_heights_unnorm[index])
    return np.asarray(dist_unnorm)


def estimate_parameters_JO(alphsize, bsize, m, b):
    alphabet = np.arange(alphsize)
    uni_dis = np.ones(alphsize) / alphsize
    uni_samples = np.random.choice(alphabet, size=m * bsize, p=uni_dis)
    uni_batches = np.split(uni_samples, m)
    uni_counts = [np.bincount(uni_batches[i], minlength=alphsize) for i in range(m)]
    alphsubset = np.ones(alphsize)
    alphsubset[:int(alphsize / 2)] = [0] * int(alphsize / 2)
    uni_estimates = [np.dot(alphsubset, uni_counts[i]) for i in range(m)]
    uni_estimates.sort()
    uni_median = np.median(uni_estimates)
    bar = 4 * (uni_estimates[int(m - 1 - b / 10)] - uni_median) ** 2
    sigma_bar = 0
    for i in range(int(m - 1 - b / 10), m):
        sigma_bar = sigma_bar + uni_estimates[i]
    sigma_bar = 4 * sigma_bar
    return bar, sigma_bar


def robust_distribution_estimator_JO(alphsize, m, b, bsize, counts):
    Batch_ind = np.ones(m)  # the index of deleted batch is changed to zero by the algorithm

    (bar, sigma_bar) = estimate_parameters_JO(alphsize, bsize, m, b)

    while True:
        mean = np.average(counts, weights=Batch_ind, axis=0)
        exp_cov = [[-mean[i] * (mean[j] / bsize) for i in range(alphsize)] for j in range(alphsize)]
        for i in range(alphsize):
            exp_cov[i][i] = mean[i] * (1 - mean[i] / bsize)

        cov = np.cov(np.array(counts).T, aweights=Batch_ind)

        cutn_round, cutn_sdp, info = compute_cutnorm(cov, exp_cov)

        estimates = [np.dot(info["cutnorm_sets"][0], counts[i]) for i in range(m)]
        median = np.median(estimates)
        sigma = 0
        del_prob = [0] * m
        for i in range(m):
            a = ((estimates[i] - median) ** 2 * Batch_ind[i])
            if a > bar:
                sigma = sigma + a
                del_prob[i] = a
        if sigma < sigma_bar:
            break
        del_prob_normalized = del_prob / sigma
        q = del_prob_normalized.tolist()
        size = np.count_nonzero(q)
        if size >= np.count_nonzero(Batch_ind == 1):
            break
        delete_index_array = np.random.choice(np.arange(m), size=size, replace=False, p=q)
        for delete_index in delete_index_array:
            sigma = sigma - del_prob[int(delete_index)]
            del_prob[int(delete_index)] = 0
            Batch_ind[int(delete_index)] = 0
            if sigma < sigma_bar:
                break
    return Batch_ind
