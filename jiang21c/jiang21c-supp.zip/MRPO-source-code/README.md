# MRPO source code
This is the MRPO source code, which gives you easy access to the reproducibility of results.
## Installation 
To run the code, you will have some python packages installed. Under Linux system, you can import part of the packages from conda by running:
```sh
conda env create -f RLGen.yaml
```
We list the packages that are not available from conda as follows:
```sh
gym 0.10.8 
``` 
## Environments
We provide walker2d as example to verify the reproducibility of MRPO. 

## Examples
To train MRPO with ppo:
```sh
python -m examples.MRPO.train \
--algorithm MRPO\
--env SunblazeWalker2dRandomNormal-v0 \
--output Walker2d_MRPOeps005seed12 \
--seed 12 \
--eps-raise 1.005 \
--total-episodes 100000
```

To train DR with ppo:
```sh
python -m examples.epopt.train \
--output walker2d_DRSeed12  \
--total-episodes 100000  \
--env SunblazeWalker2dRandomNormal-v0 \
--seed 12 \
--epsilon 1
```
To train PW-DR with ppo:
```sh
 python -m examples.epopt.train \
 --env SunblazeWalker2dRandomNormal-v0 \
 --output test \
 --seed 6 \
 --total-episodes 100000 \
 --epsilon 0.1 \
 --activate -1     
```

