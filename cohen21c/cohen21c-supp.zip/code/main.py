import time
import math
from MixOfGaussians import SeparateGaussians_kAverages,SeparateGaussians_kNoisyCenters
import numpy as np


d=2
k=2
beta = 0.05
eps = 1
delta = math.exp(-28)
R = math.ceil(512 * k * math.sqrt(d))


print("*******   Separating Gaussians with PrivatekNoisyCenters ********")
# These are the suggested parameters for separating Gaussians with PrivatekNoisyCenters. 
num_of_tuples=math.ceil(3781/eps)
Delta = math.ceil(10 * k * np.log(k/delta) * math.sqrt(np.log(k/beta))/eps)
samples_per_tuple = math.ceil(max(10 * math.pow(Delta/R, 2) * d * k, np.log(num_of_tuples * k) * k))
print("num_of_tuples = %d, samples_per_tuple = %d, Delta = %lf" % (num_of_tuples,samples_per_tuple,Delta))

start = time.time()
res = SeparateGaussians_kNoisyCenters(num_of_tuples,d,k,eps,delta,beta,R,Delta,samples_per_tuple)
end = time.time()
print("****  Result = %s ****" % res)
print("time=%d sec\n\n" % (end-start))

time.sleep(3)


print("*******   Separating Gaussians with PrivatekAverages *********")
# These are the suggested parameters for separating Gaussians with PrivatekAverages
advanced_comp = math.sqrt(2 * d * np.log(2/delta))
num_of_tuples = math.ceil(500000 * k * min(d,advanced_comp)/(eps**2))
samples_per_tuple = math.ceil(np.log(num_of_tuples*k) * k)
Lambda = math.pow(2,10) * k * math.sqrt(d)
r_min = 0.1
print("num_of_tuples = %d, samples_per_tuple = %d, Lambda = %lf" % (num_of_tuples,samples_per_tuple, Lambda))

start = time.time()
res = SeparateGaussians_kAverages(num_of_tuples,d,k,eps,delta,beta,R,samples_per_tuple,Lambda,r_min)
end = time.time()
print("****  Result = %s ****" % res)
print("time=%d sec" % (end-start))

