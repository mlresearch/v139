from bisect import bisect_right,bisect_left
import math
import numpy as np
#import secrets
import random

def left(x,g,Lambda):
    return -Lambda + math.floor((x + Lambda)/g) * g

def right(x,g,Lambda):
    return -Lambda + math.ceil((x + Lambda)/g) * g

def q(S_left,S_right,y):
    count1 = bisect_right(S_left,y)
    count2 = len(S_right) - bisect_left(S_right,y)
    return min(count1,count2)

def prob_of_segment(S_left,S_right,a_cur,a_prev,eps,Lambda,g):
    #outputs q(y) * |G \cap (a_prev,a_cur]|
    prev_grid_index = math.ceil((a_prev + Lambda)/g - 1)
    cur_grid_index = math.ceil((a_cur + Lambda)/g)
    return np.exp(eps * q(S_left,S_right,a_cur)/2) * (cur_grid_index - prev_grid_index)


def ChooseByExpMech(probabilities,eps):
    probabilities = np.array(probabilities)
    probabilities /= probabilities.sum()
    cum_prob = np.cumsum(probabilities)
    rand = random.random()
    index = np.argmax(rand <= cum_prob)
    return index
    

def PrivateInteriorPointSmallGrid(S,eps,Lambda,g):
    S_left = []
    S_right = []
    for x in S:
        x_left = left(x,g,Lambda)
        S_left.append(x_left)
        x_right = right(x,g,Lambda)
        S_right.append(x_right)
    S_left.sort()
    S_right.sort()
    scores = [q(S_left,S_right,-Lambda + i * g) for i in range(math.ceil(2*Lambda/g))]
    probabilities = [np.exp(eps * score/2) for score in scores]
    chosen_i = ChooseByExpMech(probabilities,eps)
    return -Lambda + chosen_i * g
    
    

def PrivateInteriorPointLargeGrid(S,eps,Lambda,g):
    A = []
    S_left = []
    S_right = []
    for x in S:
        x_left = left(x,g,Lambda)
        S_left.append(x_left)
        x_right = right(x,g,Lambda)
        S_right.append(x_right)
        A.append(x_left - g)
        A.append(x_left)
        A.append(x_right)
        A.append(x_right + g)
    A = sorted(set(A))
    S_left.sort()
    S_right.sort()
    m = len(A)
    probabilities = []
    for i in range(m+1):
        a_prev = A[i-1] if i>0 else -Lambda-g
        a_cur = A[i] if i<m else Lambda+g/2
        probabilities.append(prob_of_segment(S_left,S_right,a_cur,a_prev,eps,Lambda,g))
    chosen_i = ChooseByExpMech(probabilities,eps)
    a_prev = A[chosen_i-1] if chosen_i>0 else -Lambda-g
    a_cur = A[chosen_i] if chosen_i<m else Lambda+g/2
    prev_grid_index = math.ceil((a_prev + Lambda)/g - 1)
    cur_grid_index = math.ceil((a_cur + Lambda)/g)
    return -Lambda + g * (np.random.randint(prev_grid_index,cur_grid_index)+1)


def PrivateInteriorPoint(S,eps,Lambda,g):
    if Lambda/g > 1000*len(S):
        return PrivateInteriorPointLargeGrid(S,eps,Lambda,g)
    else:
        return PrivateInteriorPointSmallGrid(S,eps,Lambda,g)


def PrivateAverageR(S,eps,delta,Lambda,r_min):
    n = len(S)
    m = math.floor(n/2.5)
    S.sort()
    S_0 = S[:m]
    S_1 = S[n-m:]
    S_2 = S[m:n-m]
    
    x = PrivateInteriorPoint(S_0,eps,Lambda,r_min) - r_min
    y = PrivateInteriorPoint(S_1,eps,Lambda,r_min) + r_min
    r = y - x
    S_prime = [a for a in S_2 if (a>=x and a<=y)]
    m = len(S_prime)
    if m == 0:
        return math.ceil((random.random() - 1/2) * 2* Lambda/r_min)*r_min
    lamb = r/m
    sigma = lamb/eps * math.sqrt(2 * np.log(1.25/delta)) 
    return np.average(np.array(S_prime)) + sigma * np.random.randn()

def PrivateAverageRd(P,d,eps,delta,Lambda,r_min):
    new_eps = eps/d
    new_delta = delta/d
    advanced_comp = math.sqrt(2 * d * np.log(2/delta))
    if d > advanced_comp:
        new_eps = eps/advanced_comp
        new_delta = delta/(2 * d)
    average = []
    for i in range(d):
        S = [x[i] for x in P]
        average.append(PrivateAverageR(S,new_eps,new_delta,Lambda,r_min))
    return average

