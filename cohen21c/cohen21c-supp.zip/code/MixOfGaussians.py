#from sklearn.mixture import GaussianMixture
import numpy as np
import math
import random

from kTupleClustering import PrivatekAverages,PrivatekNoisyCenters,compute_ell,l2_dist_squared

def Lloyd_step(Points,centers):
    k = len(centers)
    Clusters = []
    for _ in range(k):
        Clusters = Clusters + [[]]
    for x in Points:
        i = np.argmin([l2_dist_squared(x, c) for c in centers])
        Clusters[i].append(x)
    for i in range(k):
        cluster_i = np.array(Clusters[i])
        centers[i] = np.average(cluster_i, axis=0) 
    return centers

def k_means_plusplus(Points,k,Lloyd):
    centers = [Points[0]]
    for _ in range(k-1):
        Scores = [np.min([l2_dist_squared(x, c) for c in centers]) for x in Points]
        probabilities = np.array(Scores)
        probabilities /= probabilities.sum()
        cum_prob = np.cumsum(probabilities)
        rand = random.random()
        index = np.argmax(rand <= cum_prob)
        centers.append(Points[index])
    if Lloyd:
        centers = Lloyd_step(Points,centers)
    return centers
             

def GenerateTuples(n,d,k,samples_per_tuple,R,Lloyd,tup_to_print):
    if k > 2*d:
        raise Exception("Please choose a value of k that is at most 2*d")
    if k % 2 != 0:
        raise Exception("Please choose even value of k")
    cov = np.identity(d)
    Means = []
    for i in range(math.floor(k/2)):
            mu = [0]*d
            mu[i] = R
            Means.append(mu)
            print("mu_%d = %d * e_%d" % (2*i,R,i))
            mu = [0]*d
            mu[i] = -R
            Means.append(mu)
            print("mu_%d = %d * e_%d" % (2*i + 1,-R,i))
    T = []
    RealClusters = []
    for _ in range(k):
        RealClusters = RealClusters + [[]]
    for j in range(n):
        Samples = []
        for _ in range(samples_per_tuple):
            i = np.random.randint(k)
            x = np.random.multivariate_normal(Means[i],cov)
            Samples.append(x)
            RealClusters[i].append(x)
        centers = k_means_plusplus(Samples,k,Lloyd)
        T.append(centers)
        if j % tup_to_print == 0:
            print("Created %d tuples (%d%%)" % (j,math.floor(100*j/n)))
    return (T,RealClusters)

def CheckTheSolution(RealClusters,Centers,k):
    print("Checking the solution ...")
    success_count = 0
    pi = []
    for i in range(k):
        index = -1
        for x in RealClusters[i]:
            L = [l2_dist_squared(x, c) for c in Centers]
            j = np.argmin(L)
            if index == -1:
                index = j
                pi.append(j)
            elif index != j:
                print("Failure!")
                return "Failure"
            else:
                success_count = success_count+1
    for i in range(k):
        for j in range(k):
            if i==j: continue
            if pi[i] == pi[j]:
                return "Failure"
    return "Success"
    

def SeparateGaussians_kAverages(n,d,k,eps,delta,beta,R,samples_per_tuple,Lambda,r_min): 
    ell = compute_ell(n,eps/2,delta/4,beta/2)
    print("ell = %d" % ell)
    if n < 2*ell + 2:
        print("n = %d is too small, should be at least %lf" % (n,2*ell + 2))
        return
     
    total_num_of_samples = samples_per_tuple * n
    print("total_num_of_samples = %d" % total_num_of_samples)
    
    (T,RealClusters) = GenerateTuples(n,d,k,samples_per_tuple,R,Lloyd=False,tup_to_print=2000)
    Centers = PrivatekAverages(T,d,eps,delta,beta,Lambda,r_min)
    print("The solution for the k-tuples problem:")
    print(Centers)
    if Centers == None:
        print("PrivateTestPartition has failed")
        return "Failure"
    res = CheckTheSolution(RealClusters,Centers,k)
    return res


 
def SeparateGaussians_kNoisyCenters(n,d,k,eps,delta,beta,R,Delta,samples_per_tuple): 
    ell = compute_ell(n,eps/2,delta/4,beta/2)
    print("ell = %d" % ell)
    if n < 2*ell + 2:
        print("n = %d is too small, should be at least %d" % (n,2*ell + 2))
        return
          
    total_num_of_samples = samples_per_tuple * n
    print("total_num_of_samples = %d" % total_num_of_samples)

    (T,RealClusters) = GenerateTuples(n,d,k,samples_per_tuple,R,Lloyd=True,tup_to_print=300)
    Centers = PrivatekNoisyCenters(T,d,eps,delta,beta,Delta)
    print("The solution for the k-tuples problem:")
    print(Centers)
    if Centers==None:
        print("PrivateTestPartition has failed")
        return "Failure"
    res = CheckTheSolution(RealClusters,Centers,k)
    return res

'''
# The Naive method adding privacy-preserving noise to each sample 
     
def SeparateGaussians_Naive(d,k,eps,delta,beta,R): 
    n=10000000 
    Lambda = R #+ 10 * math.sqrt(d)
    sigma = 2*Lambda/eps * math.sqrt(np.log(1.25/delta))
    
    if k > d:
        raise Exception("Please choose a value of k that is at most d")
    cov = np.identity(d)
    Means = []
    for i in range(k):
        mu_i = [0]*d
        mu_i[i] = R
        print("mu[%d] = " % (i,), mu_i)
        Means.append(mu_i)
    RealClusters = []
    for _ in range(k):
        RealClusters = RealClusters + [[]]   
    Samples = []
    for j in range(n):
        i = np.random.randint(k)
        x = np.random.multivariate_normal(Means[i],cov)
        for a in range(d):
            x[a] = x[a] + sigma * np.random.randn()
        Samples.append(x)
        RealClusters[i].append(x)
        if j%10000== 0:
            print("Generated %d samples" % j)
            
    gmm = GaussianMixture(n_components=k)
    gmm.fit(Samples)
    labels = gmm.predict(Samples)
    NewClusters = []
    for _ in range(k):
        NewClusters = NewClusters + [[]]  
    for j in range(n):
        i = labels[j]
        NewClusters[i].append(Samples[j])
    
    Averages = []    
    for i in range(k):
        L = np.array(NewClusters[i])
        a_i = np.average(L, axis=0)
        Averages.append(a_i)
    print(Averages)    
'''
