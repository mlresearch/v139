#from sklearn.mixture import GaussianMixture
import numpy as np
import math
import random
from PointsAverage import PrivateAverageRd

def l2_norm_squared(p):
    return np.sum(np.square(p))

def l2_dist_squared(p,q):
    return np.sum(np.square(p-q))   


def compute_m_and_eps_1(n,eps,delta,beta):
    m=1
    while True:
        eps_1 = np.log(eps*n/m - 3)
        if m>1/eps_1 * (2*np.log(1/delta) + np.log(1/beta)):
            return (m,eps_1)
        else:
            m = m+1
                        
def compute_ell(n,eps,delta,beta):
    (m,_) = compute_m_and_eps_1(n,eps,delta,beta)
    return 2*m/eps * np.log(2*m/(beta * delta))


def IsFarBalls(Balls, dist_factor):
    while len(Balls) > 1:
        (c_i,r_i_squared) = Balls[0]
        Balls=Balls[1:]
        for (c_j,r_j_squared) in Balls:
            if l2_dist_squared(c_i,c_j) <= math.pow(dist_factor,2) * max(r_i_squared,r_j_squared):
                return False
    return True

def IsPartitioned(X,B):
    k = len(B)
    if len(X) != k:
        return False  
    pi = [-1] * k
    for i in range(k):
        (c,r_sqr) = B[i]
        for j in range(k):
            x = X[j]
            if l2_dist_squared(x,c) < r_sqr:
                pi[i] = j
                break
    for i in range(k):
        if pi[i] == -1:
            return False
    return True    


def compute_B_X(X,Delta):
    k = len(X)
    return [(X[i], np.min([l2_dist_squared(X[i],X[j])/math.pow(Delta,2) for j in range(k) if j != i])) for i in range(k)]

def compute_ell_X(B,T_2):
    ell = 0
    for X in T_2:
        if not IsPartitioned(X,B):
            ell = ell + 1
    return ell

def PrivateTestCloseTuples(T_1,T_2,eps_1,eps_2,beta,Delta):
    s = 0
    B_X_star = None
    m = len(T_1)
    for X in T_1:
        B_X = compute_B_X(X,Delta)
        ell_X = compute_ell_X(B_X,T_2)
        print("\t\t ell_X = %d" % ell_X)
        noisy_ell_X = ell_X + np.random.laplace(0,m/eps_2) 
        if noisy_ell_X <= m/eps_2 * np.log(m/beta):
            B_X_star = B_X
            s = s+1
        else:
            s = s
    noisy_s = s + np.random.laplace(0,1/eps_1)
    Status = "Failure" if noisy_s < m - (1/eps_1)*np.log(1/beta) else "Success"
    B = B_X_star if Status == "Success" else None
    return (Status,B) 

def PrivateTestPartition(T,eps,delta,beta,Delta):
    n = len(T)
    (m,eps_1) = compute_m_and_eps_1(n,eps,delta,beta)
    eps_2 = eps/2
    T_1 = random.sample(T,m)
    T_2 = T
    return PrivateTestCloseTuples(T_1,T_2,eps_1,eps_2,beta,Delta)
        


#################################################################


def PrivatekAverages(T,d,eps,delta,beta,Lambda,r_min):
    n = len(T)
    if n==0: return None
    k = len(T[0])
    print("\tTesting the partition ....")
    (Status,Balls) = PrivateTestPartition(T,eps/2,delta/4,beta/2,Delta=7)
    if Status=="Failure":
        return None
    print("\tComputing the clusters ....")
    Clusters = []
    for _ in range(k):
        Clusters = Clusters + [[]]
    for i in range(n):
        for x in T[i]:
            j = np.argmin([l2_dist_squared(x, c) for (c,_) in Balls])
            Clusters[j].append(x)
    print("\tComputing the averages ....")
    Averages = []
    ell = compute_ell(n,eps/2,delta/4,beta/2)
    for i in range(k):
        ta_i = PrivateAverageRd(Clusters[i],d,eps/(4 * k * (ell + 1)),delta/(8 * k * math.exp(eps/2) * (ell + 1)),Lambda,r_min)
        Averages.append(ta_i)
    return Averages



def PrivatekNoisyCenters(T,d,eps,delta,beta,Delta):
    n = len(T)
    if n==0: return None
    k = len(T[0])
    print("\tTesting the partition ....")
    (Status,Balls) = PrivateTestPartition(T,eps/2,delta/4,beta/2,Delta)
    if Status=="Failure":
        return None
    print("\tAdding Gaussian Noise ....")
    NoisyCenters = []
    C = [c for (c,_) in Balls]
    #print("C = ",C)
    for i in range(k):
        gamma_i = 4/(Delta-2) * (np.random.laplace(0,4*k/eps) + (4*k/eps)*np.log(4*k/delta) + 1)
        lambda_i = (2/Delta) * (1+gamma_i) * np.min([math.sqrt(l2_dist_squared(C[i],C[j])) for j in range(k) if j!=i])
        sigma_i = (4*k*lambda_i/eps) * math.sqrt(2 * np.log(10 * k/delta))
        #print("Sigma_%d = %lf" % (i,sigma_i))
        ta_i = []
        for j in range(d):
            ta_i.append((C[i])[j] + sigma_i * np.random.randn())
        NoisyCenters.append(ta_i)
    return NoisyCenters


