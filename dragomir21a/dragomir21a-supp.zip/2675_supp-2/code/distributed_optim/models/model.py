from numba import njit


class Model(object):
    def __init__(self, c=0.):
        self.c = c

    def get_L(self, dataset):
        raise NotImplementedError

    @staticmethod
    @njit
    def get_1d_gradient(x, y):
        raise NotImplementedError

    def get_gradient(self, theta, dataset):
        raise NotImplementedError

    def get_stochastic_gradient(self, theta, dataset, i):
        raise NotImplementedError        

    def compute_error(self, theta, dataset):
        raise NotImplementedError
