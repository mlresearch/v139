from numba import njit
from numba.typed import List
import numpy as np
import scipy.special

from models.model import Model


vec_logit = np.vectorize(lambda x: - np.logaddexp(0, -x))

class LogisticRegression(Model):
    name = "LR"

    def get_L(self, dataset):
        @njit 
        def get_L(indptr, data):
            L = 0
            for i in range(len(indptr) - 1):
                L = max(L, np.sum(np.power(data[indptr[i]:indptr[i+1]], 2)))
            return L
        return 0.25 * get_L(dataset.X.T.indptr, dataset.X.T.data)

    @staticmethod
    @njit
    def get_1d_gradient(x, y):
        return - y / (1 + np.exp(y * x))
    
    def get_gradient(self, theta, dataset):
        s = dataset.X @ (dataset.y * scipy.special.expit(- dataset.y * (dataset.X.T @ theta)))
        return self.c * theta - s / dataset.N

    def get_Dh(self, x, y, dataset):
        return self.compute_error(x, dataset) - self.compute_error(y, dataset) - \
            np.dot(self.get_gradient(y, dataset), x - y)

    def get_stochastic_gradient_range(self, theta, dataset, inf, sup):
        X_ind_T = dataset.X.T[inf:sup]
        s = X_ind_T.T @ (dataset.y[inf:sup] * 
            scipy.special.expit(- dataset.y[inf:sup] * (X_ind_T @ theta)))
        return self.c * theta - s / (sup - inf)

    def get_stochastic_gradient_range_sparse(self, theta, dataset, inf, sup):
        X_ind_T = dataset.X.T[inf:sup]
        s = scipy.sparse.csr_matrix(X_ind_T.T @ (dataset.y[inf:sup] * scipy.special.expit(- dataset.y[inf:sup] * (X_ind_T @ theta))))
        return - s / (sup - inf)

    def get_stochastic_gradient(self, theta, dataset, indices):
        X_ind_T = dataset.X.T[indices]
        s = X_ind_T.T @ (dataset.y[indices] * 
            scipy.special.expit(- dataset.y[indices] * (X_ind_T @ theta)))
        return self.c * theta - s / len(indices)

    def compute_error(self, theta, dataset):
        s = np.sum(
            vec_logit(dataset.y * (dataset.X.T @ theta))
        ) / dataset.N
        return 0.5 * self.c * (theta @ theta) - s