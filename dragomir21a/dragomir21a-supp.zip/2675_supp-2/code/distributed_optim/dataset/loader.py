from joblib import Memory
import numpy as np


class Loader(object):
    def __init__(self, cache_path=None, N=None, split="random",
                rank=0, seed=None, **kwargs):
        self.mem_loader = Memory(cache_path)
        self.nb_samples = N
        self.seed = seed
        self.split = split
        self.get_data_slice(split, rank)

    def load(self, **kwargs):
        raise NotImplementedError

    def get_data_slice(self, split, rank):
        if split == "random":
            self.seed += rank
            self.start = 0
        elif split == "fixed":
            self.start = rank * self.nb_samples