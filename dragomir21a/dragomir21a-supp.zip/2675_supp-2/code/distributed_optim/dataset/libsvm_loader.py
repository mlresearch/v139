from joblib import Memory
from sklearn.datasets import load_svmlight_file
import numpy as np 

from dataset.dataset import Dataset 
from dataset.loader import Loader 


load_svmlight_kwargs = {
    "n_features", "dtype", "multilabel", "zero_based",
    "query_id", "offset", "length"
}


class LIBSVM_Loader(Loader):
    def __init__(self,  **kwargs):
        if "length" in kwargs:
            self.bytes_length = kwargs["length"]
        super(LIBSVM_Loader, self).__init__(**kwargs)

    def get_data_slice(self, split, rank):
        super(LIBSVM_Loader, self).get_data_slice(split, rank)
        if split == "fixed_bytes":
            self.offset = rank * self.bytes_length
            self.start = 0
        else:
            self.offset = 0

    def load(self, path_to_data=None, **kwargs):
        restricted_kwargs = {
            k: v for k,v in kwargs.items() 
            if k in load_svmlight_kwargs
        }
        restricted_kwargs["offset"] = self.offset

        @self.mem_loader.cache
        def get_data(path_to_data, **kwargs):
            return load_svmlight_file(path_to_data, **kwargs)[:2]

        X, y = get_data(path_to_data, **restricted_kwargs)
        d = Dataset(X=X.T, y=y.T, seed=self.seed)

        if self.nb_samples is not None:
            if self.split == "fixed":
                d.truncate(self.nb_samples, self.start)
            else:
                d.subsample(self.nb_samples)

        return d