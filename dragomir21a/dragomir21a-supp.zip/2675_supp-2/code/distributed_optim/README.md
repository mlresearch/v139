## Code to run Stochastic Statistically Preconditioned methods.

# Overview

Python code to run BGD, BSGD, BSAGA, and SPAG. The code is adapted from the code of Statistically Preconditioned Accelerated Gradient Method for Distributed Optimization (Hendrikx, Xiao, Bubeck, Bach, Massoulie, ICML 2020). 
At the moment, the only local solver supported is SDCA. 

# Requirements

Install the following packages:

`conda install numpy scipy numba matplotlib scikit-learn`

# Download the dataset

Data loading is performed using the libsvm loader from scikit learn. This loader is intended to work with libsvm-style datasets that can be downloaded at [this adress](https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary.html#covtype.binary), such as the RCV1 dataset used for the experiments. Caching using joblib is used by default for loading the datasets. 

To run the code, you must download one of the datasets and set the `path_to_data`, `n_features` and `zero_based` features accordingly (configured for RCV1 by default). It is also preferable to shuffle the dataset beforehand, for example using the command `shuf dataset > shuf_dataset`.

# Run the code with MPI

To run the code, use the command:

`python run_local.py --n_nodes n_nodes --config config_file`

with *n_nodes* the number of desired nodes, and *config_file* the config file.  

For instance, to run the experiments presented in the paper, use (after having downloaded the dataset and configured the path correctly):

`python run_local.py --n_nodes 100 --config config.json`

Additional arguments can also be passed directly. For instance, to plot the results, simply add the *--plot* argument as follows:

`python run_local.py --n_nodes 100 --config config.json --plot`

Contrary to the code from Hendrikx et al. (2020), this code is designed to run locally on one's own computer, and does not rely on MPI. Therefore, it is less suitable to being used at scale, but more efficient on smaller problems. 

# Performances

The code is designed for sparse datasets, and may be suboptimal in the case of dense high-dimensional data. Just in time compilation (numba) is used to speed up all critical parts, especially the local solvers.
