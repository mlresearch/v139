# To add a new cell, type '# %%'
# To add a new markdown cell, type '# %% [markdown]'
# %%
import logging
import time 

# %%
from dataset.libsvm_loader import LIBSVM_Loader 
from models.logistic_regression import LogisticRegression
from solver.solvers import AvailableSolvers
from plotter import Plotter
from parser import Parser 

# %%

args_parser = Parser()
args, data_args, algo_args, model_args, solvers = args_parser.get_args()

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("Main")
plotter = Plotter(filename=args.plotter_path)

# local_seed = seed + rank # To avoid having all local dataset being the same
model = LogisticRegression(**model_args)
data_args["N"] = args.n_nodes * data_args["N"]
dataset = LIBSVM_Loader(**data_args, seed=args.seed, rank=0).load(**data_args)

filename = str(time.time()).split(".")[0]

for solver_name, solver_args in solvers:
    solver_class = AvailableSolvers.get_sim(solver_name)
    solver = solver_class(name=solver_name, model=model, n_nodes=args.n_nodes, dataset=dataset,
            seed=args.seed, timestamp=filename, **algo_args, **solver_args)

    solver.solve(args.nb_epochs)
    plotter.add_curve(solver_name, solver.error, solver_args)


plotter.plot(show=args.plot)
# filename = str(time.time()).split(".")[0]
plotter.save(filename=filename, output_path=args.output_path, save_png=args.save_png)
args_parser.save_config(filename=filename, output_path=args.output_path)