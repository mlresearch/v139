import logging


from solver.sim_distributed.dane import SimDane
from solver.sim_distributed.spag import SimSPAG
from solver.sim_distributed.subsampling import SubsamplingDaneSim
from solver.sim_distributed.saga import SagaSim
from solver.sim_distributed.saga_sparse import SagaSimSparse
from solver.sim_distributed.svrg import SvrgSim


class AvailableSolvers(object):
    sim_solvers  = {
                "DANE": SimDane,
                "SVRG": SvrgSim,
                "SPAG": SimSPAG,
                "SAGASERV": SagaSim,
                "SPARSAGA": SagaSimSparse,
                "SUBSAMPSERV": SubsamplingDaneSim
                }
    
    log = logging.getLogger("Args")

    @staticmethod
    def get(solver_name, solvers):
        if type(solver_name) is list:
            return [s for s in 
            AvailableSolvers.get(solver_name, solvers) if s is not None]
        
        if type(solver_name) is dict:
            return AvailableSolvers.get(list(solver_name.keys()), solvers)

        if type(solver_name) is str:
            solver_type = solver_name.split("_")[0]
            solver = solvers.get(solver_type)
            if solver is None:
                AvailableSolvers.log.warning(f"Could not find solver {solver_type}")
                return [SolverNotFound, SolverNotFound]
            return solver

    @staticmethod
    def get_sim(solver_name):
        return AvailableSolvers.get(solver_name, AvailableSolvers.sim_solvers)

class SolverNotFound(object):
    def __init__(self, **kwargs):
        pass 

    def solve(self, nb_epochs):
        pass