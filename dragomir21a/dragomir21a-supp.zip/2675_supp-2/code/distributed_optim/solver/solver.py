import numpy as np
import matplotlib.pyplot as plt
import logging 
import time
import tensorflow as tf
import os 


class Solver(object):
    def __init__(self, name="Main", model=None, dataset=None, seed=0, nb_epochs=0, 
    inner_precision=1e-10, max_inner_repeats=1, tb_dir=None, tb_min_error=0., 
    timestamp="", **kwargs):
        self.name = name
        self.model = model
        self.dataset = dataset
        self.x = np.zeros(dataset.d)
        self.seed = seed
        self.rs = np.random.RandomState(seed=seed)

        self.iteration_number = 0
        self.epochs_coeff = 1
        self.error_comp_period = 1

        self.inner_precision = inner_precision
        self.max_inner_repeats = max_inner_repeats

        self.n_inner_iters = self.dataset.N
        self.error = []
        self.log = logging.getLogger(name)
        self.tb_min_error = tb_min_error
        self.setup_tensorboard(tb_dir, timestamp)

    def setup_tensorboard(self, tensorboard_dir, timestamp):
        self.tensorboard_dir = tensorboard_dir

        if tensorboard_dir is not None:
            self.log.info(f"Tensorboard summary writer dir: {tensorboard_dir}")
            self.summary_writer = tf.summary.create_file_writer(
                os.path.join(tensorboard_dir, timestamp, self.name))

    def solve(self, nb_epochs):
        grad = np.zeros(self.x.shape)
        self.error.append(self.compute_error())
        self.log.info(f"Initial error: {self.error[-1]}")
        self.log.info(f"Starting iterations, dataset shape: {self.dataset.X.shape}")
        
        t_start = time.time()
        total_nb_epochs = int(nb_epochs * self.epochs_coeff)
        while self.iteration_number < total_nb_epochs:
            self.run_step(grad, self.n_inner_iters)
            if self.iteration_number % self.error_comp_period == 0:
                self.error.append(self.compute_error())
                self.report_epoch(self.iteration_number, total_nb_epochs)
            self.iteration_number += 1   
        t_end = time.time()
        self.log.info(f"Final error: {self.compute_error()}")
        self.log.info(f"Elapsed time: {t_end - t_start}")

    def report_epoch(self, i, nb_epochs):
        self.log.info(f"Epoch {i + 1}/{nb_epochs}, error: {self.error[-1]}")
        if self.tensorboard_dir is not None:
            with self.summary_writer.as_default():
                tf.summary.scalar("error", self.error[-1], step=i)
                tf.summary.scalar("log_subop", np.log10(self.error[-1] - self.tb_min_error), step=i)

    def compute_error(self):
        return self.model.compute_error(self.x, self.dataset)

    def plot(self):
        err = np.array(self.error) - np.min(self.error)
        plt.plot(err)
        plt.yscale("log")
        plt.show()
        
    def run_step(self, grad, nb_iters):
        raise NotImplementedError