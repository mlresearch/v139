import numpy as np
from mpi4py import MPI 

from solver.sim_distributed.dane import SimDane


class SimSPAG(SimDane):
    def __init__(self, rho=0.001, sigma_rel=0.1, **kwargs):
        self.x = None
        super(SimSPAG, self).__init__(**kwargs)
        self.G = 0.
        self.sigma_rel = sigma_rel
        self.kappa_rel_inv = self.step_size * self.sigma_rel
        assert(self.kappa_rel_inv < 1.)
        self.rho = np.sqrt(self.kappa_rel_inv)
        self.log.info(f"rho: {self.rho}, step_size: {self.step_size}")
        self.v = np.copy(self.x)

    def run_step(self, grad, nb_iters):
        self.global_grad = self.get_global_gradient()

        w = (1 - self.rho) * self.v + self.rho * self.x

        grad_v = self.model.get_gradient(self.v, self.precond_data)
        grad_y = self.model.get_gradient(self.x, self.precond_data)
        grad_w = (1 - self.rho) * grad_v + self.rho * grad_y

        v_new = self.local_solver.run_step(
            - grad_w + self.global_grad * self.rho / self.sigma_rel
            - self.mu * ((1 - self.rho) * self.v + self.rho * self.x),
            self.inner_epochs
        )
        x_new = self.x + self.rho * (v_new - w)

        self.v = v_new
        self.x = (x_new + self.rho * v_new) / (1 + self.rho)