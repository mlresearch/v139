import numpy as np 
from mpi4py import MPI 
import logging 

from solver.solver import Solver


class SimDistributedSolver(Solver):
    def __init__(self, n_nodes=1, **kwargs):
        super(SimDistributedSolver, self).__init__(**kwargs)
        self.n_nodes = n_nodes
        self.batch_size = n_nodes

    def compute_error(self):
        return self.model.compute_error(self.x, self.dataset)
        
    def compute_loss(self, param):
        return self.model.compute_error(param, self.dataset)