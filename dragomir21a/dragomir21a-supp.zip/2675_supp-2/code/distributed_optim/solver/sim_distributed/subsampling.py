from mpi4py import MPI
import numpy as np

from solver.sim_distributed.dane import SimDane


class SubsamplingDaneSim(SimDane):
    def __init__(self, batch_size=1, **kwargs):
        super(SubsamplingDaneSim, self).__init__(**kwargs)
        self.batch_size = batch_size
        self.slice_size = int(self.dataset.N / self.n_nodes)
        self.epochs_coeff = int(self.n_nodes / self.batch_size)
        self.error_comp_period = self.error_comp_period * self.epochs_coeff 

    def get_stochastic_gradients(self, participants, x):
        return [
            self.model.get_stochastic_gradient_range(
                x, self.dataset, p * self.slice_size, (p+1) * self.slice_size 
            ) 
            for p in participants
        ]

    def get_global_gradient(self):
        participants = self.rs.choice(self.n_nodes, self.batch_size, replace=False)

        return np.average(
            self.get_stochastic_gradients(participants, self.x)
            , axis=0)