import numpy as np
import tensorflow as tf

from solver.sim_distributed.solver import SimDistributedSolver
from solver.local.sdca import SDCA
from solver.local.gradient_descent import AGD, GD


class SimDane(SimDistributedSolver):
    def __init__(self, step_size=0.01, precond_N=None, 
    inner_epochs=50, mu=0., inner_precision=None, max_inner_repeats=None, **kwargs):
        super(SimDane, self).__init__(**kwargs)
        self.step_size = step_size
        self.mu = mu

        self.global_grad = np.empty(self.x.shape)
        self.precond_data = self.dataset.get_subsampled(int(precond_N))
        self.log.info(f"Preconditioning dataset of size: {self.precond_data.N}")
        self.inner_epochs = inner_epochs
        self.local_solver = SDCA(
                            model=self.model,
                            dataset=self.precond_data,
                            seed=self.seed,
                            inner_precision=inner_precision,
                            max_inner_repeats=max_inner_repeats)
        
        self.local_solver.set_regularization(self.model.c + self.mu)
        self.x = self.rs.normal(scale=1000, size=self.x.shape)
        
    def report_epoch(self, i, nb_epochs):
        super(SimDane, self).report_epoch(i, nb_epochs)
        self.log.info(f"g_norm: {self.local_solver.subproblem_grad_norm}")
        if self.tensorboard_dir is not None:
            with self.summary_writer.as_default():
                tf.summary.scalar("g_norm", self.local_solver.subproblem_grad_norm, step=i)

    def run_step(self, grad, nb_iters):
        self.global_grad = self.get_global_gradient()
        grad_phi = self.model.get_gradient(self.x, self.precond_data)
        self.x = self.local_solver.run_step(
            - grad_phi - self.mu * self.x + self.global_grad * self.step_size,  # no need to divide by nb nodes
            self.inner_epochs
        )

    def get_global_gradient(self):
        return self.model.get_gradient(self.x, self.dataset)
