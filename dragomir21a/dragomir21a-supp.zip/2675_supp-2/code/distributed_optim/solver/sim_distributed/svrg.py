import numpy as np

from solver.sim_distributed.subsampling import SubsamplingDaneSim


class SvrgSim(SubsamplingDaneSim):
    def __init__(self, K=1, **kwargs):
        super(SvrgSim, self).__init__(**kwargs)
        self.grad_w = np.zeros(self.dataset.d)
        self.w = np.zeros(self.dataset.d) 
        self.iters_update_w = K * self.epochs_coeff 

    def get_global_gradient(self):
        if self.iteration_number % self.iters_update_w == 0:
            self.update_w()

        participants = self.rs.choice(self.n_nodes, self.batch_size, replace=False)

        grad_sto_x = self.get_stochastic_gradients(participants, self.x)
        grad_sto_w = self.get_stochastic_gradients(participants, self.w)

        self.global_gradient = np.average(grad_sto_x, axis=0) \
            - np.average(grad_sto_w, axis=0) \
            + self.grad_w / self.n_nodes 

        return self.global_gradient

    def update_w(self):
        self.w = self.x 
        self.grad_w = self.model.get_gradient(self.past_point, self.dataset)