import numpy as np

from solver.sim_distributed.subsampling import SubsamplingDaneSim


class SagaSimSparse(SubsamplingDaneSim):
    def __init__(self, **kwargs):
        super(SagaSimSparse, self).__init__(**kwargs)
        self.past_grads = [0. for _ in range(self.n_nodes)]
        self.grad_sum = np.sum(self.past_grads, axis=0)

    def get_stochastic_gradients(self, participants, x):
        return [
            self.model.get_stochastic_gradient_range_sparse(
                x, self.dataset, p * self.slice_size, (p+1) * self.slice_size 
            ) 
            for p in participants
        ]

    def get_global_gradient(self):
        participants = self.rs.choice(self.n_nodes, self.batch_size, replace=False)
        local_grads = self.get_stochastic_gradients(participants, self.x)

        self.global_gradient = self.grad_sum / self.n_nodes

        for i, p in enumerate(participants):
            # import pdb; pdb.set_trace()
            self.global_gradient += (local_grads[i] - self.past_grads[p]) / self.batch_size

            self.grad_sum += local_grads[i] - self.past_grads[p]
            self.past_grads[p] = local_grads[i]
        self.global_gradient = (self.global_gradient.toarray() + self.model.c * self.x)[0]

        return self.global_gradient
