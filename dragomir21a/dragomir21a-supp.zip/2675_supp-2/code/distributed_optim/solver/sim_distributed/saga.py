import numpy as np

from solver.sim_distributed.subsampling import SubsamplingDaneSim


class SagaSim(SubsamplingDaneSim):
    def __init__(self, **kwargs):
        super(SagaSim, self).__init__(**kwargs)
        self.past_grads = np.zeros((self.n_nodes, self.dataset.d))
        self.grad_sum = np.sum(self.past_grads, axis=0)

    def get_global_gradient(self):
        participants = self.rs.choice(self.n_nodes, self.batch_size, replace=False)
        local_grads = self.get_stochastic_gradients(participants, self.x)

        self.global_gradient = np.average(local_grads, axis=0) \
            - np.average(self.past_grads[participants], axis=0) \
            + self.grad_sum / self.n_nodes 

        for i, p in enumerate(participants):
            self.grad_sum += local_grads[i] - self.past_grads[p]
            self.past_grads[p] = local_grads[i]
        
        return self.global_gradient
        