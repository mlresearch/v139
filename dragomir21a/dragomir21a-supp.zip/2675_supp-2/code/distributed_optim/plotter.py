import numpy as np 
import matplotlib 
matplotlib.rc('xtick', labelsize=20) 
matplotlib.rc('ytick', labelsize=20) 
matplotlib.rc('font', size=16)

from matplotlib.lines import Line2D
import matplotlib.pyplot as plt 
import json 
import os
import logging 


marker_by_alg = {
    "DANE": "o",
    "SPAG": "+",
    "SPARSAGA": "D",
    "SUBSAMPSERV": "x"
}


color_by_alg = {
    "DANE": "tab:orange",
    "SPARSAGA": "tab:red",
    "SUBSAMPSERV": "tab:blue",
    "SPAG": "tab:green"
}

rename = {
    "SPARSAGA": "BSAGA",
    "SUBSAMPSERV": "BSGD",
    "SPAG": "SPAG",
    "DANE": "DANE (BGD)"
}


class Plotter(object):
    def __init__(self, filename=None):
        self.min_error = np.inf 
        self.curves = []
        self.log = logging.getLogger("Main")
        if filename is not None:
            self.load(filename)

    def add_curve(self, name, error, config):
        self.min_error = min(self.min_error, np.min(error))
        self.curves.append([name, error, config])

    def plot(self, show=True):
        if len(self.curves) == 0:
            return

        plt.figure(figsize=(8,6))
        plt.subplots_adjust(top=0.98, bottom=0.12, left=0.16, right=0.965, hspace=0.2, wspace=0.2)
    
        handles = []
        for i, (name, error, _) in enumerate(self.curves):
            tokens = name.split("_")
            alg, n = tokens[:2]
            
            tokens[0] = rename[tokens[0]]
            
            new_name = "_".join(tokens)
            err = np.array(error) - self.min_error
            h, = plt.plot(err, markevery=20,
                                label=new_name,
                                color=color_by_alg[alg],
                                marker=marker_by_alg[alg], 
                                linewidth=5,                               
                                markersize=15,
                                mew=5
            ) 
                            
            handles.append(h)

        plt.legend(handles=handles)
        plt.yscale("log")
        plt.ylabel("Suboptimality")
        plt.xlabel("Epoch")
        if show:
            plt.show()

    def save(self, output_path=None, save_png=False, filename=None):
        path = os.path.join(output_path, filename)
        self.log.info(path)
        self.dump(path)
        if save_png:
            plt.savefig(os.path.join(output_path + ".png"))
            
    def dump(self, path):
        if len(self.curves) > 0:
            json.dump(self.curves, open(path, "w"))

    def load(self, filename):
        if type(filename) == list:
            for f in filename:
                self.load(f) 

        elif type(filename) == str:
            for name, error, args in json.load(open(filename)):
                self.add_curve(name, error, args)