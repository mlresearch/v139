Dear reader,

This supplementary material is structured as follows:

Paper.pdf
* Paper with appendix

Code/MetaTS Public.ipynb
* MetaTS experiments in Bernoulli and Gaussian bandits

Code/CoMetaTS Public.ipynb
* MetaTS experiments in linear bandits

Sincerely yours,

The authors
