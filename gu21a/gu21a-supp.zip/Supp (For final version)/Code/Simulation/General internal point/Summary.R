XX<-NULL
n_list<-c(rep(c(200,500,1000,2000),c(3)),c(500,1000,2000))
d_list<-rep(c(5,10,20,50),c(4,4,4,3))
l_list<-letters[1:5]
Ha<-rep(5,15)
#Ha[14]<-3
##########################################
for(j in c(1:15))
{
  Result<-NULL
  for(i in l_list[1:Ha[j]])
  {Result<-rbind(Result,as.matrix(read.csv(paste(c("DTLn",as.character(n_list[j]),"d",as.character(d_list[j]),i,".csv"),collapse = ""),header = T)[,-c(1,2)]))}
  
  
  #XX<-rbind(XX,c(n_list[j],d_list[j],as.vector(rbind(colMeans(Result[,-1]/Result[,1]),apply(Result[,-1]/Result[,1],2,sd)/10))))
  Hei<-NULL
  Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,1])),2)),"(",as.character(round(sd(log(Result[,1]))/10,2)),")"),collapse = ""))
  for(i in 2:ncol(Result))
  {
    Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,i]/Result[,1])),2)),"(",as.character(round(sd(log(Result[,i]/Result[,1]))/10,2)),")"),collapse = ""))
  }
  XX<-rbind(XX,c(as.character(d_list[j]),as.character(n_list[j]),Hei))
}


colnames(XX)<-c("d","n","CL","5-NN","10-NN","k*-NN","LL","KR","GP")

#XX<-cbind(XX[,1:3],c(X[1,1]*XX[2,3]+(1-X[1,1])*XX[3,2],XX[2,3],XX[3,2]),XX[,4:5])

write.table((XX),"All.txt",sep="&")
