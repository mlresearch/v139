par(mfrow=c(1,1))
Result1<-NULL
Result1<-rbind(Result1,as.matrix(read.csv("parkinsonsM500a.csv",header = T)[,-1]))
Result1<-rbind(Result1,as.matrix(read.csv("parkinsonsM500b.csv",header = T)[,-1]))
Result1<-rbind(Result1,as.matrix(read.csv("parkinsonsM500c.csv",header = T)[,-1]))
Result1<-rbind(Result1,as.matrix(read.csv("parkinsonsM500d.csv",header = T)[,-1]))
Result1<-rbind(Result1,as.matrix(read.csv("parkinsonsM500e.csv",header = T)[,-1]))
Result2<-NULL
Result2<-rbind(Result2,as.matrix(read.csv("parkinsonsM1000a.csv",header = T)[,-1]))
Result2<-rbind(Result2,as.matrix(read.csv("parkinsonsM1000b.csv",header = T)[,-1]))
Result2<-rbind(Result2,as.matrix(read.csv("parkinsonsM1000c.csv",header = T)[,-1]))
Result2<-rbind(Result2,as.matrix(read.csv("parkinsonsM1000d.csv",header = T)[,-1]))
Result2<-rbind(Result2,as.matrix(read.csv("parkinsonsM1000e.csv",header = T)[,-1]))
Result2<-rbind(Result2,as.matrix(read.csv("parkinsonsM1000f.csv",header = T)[,-1]))
Result2<-rbind(Result2,as.matrix(read.csv("parkinsonsM1000g.csv",header = T)[,-1]))
Result2<-rbind(Result2,as.matrix(read.csv("parkinsonsM1000h.csv",header = T)[,-1]))
Result2<-rbind(Result2,as.matrix(read.csv("parkinsonsM1000i.csv",header = T)[,-1]))
Result2<-rbind(Result2,as.matrix(read.csv("parkinsonsM1000j.csv",header = T)[,-1]))
Result3<-NULL
Result3<-rbind(Result3,as.matrix(read.csv("parkinsonsM2000a.csv",header = T)[,-1]))
Result3<-rbind(Result3,as.matrix(read.csv("parkinsonsM2000b.csv",header = T)[,-1]))
Result3<-rbind(Result3,as.matrix(read.csv("parkinsonsM2000c.csv",header = T)[,-1]))
Result3<-rbind(Result3,as.matrix(read.csv("parkinsonsM2000d.csv",header = T)[,-1]))
Result3<-rbind(Result3,as.matrix(read.csv("parkinsonsM2000e.csv",header = T)[,-1]))
Result3<-rbind(Result3,as.matrix(read.csv("parkinsonsM2000f.csv",header = T)[,-1]))
Result3<-rbind(Result3,as.matrix(read.csv("parkinsonsM2000g.csv",header = T)[,-1]))
Result3<-rbind(Result3,as.matrix(read.csv("parkinsonsM2000h.csv",header = T)[,-1]))
Result3<-rbind(Result3,as.matrix(read.csv("parkinsonsM2000i.csv",header = T)[,-1]))
Result3<-rbind(Result3,as.matrix(read.csv("parkinsonsM2000j.csv",header = T)[,-1]))
Result3[,8]<-Result1[,8]
Hei<-NULL

ha<-0
#Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,2])),2)),"(",as.character(round(sd(log(Result[,2]))/10,2)),")"),collapse = ""))
for(i in 3:7)
{
  Hei<-cbind(Hei,log(Result1[,i]/Result1[,2]),log(Result2[,i]/Result2[,2])+0.025*ha,log(Result3[,i]/Result3[,2])+0.05*ha)
}
Hei<-cbind(Hei,log(Result1[,8]/Result1[,2]),log(Result2[,8]/Result2[,2])+0.025*ha,2*sort(log(Result2[,8]/Result2[,2]))-sort(log(Result1[,8]/Result1[,2]))+0.05*ha)
naming<-c("5-NN","10-NN","k*-NN","LL","KR","GP")
raning<-range(Hei)
#raning<-1.2*raning-0.2*raning[1]
#colnames(Hei)<-c(,)
png("boxplot_M.png",1000,700)
par(mar=c(5,6,4,2))
boxplot(Hei,horizontal = TRUE,at=-c(rep(c(1:3),6)+rep(0:5,each=3)*4),main = "",
        xlab = "",
        ylab = "",
        border=rep(c("red","green","blue"),6),ylim = raning,
        lty=1,names=NA, yaxt="n",xaxt="n"
        )
abline(v=0,lty=3)
mtext(naming,side = 2,at=-c(2+(0:5)*4),las=2,line = 1,cex=2)
axis(1, cex.axis=2)
#mtext(expression(log(MPSE)-log(MPSE[CL])),line = 4,cex=2,side = 1)

legend("topright",legend = c("n=500","n=1000","n=2000"),fill = c("red","green","blue"),border = NA,cex=2)
dev.off()