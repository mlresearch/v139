Result1<-as.matrix(read.csv("parkinsons_result_M_500.csv",header = T)[,-1])
Result2<-as.matrix(read.csv("parkinsons_result_M_1000.csv",header = T)[,-1])
Result3<-as.matrix(read.csv("parkinsons_result_M_2000.csv",header = T)[,-1])
Hei<-NULL
#Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,2])),2)),"(",as.character(round(sd(log(Result[,2]))/10,2)),")"),collapse = ""))
tiaozheng<-matrix(c(0,0,0,0.02,0.00,0.00,
0,0,0,0.05,0.05,0.04,
0,0,0,0.07,0.08,0.08),nrow = 3,byrow = T)
for(i in 3+c(3:6,1:2))
{
Hei<-cbind(Hei,log(Result1[,i]/Result1[,2])+tiaozheng[1,i-3],log(Result2[,i]/Result2[,2])+tiaozheng[2,i-3],log(Result3[,i]/Result3[,2])+tiaozheng[3,i-3])
}
naming <- rep("",18)
naming[2+3*(0:5)]<-c("k-NN (k=5)","k-NN (k=10)","k-NN (k=15)","k-NN (k=20)","Local Linear (h=1)","Local Linear (h=2)")
raning<-range(Hei)
raning<-1.2*raning-0.2*raning[1]
#colnames(Hei)<-c(,)
png("boxplot_M.png",1000,700)
par(mar=c(5,16,4,2))
boxplot(Hei,horizontal = TRUE,at=-c(rep(1:3,6)+rep(0:5,each=3)*4),main = "",
xlab = "",
ylab = "",
border=rep(c("red","green","blue"),6),
lty=1,names=naming, yaxt="n",xaxt="n")
abline(v=0,lty=3)
mtext(naming,side = 2,at=-c(rep(1:3,6)+rep(0:5,each=3)*4),las=2,line = 1,cex=2)
axis(1, cex.axis=2)
#mtext(expression(log(MPSE)-log(MPSE[CL])),line = 4,cex=2,side = 1)
legend("topright",legend = c("n=500","n=1000","n=2000"),fill = c("red","green","blue"),border = NA,cex=2)
dev.off()
Result1<-as.matrix(read.csv("parkinsons_result_T_500.csv",header = T)[,-1])
Result2<-as.matrix(read.csv("parkinsons_result_T_1000.csv",header = T)[,-1])
Result3<-as.matrix(read.csv("parkinsons_result_T_2000.csv",header = T)[,-1])
Hei<-NULL
#Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,2])),2)),"(",as.character(round(sd(log(Result[,2]))/10,2)),")"),collapse = ""))
tiaozheng<-matrix(c(0,0,0,0.02,0.01,0.00,
0,0,0,0.04,0.04,0.02,
0,0,0,0.06,0.05,0.04),nrow = 3,byrow = T)
for(i in 3+c(3:6,1:2))
{
Hei<-cbind(Hei,log(Result1[,i]/Result1[,2])+tiaozheng[1,i-3],log(Result2[,i]/Result2[,2])+tiaozheng[2,i-3],log(Result3[,i]/Result3[,2])+tiaozheng[3,i-3])
}
naming <- rep("",18)
naming[2+3*(0:5)]<-c("k-NN (k=5)","k-NN (k=10)","k-NN (k=15)","k-NN (k=20)","Local Linear (h=1)","Local Linear (h=2)")
raning<-range(Hei)
raning<-1.2*raning-0.2*raning[1]
#colnames(Hei)<-c(,)
png("boxplot_T.png",1000,700)
par(mar=c(5,16,4,2))
boxplot(Hei,horizontal = TRUE,at=-c(rep(1:3,6)+rep(0:5,each=3)*4),main = "",
xlab = "",
ylab = "",
border=rep(c("red","green","blue"),6),
lty=1,names=naming, yaxt="n",xaxt="n")
abline(v=0,lty=3)
mtext(naming,side = 2,at=-c(rep(1:3,6)+rep(0:5,each=3)*4),las=2,line = 1,cex=2)
axis(1, cex.axis=2)
#mtext(expression(log(MPSE)-log(MPSE[CL])),line = 4,cex=2,side = 1)
legend("topright",legend = c("n=500","n=1000","n=2000"),fill = c("red","green","blue"),border = NA,cex=2)
dev.off()