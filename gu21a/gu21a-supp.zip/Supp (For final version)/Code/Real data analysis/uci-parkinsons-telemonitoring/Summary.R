XX<-NULL

Result<-as.matrix(read.csv("parkinsons_result_M_500.csv",header = T)[,-1])
Hei<-NULL
Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,2])),2)),"(",as.character(round(sd(log(Result[,2]))/10,2)),")"),collapse = ""))
for(i in 3:ncol(Result))
{
  Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,i]/Result[,2])),2)),"(",as.character(round(sd(log(Result[,i]/Result[,2]))/10,2)),")"),collapse = ""))
}
XX<-rbind(XX,c("500M",Hei))

Result<-as.matrix(read.csv("parkinsons_result_M_1000.csv",header = T)[,-1])
Hei<-NULL
Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,2])),2)),"(",as.character(round(sd(log(Result[,2]))/10,2)),")"),collapse = ""))
for(i in 3:ncol(Result))
{
  Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,i]/Result[,2])),2)),"(",as.character(round(sd(log(Result[,i]/Result[,2]))/10,2)),")"),collapse = ""))
}
XX<-rbind(XX,c("1000M",Hei))

Result<-as.matrix(read.csv("parkinsons_result_M_2000.csv",header = T)[,-1])
Hei<-NULL
Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,2])),2)),"(",as.character(round(sd(log(Result[,2]))/10,2)),")"),collapse = ""))
for(i in 3:ncol(Result))
{
  Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,i]/Result[,2])),2)),"(",as.character(round(sd(log(Result[,i]/Result[,2]))/10,2)),")"),collapse = ""))
}
XX<-rbind(XX,c("2000M",Hei))


Result<-as.matrix(read.csv("parkinsons_result_T_500.csv",header = T)[,-1])
Hei<-NULL
Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,2])),2)),"(",as.character(round(sd(log(Result[,2]))/10,2)),")"),collapse = ""))
for(i in 3:ncol(Result))
{
  Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,i]/Result[,2])),2)),"(",as.character(round(sd(log(Result[,i]/Result[,2]))/10,2)),")"),collapse = ""))
}
XX<-rbind(XX,c("500T",Hei))

Result<-as.matrix(read.csv("parkinsons_result_T_1000.csv",header = T)[,-1])
Hei<-NULL
Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,2])),2)),"(",as.character(round(sd(log(Result[,2]))/10,2)),")"),collapse = ""))
for(i in 3:ncol(Result))
{
  Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,i]/Result[,2])),2)),"(",as.character(round(sd(log(Result[,i]/Result[,2]))/10,2)),")"),collapse = ""))
}
XX<-rbind(XX,c("1000T",Hei))

Result<-as.matrix(read.csv("parkinsons_result_T_2000.csv",header = T)[,-1])
Hei<-NULL
Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,2])),2)),"(",as.character(round(sd(log(Result[,2]))/10,2)),")"),collapse = ""))
for(i in 3:ncol(Result))
{
  Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,i]/Result[,2])),2)),"(",as.character(round(sd(log(Result[,i]/Result[,2]))/10,2)),")"),collapse = ""))
}
XX<-rbind(XX,c("2000T",Hei))

colnames(XX)<-c("n","CL","Linear","Local Linear(h=1)","Local Linear(h=2)","k-NN(k=5)","k-NN(k=10)","k-NN(k=15)","k-NN(k=20)")
XX
write.table(XX[,c(1,2,7:10-1,5:6-1)],"parkinsons_result.txt",sep="&")
