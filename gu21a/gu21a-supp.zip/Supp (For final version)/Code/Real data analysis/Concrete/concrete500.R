Parallel_N<-function(cishu)
{
  # Package
  library(mvtnorm)
  library(geometry)
  library(regpro)
  library(FNN)
  library(mlegp)
  source("Function.R")
  
  Data<-read.csv("concrete.csv",header = T)
  
  X_original<-as.matrix(Data[,-ncol(Data)])
  X_sd<-apply(X_original,2,var)
  Y_original<-Data[,ncol(Data)]
  
  n_test<-100
  n<-500
  
  Result<-NULL
  for(iter in 1:cishu)
  {
    index_selection<-sample(1:nrow(X_original),n_test+n)
    X<-X_original[index_selection,]+rmvnorm(n_test+n,sigma = diag(X_sd/100))
    Y<-Y_original[index_selection]
    mean_X<-colMeans(X)
    X<-t(t(X)-mean_X)
    #X_test<-t(t(X_test)-mean_X)
    XX<-eigen(t(X)%*%X/n)
    X<-X%*%XX$vectors%*%diag(1/sqrt(XX$values))
    X<-X[,XX$values>0.1]
    
    
    rowsum2<-rowSums(X^2)
    order_rowsum2<-order(rowsum2)[1:n_test]
    
    X_test<-X[order_rowsum2,]
    Y_test<-Y[order_rowsum2]
    X<-X[-order_rowsum2,]
    Y<-Y[-order_rowsum2]
    
    
    d<-ncol(X)
    
    
    
    Y_wm<-0*Y_test
    Y_wlm<-0*Y_test # CL
    Y_loc1<-0*Y_test # LL
    Y_kernel<-0*Y_test # KR
    
    kk<-NULL
    
    # Fitting data
    for(i in 1:n_test)
    {
      DT<-Find_simplex(X,X_test[i,])
      #DT
      CT<-Crystallization_volume(X,DT$Simplex,layer = 3)
      m<-length(CT$Layer)
      
      
      relevant_index<-sort(unique(as.vector(CT$Simplex)))
      new_X<-X[relevant_index,]
      new_Y<-Y[relevant_index]
      
      
      new_W1<-NULL
      kk<-c(kk,length(relevant_index))
      for(j in relevant_index)
      {
        new_W1<-c(new_W1,sum(CT$Simplex==j))
      }
      distancing<-colSums((t(new_X)-X_test[i,])^2)
      new_W2<-new_W1*exp(-distancing/mean(distancing))
      
      
      Y_wm[i]<-weighted.mean(new_Y,w=new_W2)
      wlm.model<-lm(new_Y~new_X,weights = new_W2)
      if(min(DT$Weights)>=0)
      {Y_wlm[i]<-sum(c(1,X_test[i,])*wlm.model$coefficients)
      }
      else
      {
        Keep_weights<-DT$Weights
        Remain_Index<-1:(d+1)
        while (prod(Keep_weights>=0)==0) 
        {
          Remain_Index<-which(Keep_weights>0)
          Keep_weights[-Remain_Index]<-0
          if(length(Remain_Index)==1)
          {
            Keep_weights[Remain_Index]<-1
          }
          else
          {
            Design_X<-t(X)[,DT$Simplex[Remain_Index[-1]]]-X[DT$Simplex[Remain_Index[1]],]
            Design_Y<-X_test[i,]-X[DT$Simplex[Remain_Index[1]],]
            Jieguo<-(solve(t(Design_X)%*%Design_X)%*%t(Design_X)%*%Design_Y)[,1]
            Keep_weights[Remain_Index[-1]]<-Jieguo
            Keep_weights[Remain_Index[1]]<-1-sum(Jieguo)
          }
        }
        
        
        
        #distans<-colSums((t(X[DT$Simplex,])-X_test[i,])^2)
        Y_wlm[i]<-sum(c(1,colSums(X[DT$Simplex,]*Keep_weights))*wlm.model$coefficients)
      }
      
      Y_loc1[i]<-loclin(X_test[i,], X, Y, h=1, kernel="gauss", type=0)
      Y_kernel[i]<-kernesti.regr(X_test[i,], X, Y, h=1, kernel="gauss")
      #print(c(i,m))
    }
    
    
    
    
    lm.model<-lm(Y~X)
    Y_ultimate<-(cbind(1,X_test)%*%lm.model$coefficients)[,1]
    
    
    
    knn.model5<-knn.reg(X,X_test,Y,k=5) # 5-NN
    knn.model10<-knn.reg(X,X_test,Y,k=10) # 10-NN
    #knn.model15<-knn.reg(X,X_test,Y,k=15)
    #knn.model20<-knn.reg(X,X_test,Y,k=20)
    
    X_ranging<-apply(X,2,range)
    X_scale<-t((t(X)-X_ranging[1,])/(X_ranging[2,]-X_ranging[1,]))
    X_test_scale<-t((t(X_test)-X_ranging[1,])/(X_ranging[2,]-X_ranging[1,]))
    
    #GP_model<-GP_fit(X_scale, Y, control = c(50 * d, 10 * d, 2 * d), nug_thres = 20,trace = FALSE, maxit = 10)
    GP_model<-mlegp(X,Y,BFGS.maxiter=100)
    Y_GP<-predict(GP_model,newData=X_test) # GP
    knn.model_a<-knn.reg(X,X_test,Y,k=ceiling(mean(kk))) # k*-NN
    
    Hei<-NULL
    Hei<-cbind(Hei,(Y_wm-Y_test)^2)
    Hei<-cbind(Hei,(Y_wlm-Y_test)^2)
    Hei<-cbind(Hei,(knn.model5$pred-Y_test)^2)
    Hei<-cbind(Hei,(knn.model10$pred-Y_test)^2)
    Hei<-cbind(Hei,(knn.model_a$pred-Y_test)^2)
    Hei<-cbind(Hei,(Y_loc1-Y_test)^2)
    Hei<-cbind(Hei,(Y_kernel-Y_test)^2)
    Hei<-cbind(Hei,(Y_GP-Y_test)^2)
    
    #colMeans(Hei[InOut$In_or_out==0,])
    Result<-rbind(Result,colMeans(Hei))
  }
  return(Result)
}

library(foreach)
library(doParallel)


cl <- makeCluster(20)
registerDoParallel(cl)
# Five cores, 2000 replications per core
wosai<- foreach(cishu=rep(1,20),.combine='rbind') %dopar% Parallel_N(cishu)
stopCluster(cl)
write.csv(wosai,"concrete500a.csv")

cl <- makeCluster(20)
registerDoParallel(cl)
# Five cores, 2000 replications per core
wosai<- foreach(cishu=rep(1,20),.combine='rbind') %dopar% Parallel_N(cishu)
stopCluster(cl)
write.csv(wosai,"concrete500b.csv")

cl <- makeCluster(20)
registerDoParallel(cl)
# Five cores, 2000 replications per core
wosai<- foreach(cishu=rep(1,20),.combine='rbind') %dopar% Parallel_N(cishu)
stopCluster(cl)
write.csv(wosai,"concrete500c.csv")

cl <- makeCluster(20)
registerDoParallel(cl)
# Five cores, 2000 replications per core
wosai<- foreach(cishu=rep(1,20),.combine='rbind') %dopar% Parallel_N(cishu)
stopCluster(cl)
write.csv(wosai,"concrete500d.csv")

cl <- makeCluster(20)
registerDoParallel(cl)
# Five cores, 2000 replications per core
wosai<- foreach(cishu=rep(1,20),.combine='rbind') %dopar% Parallel_N(cishu)
stopCluster(cl)
write.csv(wosai,"concrete500e.csv")
