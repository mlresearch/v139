Result1<-NULL
Result1<-rbind(Result1,as.matrix(read.csv("concrete200a.csv",header = T)[,-1]))
Result1<-rbind(Result1,as.matrix(read.csv("concrete200b.csv",header = T)[,-1]))
Result1<-rbind(Result1,as.matrix(read.csv("concrete200c.csv",header = T)[,-1]))
Result1<-rbind(Result1,as.matrix(read.csv("concrete200d.csv",header = T)[,-1]))
Result1<-rbind(Result1,as.matrix(read.csv("concrete200e.csv",header = T)[,-1]))
Result2<-NULL
Result2<-rbind(Result2,as.matrix(read.csv("concrete500a.csv",header = T)[,-1]))
Result2<-rbind(Result2,as.matrix(read.csv("concrete500b.csv",header = T)[,-1]))
Result2<-rbind(Result2,as.matrix(read.csv("concrete500c.csv",header = T)[,-1]))
Result2<-rbind(Result2,as.matrix(read.csv("concrete500d.csv",header = T)[,-1]))
Result2<-rbind(Result2,as.matrix(read.csv("concrete500e.csv",header = T)[,-1]))
Hei<-NULL
#Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,2])),2)),"(",as.character(round(sd(log(Result[,2]))/10,2)),")"),collapse = ""))
for(i in 3:8)
{
Hei<-cbind(Hei,log(Result1[,i]/Result1[,2]),log(Result2[,i]/Result2[,2]))
}
naming<-c("5-NN","10-NN","k*-NN","LL","KR","GP")
raning<-range(Hei)
raning<-1.2*raning-0.2*raning[1]
#colnames(Hei)<-c(,)
png("boxplot_concrete.png",1000,700)
par(mar=c(5,6,4,2))
boxplot(Hei,horizontal = TRUE,at=-c(rep(1:2,6)+rep(0:5,each=2)*3),main = "",
xlab = "",
ylab = "",
ylim = raning,
border=rep(c("red","blue"),6),
lty=1,names=NA, yaxt="n",xaxt="n")
abline(v=0,lty=3)
mtext(naming,side = 2,at=-c(1.5+(0:5)*3),las=2,line = 1,cex=2)
axis(1, cex.axis=2)
#mtext(expression(log(MPSE)-log(MPSE[CL])),line = 4,cex=2,side = 1)
legend("topright",legend = c("n=200","n=500"),fill = c("red","blue"),border = NA,cex=2)
dev.off()
