XX<-NULL
Result<-NULL
Result<-rbind(Result,as.matrix(read.csv("concrete_resulta2.csv",header = T)[,-1]))
Result<-rbind(Result,as.matrix(read.csv("concrete_resultb2.csv",header = T)[,-1]))
Result<-rbind(Result,as.matrix(read.csv("concrete_resultc2.csv",header = T)[,-1]))
Result<-rbind(Result,as.matrix(read.csv("concrete_resultd2.csv",header = T)[,-1]))
Hei<-NULL
Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,2])),2)),"(",as.character(round(sd(log(Result[,2]))/10,2)),")"),collapse = ""))
for(i in 3:ncol(Result))
{
  Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,i]/Result[,2])),2)),"(",as.character(round(sd(log(Result[,i]/Result[,2]))/10,2)),")"),collapse = ""))
}
XX<-rbind(XX,c("200",Hei))


Result<-NULL
Result<-rbind(Result,as.matrix(read.csv("concrete_resulta.csv",header = T)[,-1]))
Result<-rbind(Result,as.matrix(read.csv("concrete_resultb.csv",header = T)[,-1]))
Result<-rbind(Result,as.matrix(read.csv("concrete_resultc.csv",header = T)[,-1]))
Result<-rbind(Result,as.matrix(read.csv("concrete_resultd.csv",header = T)[,-1]))
Hei<-NULL
Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,2])),2)),"(",as.character(round(sd(log(Result[,2]))/10,2)),")"),collapse = ""))
for(i in 3:ncol(Result))
{
  Hei<-c(Hei,paste(c(as.character(round(mean(log(Result[,i]/Result[,2])),2)),"(",as.character(round(sd(log(Result[,i]/Result[,2]))/10,2)),")"),collapse = ""))
}
XX<-rbind(XX,c("500",Hei))

colnames(XX)<-c("n","CL","Linear","Local Linear(h=1)","Local Linear(h=2)","k-NN(k=5)","k-NN(k=10)","k-NN(k=15)","k-NN(k=20)")


XX
write.table(XX[,c(1,2,7:10-1,5:6-1)],"concrete_result.txt",sep="&")
