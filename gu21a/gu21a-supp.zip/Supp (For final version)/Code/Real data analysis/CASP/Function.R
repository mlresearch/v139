# Generate seed simplex (inner point)
# X: Input data points, z: Target point
# Output: index of vertices of the seed simplex close to z
Seed_simplex<-function(X,z) 
{
  # Data dimension
  n<-nrow(X)
  d<-ncol(X)
  if(((length(z)!=d)+(n<=d))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    All_index<-1:n
    # Find the closest point: s1
    Dist_all<-colSums((t(X[All_index,])-z)^2)
    vertices<-which.min(Dist_all)
    All_index<-setdiff(All_index,vertices)
    
    # Find the closet point to s1: s2
    Dist_all<-colSums((t(X[All_index,])-X[vertices,])^2)
    vertices<-c(vertices,All_index[which.min(Dist_all)])
    All_index<-setdiff(All_index,vertices)
    
    A_base<-matrix(X[vertices[2],]-X[vertices[1],],nrow = 1)
    b_base<-0.5*sum((X[vertices[2],]-X[vertices[1],])^2)
    
    
    for(j in 2:d)
    {
      r_min<-Inf
      index<-NULL
      
      for(i in All_index)
      {
        A<-rbind(A_base,X[i,]-X[vertices[1],])
        b<-c(b_base,0.5*sum((X[i,]-X[vertices[1],])^2))
        
        X_star<-t(A)%*%solve(A%*%t(A))%*%b
        if(sum(X_star^2)<r_min)
        {
          r_min<-sum(X_star^2)
          index<-i
        }
      }
      vertices<-c(vertices,index)
      All_index<-setdiff(All_index,index)
      A_base<-rbind(A_base,X[index,]-X[vertices[1],])
      b_base<-c(b_base,0.5*sum((X[index,]-X[vertices[1],])^2))
    }
    return(vertices)
  }
}

# Generate the simplex contains z (inner point)
# X: Input data points, z: Target point
# Output: index of vertices of the simplex contains z and the weights of these vertices
Find_simplex<-function(X,z)
{
  n<-nrow(X)
  d<-ncol(X)
  if(((length(z)!=d)+(n<=d))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    Simplex_set<-matrix(Seed_simplex(X,z),ncol=d+1)
    Weight_set<-NULL
    Exploring<-0
    conditions<-0
    
    while(Exploring<nrow(Simplex_set))
    {
      Exploring<-Exploring+1
      S_current<-Simplex_set[Exploring,]
      Weighting<-solve((t(X[S_current[-1],])-X[S_current[1],]),z-X[S_current[1],])
      Weighting<-c(1-sum(Weighting),Weighting)
      if(prod(Weighting>0)==1)
      {
        conditions<-1
        break
      }
      else
      {
        Weight_set<-rbind(Weight_set,Weighting)
        #cut_index<-which(Weighting<0)
        cut_index<-which.min(Weighting)
        for(i in cut_index)
        {
          Facet<-S_current[-i]
          A_base<-t(t(X)[,Facet[-1]]-X[Facet[1],])
          buchong<-t(t(X)[,Facet[-1]]+X[Facet[1],])
          b_base<-0.5*rowSums((A_base)*buchong)
          z_s1<-z-X[Facet[1],]
          direction<-z_s1-(t(A_base)%*%solve(A_base%*%t(A_base))%*%A_base%*%z_s1)[,1]
          
          candidate_index<-setdiff(1:n,Facet)
          direction_all<-(t(t(X)[,candidate_index])%*%direction)[,1]-sum(X[Facet[1],]*direction)
          candidate_index<-candidate_index[which(direction_all>0)]
          if(length(candidate_index)>0)
          {
            while(length(candidate_index)>0)
            {
              index<-candidate_index[1]
              
              A<-rbind(A_base,X[index,]-X[Facet[1],])
              b<-c(b_base,0.5*sum((X[index,]^2-X[Facet[1],]^2)))
              
              X_star<-(solve(A)%*%b)[,1]
              r<-sum((X_star-X[index,])^2)
              r_all<-rowSums((t(t(X)[,candidate_index]-X_star))^2)
              
              candidate_index<-candidate_index[which(r_all<r)] 
            }
            
            Simplex_set<-rbind(Simplex_set,c(Facet,index))
          }
          
        }
      }
      
    }
    if(conditions==1)
    {
      return(list(Simplex=S_current,Weights=Weighting))
    }
    else
    {
      all_min<-rep(0,nrow(Weight_set))
      
      for(j in 1:(d+1))
      {
        all_min<-all_min+sqrt(colSums((t(X[Simplex_set[,j],])-z)^2))
      }
      closest<-which.max(all_min)
      return(list(Simplex=Simplex_set[closest,],Weights=Weight_set[closest,]))
    }
  }
}

# Determine a set of point whether in convex hull 
# If in, use function Find_simplex of compute S(z)
# If not in, compute S(z) as the closet 
Detect_In_out<-function(X,X_test)
{
  library(geometry)
  n<-nrow(X)
  d<-ncol(X)
  n_test<-nrow(X_test)
  d_test<-ncol(X_test)
  if(((d_test!=d)+(n<=d))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    mean_X<-colMeans(X)
    Stand_X<-t(t(X)-mean_X)
    Stand_X_test<-t(t(X_test)-mean_X)
    Cross_Product<-Stand_X%*%t(Stand_X_test)
    Rank_col<-t(apply(Cross_Product,2,order,decreasing=T)[1:d,])
    In_or_out<-rep(1,n_test)
    close_simplex<-matrix(NA,nrow = n_test,ncol = d+1)
    Weight_set<-matrix(0,nrow = n_test,ncol = d+1)
    
    for(i in 1:n_test)
    {
      WW<-solve(t(Stand_X[Rank_col[i,],]),Stand_X_test[i,])
      totalWW<-sum(WW)
      if(totalWW>1)
      {
        In_or_out[i]<-0
        Facet<-Rank_col[i,]
        A_base<-t(t(X)[,Facet[-1]]-X[Facet[1],])
        buchong<-t(t(X)[,Facet[-1]]+X[Facet[1],])
        b_base<-0.5*rowSums((A_base)*buchong)
        candidate_index<-setdiff(1:n,Facet)
        
        while(length(candidate_index)>0)
        {
          index<-candidate_index[1]
          
          A<-rbind(A_base,X[index,]-X[Facet[1],])
          b<-c(b_base,0.5*sum((X[index,]^2-X[Facet[1],]^2)))
          
          X_star<-(solve(A)%*%b)[,1]
          r<-sum((X_star-X[index,])^2)
          r_all<-rowSums((t(t(X)[,candidate_index]-X_star))^2)
          
          candidate_index<-candidate_index[which(r_all<r)] 
        }
        
        close_simplex[i,]<-c(Facet,index)
        X_disting<-X[c(Facet,index),]
        disting<--2*X_disting%*%X_test[i,]+rowSums(X_disting^2)
        Weight_set[i,which.min(disting)]<-1
      }else
      {
        DT<-Find_simplex(X,X_test[i,])
        close_simplex[i,]<-DT$Simplex
        Weight_set[i,]<-DT$Weights
      }
      
    }
    return(list(In_or_out=In_or_out,close_simplex=close_simplex,Weights=Weight_set))
  }
}




# Generate the neighbor simplices of S(z)
# X: Input data points, z: Target point, layer: Maximal topological distance of simplices to S(z)
# Output: index of vertices of the neighbor simplices simplex contains z and their distance to S(z)
Crystallization<-function(X,seed_set,layer=0)
{
  n<-nrow(X)
  d<-ncol(X)
  if(((length(seed_set)!=(d+1))+(n<=d))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    S_current<-seed_set
    Simplex_set<-matrix(S_current,ncol=1)
    Final_set<-matrix(sort(S_current),ncol=1)
    layer_set<-rep(0,ncol(Simplex_set))
    Exploring<-0
    while(Exploring<ncol(Simplex_set))
    {
      Exploring<-Exploring+1
      S_current<-Simplex_set[,Exploring]
      if(layer_set[Exploring]==layer)
      {
        next
      }
      else
      {
        for(i in 1:(d+(layer_set[Exploring]==0)))
        {
          Facet<-S_current[-i]
          A_base<-t(t(X)[,Facet[-1]]-X[Facet[1],])
          buchong<-t(t(X)[,Facet[-1]]+X[Facet[1],])
          b_base<-0.5*rowSums((A_base)*buchong)
          p_s1<-X[S_current[i],]-X[Facet[1],]
          direction<-p_s1-(t(A_base)%*%solve(A_base%*%t(A_base))%*%A_base%*%p_s1)[,1]
          
          
          candidate_index<-setdiff(1:n,Facet)
          direction_all<-(t(t(X)[,candidate_index])%*%direction)[,1]-sum(X[Facet[1],]*direction)
          candidate_index<-candidate_index[which(direction_all<0)]
          if(length(candidate_index)>0)
          {
            while(length(candidate_index)>0)
            {
              index<-candidate_index[1]
              
              A<-rbind(A_base,X[index,]-X[Facet[1],])
              b<-c(b_base,0.5*sum((X[index,]^2-X[Facet[1],]^2)))
              
              X_star<-(solve(A)%*%b)[,1]
              r<-sum((X_star-X[index,])^2)
              r_all<-rowSums((t(t(X)[,candidate_index]-X_star))^2)
              
              candidate_index<-candidate_index[which(r_all<r)] 
            }
            
            Candidate_simplex<-c(Facet,index)
            sort_Candidate_simplex<-sort(Candidate_simplex)
            if(min(colSums(Final_set!=sort_Candidate_simplex))!=0)
            {
              Final_set<-cbind(Final_set,sort_Candidate_simplex)
              Simplex_set<-cbind(Simplex_set,Candidate_simplex)
              layer_set<-c(layer_set,layer_set[Exploring]+1)
            }
          }
        }
      }
    }
    return(list(Simplex=t(Final_set),Layer=layer_set))
    
  }
}

# Generate the neighbor simplices of S(z)
# X: Input data points, z: Target point, layer: Maximal topological distance of simplices to S(z)
# Output: index of vertices of the neighbor simplices simplex contains z and their distance to S(z)
Crystallization_volume<-function(X,seed_set,layer=0)
{
  n<-nrow(X)
  d<-ncol(X)
  if(((length(seed_set)!=(d+1))+(n<=d))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    S_current<-seed_set
    Simplex_set<-matrix(S_current,ncol=1)
    Final_set<-matrix(sort(S_current),ncol=1)
    layer_set<-0
    
    A<-t(t(X)[,S_current[-1]]-X[S_current[1],])
    buchong<-t(t(X)[,S_current[-1]]+X[S_current[1],])
    b<-0.5*rowSums((A)*buchong)
    X_star<-(solve(A)%*%b)[,1]
    r<-sum((X_star-X[S_current[1],])^2)
    
    basic_proport<-(r^(d/2))/abs(det(cbind(X[S_current,],1)))
    volume_set<-1
    Exploring<-0
    while(Exploring<ncol(Simplex_set))
    {
      Exploring<-Exploring+1
      S_current<-Simplex_set[,Exploring]
      if(layer_set[Exploring]==layer)
      {
        next
      }
      else
      {
        for(i in 1:(d+(layer_set[Exploring]==0)))
        {
          Facet<-S_current[-i]
          A_base<-t(t(X)[,Facet[-1]]-X[Facet[1],])
          buchong<-t(t(X)[,Facet[-1]]+X[Facet[1],])
          b_base<-0.5*rowSums((A_base)*buchong)
          p_s1<-X[S_current[i],]-X[Facet[1],]
          direction<-p_s1-(t(A_base)%*%solve(A_base%*%t(A_base))%*%A_base%*%p_s1)[,1]
          
          
          candidate_index<-setdiff(1:n,Facet)
          direction_all<-(t(t(X)[,candidate_index])%*%direction)[,1]-sum(X[Facet[1],]*direction)
          candidate_index<-candidate_index[which(direction_all<0)]
          if(length(candidate_index)>0)
          {
            while(length(candidate_index)>0)
            {
              index<-candidate_index[1]
              
              A<-rbind(A_base,X[index,]-X[Facet[1],])
              b<-c(b_base,0.5*sum((X[index,]^2-X[Facet[1],]^2)))
              
              X_star<-(solve(A)%*%b)[,1]
              r<-sum((X_star-X[index,])^2)
              r_all<-rowSums((t(t(X)[,candidate_index]-X_star))^2)
              
              candidate_index<-candidate_index[which(r_all<r)] 
            }
            
            Candidate_simplex<-c(Facet,index)
            sort_Candidate_simplex<-sort(Candidate_simplex)
            if(min(colSums(Final_set!=sort_Candidate_simplex))!=0)
            {
              Final_set<-cbind(Final_set,sort_Candidate_simplex)
              Simplex_set<-cbind(Simplex_set,Candidate_simplex)
              layer_set<-c(layer_set,layer_set[Exploring]+1)
              volume_set<-c(volume_set,basic_proport*abs(det(cbind(X[sort_Candidate_simplex,],1)))/(r^(d/2)))
            }
          }
        }
      }
    }
    return(list(Simplex=t(Final_set),Layer=layer_set,Volume=volume_set))
    
  }
}