jii<-function(cishu)
{
  # Package
  library(mvtnorm)
  library(geometry)
  library(regpro)
  library(FNN)
  source("Function.R")
  
  # hyperparameter
  #set.seed(142)
  n<-2000
  
  Result<-NULL
  for(d in c(4,6,8,10))
  {
    for(i in 1:cishu)
    {
      X<-t(rmvnorm(n,mean = rep(0,d)))
      X<-t(X-rowMeans(X))
      XX<-t(X)%*%X
      eigen_XX<-eigen(XX)
      X<-X%*%eigen_XX$vectors
      X<-t(t(X)/sqrt(eigen_XX$values))
      #round(t(X)%*%X,3)
      
      z<-rep(0,d)
      DT_time<-system.time(DT<-Find_simplex(X,z))
      CT2_time<-system.time(CT2<-Crystallization_volume(X,DT$Simplex,layer = 2))
      CT3_time<-system.time(CT3<-Crystallization_volume(X,DT$Simplex,layer = 3))
      CT4_time<-system.time(CT4<-Crystallization_volume(X,DT$Simplex,layer = 4))      
      Ai<-d
      Ai<-c(Ai,nrow(CT2$Simplex),length(unique(as.vector(CT2$Simplex))),CT2_time[1:3])
      Ai<-c(Ai,nrow(CT3$Simplex),length(unique(as.vector(CT3$Simplex))),CT3_time[1:3])
      Ai<-c(Ai,nrow(CT4$Simplex),length(unique(as.vector(CT4$Simplex))),CT4_time[1:3])      
      Result<-rbind(Result,Ai)
    }
  }
  return(Result)
}

library(foreach)
library(doParallel)

cl <- makeCluster(10)
registerDoParallel(cl)

wosai<- foreach(cishu=rep(10,10),.combine='rbind') %dopar% jii(cishu)
stopCluster(cl)
write.csv(wosai,"N2000j.csv")