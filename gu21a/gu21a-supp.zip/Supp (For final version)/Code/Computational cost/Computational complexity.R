# Package
library(mvtnorm)
library(geometry)
library(regpro)
library(FNN)
source("Function.R")

# hyperparameter
#set.seed(142)
n<-2000
d<-10
X<-t(rmvnorm(n,mean = rep(0,d)))
X<-t(X-rowMeans(X))
XX<-t(X)%*%X
eigen_XX<-eigen(XX)
X<-X%*%eigen_XX$vectors
X<-t(t(X)/sqrt(eigen_XX$values))
#round(t(X)%*%X,3)

z<-rep(0,d)
DT_time<-system.time(DT<-Find_simplex(X,z))
CT2_time<-system.time(CT2<-Crystallization_volume(X,DT$Simplex,layer = 2))
CT3_time<-system.time(CT3<-Crystallization_volume(X,DT$Simplex,layer = 3))
CT4_time<-system.time(CT4<-Crystallization_volume(X,DT$Simplex,layer = 4))
CT5_time<-system.time(CT5<-Crystallization_volume(X,DT$Simplex,layer = 5))

nrow(CT4$Simplex)
length(unique(as.vector(CT4$Simplex)))
c(CT2_time[1:3],CT3_time[1:3],CT4_time[1:3],CT5_time[1:3])