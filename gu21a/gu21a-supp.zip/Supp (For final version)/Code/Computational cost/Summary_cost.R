ALL<-NULL
for(n in c(500,1000,2000))
{
  X<-NULL
for(i in letters[1:10])
{
  X<-rbind(X,read.csv(paste(c("N",as.character(n),i,".csv"),collapse = ""),header = T)[,-1])
}
Y<-NULL
for(j in c(4,6,8,10))
{
  Y<-rbind(Y,colMeans(X[X[,1]==j,]))
}
Y<-Y[,c(1,2,3,4,7,8,9,12,13,14)]
Y<-t(Y)
rownames(Y)<-c("d",rep(c("Simplex","Vertices","Time"),3))
write.table(round(Y,3),paste(c("N",as.character(n),".txt"),collapse = ""),sep="&")
ALL<-cbind(ALL,round(Y,3))
}

write.table(ALL[c(1,4,7,10),],"time.txt",sep="&")
