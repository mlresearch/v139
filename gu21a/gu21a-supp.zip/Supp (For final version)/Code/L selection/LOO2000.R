Parallel_N<-function(cishu)
{
  # Package
  library(mvtnorm)
  library(geometry)
  library(regpro)
  library(FNN)
  library(abind)
  source("Function.R")
  
  # hyperparameter
  #set.seed(1425)
  n<-2000
  n_test<-10
  d<-5
  K<-2
  rho<-0
  SS<-diag(1-rho,d)+rho
  
  Result<-NULL
  
  for(iter in 1:cishu)
  {
    X_original<-(rmvnorm(n,sigma = SS))
    #X<-cbind(r_original*cos(theta_original),r_original*sin(theta_original))
    X_test_original<-NULL
    for(i in 1:n_test)
    {
      X_index<-sample(1:n,d+1)
      X_bili<-rexp(d+1)
      X_bili<-X_bili/sum(X_bili)
      X_test_original<-rbind(X_test_original,colSums(X_original[X_index,]*X_bili))
    }
    X_original<-t(X_original)
    X_test_original<-t(X_test_original)
    
    beta<-rnorm(d)
    
    b<-matrix(rnorm(K*d),nrow=K)
    mu<-matrix(rnorm(K*d),nrow=K)
    sigma<-sqrt(matrix(rexp(K*d),nrow=K))
    
    KX<-0*X_original
    KX_test<-0*X_test_original
    for(i in 1:K)
    {
      KX<-KX+dnorm(X_original,mu[i,],sigma[i,])*b[i,]
      KX_test<-KX_test+dnorm(X_test_original,mu[i,],sigma[i,])*b[i,]
    }
    KX<-t(KX)
    KX_test<-t(KX_test)
    X_original<-t(X_original)
    X_test_original<-t(X_test_original)
    Y<-KX%*%beta+rnorm(n)/4
    Y_test<-KX_test%*%beta#+rnorm(n_test)
    
    #X<-X+0.3*rmvnorm(n,sigma = SS)
    #X_test<-X_test+0.3*rmvnorm(n_test,sigma = SS)
    
    mean_X<-colMeans(X_original)
    X_original<-t(t(X_original)-mean_X)
    X_test_original<-t(t(X_test_original)-mean_X)
    XX<-eigen(t(X_original)%*%X_original/n)
    X<-X_original%*%XX$vectors%*%diag(1/sqrt(XX$values))
    X_test<-X_test_original%*%XX$vectors%*%diag(1/sqrt(XX$values))
    
    L_candidate<-c(1:8)
    MSE_all<-NULL
    
    for(hei in 1:nrow(X_test))  
    {
      z<-X_test[hei,]
      
      DT0<-Find_simplex(X,z)
      
      
      MSE<-NULL
      
      for(i in DT0$Simplex)
      {
        #i<-DT0$Simplex[1]
        zi<-X[i,]
        Xi<-X[-i,]
        yi<-Y[i]
        Yi<-Y[-i]
        DTi<-Find_simplex(Xi,zi)
        CTi<-Crystallization_volume(Xi,DTi$Simplex,layer = max(L_candidate))
        
        MSEi<-NULL
        for(l in L_candidate)
        {
          m<-length(CTi$Layer[CTi$Layer<=l])
          relevant_index<-sort(unique(as.vector(CTi$Simplex[CTi$Layer<=l,])))
          new_Xi<-Xi[relevant_index,]
          new_Yi<-Yi[relevant_index]
          new_Xi<-t(t(new_Xi)-zi)
          
          new_W1<-NULL
          
          for(j in relevant_index)
          {
            new_W1<-c(new_W1,sum(CTi$Simplex[CTi$Layer<=l,]==j))
          }
          distancing<-colSums((t(new_Xi))^2)
          new_W2<-new_W1*exp(-distancing/mean(distancing))
          
          wlm.model<-lm(new_Yi~new_Xi,weights = new_W2)
          ss<-summary(wlm.model)
          #ss$coefficients[1,2]
          Y_wlm<-ss$coefficients[1,1]
          
          MSEi<-c(MSEi,(yi-Y_wlm)^2)
          #print(c(i,l))
        }
        MSE<-rbind(MSE,MSEi)
      }
      MSE_all<-rbind(MSE_all,colMeans(log(MSE)*(DT0$Weights)))
    }
    
    
    MSE_final<-NULL
    for(hei in 1:nrow(X_test))  
    {
      
      z<-X_test[hei,]
      
      
      DT<-Find_simplex(X,z)
      CT<-Crystallization_volume(X,DT$Simplex,layer = max(L_candidate))
      
      MSEi<-NULL
      for(l in L_candidate)
      {
        m<-length(CT$Layer[CT$Layer<=l])
        relevant_index<-sort(unique(as.vector(CT$Simplex[CT$Layer<=l,])))
        new_X<-X[relevant_index,]
        new_Y<-Y[relevant_index]
        new_X<-t(t(new_X)-z)
        
        new_W1<-NULL
        
        for(j in relevant_index)
        {
          new_W1<-c(new_W1,sum(CT$Simplex[CT$Layer<=l,]==j))
        }
        distancing<-colSums((t(new_X))^2)
        new_W2<-new_W1*exp(-distancing/mean(distancing))
        
        wlm.model<-lm(new_Y~new_X,weights = new_W2)
        ss<-summary(wlm.model)
        #ss$coefficients[1,2]
        Y_wlm<-ss$coefficients[1,1]
        
        MSEi<-c(MSEi,(Y_test[hei]-Y_wlm)^2)
        #print(c(i,l))
      }
      
      MSE_final<-rbind(MSE_final,MSEi)
    }
    
    hoi<-apply(MSE_all,1,which.min)
    MSE_select<-vector()
    for(i in 1:nrow(X_test))
    {MSE_select[i]<-MSE_final[i,hoi[i]]}
    MSE_final<-cbind(MSE_final,MSE_select)
    Result<-rbind(Result,MSE_final)
  }
  return(Result)
}

library(foreach)
library(doParallel)

cl <- makeCluster(20)
registerDoParallel(cl)
# Five cores, 200 replications per core
wosai<- foreach(cishu=rep(5,20),.combine='rbind') %dopar% Parallel_N(cishu)
stopCluster(cl)
write.csv(wosai,"LOO2000.csv")