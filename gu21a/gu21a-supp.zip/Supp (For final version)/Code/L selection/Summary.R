Result<-read.csv("LOO200.csv",header = T)[,-1]
YY<-log(Result)-rowMeans(log(Result[,1:8]))
apply(YY,2,mean)
apply(YY,2,sd)/10
png("L200.png",480,480)
par(mfrow=c(1,1),mar=c(5.1, 5.1, 2.1, 2.1))
plot(1:8,apply(YY,2,mean)[1:8],type="p",pch=18,cex=2,xlab = "",ylab = "",yaxt="n",xaxt="n")
mtext(expression(log(MSE[L])-bar(log(MSE))),side = 2,line = 3,cex = 1.5)
mtext("L",side = 1,line = 2,cex = 1.5)
for(i in 1:7)
{segments(i,mean(YY[,i]),i+1,mean(YY[,i+1]),lty=3,lwd = 2)}
abline(h=mean(YY[,9]),col=2,lwd=2)
axis(1, cex.axis=1.5)
axis(2, cex.axis=1.5)
legend("topleft",expression(log(MSE[widetilde(L)])-bar(log(MSE))),col=2,lwd=2,cex=1.5)
dev.off()

Result1<-read.csv("LOO500.csv",header = T)[,-1]
YY1<-log(Result1)-rowMeans(log(Result1[,1:8]))
apply(YY1,2,mean)
apply(YY1,2,sd)/10
png("L500.png",480,480)
par(mfrow=c(1,1),mar=c(5.1, 5.1, 2.1, 2.1))
plot(1:8,apply(YY1,2,mean)[1:8],type="p",pch=18,cex=2,xlab = "",ylab = "",yaxt="n",xaxt="n")
mtext(expression(log(MSE[L])-bar(log(MSE))),side = 2,line = 3,cex = 1.5)
mtext("L",side = 1,line = 2,cex = 1.5)
for(i in 1:7)
{segments(i,mean(YY1[,i]),i+1,mean(YY1[,i+1]),lty=3,lwd = 2)}
abline(h=mean(YY1[,9]),col=2,lwd=2)
axis(1, cex.axis=1.5)
axis(2, cex.axis=1.5)
legend("topleft",expression(log(MSE[widetilde(L)])-bar(log(MSE))),col=2,lwd=2,cex=1.5)
dev.off()

Result2<-read.csv("LOO1000.csv",header = T)[,-1]
YY2<-log(Result2)-rowMeans(log(Result2[,1:8]))
apply(YY2,2,mean)
apply(YY2,2,sd)/10
png("L1000.png",480,480)
par(mfrow=c(1,1),mar=c(5.1, 5.1, 2.1, 2.1))
plot(1:8,apply(YY2,2,mean)[1:8],type="p",pch=18,cex=2,xlab = "",ylab = "",yaxt="n",xaxt="n")
mtext(expression(log(MSE[L])-bar(log(MSE))),side = 2,line = 3,cex = 1.5)
mtext("L",side = 1,line = 2,cex = 1.5)
for(i in 1:7)
{segments(i,mean(YY2[,i]),i+1,mean(YY2[,i+1]),lty=3,lwd = 2)}
abline(h=mean(YY2[,9]),col=2,lwd=2)
axis(1, cex.axis=1.5)
axis(2, cex.axis=1.5)
legend("topleft",expression(log(MSE[widetilde(L)])-bar(log(MSE))),col=2,lwd=2,cex=1.5)
dev.off()

Result3<-read.csv("LOO2000.csv",header = T)[,-1]
YY3<-log(Result3)-rowMeans(log(Result3[,1:8]))
apply(YY3,2,mean)
apply(YY3,2,sd)/10
png("L2000.png",480,480)
par(mfrow=c(1,1),mar=c(5.1, 5.1, 2.1, 2.1))
plot(1:8,apply(YY3,2,mean)[1:8],type="p",pch=18,cex=2,xlab = "",ylab = "",yaxt="n",xaxt="n")
mtext(expression(log(MSE[L])-bar(log(MSE))),side = 2,line = 3,cex = 1.5)
mtext("L",side = 1,line = 2,cex = 1.5)
for(i in 1:7)
{segments(i,mean(YY3[,i]),i+1,mean(YY3[,i+1]),lty=3,lwd = 2)}
abline(h=mean(YY3[,9]),col=2,lwd=2)
axis(1, cex.axis=1.5)
axis(2, cex.axis=1.5)
legend("topright",expression(log(MSE[widetilde(L)])-bar(log(MSE))),col=2,lwd=2,cex=1.5)
dev.off()
