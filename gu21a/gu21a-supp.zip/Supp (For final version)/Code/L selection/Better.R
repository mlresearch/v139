# Package
library(mvtnorm)
library(geometry)
library(regpro)
library(FNN)
library(abind)
source("Function.R")

# hyperparameter
#set.seed(145)
d<-5
r<-sqrt(2*d)
n<-500
n_test<-10
#d<-2
rho<-0
SS<-diag(1-rho,d)+rho

Result<-NULL

for(iter in 1:20)
{gg<-Sys.time()
r_original<-(runif(n)*r^d)^(1/d)
X_original<-rmvnorm(n,rep(0,d))
X<-X_original/sqrt(rowSums(X_original^2))*r_original
#X<-cbind(r_original*cos(theta_original),r_original*sin(theta_original))
X_test<-NULL
for(i in 1:n_test)
{
  X_index<-sample(1:n,d+1)
  X_bili<-rexp(d+1)
  X_bili<-X_bili/sum(X_bili)
  X_test<-rbind(X_test,colSums(X[X_index,]*X_bili))
}


#beta<-c(-1,1)/2

#Y<-rowSums(X^3)+rnorm(n)/2
#+rnorm(n_test)
Y<-sin(rowSums(X^2)*pi/2)+rnorm(n)/4
#X<-X+0.3*rmvnorm(n,sigma = SS)
#X_test<-X_test+0.3*rmvnorm(n_test,sigma = SS)
#Y<-rowSums(X^2)+rnorm(n)/4

#plot(X,pch=20,xlim = c(-r,r),ylim = c(-r,r))
# Y_wm<-0*Y_test
# #Y_cl<-0*Y_test
# Y_wlm<-0*Y_test
# Y_loc1<-0*Y_test
# Y_loc2<-0*Y_test
# #InOut<-0*Y_test

#X_test<-cbind(rep(c(-1:1),3),rep(c(-1:1),each=3))
#points(X_test,col=2,pch=19)
#Y_test<-rowSums(X_test^3)
Y_test<-sin(rowSums(X_test^2)*pi/2)
#Y_test<-rowSums(X_test^2)#+rnorm(n)/4

L_candidate<-c(1:4)
MSE_all<-NULL

for(hei in 1:nrow(X_test))  
{
  z<-X_test[hei,]
  
  DT0<-Find_simplex(X,z)
  
  
  MSE<-NULL
  
  for(i in DT0$Simplex)
  {
    #i<-DT0$Simplex[1]
    zi<-X[i,]
    Xi<-X[-i,]
    yi<-Y[i]
    Yi<-Y[-i]
    DTi<-Find_simplex(Xi,zi)
    CTi<-Crystallization_volume(Xi,DTi$Simplex,layer = max(L_candidate))
    
    MSEi<-NULL
    for(l in L_candidate)
    {
      m<-length(CTi$Layer[CTi$Layer<=l])
      relevant_index<-sort(unique(as.vector(CTi$Simplex[CTi$Layer<=l,])))
      new_Xi<-Xi[relevant_index,]
      new_Yi<-Yi[relevant_index]
      new_Xi<-t(t(new_Xi)-zi)
      
      new_W1<-NULL
      
      for(j in relevant_index)
      {
        new_W1<-c(new_W1,sum(CTi$Simplex[CTi$Layer<=l,]==j))
      }
      distancing<-colSums((t(new_Xi))^2)
      new_W2<-new_W1*exp(-distancing/mean(distancing))
      
      wlm.model<-lm(new_Yi~new_Xi,weights = new_W2)
      ss<-summary(wlm.model)
      #ss$coefficients[1,2]
      Y_wlm<-ss$coefficients[1,1]
      
      MSEi<-c(MSEi,(yi-Y_wlm)^2)
      #print(c(i,l))
    }
    MSE<-rbind(MSE,MSEi)
  }
  MSE_all<-rbind(MSE_all,colMeans(log(MSE)*(DT0$Weights)))
}


MSE_final<-NULL
for(hei in 1:nrow(X_test))  
{
  
  z<-X_test[hei,]
  
  
  DT<-Find_simplex(X,z)
  CT<-Crystallization_volume(X,DT$Simplex,layer = max(L_candidate))
  
  MSEi<-NULL
  for(l in L_candidate)
  {
    m<-length(CT$Layer[CT$Layer<=l])
    relevant_index<-sort(unique(as.vector(CT$Simplex[CT$Layer<=l,])))
    new_X<-X[relevant_index,]
    new_Y<-Y[relevant_index]
    new_X<-t(t(new_X)-z)
    
    new_W1<-NULL
    
    for(j in relevant_index)
    {
      new_W1<-c(new_W1,sum(CT$Simplex[CT$Layer<=l,]==j))
    }
    distancing<-colSums((t(new_X))^2)
    new_W2<-new_W1*exp(-distancing/mean(distancing))
    
    wlm.model<-lm(new_Y~new_X,weights = new_W2)
    ss<-summary(wlm.model)
    #ss$coefficients[1,2]
    Y_wlm<-ss$coefficients[1,1]
    
    MSEi<-c(MSEi,(Y_test[hei]-Y_wlm)^2)
    #print(c(i,l))
  }
  
  MSE_final<-rbind(MSE_final,MSEi)
}

hoi<-apply(MSE_all,1,which.min)
MSE_select<-vector()
for(i in 1:nrow(X_test))
{MSE_select[i]<-MSE_final[i,hoi[i]]}
MSE_final<-cbind(MSE_final,MSE_select)
Result<-rbind(Result,MSE_final)
print(iter)
print(Sys.time()-gg)
}

mean((Result[,-5]-Result[,5])<0)
mean(apply(Result[,-5],1,min)-Result[,5])
mean(Result[,5])
apply(log(Result),2,mean)
mean(log(apply(Result[,-5],1,min)))
