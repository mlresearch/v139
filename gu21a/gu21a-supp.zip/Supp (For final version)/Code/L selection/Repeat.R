# Package
library(mvtnorm)
library(geometry)
library(regpro)
library(FNN)
source("Function.R")

# hyperparameter
#set.seed(14542)
n<-4000
n_test<-1
d<-5
K<-3
rho<-0
SS<-diag(1-rho,d)+rho

Result0<-NULL
Result0A<-NULL
Result0B<-NULL
Result0C<-NULL
Result1<-NULL

iter<-0

while(iter<100)
{  # Data generation
  X_original<-t(rmvnorm(n,sigma = SS))
  X_test_original<-rowMeans(X_original)
  #for(i in 1:n_test)
  #{
  #  X_bili<-rexp(n)
  #  X_bili<-X_bili/sum(X_bili)
  #  X_test_original<-cbind(X_test_original,X_original%*%X_bili)
  #}
  #X<-matrix(rexp(n*d)*(2*rbinom(n*d,1,0.5)-1),nrow = d)
  #X_test<-matrix(rexp(n_test*d)*(2*rbinom(n_test*d,1,0.5)-1),nrow = d)
  beta<-rnorm(d)
  
  b<-matrix(rnorm(K*d),nrow=K)
  mu<-matrix(rnorm(K*d),nrow=K)/5
  sigma<-sqrt(matrix(rexp(K*d),nrow=K))
  
  KX<-0*X_original
  KX_test<-0*X_test_original
  for(i in 1:K)
  {
    KX<-KX+dnorm(X_original,mu[i,],sigma[i,])*b[i,]
    KX_test<-KX_test+dnorm(X_test_original,mu[i,],sigma[i,])*b[i,]
  }
  KX<-t(KX)
  KX_test<-t(KX_test)
  X_original<-t(X_original)
  X_test_original<-t(X_test_original)
  Y<-KX%*%beta+rnorm(n)/3
  Y_test<-KX_test%*%beta#+rnorm(n_test)
  
  #X<-X+0.3*rmvnorm(n,sigma = SS)
  #X_test<-X_test+0.3*rmvnorm(n_test,sigma = SS)
  
  mean_X<-colMeans(X_original)
  X_original<-t(t(X_original)-mean_X)
  X_test_original<-t(t(X_test_original)-mean_X)
  XX<-eigen(t(X_original)%*%X_original/n)
  X<-X_original%*%XX$vectors%*%diag(1/sqrt(XX$values))
  X_test<-X_test_original%*%XX$vectors%*%diag(1/sqrt(XX$values))
  X<-round(X,3)
  X_test<-round(X_test,3)
  
  # Y_wm<-0*Y_test
  # #Y_cl<-0*Y_test
  # Y_wlm<-0*Y_test
  # Y_loc1<-0*Y_test
  # Y_loc2<-0*Y_test
  # #InOut<-0*Y_test
  
  
  
  z<-X_test[1,]
  
  DT0<-Find_simplex(X,z)
  
  
  L_candidate<-c(0,1,2,3,4)
  
  MSE<-NULL
  
  for(i in DT0$Simplex)
  {
    #i<-DT0$Simplex[1]
    zi<-X[i,]
    Xi<-X[-i,]
    yi<-Y[i]
    Yi<-Y[-i]
    DTi<-Find_simplex(Xi,zi)
    CTi<-Crystallization_volume(Xi,DTi$Simplex,layer = 4)
    
    MSEi<-NULL
    for(l in L_candidate)
    {
      m<-length(CTi$Layer[CTi$Layer<=l])
      relevant_index<-sort(unique(as.vector(CTi$Simplex[CTi$Layer<=l,])))
      new_Xi<-Xi[relevant_index,]
      new_Yi<-Yi[relevant_index]
      
      new_W1<-NULL
      
      for(j in relevant_index)
      {
        new_W1<-c(new_W1,sum(CTi$Simplex[CTi$Layer<=l,]==j))
      }
      distancing<-colSums((t(new_Xi)-zi)^2)
      new_W2<-new_W1*exp(-distancing/mean(distancing))
      
      wlm.model<-lm(new_Yi~new_Xi,weights = new_W2)
      Y_wlm<-sum(c(1,zi)*wlm.model$coefficients)
      
      MSEi<-c(MSEi,(yi-Y_wlm)^2)
      
    }
    MSE<-rbind(MSE,MSEi)
  }
  Result0<-rbind(Result0,colMeans(MSE))
  Result0A<-rbind(Result0A,colMeans(MSE*DT0$Weights))
  Result0B<-rbind(Result0B,colMeans(log(MSE)))
  Result0C<-rbind(Result0C,colMeans(log(MSE)*DT0$Weights))
  
  #########################################################
  DT<-Find_simplex(X,z)
  CT<-Crystallization_volume(X,DT$Simplex,layer = 4)
  
  MSE<-NULL
  for(l in L_candidate)
  {
    m<-length(CT$Layer[CT$Layer<=l])
    relevant_index<-sort(unique(as.vector(CT$Simplex[CT$Layer<=l,])))
    new_X<-X[relevant_index,]
    new_Y<-Y[relevant_index]
    
    new_W1<-NULL
    
    for(j in relevant_index)
    {
      new_W1<-c(new_W1,sum(CT$Simplex[CT$Layer<=l,]==j))
    }
    distancing<-colSums((t(new_X)-z)^2)
    new_W2<-new_W1*exp(-distancing/mean(distancing))
    
    wlm.model<-lm(new_Y~new_X,weights = new_W2)
    Y_wlm<-sum(c(1,z)*wlm.model$coefficients)
    
    MSE<-c(MSE,(Y_test-Y_wlm)^2)
    
  }
  Result1<-rbind(Result1,MSE)
  iter<-iter+1
  print(iter)
}  

colMeans(abs(cbind(
apply(Result0,1,which.min)-apply(Result1,1,which.min),
apply(Result0A,1,which.min)-apply(Result1,1,which.min),
apply(Result0B,1,which.min)-apply(Result1,1,which.min),
apply(Result0C,1,which.min)-apply(Result1,1,which.min)))==1)

mean(apply(Result0[,-length(L_candidate)],1,which.min)==apply(Result1[,-1],1,which.min))
mean(apply(Result0A[,-length(L_candidate)],1,which.min)==apply(Result1[,-1],1,which.min))
mean(apply(Result0B[,-length(L_candidate)],1,which.min)==apply(Result1[,-1],1,which.min))
mean(apply(Result0C[,-length(L_candidate)],1,which.min)==apply(Result1[,-1],1,which.min))

