# Generate seed simplex
# X: Input data points, z: Target point
# Output: index of vertices of the seed simplex close to z
Seed_simplex<-function(X,z) 
{
  # Data dimension
  n<-nrow(X)
  d<-ncol(X)
  if(((length(z)!=d)+(n<=d))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    All_index<-1:n
  # Find the closest point: s1
  Dist_all<-colSums((t(X[All_index,])-z)^2)
  vertices<-which.min(Dist_all)
  All_index<-setdiff(All_index,vertices)
  
  # Find the closet point to s1: s2
  Dist_all<-colSums((t(X[All_index,])-X[vertices,])^2)
  vertices<-c(vertices,All_index[which.min(Dist_all)])
  All_index<-setdiff(All_index,vertices)
  
  A_base<-matrix(X[vertices[2],]-X[vertices[1],],nrow = 1)
  b_base<-0.5*sum((X[vertices[2],]-X[vertices[1],])^2)
  
  
  for(j in 2:d)
  {
    r_min<-Inf
    index<-NULL
    
    for(i in All_index)
    {
      A<-rbind(A_base,X[i,]-X[vertices[1],])
      b<-c(b_base,0.5*sum((X[i,]-X[vertices[1],])^2))
    
      X_star<-t(A)%*%solve(A%*%t(A))%*%b
      if(sum(X_star^2)<r_min)
      {
        r_min<-sum(X_star^2)
        index<-i
      }
    }
    vertices<-c(vertices,index)
    All_index<-setdiff(All_index,index)
    A_base<-rbind(A_base,X[index,]-X[vertices[1],])
    b_base<-c(b_base,0.5*sum((X[index,]-X[vertices[1],])^2))
  }
  return(vertices)
  }
}

# Generate the simplex contains z
# X: Input data points, z: Target point
# Output: index of vertices of the simplex contains z and the weights of these vertices
Find_simplex<-function(X,z)
{
  n<-nrow(X)
  d<-ncol(X)
  if(((length(z)!=d)+(n<=d))!=0)
  {
    print("Invalid input.")
  }
  else
  {
  Simplex_set<-matrix(Seed_simplex(X,z),ncol=d+1)
  Weight_set<-NULL
  Exploring<-0
  conditions<-0
  
  while(Exploring<nrow(Simplex_set))
  {
    Exploring<-Exploring+1
    S_current<-Simplex_set[Exploring,]
    Weighting<-solve((t(X[S_current[-1],])-X[S_current[1],]),z-X[S_current[1],])
    Weighting<-c(1-sum(Weighting),Weighting)
    if(prod(Weighting>0)==1)
    {
      conditions<-1
      break
    }
    else
    {
      Weight_set<-rbind(Weight_set,Weighting)
      cut_index<-which(Weighting<0)
      for(i in cut_index)
      {
        Facet<-S_current[-i]
        A_base<-t(t(X)[,Facet[-1]]-X[Facet[1],])
        buchong<-t(t(X)[,Facet[-1]]+X[Facet[1],])
        b_base<-0.5*rowSums((A_base)*buchong)
        z_s1<-z-X[Facet[1],]
        direction<-z_s1-(t(A_base)%*%solve(A_base%*%t(A_base))%*%A_base%*%z_s1)[,1]
        
        candidate_index<-setdiff(1:n,Facet)
        direction_all<-(t(t(X)[,candidate_index])%*%direction)[,1]-sum(X[Facet[1],]*direction)
        candidate_index<-candidate_index[which(direction_all>0)]
        if(length(candidate_index)>0)
        {
          while(length(candidate_index)>0)
          {
            index<-candidate_index[1]
            
            A<-rbind(A_base,X[index,]-X[Facet[1],])
            b<-c(b_base,0.5*sum((X[index,]^2-X[Facet[1],]^2)))
            
            X_star<-(solve(A)%*%b)[,1]
            r<-sum((X_star-X[index,])^2)
            r_all<-rowSums((t(t(X)[,candidate_index]-X_star))^2)
            
            candidate_index<-candidate_index[which(r_all<r)] 
          }
        
          Simplex_set<-rbind(Simplex_set,c(Facet,index))
        }
        
      }
    }
    
  }
  if(conditions==1)
  {
    return(list(Simplex=S_current,Weights=Weighting))
  }
  else
  {
    all_min<-apply(Weight_set,1,min)
    closest<-which.max(all_min)
    return(list(Simplex=Simplex_set[closest,],Weights=Weight_set[closest,]))
  }
  }
}

# Generate the neighbor simplices of S(z)
# X: Input data points, z: Target point, layer: Maximal topological distance of simplices to S(z)
# Output: index of vertices of the neighbor simplices simplex contains z and their distance to S(z)
Crystallization<-function(X,z,layer=0)
{
  n<-nrow(X)
  d<-ncol(X)
  if(((length(z)!=d)+(n<=d))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    S_current<-Find_simplex(X,z)$Simplex
    Simplex_set<-matrix(S_current,ncol=1)
    Final_set<-matrix(sort(S_current),ncol=1)
    layer_set<-0
    Exploring<-0
    while(Exploring<ncol(Simplex_set))
    {
      Exploring<-Exploring+1
      S_current<-Simplex_set[,Exploring]
      if(layer_set[Exploring]==layer)
      {
        next
      }
      else
      {
        for(i in 1:(d+(layer_set[Exploring]==0)))
        {
          Facet<-S_current[-i]
          A_base<-t(t(X)[,Facet[-1]]-X[Facet[1],])
          buchong<-t(t(X)[,Facet[-1]]+X[Facet[1],])
          b_base<-0.5*rowSums((A_base)*buchong)
          p_s1<-X[S_current[i],]-X[Facet[1],]
          direction<-p_s1-(t(A_base)%*%solve(A_base%*%t(A_base))%*%A_base%*%p_s1)[,1]
          
          
          candidate_index<-setdiff(1:n,Facet)
          direction_all<-(t(t(X)[,candidate_index])%*%direction)[,1]-sum(X[Facet[1],]*direction)
          candidate_index<-candidate_index[which(direction_all<0)]
          if(length(candidate_index)>0)
          {
            while(length(candidate_index)>0)
            {
              index<-candidate_index[1]
              
              A<-rbind(A_base,X[index,]-X[Facet[1],])
              b<-c(b_base,0.5*sum((X[index,]^2-X[Facet[1],]^2)))
              
              X_star<-(solve(A)%*%b)[,1]
              r<-sum((X_star-X[index,])^2)
              r_all<-rowSums((t(t(X)[,candidate_index]-X_star))^2)
              
              candidate_index<-candidate_index[which(r_all<r)] 
            }
            
            Candidate_simplex<-c(Facet,index)
            sort_Candidate_simplex<-sort(Candidate_simplex)
            if(prod(colSums(Final_set!=sort_Candidate_simplex))!=0)
            {
              Final_set<-cbind(Final_set,sort_Candidate_simplex)
              Simplex_set<-cbind(Simplex_set,Candidate_simplex)
              layer_set<-c(layer_set,layer_set[Exploring]+1)
            }
          }
        }
      }
    }
    return(list(Simplex=t(Final_set),Layer=layer_set))
    
  }
}