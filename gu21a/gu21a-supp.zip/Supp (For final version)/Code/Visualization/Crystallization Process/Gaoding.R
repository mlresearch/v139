# Package
library(mvtnorm)
library(geometry)

# hyperparameter
n<-100
p<-10

# Data generation
X<-rmvnorm(n,mean = rep(0,p))

system.time(DT<-delaunayn(X))



All_square<-rowSums(X^2)
Radius<-vector()
Min_dist<-vector()

for(i in 1:nrow(DT))
{
  A_minus<-t(t(X[DT[i,-1],])-X[DT[i,1],])
  A_plus<-t(t(X[DT[i,-1],])+X[DT[i,1],])
  B<-rowSums(A_plus*A_minus)/2
  Center<-solve(A_minus,B)
  Radius[i]<-sqrt(sum((Center-X[DT[i,1],])^2))
  Min_dist[i]<-min(sqrt(sum(Center^2)+All_square-2*colSums(t(X)*Center)))
}
cbind(Radius,Min_dist)
#max(abs(Radius-Min_dist))
