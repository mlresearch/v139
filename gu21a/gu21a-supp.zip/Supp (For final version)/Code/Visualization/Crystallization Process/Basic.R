# Package
library(mvtnorm)
library(geometry)
source("Function.R")

# hyperparameter
n<-200
d<-2
p<-c(0,0)

# Data generation
#X<-rmvnorm(n,mean = rep(0,d))
set.seed(2685)
X<-matrix(runif(n*d,-1,1),nrow=n)
#X<-t(t(X)-colMeans(X))
TT<-Seed_simplex(X,p)
plot(X,pch=20,col=1,cex=0.5)
points(0,0,col=2,pch=20)
for(i in 1:d)
{
  for(j in (i+1):(d+1))
  {
    segments(X[TT[i],1],X[TT[i],2],X[TT[j],1],X[TT[j],2],col="green")
  }
}
DT<-Find_simplex(X,p)
for(i in 1:d)
{
  for(j in (i+1):(d+1))
  {
    segments(X[DT$Simplex[i],1],X[DT$Simplex[i],2],X[DT$Simplex[j],1],X[DT$Simplex[j],2],col="blue")
  }
}

DTT<-delaunayn(X)
DTT<-apply(DTT,1,sort)

#plot(X,pch=20,col=1,cex=0.5)
#points(0,0,col=2,pch=20)
#for(i in 1:d)
#{
#  for(j in (i+1):(d+1))
#  {
#    segments(X[CT$Simplex[1,i],1],X[CT$Simplex[1,i],2],X[CT$Simplex[1,j],1],X[CT$Simplex[1,j],2],col=CT$Layer[1]+2)
#  }
#}

#for(hehe in 2:length(CT$Layer))
#{
#  for(i in 1:d)
#  {
#      segments(X[CT$Simplex[hehe,i],1],X[CT$Simplex[hehe,i],2],X[CT$Simplex[hehe,d+1],1],X[CT$Simplex[hehe,d+1],2],col=CT$Layer[hehe]+2)
#  }
#}

CT<-Crystallization(X,p,layer=5)
all_check<-NULL
for(i in 1:length(CT$Layer))
{
  all_check<-c(all_check,prod(colSums(DTT!=CT$Simplex[i,]))==0)
}


coloring<-heat.colors(6,alpha=0.6)
for(l in 0:5)
{
  png(paste(c("Crystallization",as.character(n),"_",as.character(l),".png"),collapse = ""),height = 1000,width = 1000)
  par(mar=c(2,2,2,2))
  plot(X,pch=20,col=1,cex=2,xlim = range(X[unique(CT$Simplex),1]),ylim = range(X[unique(CT$Simplex),2]),xlab = "",ylab = "",main = paste(c("Topological distance=",as.character(l)),collapse = ""))
  for(hehe in 1:sum(CT$Layer<=l))
  {
    polygon(X[CT$Simplex[hehe,],1],X[CT$Simplex[hehe,],2],border = gray(0.25),col = coloring[CT$Layer[hehe]+1])
  }
  points(0,0,col="green",pch=20,cex=2)
  text(0,0,"Target point",col="green",cex=2,adj = c(1,0))
  dev.off()
}

png(paste(c("Crystallization",as.character(n),".png"),collapse = ""),height = 1000,width = 1500)
par(mar=c(3,3,3,3),mfrow=c(2,3))
for(l in 0:5)
{
  plot(X,pch=20,col=1,cex=2,xlim = range(X[unique(CT$Simplex),1]),ylim = range(X[unique(CT$Simplex),2]),xlab = "",ylab = "",main = paste(c("Topological distance=",as.character(l)),collapse = ""))
  for(hehe in 1:sum(CT$Layer<=l))
  {
    polygon(X[CT$Simplex[hehe,],1],X[CT$Simplex[hehe,],2],border = gray(0.25),col = coloring[CT$Layer[hehe]+1])
  }
  points(0,0,col="green",pch=20,cex=2)
  text(0,0,"Target point",col="green",cex=2,adj = c(1,0))
  
}
dev.off()
min(all_check)

####################### Normal
n<-200
set.seed(156)
X<-matrix(rnorm(n*d),nrow=n)
X<-t(t(X)-colMeans(X))
#X<-t(t(X)-colMeans(X))
TT<-Seed_simplex(X,p)
plot(X,pch=20,col=1,cex=0.5)
points(0,0,col=2,pch=20)
for(i in 1:d)
{
  for(j in (i+1):(d+1))
  {
    segments(X[TT[i],1],X[TT[i],2],X[TT[j],1],X[TT[j],2],col="green")
  }
}
DT<-Find_simplex(X,p)
for(i in 1:d)
{
  for(j in (i+1):(d+1))
  {
    segments(X[DT$Simplex[i],1],X[DT$Simplex[i],2],X[DT$Simplex[j],1],X[DT$Simplex[j],2],col="blue")
  }
}

DTT<-delaunayn(X)
DTT<-(apply(DTT,1,sort))


CT<-Crystallization(X,p,layer=5)
all_check<-NULL
for(i in 1:length(CT$Layer))
{
  all_check<-c(all_check,prod(colSums(DTT!=CT$Simplex[i,]))==0)
}


coloring<-heat.colors(6,alpha=0.6)
for(l in 0:5)
{
  png(paste(c("Crystallization_Normal",as.character(n),"_",as.character(l),".png"),collapse = ""),height = 1000,width = 1000)
  par(mar=c(2,2,2,2))
  plot(X,pch=20,col=1,cex=2,xlim = range(X[unique(CT$Simplex),1]),ylim = range(X[unique(CT$Simplex),2]),xlab = "",ylab = "",main = paste(c("Topological distance=",as.character(l)),collapse = ""))
  for(hehe in 1:sum(CT$Layer<=l))
  {
    polygon(X[CT$Simplex[hehe,],1],X[CT$Simplex[hehe,],2],border = gray(0.25),col = coloring[CT$Layer[hehe]+1])
  }
  points(0,0,col="blue",pch=18,cex=4)
  text(0,0,"Target point",col="blue",cex=4,adj = c(1.1,-0.1))
  dev.off()
}

png(paste(c("Crystallization_Normal",as.character(n),".png"),collapse = ""),height = 1000,width = 1500)
par(mar=c(1,1,1,1),mfrow=c(2,3))
for(l in 0:5)
{
  plot(X,pch=20,col=1,cex=2,xlim = range(X[unique(CT$Simplex),1]),ylim = range(X[unique(CT$Simplex),2]),xlab = "",ylab = "",main = "")
  for(hehe in 1:sum(CT$Layer<=l))
  {
    polygon(X[CT$Simplex[hehe,],1],X[CT$Simplex[hehe,],2],border = gray(0.25),col = coloring[CT$Layer[hehe]+1])
  }
  points(0,0,col="blue",pch=18,cex=4)
  text(0,0,"Target point",col="blue",cex=4,adj = c(1.1,-0.1))
  
}
dev.off()
min(all_check)
###########################################
library(plot3D)
library("plotrix")
library(rgl)
# hyperparameter
n<-100
d<-3
p<-c(0,0,0)

# Data generation
set.seed(56)
X<-rmvnorm(n,mean = rep(0,d))
X<-t(t(X)-colMeans(X))
CT<-Crystallization(X,p,layer=5)
plot3d(X[,1],X[,2],X[,3],pch=20,col=1,cex=3,xlab = "",ylab = "",zlab = "",xlim = range(X[unique(CT$Simplex),1]),ylim = range(X[unique(CT$Simplex),2]),zlim = range(X[unique(CT$Simplex),3]))
for(l in 0:5)
{
  for(hehe in which(CT$Layer==l))
{
  for(i in 1:(d+1))
  {
    rgl.triangles(X[CT$Simplex[hehe,-i],1],X[CT$Simplex[hehe,-i],2],X[CT$Simplex[hehe,-i],3],col="blue",alpha=0.4-CT$Layer[hehe]*0.4/6)
  }
}
  rgl.points(0,0,0,col=2,size=16,pch=18)
  rgl.texts(0,0,0,"Target point",col=2,cex=3,adj = c(1.1,-0.1))
  #snapshot3d( paste(c("Crystallization3D",as.character(l),".png"),collapse = ""), fmt = "png")
readline(prompt="Press [enter] to continue")
}
###########################################
# hyperparameter
n<-1000
d<-5
p<-c(0,0,0,0,0)
X<-rmvnorm(n,mean = rep(0,d))
X<-t(t(X)-colMeans(X))
CT<-Crystallization(X,p,layer=5)
length(CT$Layer)
