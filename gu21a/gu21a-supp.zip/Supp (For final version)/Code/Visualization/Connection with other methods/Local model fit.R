# Package
library(mvtnorm)
library(geometry)
library(regpro)
library(FNN)
library(plotrix)
source("Function.R")

# hyperparameter
#set.seed(142)
n<-100
d<-2
rho<-0
SS<-diag(1-rho,d)+rho
z<-c(0,1)

Result<-NULL

gg<-Sys.time()

set.seed(469)
# Data generation
X<-abs(rmvnorm(n,sigma = SS))
Signing<-2*matrix(rbinom(n*d,1,0.8),nrow=n)-1
X<-X*Signing
distancing<-colSums((t(X)-z)^2)
mean_X<-colMeans(X)
ordering<-order(distancing)
DT<-Find_simplex(X,z)
CT<-Crystallization(X,DT$Simplex,layer = 3)
index_in<-unique(as.vector(CT$Simplex))
max_dist2<-sqrt(max(distancing[index_in]))
fanwei<-1.05*max(c(sqrt(distancing[ordering[20]]),max_dist2))


png("KNN.png",350,1400)
par(mfrow=c(4,1),mar=c(2,2,2,2))
for(i in c(5,10,15,20))
{
  plot(X[-ordering[1:i],],type="p",pch=20,xlab = "",ylab = "",,lwd=3,main="",xlim = c(-fanwei,fanwei),ylim = 1+c(-fanwei,fanwei))
  abline(h=0,col="green",lty=5)
  abline(v=0,col="green",lty=5)
  z<-c(0,1)
  points(0,1,col="blue",pch=18,cex=3)
  points(X[ordering[1:i],],col=2,pch=17,cex=3)
  #points(mean(X[ordering[1:i],1]),mean(X[ordering[1:i],2]),col=2,pch=10,lwd=2)
  draw.circle(0,1,radius = sqrt(distancing[ordering[i]]),border = "blue",lty=2)
  legend("topleft",col=c("blue","red"),pch = c(18,17),cex=2,legend = c("Target point","Neighbor"))
}
dev.off()

png("DT.png",350,1400)
#DT<-Find_simplex(X,z)
#CT<-Crystallization(X,DT$Simplex,layer = 3)
par(mfrow=c(4,1),mar=c(2,2,2,2))
for(i in c(0,1,2,3))
{
  index_in<-unique(as.vector(CT$Simplex[CT$Layer<=i,]))
  plot(X[-index_in,],type="p",pch=20,xlab = "",ylab = "",,lwd=3,main="",xlim = c(-fanwei,fanwei),ylim = 1+c(-fanwei,fanwei))
  abline(h=0,col="green",lty=5)
  abline(v=0,col="green",lty=5)
  z<-c(0,1)
  points(0,1,col="blue",pch=18,cex=3)
  
  #points(mean(X[ordering[1:i],1]),mean(X[ordering[1:i],2]),col=2,pch=10,lwd=2)
  for(a in which(CT$Layer<=i))
  {polygon(X[CT$Simplex[a,],1],X[CT$Simplex[a,],2],border = gray(0.25),col = NA)}
  points(X[index_in,],col=2,pch=17,cex=3)
  legend("topleft",col=c("blue","red"),pch = c(18,17),cex=2,legend = c("Target point","Neighbor"))
}
dev.off()

#############################################################################

cummean_X_kNN<-apply(X[ordering,],2,cumsum)/(1:length(ordering))

DT<-Find_simplex(X,z)
CT<-Crystallization(X,DT$Simplex,layer = 5)
cummean_X_DT<-NULL
for(i in c(0:5))
{
  relevant_index<-sort(unique(as.vector(CT$Simplex[CT$Layer<=i,])))
  new_X<-X[relevant_index,]
  
  new_W1<-NULL
  
  for(j in relevant_index)
  {
    new_W1<-c(new_W1,sum(CT$Simplex[CT$Layer<=i,]==j))
  }
  distancing<-colSums((t(new_X)-z)^2)
  new_W2<-new_W1*exp(-distancing/mean(distancing))
  cummean_X_DT<-rbind(cummean_X_DT,apply(new_X,2,weighted.mean,w=new_W2))
}
cummean_X_loclin<-NULL
distancing<-colSums((t(X)-z)^2)
for(h in 2^c((-2):2/2))
{
  new_W2<-exp(-distancing/(2*h^2))
  cummean_X_loclin<-rbind(cummean_X_loclin,apply(X,2,weighted.mean,w=new_W2))
}

xrang<-1.1*range(c(cummean_X_kNN[1:20,1],cummean_X_DT[,1],cummean_X_loclin[,1],0,mean_X[1]))-0.1*mean(c(cummean_X_kNN[1:20,1],cummean_X_DT[,1],cummean_X_loclin[,1],0,mean_X[1]))
yrang<-1.1*range(c(cummean_X_kNN[1:20,2],cummean_X_DT[,2],cummean_X_loclin[,2],1,mean_X[1]))-0.1*mean(c(cummean_X_kNN[1:20,2],cummean_X_DT[,2],cummean_X_loclin[,2],1,mean_X[2]))

png("Paths.png",1000,1000)
par(mfrow=c(1,1),mar=c(2,2,2,2))
plot(0,0,type="n",pch=20,xlab = "",ylab = "",lwd=3,main="",xlim = xrang,ylim = yrang)
#abline(h=0,col="green",lty=5)
abline(v=0,col="green",lty=5)
z<-c(0,1)
points(0,1,col="blue",pch=18,cex=4)
points(mean_X[1],mean_X[2],col="black",pch=11,cex=4)
points(cummean_X_kNN[1:20,],col="purple",pch=17,cex=2)

  #points(X[ordering[1:i],],col=2,pch=17,lwd=3)
  #points(mean(X[ordering[1:i],1]),mean(X[ordering[1:i],2]),col=2,pch=10,lwd=2)
  #draw.circle(0,1,radius = sqrt(distancing[ordering[i]]),border = "blue",lty=2)
text(cummean_X_kNN[1,1],cummean_X_kNN[1,2],"k=1",col = "purple",adj = c(1.2,1.2),cex=2)
text(cummean_X_kNN[5,1],cummean_X_kNN[5,2],"k=5",col = "purple",adj = c(0.5,1.4),cex=2)
text(cummean_X_kNN[10,1],cummean_X_kNN[10,2],"k=10",col = "purple",adj = c(-0.5,0.5),cex=2)
text(cummean_X_kNN[15,1],cummean_X_kNN[15,2],"k=15",col = "purple",adj = c(1.2,0.3),cex=2)
text(cummean_X_kNN[20,1],cummean_X_kNN[20,2],"k=20",col = "purple",adj = c(0.3,1.2),cex=2)

for(i in c(2:20))
{
  #points(X[ordering[1:i],],col=2,pch=17,lwd=3)
  #points(mean(X[ordering[1:i],1]),mean(X[ordering[1:i],2]),col=2,pch=10,lwd=2)
  #draw.circle(0,1,radius = sqrt(distancing[ordering[i]]),border = "blue",lty=2)
  segments(cummean_X_kNN[i-1,1],cummean_X_kNN[i-1,2],cummean_X_kNN[i,1],cummean_X_kNN[i,2],lty = 2,col = "purple")
}
#dev.off()

points(cummean_X_DT,col="red",pch=15,cex=2)

  #points(X[ordering[1:i],],col=2,pch=17,lwd=3)
  #points(mean(X[ordering[1:i],1]),mean(X[ordering[1:i],2]),col=2,pch=10,lwd=2)
  #draw.circle(0,1,radius = sqrt(distancing[ordering[i]]),border = "blue",lty=2)
text(cummean_X_DT[0+1,1],cummean_X_DT[0+1,2],"L=0",col = "red",adj = c(1.4,0.4),cex=2)
text(cummean_X_DT[1+1,1],cummean_X_DT[1+1,2],"L=1",col = "red",adj = c(1.4,0.4),cex=2)
text(cummean_X_DT[5+1,1],cummean_X_DT[5+1,2],"L=5",col = "red",adj = c(-0.4,-0.4),cex=2)

for(i in c(1:5))
{
  #points(X[ordering[1:i],],col=2,pch=17,lwd=3)
  #points(mean(X[ordering[1:i],1]),mean(X[ordering[1:i],2]),col=2,pch=10,lwd=2)
  #draw.circle(0,1,radius = sqrt(distancing[ordering[i]]),border = "blue",lty=2)
  segments(cummean_X_DT[i,1],cummean_X_DT[i,2],cummean_X_DT[i+1,1],cummean_X_DT[i+1,2],lty = 2,col = "red")
}
#dev.off()

points(cummean_X_loclin[-1,],col="black",pch=18,cex=2)

  #points(X[ordering[1:i],],col=2,pch=17,lwd=3)
  #points(mean(X[ordering[1:i],1]),mean(X[ordering[1:i],2]),col=2,pch=10,lwd=2)
  #draw.circle(0,1,radius = sqrt(distancing[ordering[i]]),border = "blue",lty=2)
#text(cummean_X_loclin[1,1],cummean_X_loclin[1,2],expression(paste("log"[2],"(h)=-1",collapse = "")),col = "black",adj = c(1.1,1.1))
text(cummean_X_loclin[2,1],cummean_X_loclin[2,2],expression(paste("log"[2],"(h)=-0.5",collapse = "")),col = "black",adj = c(1.1,1.1),cex=2)
text(cummean_X_loclin[3,1],cummean_X_loclin[3,2],expression(paste("log"[2],"(h)=0",collapse = "")),col = "black",adj = c(1.1,1.1),cex=2)
text(cummean_X_loclin[4,1],cummean_X_loclin[4,2],expression(paste("log"[2],"(h)=0.5",collapse = "")),col = "black",adj = c(1.1,1.1),cex=2)
text(cummean_X_loclin[5,1],cummean_X_loclin[5,2],expression(paste("log"[2],"(h)=1",collapse = "")),col = "black",adj = c(1.1,1.1),cex=2)

for(i in c(2:4))
{
  #points(X[ordering[1:i],],col=2,pch=17,lwd=3)
  #points(mean(X[ordering[1:i],1]),mean(X[ordering[1:i],2]),col=2,pch=10,lwd=2)
  #draw.circle(0,1,radius = sqrt(distancing[ordering[i]]),border = "blue",lty=2)
  segments(cummean_X_loclin[i,1],cummean_X_loclin[i,2],cummean_X_loclin[i+1,1],cummean_X_loclin[i+1,2],lty = 2,col = "black")
}
legend("topright",legend = c("Target point","Sample mean","Crystallization learning","k-NN regression","Local linear regression"),col=c("blue","black","red","purple","black"),lty=c(0,0,2,2,2),pch=c(18,11,15,17,18),cex=c(2,2,2,2,2))
dev.off()

#############################################################
mid_direction<-mean_X-z
mid_direction<-mid_direction/sqrt(sum(mid_direction^2))
angles<-0:359/180
X_standard<-cbind(cos(angles*pi),sin(angles*pi))
kappa<-1

KDE_KNN<-NULL
Hei<-0*angles
ranging<-NULL
for(i in 1:4)
{
  for(j in (i-1)*5+1:5)
  {
    fangxiang<-X[ordering[j],]-z
    fangxiang<-fangxiang/sqrt(sum(fangxiang^2))
    Hei<-Hei+exp(kappa*(X_standard%*%fangxiang)[,1])
  }
  KDE_KNN<-cbind(KDE_KNN,Hei/mean(Hei))
  ranging<-cbind(ranging,X_standard*Hei/mean(Hei)*i)
}
ranging<-max(abs(ranging))

png("kNN_angle.png",500,500)
par(mfrow=c(1,1))
#par(mfrow=c(1,3))
plot(0,0,type = "p",pch=20,xlab = "",ylab = "",main="",xlim = c(-ranging,ranging),ylim = c(-ranging,ranging),axes = F)

mtext(expression(0),4)
mtext(expression(pi/2),3)
mtext(expression(pi),2)
mtext(expression(3*pi/2),1)
coloring<-rainbow(12)[1:4]
for(i in 4:1)
{
  for(j in 1:360)
  {
    lai<-c(j,j%%360+1)
    polygon(c(0,i*KDE_KNN[lai,i]*X_standard[lai,1]),c(0,i*KDE_KNN[lai,i]*X_standard[lai,2]),col=coloring[i],border = coloring[i])
  }
  #draw.circle(0,0,i,lty=3)
}

for(i in 4:1)
{
  draw.circle(0,0,i,lty=3)
}
legend("topright",legend = c("k=5","k=10","k=15","k=20"),fill = coloring)
abline(h=0)
abline(v=0)
arrows(0,0,ranging*mid_direction[1],ranging*mid_direction[2],lwd=2)
dev.off()


KDE_DT<-NULL
ranging<-NULL
for(i in c(0:3))
{
  relevant_index<-sort(unique(as.vector(CT$Simplex[CT$Layer<=i,])))
  new_X<-X[relevant_index,]
  
  new_W1<-NULL
  Hei<-NULL
  for(j in relevant_index)
  {
    new_W1<-c(new_W1,sum(CT$Simplex[CT$Layer<=i,]==j))
    fangxiang<-X[j,]-z
    fangxiang<-fangxiang/sqrt(sum(fangxiang^2))
    Hei<-rbind(Hei,exp(kappa*(X_standard%*%fangxiang)[,1]))
  }
  distancing<-colSums((t(new_X)-z)^2)
  new_W2<-new_W1*exp(-distancing/mean(distancing))
  
  #All<-colSums(Hei*new_W2)
  All<-colSums(Hei)
  KDE_DT<-cbind(KDE_DT,All/mean(All))
  ranging<-cbind(ranging,X_standard*All/mean(All)*(i+1))
}
ranging<-max(abs(ranging))
png("DT_angle.png",500,500)
plot(0,0,type = "p",pch=20,xlab = "",ylab = "",main="",xlim = c(-ranging,ranging),ylim = c(-ranging,ranging),axes = F)

mtext(expression(0),4)
mtext(expression(pi/2),3)
mtext(expression(pi),2)
mtext(expression(3*pi/2),1)
coloring<-rainbow(12)[1:4]
for(i in 4:1)
{
  for(j in 1:360)
  {
    lai<-c(j,j%%360+1)
    polygon(c(0,i*KDE_DT[lai,i]*X_standard[lai,1]),c(0,i*KDE_DT[lai,i]*X_standard[lai,2]),col=coloring[i],border = coloring[i])
  }
  #draw.circle(0,0,i,lty=3)
}

for(i in 4:1)
{
  draw.circle(0,0,i,lty=3)
}
legend("topright",legend = c("L=0","L=1","L=2","L=3"),fill = coloring)
abline(h=0)
abline(v=0)
arrows(0,0,ranging*mid_direction[1],ranging*mid_direction[2],lwd=2)
dev.off()



KDE_loclin<-NULL
ranging<-NULL
distancing<-colSums((t(X)-z)^2)



for(i in c(0:3))
{
  new_W2<-exp(-distancing/((2)^(i-1)))
  
  Hei<-NULL
  for(j in 1:n)
  {
    fangxiang<-X[j,]-z
    fangxiang<-fangxiang/sqrt(sum(fangxiang^2))
    Hei<-rbind(Hei,exp(kappa*(X_standard%*%fangxiang)[,1]))
  }
  #distancing<-colSums((t(new_X)-z)^2)
  #new_W2<-new_W1*exp(-distancing/mean(distancing))
  
  All<-colSums(Hei*new_W2)
  #All<-colSums(Hei)
  KDE_loclin<-cbind(KDE_loclin,All/mean(All))
  ranging<-cbind(ranging,X_standard*All/mean(All)*(i+1))
}
ranging<-max(abs(ranging))
png("Loclin_angle.png",500,500)
plot(0,0,type = "p",pch=20,xlab = "",ylab = "",main="",xlim = c(-ranging,ranging),ylim = c(-ranging,ranging),axes = F)

mtext(expression(0),4)
mtext(expression(pi/2),3)
mtext(expression(pi),2)
mtext(expression(3*pi/2),1)
coloring<-rainbow(12)[1:4]
for(i in 4:1)
{
  for(j in 1:360)
  {
    lai<-c(j,j%%360+1)
    polygon(c(0,i*KDE_loclin[lai,i]*X_standard[lai,1]),c(0,i*KDE_loclin[lai,i]*X_standard[lai,2]),col=coloring[i],border = coloring[i])
  }
  #draw.circle(0,0,i,lty=3)
}

for(i in 4:1)
{
  draw.circle(0,0,i,lty=3)
}
legend("topright",legend = c(expression(paste("log"[2],"(h)=-0.5",collapse = "")),expression(paste("log"[2],"(h)=0",collapse = "")),expression(paste("log"[2],"(h)=0.5",collapse = "")),expression(paste("log"[2],"(h)=1",collapse = ""))),fill = coloring)
abline(h=0)
abline(v=0)
arrows(0,0,ranging*mid_direction[1],ranging*mid_direction[2],lwd=2)
dev.off()


###################################################################################
n<-16
d<-2
rho<-0
SS<-diag(1-rho,d)+rho

set.seed(4269)
# Data generation
XX<-matrix(runif(n*d,0,0.5),n,d)+cbind(rep(1:4*0.5-1.5,4),rep(1:4*0.5-1.5,each=4))
DT_XX<-delaunayn(XX)

par(mfrow=c(1,1))

png("DT_example.png",500,500)
plot(XX,type="n",xlab = "",ylab = "",xlim = c(-1,1),ylim = c(-1,1),axes = F)
for(i in 1:nrow(DT_XX))
{
  polygon(XX[DT_XX[i,],],border = gray(0))
}
points(XX,col=2,pch=20,cex=4)
#for(i in 1:n)
#{text(XX[i,1],XX[i,2],as.character(i),col=2,pch=20,cex=1,adj=c(1.1,1.1))}
dev.off()


RT_XX<-DT_XX
for(i in 2:nrow(RT_XX)-1)
{
  for(j in (i+1):nrow(RT_XX))
  {
    douyou<-intersect(RT_XX[i,],RT_XX[j,])
    only_i<-setdiff(RT_XX[i,],RT_XX[j,])
    only_j<-setdiff(RT_XX[j,],RT_XX[i,])
    if(length(douyou)==2)
    {
      vector_i<-t(XX[douyou,])-XX[only_i,]
      vector_ij<-XX[only_j,]-XX[only_i,]
      all_prod<-solve(vector_i,vector_ij)
      if(prod(all_prod>0)==1)
      {
        RT_XX[i,]<-c(only_i,only_j,douyou[1])
        RT_XX[j,]<-c(only_i,only_j,douyou[2])
      }
    }
  }
}
png("RT_example.png",500,500)
 plot(XX,type="n",xlab = "",ylab = "",xlim = c(-1,1),ylim = c(-1,1),axes = F)
 for(i in 1:nrow(RT_XX))
 {
   polygon(XX[RT_XX[i,],],border = gray(0))
 }
 points(XX,col=2,pch=20,cex=4)
 dev.off()
 
 
 ###################################################################################
 n<-16
 d<-2
 rho<-0
 SS<-diag(1-rho,d)+rho
 
 set.seed(4269)
 # Data generation
 XX<-matrix(runif(n*d,0,0.5),n,d)+cbind(rep(1:4*0.5-1.5,4),rep(1:4*0.5-1.5,each=4))
 DT_XX<-delaunayn(XX)
 
 par(mfrow=c(1,1),mar=c(2,2,2,2))
 
 png("DT_example_circle.png",500,500)
 xuanze<-sample(1:nrow(DT_XX),3)
 plot(XX,type="n",xlab = "",ylab = "",xlim = c(-1.25,1.25),ylim = c(-1.25,1.25),axes = F)
 points(XX,col=2,pch=20,cex=2)
 for(i in 1:nrow(DT_XX))
 {
   polygon(XX[DT_XX[i,],],border = gray(0.75))
   A<-t(t(XX[DT_XX[i,-1],])-XX[DT_XX[i,1],])
   b<-(rowSums(XX[DT_XX[i,-1],]^2)-sum(XX[DT_XX[i,1],]^2))/2
   centers<-solve(A,b)
   r<-sqrt(sum((centers-XX[DT_XX[i,1],])^2))
   #curve(function(x){centers[2]+sqrt(r^2-(x-centers[1])^2)},lty=3,border = gray(0.75),from = centers[1]-r,to = centers[1]-r)
   X_xuan<-centers[1]+((-99):99)/100*r
   Y_up<-centers[2]+sqrt(r^2-(X_xuan-centers[1])^2)
   Y_down<-centers[2]-sqrt(r^2-(X_xuan-centers[1])^2)
   lines(c(centers[1]-r,X_xuan,centers[1]+r),c(centers[2],Y_up,centers[2]),lty=1,col = gray(0.95))
   lines(c(centers[1]-r,X_xuan,centers[1]+r),c(centers[2],Y_down,centers[2]),lty=1,col = gray(0.95))
   points(XX[DT_XX[i,],],col=2,pch=20,cex=4)
   #readline("press enter to continue")
 }
 for(i in xuanze)
 {
   polygon(XX[DT_XX[i,],],border = "blue")
   A<-t(t(XX[DT_XX[i,-1],])-XX[DT_XX[i,1],])
   b<-(rowSums(XX[DT_XX[i,-1],]^2)-sum(XX[DT_XX[i,1],]^2))/2
   centers<-solve(A,b)
   r<-sqrt(sum((centers-XX[DT_XX[i,1],])^2))
   X_xuan<-centers[1]+((-100):100)/100*r
   Y_up<-centers[2]+sqrt(r^2-(X_xuan-centers[1])^2)
   Y_down<-centers[2]-sqrt(r^2-(X_xuan-centers[1])^2)
   lines(c(centers[1]-r,X_xuan,centers[1]+r),c(centers[2],Y_up,centers[2]),lty=1,col = "blue")
   lines(c(centers[1]-r,X_xuan,centers[1]+r),c(centers[2],Y_down,centers[2]),lty=1,col = "blue")
   points(XX[DT_XX[i,],],col=2,pch=20,cex=4)
   #readline("press enter to continue")
 }
 #points(XX,col=2,pch=20,cex=2)
 #for(i in 1:n)
 #{text(XX[i,1],XX[i,2],as.character(i),col=2,pch=20,cex=1,adj=c(1.1,1.1))}
 dev.off()
 
 
