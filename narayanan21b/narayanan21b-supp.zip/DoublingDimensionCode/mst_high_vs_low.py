import mlpack
import numpy as np
import matplotlib.pyplot as plt
from flcode import *

# function to calculate MST cost without using disance matrix
def mst_cost(points, edges):
    m = edges.shape[0]
    cost = 0.0
    for i in range(m):
        start_vtx = edges[i, 0]
        end_vtx = edges[i, 1]
        cost += np.linalg.norm(points[int(start_vtx),:] - points[int(end_vtx),:])
    return cost


if __name__ == '__main__':

    print('constructing synthetic dataset')
    n = 1000
    points = np.random.normal(size = n)
    points = np.diag(points)

    alt_points = np.zeros((1000, 1000))
    for i in range(1000):
        for j in range(i):
            alt_points[i,j] = points[j,j]


    output = mlpack.emst(points)['output']
    act_cost = output[:, 2].sum()

    output_alt = mlpack.emst(alt_points)['output']
    act_cost_alt = output_alt[:, 2].sum()


    # print(running projection experiment)
    dvals = range(5, 21)
    pullback_points = []
    pullback_alt = []

    for d in dvals:
        total1 = 0.0
        total2 = 0.0
        for t in range(25):
            projected_points = do_random_projection(points, d)
            new_output = mlpack.emst(projected_points)['output']
            total1 += mst_cost(points, new_output[:, 0:2])/25.0
            
            projected_points_alt = do_random_projection(alt_points, d)
            new_output_alt = mlpack.emst(projected_points_alt)['output']
            total2 += mst_cost(alt_points,new_output_alt[:, 0:2])/25.0

        pullback_points.append(total1/act_cost)
        pullback_alt.append(total2/act_cost_alt)


    # Figure 4c of the paper
    print('plotting results')

    plt.figure(figsize=(10,8))
    plt.rc('font', family='serif')

    plt.plot(dvals, pullback_points, '-', label = "High Doubling Dimension", markersize=6, linewidth=3)
    plt.plot(dvals, pullback_alt, '--', label = "Low Doubling Dimension", markersize=6, linewidth=3, color="C0")

    plt.xlabel("Projected Dimension", fontsize=20)
    plt.ylabel("Pullback Tree / MST", fontsize=20)
    plt.xticks(fontsize=20)
    plt.yticks(fontsize=20)
    # plt.ylim([1.15, 1.6])
    plt.legend(fontsize=20)
    # plt.savefig("MST_comparision.pdf", bbox_inches = 'tight', pad_inches = 0)
    plt.show()

