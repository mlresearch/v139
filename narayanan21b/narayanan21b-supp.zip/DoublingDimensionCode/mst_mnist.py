import mlpack
import numpy as np
import matplotlib.pyplot as plt
from flcode import *

# Function to compute MST cost using distance matrix
def mst_cost(distances, edges):
    m = edges.shape[0]
    cost = 0.0
    for i in range(m):
        start_vtx = edges[i, 0]
        end_vtx = edges[i, 1]
        cost += distances[int(start_vtx), int(end_vtx)]
    return cost

print('loading data')
mnist_data = np.load('data/mnist_data.npz')['mnist_data']
distance_mnist = distance_matrix(mnist_data, mnist_data)
distance_sorted_mnist = np.copy(distance_mnist)
distance_sorted_mnist.sort(axis=1)
print('data loaded')

# Running time experiments
print('doing time experiment')
print('NOTE: make sure you are not running any other intensive program since that can affect time calculations')

time_d_mnist = []
for d in range(5,21):
    curr_time = np.zeros(25)
    for j in range(25):
        start = time.time()
        reduced_points_mnist = do_random_projection(mnist_data, d)
        mlpack.emst(reduced_points_mnist)
        curr_time[j] = time.time()-start
    time_d_mnist.append(np.median(curr_time))


# Cost
print('doing cost experiment')

cost_d_mnist = []
for d in range(5,21):
    curr_cost = 0.0
    for j in range(20):
        reduced_points_mnist = do_random_projection(mnist_data, d)
        output = mlpack.emst(reduced_points_mnist)['output']
        curr_cost += mst_cost(distance_mnist, output[:, 0:2])*.05
    cost_d_mnist.append(curr_cost)

# Actual cost
output_mnist = mlpack.emst(mnist_data)['output']
act_cost_mnist = output_mnist[:, 2].sum()

# Figure 4b of the paper
print('plotting results')

plt.rcParams['ytick.major.pad'] = 0

fig, ax1 = plt.subplots(figsize=(10,8))
plt.rc('font', family='serif')

ax1.set_xlabel("Projected Dimension", fontsize=20)
ax1.set_ylabel("Pullback Tree / MST", fontsize=20,color="C0", fontweight="bold")

ax1.plot(range(5,21), [k/act_cost_mnist for k in cost_d_mnist], '.-', label = "Ratio", markersize=12, linewidth=1.5,color="C0")

ax1.tick_params(labelsize=20)
ax1.tick_params(axis='y', labelcolor="C0")
ax1.set_title("MNIST '2' Dataset", fontsize=20)

ax2 = ax1.twinx()
ax2.set_ylabel("Average Running Time (s)", fontsize=20, color="C1", fontweight="bold")

ax2.plot(range(5,21), time_d_mnist, '.-', label = "MST Time", markersize=12, linewidth=1.5, color="C1")


ax2.tick_params(labelsize=20)
ax2.tick_params(axis='y', labelcolor="C1")

for label in ax1.get_yticklabels():
    label.set_fontweight("bold")
    
for label in ax2.get_yticklabels():
    label.set_fontweight("bold")
                        
fig.tight_layout()   

# plt.savefig("mst_mnist.pdf", bbox_inches = 'tight', pad_inches = 0)
plt.show()