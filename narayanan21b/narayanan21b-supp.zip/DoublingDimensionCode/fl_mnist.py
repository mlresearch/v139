from flcode import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.lines as mlines

print('loading data')
mnist_data = np.load('data/mnist_data.npz')['mnist_data']
distance_mnist = distance_matrix(mnist_data, mnist_data)
distance_sorted_mnist = np.copy(distance_mnist)
distance_sorted_mnist.sort(axis=1)
print('data loaded')


# targeted number of centers
print('doing accuracy experiment')

targets = [500, 200, 100]
accuracy_mnist = np.zeros((3,16))
num_points = 1000

for j in range(3):
    curr_accuracy = []
    for d in range(5,21):
        reduced_points_mnist = do_random_projection(mnist_data, d)
        distance_reduced_mnist = distance_matrix(reduced_points_mnist, reduced_points_mnist)
        distance_reduced_sorted_mnist = np.copy(distance_reduced_mnist)
        distance_reduced_sorted_mnist.sort(axis=1)


        good_cost = cost_finder_new(mnist_data, reduced_points_mnist, distance_mnist, distance_sorted_mnist, distance_reduced_mnist, distance_reduced_sorted_mnist, d, 1000, targets[j])

        accuracy_score = 0.0

        for i in range(10):
            reduced_points_mnist = do_random_projection(mnist_data, d)
            distance_reduced_mnist = distance_matrix(reduced_points_mnist, reduced_points_mnist)
            distance_reduced_sorted_mnist = np.copy(distance_reduced_mnist)
            distance_reduced_sorted_mnist.sort(axis=1)

            curr_result, curr_facility = experiment_slim(mnist_data, reduced_points_mnist, distance_mnist, distance_sorted_mnist, distance_reduced_mnist, distance_reduced_sorted_mnist, d, [good_cost], num_points,new_proj = False, timing = False)
            curr_result = curr_result[0]
            accuracy_score += curr_result[2]/curr_result[0]/10.0
        curr_accuracy.append(accuracy_score)
    accuracy_mnist[j,:] = curr_accuracy

print('done with accuracy experiment')

# Finding runtimes
# NOTE: make sure you are not running any other intensive program since that can affect time calculations
print('doing time experiment')
print('NOTE: make sure you are not running any other intensive program since that can affect time calculations')

kvals = [500, 200, 100]
time_matrix_mnist = np.zeros((3,16))  # k by d

for i in range(3):
    curr_d = []
    for d in range(5,21):
        reduced_points_mnist = do_random_projection(mnist_data, d)
        distance_reduced_mnist = distance_matrix(reduced_points_mnist, reduced_points_mnist)
        distance_reduced_sorted_mnist = np.copy(distance_reduced_mnist)
        distance_reduced_sorted_mnist.sort(axis=1)
        good_cost = cost_finder_new(mnist_data, reduced_points_mnist, distance_mnist, distance_sorted_mnist, distance_reduced_mnist, distance_reduced_sorted_mnist, d, 1000, kvals[i])
        curr_time = np.zeros(20)
        
        for j in range(20):
            reduced_points_mnist = do_random_projection(mnist_data, d)
            start = time.time()
            distance_reduced_mnist = distance_matrix(reduced_points_mnist, reduced_points_mnist)
            distance_reduced_sorted_mnist = np.copy(distance_reduced_mnist)
            distance_reduced_sorted_mnist.sort(axis=1)
            MP_alg(distance_reduced_sorted_mnist, distance_reduced_mnist, reduced_points_mnist, good_cost)
            curr_time[j] = time.time()-start
        curr_d.append(np.median(curr_time))
    time_matrix_mnist[i,:] = curr_d


# Figure 3b of the paper
print('plotting results')

plt.rcParams['ytick.major.pad'] = 0
fig, ax1 = plt.subplots(figsize=(10,8))
plt.rc('font', family='serif')

ax1.set_xlabel("Projected Dimension", fontsize=20)
ax1.set_ylabel("Pullback Clustering / Best Clustering", fontsize=20,color="C0", fontweight="bold")
ax1.plot(range(5,21), accuracy_mnist[0,:], 'o-', label = "k=n/2", markersize=12, linewidth=1.5,color="C0")
ax1.plot(range(5,21), accuracy_mnist[1,:], '^-', label = "k=n/5", markersize=12, linewidth=1.5,color="C0")
ax1.plot(range(5,21), accuracy_mnist[2,:], 'x-', label = "k=n/10", markersize=12, linewidth=1.5, markeredgewidth=3,color="C0")
ax1.tick_params(labelsize=20)
ax1.tick_params(axis='y', labelcolor="C0")
ax1.set_title("MNIST '2' Dataset", fontsize=20)

ax2 = ax1.twinx()
ax2.set_ylabel("Average Running Time (s)", fontsize=20, color="C1", fontweight="bold")

ax2.plot(range(5,21), time_matrix_mnist[0,:], 'o-', label = "k=n/2", markersize=12, linewidth=1.5, color="C1")
ax2.plot(range(5,21), time_matrix_mnist[1,:], '^-', label = "k=n/5", markersize=12, linewidth=1.5, color="C1")
ax2.plot(range(5,21), time_matrix_mnist[2,:], 'x-', label = "k=n/10", markersize=12, linewidth=1.5, markeredgewidth=3, color="C1")

ax2.tick_params(labelsize=20)
ax2.tick_params(axis='y', labelcolor="C1")

l1 = mlines.Line2D([], [], color='black', marker='o', ls='', label='k=n/2', markersize=10)
l2 = mlines.Line2D([], [], color='black', marker='^', ls='', label='k=n/5', markersize=10)
l3 = mlines.Line2D([], [], color='black', marker='x', ls='', label='k=n/10', markersize=10, markeredgewidth=3)
ax1.legend(handles=[l1, l2, l3], fontsize=20, loc="upper center")
fig.tight_layout()   

for label in ax1.get_yticklabels():
    label.set_fontweight("bold")
    
for label in ax2.get_yticklabels():
    label.set_fontweight("bold")
# plt.savefig("fac_loc_mnist.pdf", bbox_inches = 'tight', pad_inches = 0)
plt.show()
