Code for "Randomized Dimensionality Reduction for Facility Location and Single-Linkage Clustering" (ICML 2021).

Tested with Python 3.7.4.

First, make sure you have all the packages from requirements.txt

## Datasets:

The datasets used in the paper are under the data folder.


## Figures from Paper:

The figures from the paper can be generated after running the following files:

- Figure 3a: fl_faces.py
- Figure 3b: fl_mnist.py
- Figure 4a: mst_faces.py
- Figure 4b: mst_faces.py
- Figure 4c: mst_high_vs_low.py

## Sample Useage:

See the file example.py to see an example of the following:

- MP algorithm for facility location
- MST algorithm from mlpack
- Dimensionality reduction
