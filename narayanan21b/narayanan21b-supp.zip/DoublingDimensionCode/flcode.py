import numpy as np
import time
import matplotlib.pyplot as plt
from scipy.spatial import distance_matrix
from sklearn import random_projection


################ Auxilliary functions ################
def binary_search(arr, high, low, cost, tol):
    
    while high-low > 1:
        med = (low+high)//2
        curr_sum = (med+1)*arr[med]- arr[0:med+1].sum() 
        if abs(curr_sum - cost) <= tol:
            return med
        elif curr_sum < cost:
            low = med
        else:
            high = med

    high_sum = (high+1)*arr[high]- arr[0:high+1].sum() 
        
    if high_sum > cost + tol:
        return low
    else:
        return high

    
# find radius given index
def calculate_radius(arr, indx, cost):
    curr_sum = (indx+1)*arr[indx]-arr[0:indx+1].sum() 
    diff = cost-curr_sum
    radius = arr[indx] + diff/(indx+1)
    return radius

def do_random_projection(X, d):
    ''' returns the data X after undergoing a random projection to dimension d'''

    transformer = random_projection.GaussianRandomProjection(n_components = d)
    X_new = transformer.fit_transform(X)
    X_new = X_new
    return X_new

def calculate_total_cost(distance, centers, N):
    return distance[:, centers].min(axis=1).sum()

# find appropriate opening costs
def cost_finder_new(data, reduced_data, distance, sorted_distance, reduced_distance, reduced_sorted_distance, dim, num_points, target):
    cost_min = 1e-8
    cost_max = 100
    current_cost = (cost_max + cost_min)/2
    costs = [current_cost]
    curr_result, curr_facility  = experiment_slim(data, reduced_data, distance, sorted_distance, reduced_distance, reduced_sorted_distance, dim, costs, num_points, new_proj = False, timing = False)
    curr_fac = curr_facility[0][1]
    while curr_fac != target:
        if curr_fac > target:
            cost_min = current_cost
            current_cost = (current_cost + cost_max)/2
            costs = [current_cost]
        else:
            cost_max = current_cost
            current_cost = (current_cost + cost_min)/2
            costs = [current_cost]
        curr_result, curr_facility  = experiment_slim(data, reduced_data, distance, sorted_distance, reduced_distance, reduced_sorted_distance, dim, costs, num_points, new_proj = False, timing = False)
        curr_fac = curr_facility[0][1]
        if abs(curr_fac-target) <= 5:
            return current_cost
    return current_cost


# auxilliary function to run many experiments at once
def experiment_slim(point_set, reduced_points, distance, distance_sorted, distance_reduced, distance_reduced_sorted, dim, costs, num_points, new_proj = False, timing = False):    
    
    
    cost_vector = []
    num_facilities = []
    

    for cost in costs:
        start = time.time()
        actual_cost = MP_alg(distance_sorted, distance, point_set, cost)
        reduced_cost = MP_alg(distance_reduced_sorted, distance_reduced, reduced_points, cost)
        pullback_cost = distance[:, reduced_cost[0]].min(axis=1).sum() + len(reduced_cost[0])*cost        
        cost_vector.append((actual_cost[1], reduced_cost[1], pullback_cost))
        num_facilities.append((len(actual_cost[0]), len(reduced_cost[0])))
        
        if new_proj:
            reduced_points = do_random_projection(point_set, dim)
            distance_reduced = distance_matrix(reduced_points, reduced_points)
            distance_reduced_sorted = np.copy(distance_reduced)
            distance_reduced_sorted.sort(axis=1)
    
    if timing:
        print(time.time()-start)
        
    return (cost_vector, num_facilities)

################ Main MP algorithm function ################

# MP Algorithm
#####
# Input: distance, points, cost
# distance_sorted: N by N distance matrix sorted by rows
# distance: N by N distance matrix
# points: N by d array of points
# cost: opening cost of a facility
#####
# Output: facility location cost = distance cost + opening costs
#####
def MP_alg(distance_sorted, distance, points, cost):
    
    
    N = points.shape[0]    # get number of points
    radii = []             # initialize array for radii
    centers = []           # initialize array for centers
    
    for i in range(N):     # calculate the radii
        curr_array = distance_sorted[i,:]
        curr_indx = binary_search(curr_array, N, 0, cost, 1e-10)
        curr_radius = calculate_radius(curr_array, curr_indx, cost)
        radii.append((i, curr_radius))

    radii = sorted(radii, key = lambda t: t[1])   # sort radii from smallest to largest
    
    for tup in radii:   # greedily select centers
        curr_index = tup[0]
        curr_radii = tup[1]
        curr_point = points[curr_index]
        if len(centers) == 0:
            centers.append(curr_index)
        else:
            curr_cost = distance[curr_index, centers].min()#min(distance[curr_index, k] for k in centers)
            if curr_cost > 2*curr_radii:
                centers.append(curr_index)
                
    total_cost =  distance[:, centers].min(axis=1).sum() + len(centers)*cost
    
    return (centers, total_cost)