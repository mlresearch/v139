import numpy as np
from flcode import *
import mlpack
from mst_high_vs_low import *


# Example of Facility Location calculation

N = 100 # number of points
d = 25  # dimension
points = np.random.random((N, d)) # generate some random points
distance = distance_matrix(points, points)  # calculate distance matrix   
distance_sorted = np.copy(distance)
distance_sorted.sort(axis=1) # sorted distance matrix along rows
cost = 1 # cost to open a facility
centers, total_cost = MP_alg(distance_sorted, distance, points, cost) # returns the centers and the objective value
print('FL cost:', total_cost)

# Example of dimensionality reduction

d = 5 # dim to project into
projected_points = do_random_projection(points, d) # new projected points
print(points.shape, projected_points.shape)


# Example of MST calculation

mst_high =  mlpack.emst(points)['output'] # Get MST 
print('MST cost:', mst_high[:, 2].sum())

