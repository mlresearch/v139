"""Module that provides adapters between SoftlearningEnv and other universes"""
