%Code for Detection of Signal in the Spiked Rectangular Models, submitted to ICML 2021 
clear;

px=-20:0.1:20;

p=1/sqrt(2*pi)*(exp(-2*(px-sqrt(3)/2).^2)+exp(-2*(px+sqrt(3)/2).^2));

Fg=2.50819;

M=1024;
N=2048;
d0=M/N;

lamb_th_org=sqrt(d0);
lamb_th_af=sqrt(d0)/Fg;

lam=(lamb_th_org+lamb_th_af)/2;

u=2*round(rand(M,1))-1;
v=2*round(rand(N,1))-1;

u=u/sqrt(M);
v=v/sqrt(N);


X=randmat(p,px,M,N);

Ya=sqrt(lam)*u*v.'+X;
Yta=1/(sqrt(Fg*N))*2*(sqrt(3)-exp(4*sqrt(3)*sqrt(N)*Ya).*(sqrt(3)-2*sqrt(N)*Ya)+2*sqrt(N)*Ya)./(1+exp(4*sqrt(3)*sqrt(N)*Ya));

Ya=min(Ya,1);
Yta=min(Yta,1);

figure
subplot(2,1,1)
histogram(eig(Ya*Ya.'),'Normalization','pdf');
subplot(2,1,2)
histogram(eig(Yta*Yta.'),'Normalization','pdf');

