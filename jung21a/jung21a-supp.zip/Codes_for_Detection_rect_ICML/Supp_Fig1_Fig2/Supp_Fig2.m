%Code for Detection of Signal in the Spiked Rectangular Models, submitted to ICML 2021 

clear;
ts = datestr(now);
timestamp = [ts(1:11) '-' ts(13:14) '-' ts(16:17)];

px=-20:0.1:20;

p=1/sqrt(2*pi)*(exp(-2*(px-sqrt(3)/2).^2)+exp(-2*(px+sqrt(3)/2).^2));

Fg=2.50819;

M=1024;
N=2048;
d0=M/N;

lamb_th_org=sqrt(d0);
lamb_th_af=sqrt(d0)/Fg;

lam=(lamb_th_org+lamb_th_af)/2;

trials=500;

lambda1=zeros(trials,1);
lambda1t=zeros(trials,1);

tstart=tic;
for i=1:trials

[lambda1(i),lambda1t(i)]=prepdata(p,px,M,N,lam,Fg);

end

tend=toc(tstart);


figure;
subplot(2,1,1)
histogram(real(lambda1),'Normalization','pdf');
xline((1+sqrt(d0))^2);
xline((1+lam)*(1+(d0)/(lam)));

xlim([2.8 3.4])


subplot(2,1,2)
histogram(real(lambda1t),'Normalization','pdf');
xline((1+sqrt(d0))^2);
xline((1+lam*(Fg))*(1+(d0)/(lam*Fg)));
xlim([2.8 3.4])
