function [mat]=randmat(p,px,M,N)

mat=randpdf(p,px,[M,N]);

mat=mat/sqrt(N);

