function [lambda1,lambda1t]=prepdata(p,px,M,N,lam,Fg)

u=2*round(rand(M,1))-1;
v=2*round(rand(N,1))-1;

u=u/sqrt(M);
v=v/sqrt(N);



X=randmat(p,px,M,N);

Ya=sqrt(lam)*u*v.'+X;
Yta=1/(sqrt(Fg*N))*2*(sqrt(3)-exp(4*sqrt(3)*sqrt(N)*Ya).*(sqrt(3)-2*sqrt(N)*Ya)+2*sqrt(N)*Ya)./(1+exp(4*sqrt(3)*sqrt(N)*Ya));

Ya=min(Ya,1);
Yta=min(Yta,1);

lambda1=eigs(Ya*Ya.',1);
lambda1t=eigs(Yta*Yta.',1);

