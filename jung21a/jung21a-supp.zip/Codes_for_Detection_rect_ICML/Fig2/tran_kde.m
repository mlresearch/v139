function h=tran_kde(Y,x)
f=0;
g=0;
[M,N]=size(Y);
for i=1:M
	for j=1:N
		f=f+exp(-(M*N)^(2/5).*(x-sqrt(N)*Y(i,j)).^2/2);
		g=g-(M*N)^(2/5).*(x-sqrt(N)*Y(i,j)).*exp(-(M*N)^(2/5)*(x-sqrt(N)*Y(i,j)).^2/2);
	end
end
h=-g/(sqrt(N)*f);