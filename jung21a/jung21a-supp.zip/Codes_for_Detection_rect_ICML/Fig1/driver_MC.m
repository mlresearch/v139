%Code for Detection of Signal in the Spiked Rectangular Models, submitted to ICML 2021 

clear;
load('ex2.mat') %'ex1.mat'
ts = datestr(now);
timestamp = [ts(1:11) '-' ts(13:14) '-' ts(16:17)];

% dimension of the data matrix
M=784;
N=[392, 588, 784, 1568, 3136];

%normalize the example data
mean1=mean(ex2);
norm1=norm(ex2-mean(ex2));
u=(ex2-mean1)/norm1;

%%%%%%%%%%%%
%%First N=392
%%%%%%%%%%%%
% prepare v
% v is distributed by Rademacher 
v1=(2*round(rand(N(1),1))-1)/sqrt(N(1)); 
% Noise matrix
% Noise is distributed by 1/2 Normal + sqrt(3)/2 Rademacher
X1=(1/2*randn(M,N(1))+sqrt(3)/2*(2*round(rand(M,N(1)))-1))/sqrt(N(1));
Fg=2.50819; %Fisher information for the assumed noise


%form the data
Ya1=u*v1.'+X1;
% data after the transformation using the noise model 
Yta1=1/(sqrt(Fg*N(1)))*2*(sqrt(3)-exp(4*sqrt(3)*sqrt(N(1))*Ya1).*(sqrt(3)-2*sqrt(N(1))*Ya1)+2*sqrt(N(1))*Ya1)./(1+exp(4*sqrt(3)*sqrt(N(1))*Ya1));

%Find the eigenvector of the largest eigenvalue
[Va1,Da1]=eigs(Ya1*Ya1.',1);
[Vta1,Dta1]=eigs(Yta1*Yta1.',1);

%recovery
u_recp1=(Va1)*norm1+mean1;
u_recm1=(-Va1)*norm1+mean1;

u_rectp1=Vta1*norm1+mean1;
u_rectm1=(-Vta1)*norm1+mean1;


%%%%%%%%%%%%
%%First N=588
%%%%%%%%%%%%
v2=(2*round(rand(N(2),1))-1)/sqrt(N(2)); 
% Noise matrix
% Noise is distributed by 1/2 Normal + sqrt(3)/2 Rademacher
X2=(1/2*randn(M,N(2))+sqrt(3)/2*(2*round(rand(M,N(2)))-1))/sqrt(N(2));
Fg=2.50819; %Fisher information for the assumed noise


% form the data
Ya2=u*v2.'+X2;
% data after the transformation using the noise model 
Yta2=1/(sqrt(Fg*N(2)))*2*(sqrt(3)-exp(4*sqrt(3)*sqrt(N(2))*Ya2).*(sqrt(3)-2*sqrt(N(2))*Ya2)+2*sqrt(N(2))*Ya2)./(1+exp(4*sqrt(3)*sqrt(N(2))*Ya2));


%Find the eigenvector of the largest eigenvalue
[Va2,Da2]=eigs(Ya2*Ya2.',1);
[Vta2,Dta2]=eigs(Yta2*Yta2.',1);

%recovery
u_recp2=(Va2)*norm1+mean1;
u_recm2=(-Va2)*norm1+mean1;

u_rectp2=Vta2*norm1+mean1;
u_rectm2=(-Vta2)*norm1+mean1;

%%%%%%%%%%%%
%%Third N=784
%%%%%%%%%%%%
v3=(2*round(rand(N(3),1))-1)/sqrt(N(3)); 
% Noise matrix
% Noise is distributed by 1/2 Normal + sqrt(3)/2 Rademacher
X3=(1/2*randn(M,N(3))+sqrt(3)/2*(2*round(rand(M,N(3)))-1))/sqrt(N(3));
Fg=2.50819; %Fisher information for the assumed noise


% form the data
Ya3=u*v3.'+X3;
% data after the transformation using the noise model 
Yta3=1/(sqrt(Fg*N(3)))*2*(sqrt(3)-exp(4*sqrt(3)*sqrt(N(3))*Ya3).*(sqrt(3)-2*sqrt(N(3))*Ya3)+2*sqrt(N(3))*Ya3)./(1+exp(4*sqrt(3)*sqrt(N(3))*Ya3));

%Find the eigenvector of the largest eigenvalue
[Va3,Da3]=eigs(Ya3*Ya3.',1);
[Vta3,Dta3]=eigs(Yta3*Yta3.',1);

%recovery
u_recp3=(Va3)*norm1+mean1;
u_recm3=(-Va3)*norm1+mean1;

u_rectp3=Vta3*norm1+mean1;
u_rectm3=(-Vta3)*norm1+mean1;

%%%%%%%%%%%%
%%Fourth N=980
%%%%%%%%%%%%
v4=(2*round(rand(N(4),1))-1)/sqrt(N(4)); 
% Noise matrix
% Noise is distributed by 1/2 Normal + sqrt(3)/2 Rademacher
X4=(1/2*randn(M,N(4))+sqrt(3)/2*(2*round(rand(M,N(4)))-1))/sqrt(N(4));
Fg=2.50819; %Fisher information for the assumed noise


% form the data
Ya4=u*v4.'+X4;
% data after the transformation using the noise model 
Yta4=1/(sqrt(Fg*N(4)))*2*(sqrt(3)-exp(4*sqrt(3)*sqrt(N(4))*Ya4).*(sqrt(3)-2*sqrt(N(4))*Ya4)+2*sqrt(N(4))*Ya4)./(1+exp(4*sqrt(3)*sqrt(N(4))*Ya4));


%Find the eigenvector of the largest eigenvalue
[Va4,Da4]=eigs(Ya4*Ya4.',1);
[Vta4,Dta4]=eigs(Yta4*Yta4.',1);

%recovery
u_recp4=(Va4)*norm1+mean1;
u_recm4=(-Va4)*norm1+mean1;

u_rectp4=Vta4*norm1+mean1;
u_rectm4=(-Vta4)*norm1+mean1;

%%%%%%%%%%%%
%%Fourth N=1176
%%%%%%%%%%%%
v5=(2*round(rand(N(5),1))-1)/sqrt(N(5)); 
% Noise matrix
% Noise is distributed by 1/2 Normal + sqrt(3)/2 Rademacher
X5=(1/2*randn(M,N(5))+sqrt(3)/2*(2*round(rand(M,N(5)))-1))/sqrt(N(5));
Fg=2.50819; %Fisher information for the assumed noise


% form the data
Ya5=u*v5.'+X5;
% data after the transformation using the noise model 
Yta5=1/(sqrt(Fg*N(5)))*2*(sqrt(3)-exp(4*sqrt(3)*sqrt(N(5))*Ya5).*(sqrt(3)-2*sqrt(N(5))*Ya5)+2*sqrt(N(5))*Ya5)./(1+exp(4*sqrt(3)*sqrt(N(5))*Ya5));

%Find the eigenvector of the largest eigenvalue
[Va5,Da5]=eigs(Ya5*Ya5.',1);
[Vta5,Dta5]=eigs(Yta5*Yta5.',1);

%recovery
u_recp5=(Va5)*norm1+mean1;
u_recm5=(-Va5)*norm1+mean1;

u_rectp5=Vta5*norm1+mean1;
u_rectm5=(-Vta5)*norm1+mean1;



figure
subplot(2,11,1)
imshow(uint8(reshape(ex2,28,28)));
subplot(2,11,2)
imshow(uint8(reshape(u_rectp5,28,28)));
subplot(2,11,3)
imshow(uint8(reshape(u_rectm5,28,28)));
subplot(2,11,4)
imshow(uint8(reshape(u_rectp4,28,28)));
subplot(2,11,5)
imshow(uint8(reshape(u_rectm4,28,28)));
subplot(2,11,6)
imshow(uint8(reshape(u_rectp3,28,28)));
subplot(2,11,7)
imshow(uint8(reshape(u_rectm3,28,28)));
subplot(2,11,8)
imshow(uint8(reshape(u_rectp2,28,28)));
subplot(2,11,9)
imshow(uint8(reshape(u_rectm2,28,28)));
subplot(2,11,10)
imshow(uint8(reshape(u_rectp1,28,28)));
subplot(2,11,11)
imshow(uint8(reshape(u_rectm1,28,28)));

subplot(2,11,13)
imshow(uint8(reshape(u_recp5,28,28)));
subplot(2,11,14)
imshow(uint8(reshape(u_recm5,28,28)));
subplot(2,11,15)
imshow(uint8(reshape(u_recp4,28,28)));
subplot(2,11,16)
imshow(uint8(reshape(u_recm4,28,28)));
subplot(2,11,17)
imshow(uint8(reshape(u_recp3,28,28)));
subplot(2,11,18)
imshow(uint8(reshape(u_recm3,28,28)));
subplot(2,11,19)
imshow(uint8(reshape(u_recp2,28,28)));
subplot(2,11,20)
imshow(uint8(reshape(u_recm2,28,28)));
subplot(2,11,21)
imshow(uint8(reshape(u_recp1,28,28)));
subplot(2,11,22)
imshow(uint8(reshape(u_recm1,28,28)));


