%Code for Detection of Signal in the Spiked Rectangular Models, submitted to ICML 2021 

clear;
ts = datestr(now);
timestamp = [ts(1:11) '-' ts(13:14) '-' ts(16:17)];

px=-20:0.1:20;


M=256;
N=512;
d0=M/N;


lam=0:0.05:0.7;

trials=10000;


type1_alg1=zeros(size(lam,2),1);
type2_alg1=zeros(size(lam,2),1);


tstart=tic;

Lalg1H1=zeros(size(lam,2),trials);
Lalg1H0=zeros(size(lam,2),trials);

for i=1:trials

[Y,X]=prepdata(M,N,lam);

[ind_error1,Lalg1H1(:,i)]=alg1(Y,M,N,lam);


[ind_error3,Lalg1H0(:,i)]=alg1_H0(X,M,N,lam);

type1_alg1=type1_alg1+(1-ind_error1);


type2_alg1=type2_alg1+ind_error3;

percentage_done = i/trials*100

end
tend=toc(tstart)


avg_Pe1=(type1_alg1+type2_alg1)/(trials);


figure;
subplot(1,2,1)
tlam=6;
histogram(real(Lalg1H0(tlam,:)),'Normalization','pdf');
hold on
histogram(real(Lalg1H1(tlam,:)),'Normalization','pdf');
th=-log(1-lam(tlam)^2/d0);
xline(th);
subplot(1,2,2)
tlam=10;
histogram(real(Lalg1H0(tlam,:)),'Normalization','pdf');
hold on
histogram(real(Lalg1H1(tlam,:)),'Normalization','pdf');
th=-log(1-lam(tlam)^2/d0);
xline(th);


lambda=[0:0.05:0.5];


err=erfc(1/4*sqrt(-log(1-lambda.^2/d0)));

figure;
plot(lam(1:11),avg_Pe1(1:11),lambda,err);
legend('simulation','limiting error');
