function [out,L]=alg1_H0(X,M,N,lam)



d0=M/N;
out=zeros(size(lam,2),1);

L=zeros(size(lam,2),1);

for i=1:size(L)
    L(i)=-log(det((1+d0/lam(i))*(1+lam(i))*eye(M)-X*X.'))...
     +M*(lam(i)/d0-log(lam(i)/d0)-(1-d0)/d0*log(1+lam(i)) );

th=-log(1-lam(i)^2/d0);
if L(i)<=th
    out(i)=0;
else
    out(i)=1;
end

end