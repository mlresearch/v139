function [Y,X]=prepdata(M,N,lam)



Y=zeros(M,N,size(lam,2));

u=(2*round(rand(M,1))-1)/sqrt(M);
v=(2*round(rand(N,1))-1)/sqrt(N);

X=randmat(M,N);

for i=1:size(lam,2)
Y(:,:,i)=sqrt(lam(i))*(u*v.')+X;
end

