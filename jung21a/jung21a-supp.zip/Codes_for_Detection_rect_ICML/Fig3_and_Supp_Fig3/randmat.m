function [mat]=randmat(M,N)

mat=normrnd(0,1,[M,N]);


mat=mat/sqrt(N);