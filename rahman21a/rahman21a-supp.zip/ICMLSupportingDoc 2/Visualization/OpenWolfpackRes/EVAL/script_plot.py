import seaborn as sns; sns.set()
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd

import csv

from os import listdir
from os.path import isfile, join

mypath = "DGN-MARL"

onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f)) if ".csv" in f]
print(onlyfiles)
raw_data_1 = []

for file_res in onlyfiles:
    data1 = []
    with open(mypath+"/"+file_res) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        counter = 0
        for row in csv_reader:
            if counter != 0:
                data1.append(row[2])
            counter += 1
    raw_data_1.append(data1)

min_len1 = min([len(a) for a in raw_data_1])
raw_data_1 = [a[:min_len1] for a in raw_data_1]

raw_data_np1 = np.asarray(raw_data_1).astype(np.float)

df1 = pd.DataFrame(raw_data_np1).melt()

print(df1.groupby('variable').mean().iloc[38], 1.96*df1.groupby('variable').sem().iloc[38])
