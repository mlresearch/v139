import seaborn as sns; sns.set()
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd

import csv

from os import listdir
from os.path import isfile, join

mypath = "GPL-SPI"
mypath2 = "LSTM"
mypath4 = "LSTM-RFM"
mypath5 = "MADDPG"
mypath6 = "DGN-MARL"

onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f)) and ".csv" in f]
onlyfiles2 = [f for f in listdir(mypath2) if isfile(join(mypath2, f)) and ".csv" in f]
onlyfiles4 = [f for f in listdir(mypath4) if isfile(join(mypath4, f)) and ".csv" in f]
onlyfiles5 = [f for f in listdir(mypath5) if isfile(join(mypath5, f)) and ".csv" in f]
onlyfiles6 = [f for f in listdir(mypath6) if isfile(join(mypath6, f)) and ".csv" in f]

raw_data_1 = []
raw_data_2 = []
raw_data_4 = []
raw_data_5 = []
raw_data_6 = []

for file_res in onlyfiles:
    data1 = []
    with open(mypath+"/"+file_res) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        counter = 0
        for row in csv_reader:
            if counter != 0:
                data1.append(row[2])
            counter += 1
    raw_data_1.append(data1)

for file_res in onlyfiles2:
    data2 = []
    with open(mypath2+"/"+file_res) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        counter = 0
        for row in csv_reader:
            if counter != 0:
                data2.append(row[2])
            counter += 1
    raw_data_2.append(data2)

for file_res in onlyfiles4:
    data4 = []
    with open(mypath4+"/"+file_res) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        counter = 0
        for row in csv_reader:
            if counter != 0:
                data4.append(row[2])
            counter += 1
    raw_data_4.append(data4)

for file_res in onlyfiles5:
    data5 = []
    with open(mypath5+"/"+file_res) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        counter = 0
        for row in csv_reader:
            if counter != 0:
                data5.append(row[2])
            counter += 1
    raw_data_5.append(data5)

for file_res in onlyfiles6:
    data6 = []
    with open(mypath6+"/"+file_res) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        counter = 0
        for row in csv_reader:
            if counter != 0:
                data6.append(row[2])
            counter += 1
    raw_data_6.append(data6)

min_len1, min_len2, min_len4, min_len5, min_len6 = min([len(a) for a in raw_data_1]), min([len(a) for a in raw_data_2]), min([len(a) for a in raw_data_4]), min([len(a) for a in raw_data_5]), min([len(a) for a in raw_data_6])
min_all = min([min_len1, min_len2, min_len6, min_len4, min_len5])
raw_data_1 = [a[:min_all] for a in raw_data_1]
raw_data_2 = [a[:min_all] for a in raw_data_2]
raw_data_4 = [a[:min_all] for a in raw_data_4]
raw_data_5 = [a[:min_all] for a in raw_data_5]
raw_data_6 = [a[:min_all] for a in raw_data_6]

raw_data_np1 = np.asarray(raw_data_1).astype(np.float)
raw_data_np2 = np.asarray(raw_data_2).astype(np.float)
raw_data_np4 = np.asarray(raw_data_4).astype(np.float)
raw_data_np5 = np.asarray(raw_data_5).astype(np.float)
raw_data_np6 = np.asarray(raw_data_6).astype(np.float)

df1 = pd.DataFrame(raw_data_np1).melt()
df2 = pd.DataFrame(raw_data_np2).melt()
df4 = pd.DataFrame(raw_data_np4).melt()
df5 = pd.DataFrame(raw_data_np5).melt()
df6 = pd.DataFrame(raw_data_np6).melt()

print(df6.groupby('variable').mean().iloc[39], 1.96*df6.groupby('variable').sem().iloc[39])
#print(df2.groupby('variable').mean(), 1.96*df2.groupby('variable').sem())
#print(df3.groupby('variable').mean(), 1.96*df3.groupby('variable').sem())
#print(df4.groupby('variable').mean(), 1.96*df4.groupby('variable').sem())
#print(df5.groupby('variable').mean(), 1.96*df5.groupby('variable').sem())
