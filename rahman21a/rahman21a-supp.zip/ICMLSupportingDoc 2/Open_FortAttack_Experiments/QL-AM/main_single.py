import argparse
import gym
import random
import lbforaging
from Agent import LSTMAgent
from torch.utils.tensorboard import SummaryWriter
import numpy as np
from gym.vector import AsyncVectorEnv
from stable_baselines.common.vec_env.subproc_vec_env import SubprocVecEnv
from datetime import date
import random
import string
import os
import json

parser = argparse.ArgumentParser()
parser.add_argument('--lr', type=float, default=1e-3, help='learning rate')
parser.add_argument('--gamma', type=float, default=0.99, help='dicount_rate')
parser.add_argument('--max_num_steps', type=int, default=400000, help="Number of episodes for training")
parser.add_argument('--eps_length', type=int, default=200, help="Number of episodes for training")
parser.add_argument('--update_frequency', type=int, default=4, help="Timesteps between updates")
parser.add_argument('--saving_frequency', type=int,default=50,help="saving frequency")
parser.add_argument('--with_gpu', type=bool,default=False,help="with gpu")
parser.add_argument('--num_envs', type=int,default=16, help="Number of environments")
parser.add_argument('--tau', type=float,default=0.001, help="tau")
parser.add_argument('--clip_grad', type=float,default=10.0, help="gradient clipping")
parser.add_argument('--eval_eps', type=int, default=5, help="Evaluation episodes")
parser.add_argument('--save_dir', type=str, default='parameters', help="parameter dir name")
parser.add_argument('--num_players_train', type=int, default=2, help="num players train")
parser.add_argument('--seed', type=int, default=0, help="seed")
parser.add_argument('--eval_init_seed', type=int, default=2500, help="seed")
parser.add_argument('--weight_predict', type=float, default=1.0, help="seed")

args = parser.parse_args()

if __name__ == '__main__':

    args = vars(args)

    num_players_train = 3
    num_players_test = 5

    def make_env(env_id, rank,  seed=1285, effective_max_num_players=3, with_shuffle=False, gnn_input=True,
                 with_gnn_shuffle=True):
        def _init():
            env = gym.make(
                env_id, seed=seed + rank,
                effective_max_num_players=effective_max_num_players,
                init_num_players=effective_max_num_players,
                with_shuffle=with_shuffle,
                with_gnn_shuffle = with_gnn_shuffle,
                gnn_input=gnn_input
            )
            return env

        return _init

    today = date.today()
    d1 = today.strftime("%d_%m_%Y")

    def randomString(stringLength=10):
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(stringLength))

    random_experiment_name = randomString(10)
    writer = SummaryWriter(log_dir="runs/"+random_experiment_name)
    directory = os.path.join(args['save_dir'], random_experiment_name)
    if not os.path.exists(directory):
        os.makedirs(directory)

    with open(os.path.join(directory,'params.json'), 'w') as json_file:
        json.dump(args, json_file)

    agent = LSTMAgent(args=args)
    env = AsyncVectorEnv(
        [make_env('Foraging-8x8-3f-v0', i,
        args['seed'], num_players_train)
        for i in range(args['num_envs'])]
    )

    save_dirs = os.path.join(directory, 'params_0')
    agent.save_parameters(save_dirs)

    # Test at train dataset
    avgs = []
    num_dones, per_worker_rew = [0] * args['num_envs'], [0] * args['num_envs']
    agent.reset(None)
    env_eval = AsyncVectorEnv(
        [make_env('Foraging-8x8-3f-v0', i,
                  args['eval_init_seed'], num_players_train)
         for i in range(args['num_envs'])]
    )

    obs = env_eval.reset()
    while (all([k < args['eval_eps'] for k in num_dones])):
        acts = agent.step(obs, eval=True)
        n_obs, rewards, dones, info = env_eval.step(acts)
        per_worker_rew = [k + l for k, l in zip(per_worker_rew, rewards)]
        obs = n_obs
        agent.reset(dones)

        for idx, flag in enumerate(dones):
            if flag:
                if num_dones[idx] < args['eval_eps']:
                    num_dones[idx] += 1
                    avgs.append(per_worker_rew[idx])
                per_worker_rew[idx] = 0

    avg_total_rewards = (sum(avgs) + 0.0) / len(avgs)
    print("Finished eval with rewards " + str(avg_total_rewards))
    env_eval.close()
    writer.add_scalar('Rewards/train_set', sum(avgs) / len(avgs), 0)

    # Test at test dataset
    avgs = []
    num_dones, per_worker_rew = [0] * args['num_envs'], [0] * args['num_envs']
    agent.reset(None)
    env_eval = AsyncVectorEnv(
        [make_env('Foraging-8x8-3f-v0', i,
                  args['eval_init_seed'], num_players_test)
         for i in range(args['num_envs'])]
    )

    obs = env_eval.reset()
    while (all([k < args['eval_eps'] for k in num_dones])):
        acts = agent.step(obs, eval=True)
        n_obs, rewards, dones, info = env_eval.step(acts)
        per_worker_rew = [k + l for k, l in zip(per_worker_rew, rewards)]
        obs = n_obs
        agent.reset(dones)

        for idx, flag in enumerate(dones):
            if flag:
                if num_dones[idx] < args['eval_eps']:
                    num_dones[idx] += 1
                    avgs.append(per_worker_rew[idx])
                per_worker_rew[idx] = 0

    avg_total_rewards = (sum(avgs) + 0.0) / len(avgs)
    print("Finished eval with rewards " + str(avg_total_rewards))
    env_eval.close()
    writer.add_scalar('Rewards/eval', sum(avgs) / len(avgs), 0)

    num_episode = args["max_num_steps"] // args["eps_length"]
    for ep_num in range(num_episode):
        print(ep_num)
        avgs = []
        num_dones, per_worker_rew = [0] * args['num_envs'], [0] * args['num_envs']

        obs = env.reset()
        agent.reset(None)
        agent.set_epsilon(max(1.0 - ((ep_num + 0.0) / 1500) * 0.95, 0.05))
        agent.compute_target(None, None, None, None, obs, add_storage=False)
        steps = 0

        while steps < args["eps_length"]:
            acts = agent.step(obs)
            n_obs, rewards, dones, info = env.step(acts)
            per_worker_rew = [k + l for k, l in zip(per_worker_rew, rewards)]
            agent.reset(dones)
            agent.compute_target(obs, rewards, acts, dones, n_obs, add_storage=True)
            obs = n_obs

            for idx, flag in enumerate(dones):
                if flag:
                    num_dones[idx] += 1
                    avgs.append(per_worker_rew[idx])
                    per_worker_rew[idx] = 0

            steps += 1
            if steps % args['update_frequency'] == 0:
                agent.update()

        train_avgs = (sum(avgs) + 0.0)/len(avgs)  if len(avgs) != 0 else 0.0
        writer.add_scalar('Rewards/train', train_avgs, ep_num)

        if (ep_num + 1) % args['saving_frequency'] == 0:
            save_dirs = os.path.join(directory, 'params_'+str((ep_num +
                                                               1) // args['saving_frequency']))
            agent.save_parameters(save_dirs)
            avgs = []
            num_dones, per_worker_rew = [0] * args['num_envs'], [0] * args['num_envs']
            agent.reset(None)
            env_eval = AsyncVectorEnv(
                [make_env('Foraging-8x8-3f-v0', i,
                          args['eval_init_seed'], num_players_train)
                 for i in range(args['num_envs'])]
            )

            obs = env_eval.reset()
            while (all([k < args['eval_eps'] for k in num_dones])):
                acts = agent.step(obs, eval=True)
                n_obs, rewards, dones, info = env_eval.step(acts)
                per_worker_rew = [k + l for k, l in zip(per_worker_rew, rewards)]
                obs = n_obs
                agent.reset(dones)

                for idx, flag in enumerate(dones):
                    if flag:
                        if num_dones[idx] < args['eval_eps']:
                            num_dones[idx] += 1
                            avgs.append(per_worker_rew[idx])
                        per_worker_rew[idx] = 0

            avg_total_rewards = (sum(avgs) + 0.0) / len(avgs)
            print("Finished eval with rewards " + str(avg_total_rewards))
            env_eval.close()
            writer.add_scalar('Rewards/train_set', sum(avgs) / len(avgs),
                              (ep_num + 1) // args['saving_frequency'])

            avgs = []
            num_dones, per_worker_rew = [0] * args['num_envs'], [0] * args['num_envs']
            agent.reset(None)
            env_eval = AsyncVectorEnv(
                [make_env('Foraging-8x8-3f-v0', i,
                          args['eval_init_seed'], num_players_test)
                 for i in range(args['num_envs'])]
            )

            obs = env_eval.reset()
            while (all([k < args['eval_eps'] for k in num_dones])):
                acts = agent.step(obs, eval=True)
                n_obs, rewards, dones, info = env_eval.step(acts)
                per_worker_rew = [k + l for k, l in zip(per_worker_rew, rewards)]
                obs = n_obs
                agent.reset(dones)

                for idx, flag in enumerate(dones):
                    if flag:
                        if num_dones[idx] < args['eval_eps']:
                            num_dones[idx] += 1
                            avgs.append(per_worker_rew[idx])
                        per_worker_rew[idx] = 0

            avg_total_rewards = (sum(avgs) + 0.0) / len(avgs)
            print("Finished eval with rewards " + str(avg_total_rewards))
            env_eval.close()
            writer.add_scalar('Rewards/eval', sum(avgs) / len(avgs),
                              (ep_num + 1) // args['saving_frequency'])



