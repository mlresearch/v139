#!/bin/bash

export OMP_NUM_THREADS=1
#source activate pytorch_p36
python train_open_env.py --reward-type="sparse" --lr=0.0001 --agent-type=-1
rm -rf Agent.py arguments.py main_single.py misc.py Network.py runner.sh

