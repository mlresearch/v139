import torch
import torch.nn as nn
import torch.nn.functional as F
import dgl.function as fn
import torch.distributions as dist
import dgl
from misc import gumbel_softmax, categorical_sample

class GATLayer(nn.Module):
    def __init__(self, in_dim, out_dim):
        super(GATLayer, self).__init__()
        # equation (1)
        self.fc_q = nn.Linear(in_dim, out_dim)
        self.fc_m = nn.Linear(in_dim, out_dim)
        self.fc_k = nn.Linear(in_dim, out_dim)

    def edge_attention(self, edges, tau=1.0):
        # edge UDF for equation (2)
        z2 = torch.sum(tau * edges.src['z_k'] * edges.dst['z_q'], dim=1, keepdim=True)
        return {'e': z2}

    def message_func(self, edges):
        # message UDF for equation (3) & (4)
        return {'z': edges.src['z_m'], 'e': edges.data['e']}

    def reduce_func(self, nodes):
        # reduce UDF for equation (3) & (4)
        # equation (3)
        alpha = F.softmax(nodes.mailbox['e'], dim=1)
        # equation (4)
        h = torch.sum(alpha * nodes.mailbox['z'], dim=1)
        return {'h': h}

    def forward(self, graph, h, tau=1.0):
        # equation (1)
        z_q = self.fc_q(h)
        z_k = self.fc_k(h)
        z_m = self.fc_m(h)

        graph.ndata['z_q'] = z_q
        graph.ndata['z_k'] = z_k
        graph.ndata['z_m'] = z_m

        # equation (2)
        edge_attention_func = lambda x: self.edge_attention(edges=x, tau=tau)
        graph.apply_edges(edge_attention_func)
        # equation (3) & (4)
        graph.update_all(self.message_func, self.reduce_func)
        results = graph.ndata['h']

        e_keys = list(graph.edata.keys())
        n_keys = list(graph.ndata.keys())

        for key in e_keys:
            graph.edata.pop(key)
        for key in n_keys:
            graph.ndata.pop(key)

        return results

class MultiHeadGATLayer(nn.Module):
    def __init__(self, in_dim, hid_dim, out_dim, num_heads, merge='cat', tau=0.3):
        super(MultiHeadGATLayer, self).__init__()
        self.heads = nn.ModuleList()
        for i in range(num_heads):
            self.heads.append(GATLayer(in_dim, hid_dim))
        self.merge = merge

        if self.merge == "cat":
            self.fc_out = nn.Linear(hid_dim * num_heads, out_dim)
        else:
            self.fc_out = nn.Linear(hid_dim, out_dim)

        self.tau=tau

    def forward(self, graph, h):
        head_outs = [attn_head(graph, h, tau=self.tau) for attn_head in self.heads]
        if self.merge == 'cat':
            # concat on the output feature dimension (dim=1)
            return F.relu(self.fc_out(torch.cat(head_outs, dim=1)))
        else:
            # merge using average
            return F.relu(self.fc_out(torch.mean(torch.stack(head_outs))))

class RFMBlock(nn.Module):
    def __init__(self, dim_in_node, dim_in_edge, dim_in_u, hidden_dim, dim_out):
        super(RFMBlock, self).__init__()
        self.fc_edge = nn.Linear(dim_in_edge,hidden_dim)
        self.fc_edge2 = nn.Linear(hidden_dim, dim_out)
        self.fc_node = nn.Linear(dim_in_node, hidden_dim)
        self.fc_node2 = nn.Linear(hidden_dim, dim_out)
        self.fc_u = nn.Linear(dim_in_u, hidden_dim)
        self.fc_u2 = nn.Linear(hidden_dim, dim_out)
        self.dim_out = dim_out
        # Check Graph batch

        self.graph_msg = fn.copy_edge(edge='edge_feat', out='m')
        self.graph_reduce = fn.sum(msg='m', out='h')

    def graph_message_func(self,edges):
        return {'m': edges.data['edge_feat'] }

    def graph_reduce_func(self,nodes):
        msgs = torch.sum(nodes.mailbox['m'], dim=1)
        return {'h': msgs}

    def compute_edge_repr(self, graph, edges, g_repr):
        edge_nums = graph.batch_num_edges
        u = torch.cat([g[None,:].repeat(num_edge,1) for g, num_edge
                       in zip(g_repr,edge_nums) if num_edge != 0], dim=0)
        inp = torch.cat([edges.data['edge_feat'],edges.src['node_feat'],edges.dst['node_feat'], u], dim=-1)
        return {'edge_feat' : self.fc_edge2(F.relu(self.fc_edge(inp)))}

    def compute_node_repr(self, graph, nodes, g_repr):
        node_nums = graph.batch_num_nodes
        u = torch.cat([g[None, :].repeat(num_node, 1) for g, num_node
                       in zip(g_repr, node_nums)], dim=0)

        if 'h' not in nodes.data.keys():
            messages = torch.zeros([nodes.data['node_feat'].shape[0], self.dim_out])
        else:
            messages = nodes.data['h']
        inp = torch.cat([nodes.data['node_feat'], messages, u], dim=-1)
        return {'node_feat' : self.fc_node2(F.relu(self.fc_node(inp)))}

    def compute_u_repr(self, n_comb, e_comb, g_repr):
        inp = torch.cat([n_comb, e_comb, g_repr], dim=-1)
        return self.fc_u2(F.relu(self.fc_u(inp)))

    def forward(self, graph, edge_feat, node_feat, g_repr):
        node_trf_func = lambda x: self.compute_node_repr(nodes=x, graph=graph, g_repr=g_repr)

        graph.edata['edge_feat'] = edge_feat
        graph.ndata['node_feat'] = node_feat
        edge_trf_func = lambda x : self.compute_edge_repr(edges=x, graph=graph, g_repr=g_repr)

        graph.apply_edges(edge_trf_func)
        graph.update_all(self.graph_message_func, self.graph_reduce_func, node_trf_func)

        e_comb = dgl.sum_edges(graph, 'edge_feat')
        n_comb = dgl.sum_nodes(graph, 'node_feat')

        e_out = graph.edata['edge_feat']
        n_out = graph.ndata['node_feat']

        e_keys = list(graph.edata.keys())
        n_keys = list(graph.ndata.keys())
        for key in e_keys:
            graph.edata.pop(key)
        for key in n_keys:
            graph.ndata.pop(key)

        return e_out, n_out, self.compute_u_repr(n_comb, e_comb, g_repr)

class RFMBlockPseudolikelihood(nn.Module):
    def __init__(self, dim_in_node, dim_in_edge, dim_in_u, hidden_dim, dim_out, act_dims):
        super(RFMBlockPseudolikelihood, self).__init__()
        self.fc_edge = nn.Linear(dim_in_edge+act_dims,hidden_dim)
        self.fc_edge2 = nn.Linear(hidden_dim, dim_out)
        self.fc_node = nn.Linear(dim_in_node, hidden_dim)
        self.fc_node2 = nn.Linear(hidden_dim, dim_out)
        self.dim_out = dim_out
        self.fc_u = nn.Linear(dim_in_u, hidden_dim)
        self.fc_u2 = nn.Linear(hidden_dim, dim_out)
        # Check Graph batch

        self.graph_msg = fn.copy_edge(edge='edge_feat', out='m')
        self.graph_reduce = fn.sum(msg='m', out='h')

    def graph_message_func(self,edges):
        return {'m': edges.data['edge_feat'] }

    def graph_reduce_func(self,nodes):
        msgs = torch.sum(nodes.mailbox['m'], dim=1)
        return {'h': msgs}

    def compute_edge_repr(self, graph, edges, g_repr):
        edge_nums = graph.batch_num_edges
        u = torch.cat([g[None,:].repeat(num_edge,1) for g, num_edge
                       in zip(g_repr,edge_nums) if num_edge != 0], dim=0)
        inp = torch.cat([edges.data['edge_feat'],edges.src['node_feat'], edges.src['add_acts'],
                         edges.dst['node_feat'], u], dim=-1)
        return {'edge_feat' : self.fc_edge2(F.relu(self.fc_edge(inp)))}

    def compute_node_repr(self, graph, nodes, g_repr):
        node_nums = graph.batch_num_nodes
        u = torch.cat([g[None, :].repeat(num_node, 1) for g, num_node
                       in zip(g_repr, node_nums)], dim=0)

        if 'h' not in nodes.data.keys():
            messages = torch.zeros([nodes.data['node_feat'].shape[0], self.dim_out])
        else:
            messages = nodes.data['h']

        inp = torch.cat([nodes.data['node_feat'], messages, u], dim=-1)
        return {'node_feat' : self.fc_node2(F.relu(self.fc_node(inp)))}

    def compute_u_repr(self, n_comb, e_comb, g_repr):
        inp = torch.cat([n_comb, e_comb, g_repr], dim=-1)
        return self.fc_u2(F.relu(self.fc_u(inp)))

    def forward(self, graph, edge_feat, node_feat, g_repr, add_acts):
        node_trf_func = lambda x: self.compute_node_repr(nodes=x, graph=graph, g_repr=g_repr)

        graph.edata['edge_feat'] = edge_feat
        graph.ndata['node_feat'] = node_feat
        graph.ndata['add_acts'] = add_acts
        edge_trf_func = lambda x : self.compute_edge_repr(edges=x, graph=graph, g_repr=g_repr)

        graph.apply_edges(edge_trf_func)
        graph.update_all(self.graph_message_func, self.graph_reduce_func, node_trf_func)

        e_comb = dgl.sum_edges(graph, 'edge_feat')
        n_comb = dgl.sum_nodes(graph, 'node_feat')

        e_out = graph.edata['edge_feat']
        n_out = graph.ndata['node_feat']

        e_keys = list(graph.edata.keys())
        n_keys = list(graph.ndata.keys())
        for key in e_keys:
            graph.edata.pop(key)
        for key in n_keys:
            graph.ndata.pop(key)

        return e_out, n_out, self.compute_u_repr(n_comb, e_comb, g_repr)

class OppoModelNet(nn.Module):
    def __init__(self, dim_in_node, dim_in_u, hidden_dim,
                 dim_lstm_out, dim_mid, dim_out, act_dims,
                 dim_last, rfm_hidden_dim, last_hidden):
        super(OppoModelNet, self).__init__()
        self.dim_lstm_out = dim_lstm_out
        self.act_dims = act_dims

        self.mlp1a = nn.Linear(dim_in_node + dim_in_u, hidden_dim)
        self.mlp1b = nn.Linear(hidden_dim, dim_mid)
        self.lstm1 = nn.LSTM(dim_mid, dim_lstm_out, batch_first=True)
        self.mlp1 = nn.Linear(dim_lstm_out, dim_out)

        self.mlp1_readout = nn.Linear(dim_last, last_hidden)
        self.mlp1_readout2 = nn.Linear(last_hidden, act_dims)

        self.mlp2a = nn.Linear(dim_in_node + dim_in_u, hidden_dim)
        self.mlp2b = nn.Linear(hidden_dim, dim_mid)
        self.lstm2 = nn.LSTM(dim_mid, dim_lstm_out, batch_first=True)
        self.mlp2 = nn.Linear(dim_lstm_out, dim_out)

        self.mlp2_readout = nn.Linear(dim_last, last_hidden)
        self.mlp2_readout2 = nn.Linear(last_hidden, act_dims)

        self.GNBlock_theta = RFMBlock(dim_last+dim_out, 2*dim_out, 2*dim_last, rfm_hidden_dim,
                                 dim_last)
        self.GNBlock_pi = RFMBlockPseudolikelihood(dim_last+dim_out, 2*dim_out, 2*dim_last, rfm_hidden_dim,
                                 dim_last, act_dims)

    def forward(self, graph, obs, hidden_n, mode="theta", add_acts=None):

        if mode == "theta":
            updated_n_feat = self.mlp1b(F.relu(self.mlp1a(obs)))
            updated_n_feat, n_hid = self.lstm1(updated_n_feat.view(updated_n_feat.shape[0], 1, -1), hidden_n)
            updated_n_feat = self.mlp1(F.relu(updated_n_feat.squeeze(1)))

            edge_feat = torch.zeros([graph.number_of_edges(), 0])
            g_repr = torch.zeros([len(graph.batch_num_nodes), 0])

            updated_e_feat, updated_n_feat, updated_u_feat = self.GNBlock_theta.forward(graph, edge_feat,
                                                                                  updated_n_feat, g_repr)

            return self.mlp1_readout2(F.relu(self.mlp1_readout(updated_n_feat))), n_hid

        updated_n_feat = self.mlp2b(F.relu(self.mlp2a(obs)))
        updated_n_feat, n_hid = self.lstm2(updated_n_feat.view(updated_n_feat.shape[0], 1, -1), hidden_n)
        updated_n_feat = self.mlp2(F.relu(updated_n_feat.squeeze(1)))

        edge_feat = torch.zeros([graph.number_of_edges(), 0])
        g_repr = torch.zeros([len(graph.batch_num_nodes), 0])

        updated_e_feat, updated_n_feat, updated_u_feat = self.GNBlock_pi.forward(graph, edge_feat,
                                                                                 updated_n_feat, g_repr,
                                                                                 add_acts)

        return self.mlp2_readout2(F.relu(self.mlp2_readout(updated_n_feat))), n_hid

class GraphLSTM(nn.Module):
    def __init__(self, dim_in_node, dim_in_edge, dim_in_u, dim_out, unbatch_return_feats=True):
        super(GraphLSTM, self).__init__()
        self.lstm_edge = nn.LSTM(dim_in_edge, dim_out, batch_first=True)
        self.lstm_node = nn.LSTM(dim_in_node, dim_out, batch_first=True)
        self.lstm_u = nn.LSTM(dim_in_u, dim_out, batch_first=True)

        self.graph_msg = fn.copy_edge(edge='edge_feat', out='m')
        self.graph_reduce = fn.sum(msg='m', out='h')
        self.unbatch_return_feats = unbatch_return_feats

    def graph_message_func(self,edges):
        return {'m': edges.data['edge_feat']}

    def graph_reduce_func(self,nodes):
        msgs = torch.sum(nodes.mailbox['m'], dim=1)
        return {'h': msgs}

    def compute_edge_repr(self, graph, edges, g_repr):
        edge_nums = graph.batch_num_edges
        u = torch.cat([g[None, :].repeat(num_edge, 1) for g, num_edge
                       in zip(g_repr, edge_nums) if num_edge != 0], dim=0)
        inp = torch.cat([edges.data['edge_feat'], edges.src['node_feat'],
                         edges.dst['node_feat'], u], dim=-1)[:,None,:]
        hidden = (edges.data['hidden1'][None,:,:], edges.data['hidden2'][None,:,:])
        out, hidden = self.lstm_edge(inp, hidden)
        out_shape = out.shape
        out = out.view([out_shape[0], out_shape[2]])
        return {'edge_feat': F.relu(out), 'hidden1' : hidden[0][0], 'hidden2' : hidden[1][0]}

    def compute_node_repr(self, graph, nodes, g_repr):
        node_nums = graph.batch_num_nodes
        u = torch.cat([g[None, :].repeat(num_node, 1) for g, num_node
                       in zip(g_repr, node_nums)], dim=0)
        inp = torch.cat([nodes.data['node_feat'], nodes.data['h'], u], dim=-1)[:,None,:]
        hidden = (nodes.data['hidden1'][None,:,:], nodes.data['hidden2'][None,:,:])
        out, hidden = self.lstm_node(inp, hidden)
        out_shape = out.shape
        out = out.view([out_shape[0], out_shape[2]])
        return {'node_feat' : F.relu(out), 'hidden1' : hidden[0][0], 'hidden2' : hidden[1][0]}

    def compute_u_repr(self, n_comb, e_comb, g_repr, hidden):
        inp = torch.cat([n_comb, e_comb, g_repr], dim=-1)[:,None,:]
        out, hidden = self.lstm_u(inp, hidden)
        out_shape = out.shape
        out = out.view([out_shape[0], out_shape[2]])
        return F.relu(out), hidden


    def forward(self, graph, edge_feat, node_feat, g_repr, edge_hidden, node_hidden, graph_hidden):

        graph.edata['edge_feat'] = edge_feat
        graph.ndata['node_feat'] = node_feat
        graph.edata['hidden1'] = edge_hidden[0][0]
        graph.ndata['hidden1'] = node_hidden[0][0]
        graph.edata['hidden2'] = edge_hidden[1][0]
        graph.ndata['hidden2'] = node_hidden[1][0]

        node_trf_func = lambda x : self.compute_node_repr(nodes=x, graph=graph, g_repr=g_repr)
        edge_trf_func = lambda x: self.compute_edge_repr(edges=x, graph=graph, g_repr=g_repr)
        graph.apply_edges(edge_trf_func)
        graph.update_all(self.graph_message_func, self.graph_reduce_func, node_trf_func)

        e_comb = dgl.sum_edges(graph, 'edge_feat')
        n_comb = dgl.sum_nodes(graph, 'node_feat')

        u_out, u_hidden = self.compute_u_repr(n_comb, e_comb, g_repr, graph_hidden)

        e_feat = graph.edata['edge_feat']
        n_feat = graph.ndata['node_feat']

        h_e = (torch.unsqueeze(graph.edata['hidden1'],0),torch.unsqueeze(graph.edata['hidden2'],0))
        h_n =  (torch.unsqueeze(graph.ndata['hidden1'],0),torch.unsqueeze(graph.ndata['hidden2'],0))

        e_keys = list(graph.edata.keys())
        n_keys = list(graph.ndata.keys())
        for key in e_keys:
            graph.edata.pop(key)
        for key in n_keys:
            graph.ndata.pop(key)

        return e_feat, h_e, n_feat, h_n, u_out, u_hidden

class MRFLayer(nn.Module):
    def __init__(self, dim_in_node, mid_pair, mid_nodes, mid_edge_class, num_acts,
                 pair_comp="avg", edge_filt="gumbel", f_train_method="lbp", q_train_method="avg",
                 mid_pair_out=8, device=None):
        super(MRFLayer, self).__init__()
        self.pair_comp = pair_comp
        self.edge_filt = edge_filt
        self.mid_pair = mid_pair
        self.num_acts = num_acts

        self.f_train_method = f_train_method
        self.q_train_method = q_train_method

        if self.pair_comp=="bmm":
            self.jf1 = nn.Linear(2*dim_in_node, self.mid_pair)
            self.ju1 = nn.Linear(3*dim_in_node, self.mid_pair)
        else:
            self.jf1 = nn.Linear(2*dim_in_node, self.mid_pair)
            self.ju1 = nn.Linear(3*dim_in_node, self.mid_pair)

        if self.pair_comp=="bmm":
            self.mid_pair_out = mid_pair_out
            self.jf2 = nn.Linear(self.mid_pair,num_acts*self.mid_pair_out)
            self.ju2 = nn.Linear(self.mid_pair,num_acts*self.mid_pair_out)
        else:
            self.jf2 = nn.Linear(self.mid_pair, num_acts * num_acts)
            self.ju2 = nn.Linear(self.mid_pair, num_acts * num_acts)

        self.if1 = nn.Linear(dim_in_node, mid_nodes)
        self.if2 = nn.Linear(mid_nodes, num_acts)
        self.iu1 = nn.Linear(2*dim_in_node, mid_nodes)
        self.iu2 = nn.Linear(mid_nodes, num_acts)

        self.mid_edge_class = mid_edge_class
        self.edge_flag_repr = nn.Linear(2*dim_in_node, self.mid_edge_class)
        self.edge_flag_repr_u = nn.Linear(3*dim_in_node, self.mid_edge_class)
        self.edge_classifier = nn.Linear(self.mid_edge_class, 2)
        self.edge_classifier_u = nn.Linear(self.mid_edge_class, 2)

        self.mid_pair = mid_pair
        self.num_acts = num_acts
        self.device = device

        if self.device is None:
            self.device = 'cuda' if torch.cuda.is_available() else 'cpu'

    def compute_node_data(self, nodes):
        return {'indiv_factor': self.if2(F.relu(self.if1(nodes.data['node_feat']))),
                'indiv_util': self.iu2(F.relu(self.iu1(nodes.data['node_feat_u'])))}

    def compute_edge_data(self, edges, graph, evaluate=False, gumbel_temp=None,
                          target_edges=None, target_edges_f=None):
        inp = edges.data['edge_feat']
        inp_reflected = edges.data['edge_feat_reflected']
        inp_u = edges.data['edge_feat_u']
        inp_reflected_u = edges.data['edge_feat_reflected_u']

        if self.pair_comp == 'bmm':
            # Compute the factor components.
            factor_comp = self.jf2(F.relu(self.jf1(inp))).view(-1,self.num_acts, self.mid_pair_out)
            factor_comp_reflected = self.jf2(F.relu(self.jf1(inp_reflected))).view(-1,self.num_acts,
                                                                                   self.mid_pair_out).permute(0,2,1)
            # Compute the util components
            util_comp = self.ju2(F.relu(self.ju1(inp_u))).view(-1,self.num_acts, self.mid_pair_out)
            util_comp_reflected = self.ju2(F.relu(self.ju1(inp_reflected_u))).view(-1,self.num_acts,
                                                                                   self.mid_pair_out).permute(0,2,1)

            factor_vals = torch.bmm(factor_comp, factor_comp_reflected).permute(0,2,1)
            util_vals = torch.bmm(util_comp, util_comp_reflected).permute(0,2,1)
        else:
            factor_comp = self.jf2(F.relu(self.jf1(inp))).view(-1,self.num_acts, self.num_acts)
            factor_comp_reflected = self.jf2(F.relu(self.jf1(inp_reflected))).view(-1,self.num_acts,
                                                                                   self.num_acts).permute(0,2,1)

            util_comp = self.ju2(F.relu(self.ju1(inp_u))).view(-1, self.num_acts, self.num_acts)
            util_comp_reflected = self.ju2(F.relu(self.ju1(inp_reflected_u))).view(-1, self.num_acts,
                                                                                 self.num_acts).permute(0,2,1)

            factor_vals = ((factor_comp + factor_comp_reflected)/2.0).permute(0,2,1)
            util_vals = ((util_comp + util_comp_reflected)/2.0).permute(0,2,1)

        # Compute representation of edge for edge existence computation
        edge_flag_repr, edge_flag_repr_ref = self.edge_flag_repr(inp.detach()), self.edge_flag_repr(inp_reflected.detach())
        edge_flag_repr_sum = F.relu((edge_flag_repr + edge_flag_repr_ref)/2.0)
        edge_flags_logits = self.edge_classifier(edge_flag_repr_sum)

        edge_flag_repr_u, edge_flag_repr_ref_u = self.edge_flag_repr_u(inp_u.detach()), self.edge_flag_repr_u(inp_reflected_u.detach())
        edge_flag_repr_sum_u = F.relu((edge_flag_repr_u + edge_flag_repr_ref_u) / 2.0)
        edge_flags_u_logits = self.edge_classifier_u(edge_flag_repr_sum_u)

        edge_flags = target_edges_f
        if edge_flags is None:
            edge_flags = gumbel_softmax(edge_flags_logits, graph, hard=True, temperature=gumbel_temp, evaluate=evaluate)
        default_m = torch.zeros([edge_flags.shape[0], 1, self.num_acts]).to(self.device)

        edge_flags_u = target_edges
        if edge_flags_u is None:
            edge_flags_u = categorical_sample(edge_flags_u_logits, graph)
        log_edges = dist.Categorical(logits=edge_flags_u_logits).log_prob(1-edge_flags_u[:,0])

        edge_factors = factor_vals.unsqueeze(1)
        default_edge_factors = torch.zeros_like(edge_factors)
        used_factors = torch.cat([edge_factors,
                                default_edge_factors], dim=1)
        used_factors_shape = used_factors.shape
        used_factors_mult = used_factors.view(used_factors_shape[0], used_factors_shape[1], -1)

        edge_flags_entry = torch.unsqueeze(edge_flags, -1)
        edge_flags_u_entry = torch.unsqueeze(edge_flags_u, -1)

        # Try printing used_factors_mult * edge_flags_entry.detach()
        final_factor = (used_factors_mult * edge_flags_entry.detach()).sum(dim=1).view(used_factors_shape[0],
                                                                                        used_factors_shape[-1],
                                                                                        used_factors_shape[-1])

        util_factors = util_vals.unsqueeze(1)
        default_edge_u_factors = torch.zeros_like(util_factors)
        used_u_factors = torch.cat([util_factors,
                                    default_edge_u_factors], dim=1)
        used_u_factors_shape = used_u_factors.shape
        used_u_factors_mult = used_u_factors.view(used_u_factors_shape[0], used_u_factors_shape[1], -1)

        final_u_factor = (used_u_factors_mult * edge_flags_u_entry.detach()).sum(dim=1).view(used_u_factors_shape[0],
                                                                                        used_u_factors_shape[-1],
                                                                                        used_u_factors_shape[-1])
        reflected_factor_vals = final_factor.permute(0, 2, 1)
        reflected_util_vals = final_u_factor.permute(0, 2, 1)

        return {'factor_vals': final_factor, 'util_vals': final_u_factor,
                'reflected_factor_vals': reflected_factor_vals,
                'reflected_util_vals': reflected_util_vals,
                'default_m': default_m,
                'edge_filt_logits': edge_flags_logits,
                'edge_filt_logits_u': edge_flags_u_logits,
                'edge_flags': edge_flags_entry,
                'log_edges_u': log_edges,
                'edge_flags_u': edge_flags_u_entry}

    def graph_edge_update_func(self, edges, graph):

        # Compute forward message for edge
        aggregated_msg = edges.src['model_msg'] - edges.data['reverse_msg'] + edges.src['indiv_factor']
        m = edges.data['factor_vals'] + aggregated_msg.unsqueeze(1)
        m_sum = torch.unsqueeze(torch.logsumexp(m,-1), 1)
        msg = (torch.cat([m_sum,edges.data['default_m']], dim=1) * edges.data['edge_flags']).sum(dim=1)

        # Compute reverse message for edge
        aggregated_msg_reverse = (edges.dst['model_msg'] - edges.data['msg']) + edges.dst['indiv_factor']
        m_rev = edges.data['reflected_factor_vals'] + torch.unsqueeze(aggregated_msg_reverse,1)
        m_rev_sum = torch.unsqueeze(torch.logsumexp(m_rev,-1),1)
        msg_rev = (torch.cat([m_rev_sum,edges.data['default_m']], dim=1) *
                    edges.data['edge_flags']).sum(dim=1)

        # Compute forward util for edge
        util = (edges.src['util_msg'] -
                edges.data['reverse_util_msg']) + edges.src['indiv_util']
        total_util_msg = edges.data['util_vals'] + torch.unsqueeze(util, 1)
        m_normalized = torch.softmax(m, dim=-1)
        util_msg = torch.unsqueeze((total_util_msg * m_normalized.detach()).sum(dim=-1), 1)
        util_msg = (torch.cat([util_msg,edges.data['default_m']], dim=1) * edges.data['edge_flags_u']).sum(dim=1)

        # Compute backward util for edge
        rev_util = (edges.dst['util_msg'] -
                edges.data['util_msg']) + edges.dst['indiv_util']
        rev_total_util_msg = edges.data['reflected_util_vals'] + torch.unsqueeze(rev_util, 1)
        m_rev_normalized = torch.softmax(m_rev, dim=-1)
        rev_util_msg = torch.unsqueeze((rev_total_util_msg * m_rev_normalized.detach()).sum(dim=-1), 1)
        rev_util_msg = (torch.cat([rev_util_msg,
                        edges.data['default_m']], dim=1) *
                        edges.data['edge_flags_u']).sum(dim=1)

        graph.edata['msg'] = msg
        graph.edata['reverse_msg'] = msg_rev
        graph.edata['util_msg'] = util_msg
        graph.edata['reverse_util_msg'] = rev_util_msg

        return {'msg': msg, 'util_msg': util_msg}

    def graph_lbp_update_func(self, edges, graph):
        aggregated_msg = edges.src['model_msg'] - edges.data['reverse_msg'] + edges.src['indiv_factor']

        m = edges.data['factor_vals'] + torch.unsqueeze(aggregated_msg, 1)
        log_m = torch.logsumexp(m, -1)
        m_sum = torch.unsqueeze(log_m, 1)
        msg = (torch.cat([m_sum, edges.data['default_m']], dim=1) * edges.data['edge_flags']).sum(dim=1)

        # Compute reverse message for edge
        aggregated_msg_reverse = (edges.dst['model_msg'] - edges.data['msg']) + edges.dst['indiv_factor']
        m_rev = edges.data['reflected_factor_vals'] + torch.unsqueeze(aggregated_msg_reverse, 1)
        log_m_rev = torch.logsumexp(m_rev, -1)
        m_rev_sum = torch.unsqueeze(log_m_rev, 1)
        msg_rev = (torch.cat([m_rev_sum, edges.data['default_m']], dim=1) *
                    edges.data['edge_flags']).sum(dim=1)

        graph.edata['msg'] = msg
        graph.edata['reverse_msg'] = msg_rev

        return {'msg': msg}

    def graph_reduce_func(self, nodes, mode="inf"):
        mod_msg = torch.sum(nodes.mailbox['msg'], dim=1)
        if mode=="inf":
            util_msg = torch.sum(nodes.mailbox['util_msg'], dim=1)
            return {'model_msg': mod_msg, 'util_msg': util_msg}
        else:
            return {'model_msg': mod_msg}

    def graph_uf_product(self, graph, edges, acts):
        src, dst = graph.edges()
        acts_src = torch.Tensor([acts[idx] for idx in src.tolist()])

        m = edges.data['factor_vals']
        reshaped_acts = acts_src.view(m.shape[0], 1, -1).long().repeat(1, self.num_acts, 1)
        m = m.gather(-1, reshaped_acts).permute(0, 2, 1)
        msg = (torch.cat([m, edges.data['default_m']], dim=1) * edges.data['edge_flags']).sum(dim=1)

        u = edges.data['util_vals']
        u = u.gather(-1, reshaped_acts).permute(0,2,1)
        u_msg = (torch.cat([u, edges.data['default_m']], dim=1) * edges.data['edge_flags_u']).sum(dim=1)

        return {'f_msg':msg, 'u_msg': u_msg}

    def graph_sum_all(self, nodes):
        mod_msg = torch.sum(nodes.mailbox['f_msg'], dim=1)
        util_msg = torch.sum(nodes.mailbox['u_msg'], dim=1)
        return {'f_msg_prod':mod_msg, 'u_msg_sum': util_msg }

    def forward(self, graph, edge_feats, node_feats, edge_feat_reflected,
                edge_feats_u, node_feats_u, edge_feat_reflected_u,
                mode="train", joint_acts=None,
                evaluate=False, gumbel_temp=None, graph_learning=False,
                target_edges=None, target_edges_f=None):

        graph.edata['edge_feat'] = edge_feats
        graph.edata['edge_feat_u'] = edge_feats_u
        graph.edata['edge_feat_reflected'] = edge_feat_reflected
        graph.edata['edge_feat_reflected_u'] = edge_feat_reflected_u
        graph.ndata['node_feat'] = node_feats
        graph.ndata['node_feat_u'] = node_feats_u

        n_weights = torch.zeros([node_feats.shape[0],1])

        zero_indexes, offset = [0], 0
        num_nodes = graph.batch_num_nodes

        for a in num_nodes[:-1]:
            offset += a
            zero_indexes.append(offset)

        n_weights[zero_indexes] = 1
        graph.ndata['weights'] = n_weights
        graph.ndata['mod_weights'] = 1-n_weights

        graph.apply_nodes(lambda x: self.compute_node_data(x))
        computed_edge_data = lambda x : self.compute_edge_data(
            x, graph, evaluate=evaluate, gumbel_temp=gumbel_temp,
            target_edges=target_edges,
            target_edges_f=target_edges_f
        )
        graph.apply_edges(computed_edge_data)

        if mode == "inference":

            graph.ndata['model_msg'] = torch.zeros_like(graph.ndata['indiv_factor']).to(self.device)
            graph.edata['reverse_msg'] = torch.zeros(graph.number_of_edges(),self.num_acts).to(self.device)
            graph.edata['msg'] = torch.zeros(graph.number_of_edges(),self.num_acts).to(self.device)

            graph.ndata['util_msg'] = torch.zeros_like(graph.ndata['indiv_util']).to(self.device)
            graph.edata['util_msg'] = torch.zeros(graph.number_of_edges(),self.num_acts).to(self.device)
            graph.edata['reverse_util_msg'] = torch.zeros(graph.number_of_edges(),self.num_acts).to(self.device)

            edge_update_fun = lambda x : self.graph_edge_update_func(x, graph=graph)
            g_lists = graph.batch_num_nodes
            for a in range(max(g_lists)):
                graph.update_all(message_func=edge_update_fun, reduce_func=self.graph_reduce_func)

            graph.ndata['total_all'] = graph.ndata['util_msg'] + graph.ndata['indiv_util']
            returned_values = dgl.sum_nodes(graph, 'total_all', 'weights')
            dgl_node_feat = dgl.sum_nodes(graph, 'node_feat_u', 'weights')
            dgl_edge_log_total = dgl.sum_edges(graph, 'log_edges_u')

            e_keys = list(graph.edata.keys())
            n_keys = list(graph.ndata.keys())

            gumbel_logits_u = graph.edata['edge_filt_logits_u']
            all_edges = graph.edata['edge_flags_u']
            all_edges_f = graph.edata['edge_flags']

            for key in e_keys:
                graph.edata.pop(key)

            for key in n_keys:
                graph.ndata.pop(key)

            return returned_values, gumbel_logits_u, all_edges.squeeze(-1), dgl_edge_log_total/2.0, dgl_node_feat, \
                   all_edges_f.squeeze(-1)

        graph.ndata['model_msg'] = torch.zeros_like(graph.ndata['indiv_factor']).to(self.device)
        graph.edata['reverse_msg'] = torch.zeros(graph.number_of_edges(), self.num_acts).to(self.device)
        graph.edata['msg'] = torch.zeros(graph.number_of_edges(), self.num_acts).to(self.device)

        graph.ndata['util_msg'] = torch.zeros_like(graph.ndata['indiv_util']).to(self.device)
        graph.edata['util_msg'] = torch.zeros(graph.number_of_edges(), self.num_acts).to(self.device)
        graph.edata['reverse_util_msg'] = torch.zeros(graph.number_of_edges(), self.num_acts).to(self.device)

        m_func = lambda x: self.graph_uf_product(graph, x, joint_acts)
        graph.update_all(message_func=m_func,
                        reduce_func=self.graph_sum_all)

        indiv_f_zeros = graph.ndata['indiv_factor']
        f_msg_prod_zeros = graph.ndata['f_msg_prod']
        indiv_u_zeros = graph.ndata['indiv_util']
        u_msg_sum_zeros = 0.5 * graph.ndata['u_msg_sum']

        graph.ndata['selected_softmaxes'] = F.log_softmax(indiv_f_zeros + f_msg_prod_zeros, dim=-1).gather(-1,
                                                            torch.Tensor(joint_acts)[:,None].long())
        graph.ndata['utils_sum_all'] = (indiv_u_zeros + u_msg_sum_zeros).gather(-1, torch.Tensor(joint_acts)[:,None].long())
        f_values = dgl.sum_nodes(graph, 'selected_softmaxes', 'mod_weights')
        q_values = dgl.sum_nodes(graph, 'utils_sum_all')

        perc_edges = dgl.mean_edges(graph, 'edge_flags')[:,0,:]
        f_edges = perc_edges
        gumbel_logits = graph.edata['edge_filt_logits']

        e_keys = list(graph.edata.keys())
        n_keys = list(graph.ndata.keys())

        for key in e_keys:
            graph.edata.pop(key)

        for key in n_keys:
            graph.ndata.pop(key)

        return f_values, f_edges, gumbel_logits, q_values

class RFMLSTMMiddle(nn.Module):
    def __init__(self, dim_in_node, dim_in_edge, dim_in_u, hidden_dim, hidden_dim2, dim_lstm_out, dim_mid, dim_out,
                 fin_mid_dim, act_dims, with_added_u_feat=False, added_u_feat_dim=0, mode="dqn",
                 with_oppo_modelling=False):
        super(RFMLSTMMiddle, self).__init__()
        self.dim_lstm_out = dim_lstm_out
        self.mode = mode
        self.with_added_u_feat = with_added_u_feat
        self.with_oppo_modelling = with_oppo_modelling

        if not self.with_added_u_feat:
            self.GNBlock = RFMBlock(dim_mid+ dim_in_node + dim_in_u,
                                2 * dim_in_node + dim_in_u + dim_in_edge,
                               	2 * dim_mid + dim_in_u, hidden_dim,
                                dim_mid)
        else:
            self.GNBlock = RFMBlock(dim_mid + dim_in_node + dim_in_u + added_u_feat_dim,
                                    2 * dim_in_node + dim_in_u + dim_in_edge + added_u_feat_dim,
                                    2 * dim_mid + dim_in_u + added_u_feat_dim, hidden_dim,
                                    dim_mid)
        self.GraphLSTM = GraphLSTM(dim_lstm_out+2*dim_mid, 4*dim_mid, 2*dim_lstm_out + dim_mid, dim_lstm_out)
        self.GNBlock2 = RFMBlock(dim_out+2*dim_lstm_out, 4*dim_lstm_out, 2*dim_out + dim_lstm_out, hidden_dim2,
                                 dim_out)

        self.pre_q_net = nn.Linear(dim_out, fin_mid_dim)
        self.q_net = nn.Linear(fin_mid_dim, act_dims)

        if self.with_oppo_modelling:
            self.pre_act_pred_model = nn.Linear(dim_out, fin_mid_dim)
            self.act_pred_model = nn.Linear(fin_mid_dim, act_dims)



    def forward(self, graph, edge_feat, node_feat, u_obs, hidden_e, hidden_n, hidden_u, added_u_feat=None):

        g_repr = u_obs

        updated_e_feat, updated_n_feat, updated_u_feat = self.GNBlock.forward(graph, edge_feat,
                                                                              node_feat, g_repr)
        updated_e_feat, e_hid, updated_n_feat, n_hid, updated_u_feat, u_hid = self.GraphLSTM.forward(graph,
                                                                              updated_e_feat, updated_n_feat,
                                                                              updated_u_feat, hidden_e,
                                                                              hidden_n, hidden_u)
        updated_e_feat, updated_n_feat, updated_u_feat = self.GNBlock2.forward(graph, updated_e_feat,
                                                                               updated_n_feat, updated_u_feat)

        inp = updated_n_feat
        if self.mode=="dqn":
            out = self.q_net(F.relu(self.pre_q_net(inp)))
            return out, e_hid, n_hid, u_hid

        zero_indexes = [0]
        for a in range(len(graph.batch_num_nodes) - 1):
            zero_indexes.append(zero_indexes[a] + graph.batch_num_nodes[a])

        inp = updated_n_feat[zero_indexes]

        if self.with_oppo_modelling:
            non_zero_indexes = [a for a in range(graph.number_of_nodes()) if not a in zero_indexes]
            action_pred_inp = updated_n_feat[non_zero_indexes]

        out = self.q_net(F.relu(self.pre_q_net(inp)))
        if self.with_oppo_modelling:
            action_modeling_res = self.act_pred_model(F.relu(self.pre_act_pred_model(
                action_pred_inp)))
            return (out, action_modeling_res), e_hid, n_hid, u_hid

        return out, e_hid, n_hid, u_hid

class LSTMController(nn.Module):
    def __init__(self, dim_feature, hidden_dim, dim_lstm_out, dim_mid, dim_out,
                 act_dims, mid_nodes=25, with_oppo_modelling=True):
        super(LSTMController, self).__init__()
        self.mlp1a = nn.Linear(dim_feature, hidden_dim)
        self.mlp1b = nn.Linear(hidden_dim, dim_mid)
        self.lstm2 =  nn.LSTM(dim_mid, dim_lstm_out, batch_first=True)
        self.mlp2 = nn.Linear(dim_lstm_out, dim_out)

        self.mlp_last = nn.Linear(dim_out, mid_nodes)
        self.mlp_last2 = nn.Linear(mid_nodes, act_dims)
        self.with_oppo_modelling = with_oppo_modelling

        if with_oppo_modelling:
            self.pre_act_pred_model_1 = nn.Linear(dim_out, mid_nodes)
            self.act_pred_model_1 = nn.Linear(mid_nodes, act_dims)

            self.pre_act_pred_model_2 = nn.Linear(dim_out, mid_nodes)
       	    self.act_pred_model_2 = nn.Linear(mid_nodes, act_dims)

    def forward(self, input, hidden):
        out = F.relu(self.mlp1a(input))
        out = self.mlp1b(out)
        out, hid = self.lstm2(out.view(out.shape[0],1,-1), hidden)
        out = F.relu(self.mlp2(out[:,0,:]))
        out1 = self.mlp_last2(F.relu(self.mlp_last(out)))
        
        if self.with_oppo_modelling:
            action_modeling_res1 = self.act_pred_model_1(F.relu(self.pre_act_pred_model_1(
                out)))

            action_modelling_res2 = self.act_pred_model_2(F.relu(self.pre_act_pred_model_2(
                out)))

            return (out1, (action_modeling_res1, action_modelling_res2)), hid 
        return out1, hid

    def hard_copy(self, source):
        for target_param, source_param in zip(self.parameters(), source.parameters()):
            target_param.data.copy_(source_param.data)

    def hard_copy_fs(self, source):
        for (k, l), (m, n), in zip(self.named_parameters(), source.named_parameters()):
            if ('GNBlockF' in k or 'GraphLSTMF' in k or 'q_net.jf' in k or 'q_net.if' in k
                    or 'q_net.edge_flag_repr' in k or 'q_net.edge_classifier' in k
                    or 'value_net' in k):
                l.data.copy_(n.data)

class DGNController(nn.Module):
    def __init__(self, dim_feature, hidden_dim, dim_lstm_out, dim_mid, dim_out, act_dims, mid_nodes=25, num_heads=8, tau=0.3):
        super(DGNController, self).__init__()
        self.mlp1a = nn.Linear(dim_feature, hidden_dim)
        self.mlp1b = nn.Linear(hidden_dim, dim_mid)
        self.lstm2 = nn.LSTM(dim_mid, dim_lstm_out, batch_first=True)
        self.mlp2 = nn.Linear(dim_lstm_out, dim_out)
        self.tau = tau

        self.mlp_last = MultiHeadGATLayer(dim_out, mid_nodes, mid_nodes, num_heads, tau=tau)
        self.mlp_last2 = nn.Linear(dim_out+mid_nodes, act_dims)

    def hard_copy(self, source):
        for target_param, source_param in zip(self.parameters(), source.parameters()):
            target_param.data.copy_(source_param.data)

    def forward(self, graph, input, hidden):
        out = F.relu(self.mlp1a(input))
        out = self.mlp1b(out)
        out, hid = self.lstm2(out.view(out.shape[0], 1, -1), hidden)
        out = F.relu(self.mlp2(out[:, 0, :]))

        DGN_out = self.mlp_last(graph, out)
        offset, first_idxes = 0, [0]

        for num_node in graph.batch_num_nodes[:-1]:
            offset += num_node
            first_idxes.append(offset)

        DGN_out = DGN_out[first_idxes, :]
        out = out[first_idxes, :]
        out1 = self.mlp_last2(F.relu(torch.cat([DGN_out, out], dim=-1)))

        return out1, hid

