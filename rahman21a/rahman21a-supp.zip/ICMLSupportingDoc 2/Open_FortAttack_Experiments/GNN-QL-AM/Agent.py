import random
from Network import *
import torch
import torch.nn as nn
import torch.optim as optim
import dgl
import torch.distributions as dist
import numpy as np
from sys import getsizeof

# Add storage for the neighbourhood flags

def hard_copy(target_net, source_net):
    for target_param, param in zip(target_net.parameters(), source_net.parameters()):
        target_param.data.copy_(param.data)

def soft_copy(target_net, source_net, tau=0.001):
    for target_param, param in zip(target_net.parameters(), source_net.parameters()):
        target_param.data.copy_(tau*param + (1-tau)*target_param)

class CentralizedController(object):
    def __init__(self, args=None, rollout_freq=8, epsilon=1.0, num_acts=5, optimizer=None,
                 mode="train", device=None, with_added_u=True, added_u_dim=0):

        self.args = args
        self.with_added_u = with_added_u
        self.num_acts = num_acts
        if self.with_added_u:
            self.added_u_dim = added_u_dim

        # Initialize neural network dimensions
        self.dim_lstm_out = 50
        self.device = device
        if self.device is None:
            self.device = 'cuda' if torch.cuda.is_available() and self.args['with_gpu'] else 'cpu'

        self.dqn_net = RFMLSTMMiddle(2, 60, 40, 50, 35, 30, 40, 5, with_added_u_feat=True,
                                 added_u_feat_dim=self.added_u_dim).to(self.device)
        self.target_dqn_net = RFMLSTMMiddle(2, 60, 40, 50, 35, 30, 40, 5, with_added_u_feat=True,
                                        added_u_feat_dim=self.added_u_dim).to(self.device)
        hard_copy(self.target_dqn_net, self.dqn_net)
        self.mode = mode

        # Set params for Backprop
        self.rollout_freq = rollout_freq
        self.optimizer = optimizer
        if self.optimizer is None:
            self.optimizer = optim.Adam(self.dqn_net.parameters(), lr=self.args['lr'])

        # Stored data for training
        self.predicted_vals = []
        self.target_vals = None
        self.epsilon = epsilon

        self.hiddens = None
        self.target_hiddens = None
        self.graph = None

        self.loss_module = nn.MSELoss()

    def step(self, obs, eval=False):
        p_graph, e_ob, n_ob, u_ob, e_hiddens, n_hiddens, u_hiddens = self.prep(obs, self.hiddens)
        batch_graph = p_graph

        out, e_hid, n_hid, u_hid = self.dqn_net(batch_graph, e_ob, n_ob, u_ob,
                                                e_hiddens, n_hiddens, u_hiddens,
                                                evaluate=eval)

        self.hiddens = (e_hid, n_hid, u_hid)

        _, act = torch.max(out, dim=-1)

        acts = []
        batch_nodes = batch_graph.batch_num_nodes
        idx = 0
        for num_nodes in batch_nodes:
            sb_act = []
            for adds in range(num_nodes):
                if eval:
                    a = act[idx].item()
                else:
                    a = act[idx].item() if random.random() > self.epsilon else random.randint(0, self.num_acts-1)
                sb_act.append(a)
                idx += 1
            acts.append(sb_act)

        action_tensors = torch.cat([torch.Tensor(a) for a in acts], dim=0)
        if not eval:
            self.predicted_vals.append(torch.gather(out, -1, action_tensors[:,None].long()))

        return acts

    def compute_target(self, rewards, dones, next_obs, add_storage=True):
        p_graph, ne_ob, nn_ob, nu_ob, te_hiddens, tn_hiddens, tu_hiddens = self.prep(next_obs, self.target_hiddens)
        batch_graph = p_graph

        out, e_hid, n_hid, u_hid = self.target_dqn_net(batch_graph, ne_ob, nn_ob, nu_ob,
                                                te_hiddens, tn_hiddens, tu_hiddens)

        self.target_hiddens = (e_hid, n_hid, u_hid)

        if add_storage:
            rew_t = torch.Tensor([elem for rew in rewards for elem in rew])[:, None]
            dones = torch.Tensor([df for done in dones for df in done])[:, None]
            targets = rew_t + self.args['gamma'] * (1 - dones) * torch.max(out, dim=-1, keepdim=True)[0]
            self.target_vals.append(targets)

    def prep(self, obs, hiddens):
        if self.graph is None:
            self.graph = []
            for ob in obs:
                graph_ob = dgl.DGLGraph()
                graph_ob.add_nodes(len(ob))
                src, dst = zip(*[(a,b) for a in range(len(ob)) for b in range(len(ob)) if a!=b])
                graph_ob.add_edges(src, dst)
                self.graph.append(graph_ob)

            self.graph = dgl.batch(self.graph)

        n_ob = torch.cat([torch.Tensor(elem[:2])[None,:].float() for a in obs for elem in a], dim=0)
        e_ob = torch.zeros([self.graph.number_of_edges(),0])
        u_ob = torch.cat([torch.Tensor(k[0][2:]).float()[None,:] for k in obs], dim=0)

        if hiddens is None:
            n_hid = (torch.zeros([1,self.graph.number_of_nodes(),self.dim_lstm_out]),
                          torch.zeros([1,self.graph.number_of_nodes(),self.dim_lstm_out]))
            e_hid = (torch.zeros([1,self.graph.number_of_edges(),self.dim_lstm_out]),
                          torch.zeros([1,self.graph.number_of_edges(),self.dim_lstm_out]))
            u_hid = (torch.zeros([1,len(obs),self.dim_lstm_out]),
                          torch.zeros([1,len(obs),self.dim_lstm_out]))

        else:
            n_hid = hiddens[1]
            e_hid = hiddens[0]
            u_hid = hiddens[2]

        return self.graph, e_ob, n_ob, u_ob, e_hid, n_hid, u_hid

    def reset(self):
        self.predicted_vals = []
        self.target_vals = []
        self.hiddens = None
        self.target_hiddens = None
        self.graph = None

    def load_parameters(self, filename):
        self.dqn_net.load_state_dict(torch.load(filename))
        self.target_dqn_net.state_dict(torch.load(filename+"_target_dqn"))
        self.target_dqn_net.eval()

    def save_parameters(self, filename):
        torch.save(self.dqn_net.state_dict(), filename)
        torch.save(self.target_dqn_net.state_dict(), filename+"_target_dqn")

    def set_epsilon(self, eps):
        self.epsilon = eps

    def update(self):
        self.optimizer.zero_grad()
        pred_tensor = torch.cat(self.predicted_vals, dim = 0)
        target_tensor = torch.cat(self.target_vals, dim = 0)

        loss = self.loss_module(pred_tensor, target_tensor.detach())
        loss.backward()
        torch.nn.utils.clip_grad_norm(self.dqn_net.parameters(), self.args['clip_grad'])

        self.optimizer.step()

        soft_copy(self.target_dqn_net, self.dqn_net, self.args['tau'])
        self.predicted_vals = []
        self.target_vals = []

        self.hiddens = ((self.hiddens[0][0].detach(), self.hiddens[0][1].detach()),
                            (self.hiddens[1][0].detach(), self.hiddens[1][1].detach()),
                            (self.hiddens[2][0].detach(), self.hiddens[2][1].detach()))

class DGNAgent(object):
    def __init__(self, args=None, optimizer=None,
                 mode="train", device=None, epsilon=1.0,
                 with_oppo_modeling=True):

        self.args = args
        self.with_oppo_modeling = with_oppo_modeling

        # Initialize neural network dimensions
        self.dim_lstm_out = 128
        self.device = device
        if self.device is None:
            self.device = 'cuda' if torch.cuda.is_available() else 'cpu'

        self.dqn_net = DGNController(15, 64, 128, 64, 128, 8).to(self.device)
        self.target_dqn_net = DGNController(15, 64, 128, 64, 128, 8).to(
            self.device)

        self.model_network = OppoModelNet(
            7, 0, 64, 128, 64, 128, 8, 70, 40, 128
        )

        self.act_dims = 8
        hard_copy(self.target_dqn_net, self.dqn_net)
        self.mode = mode
        # Hidden tensors
        self.hiddens = None
        self.target_hiddens = None
        self.model_hiddens = None
        self.model_hiddens_pi = None
        self.graph_structure = None

        # Set params for Backprop
        self.optimizer = optimizer
        if self.optimizer is None:
            self.optimizer = optim.Adam(list(self.dqn_net.parameters())+ list(self.model_network.parameters()), lr=self.args['lr'])

        # Stored data for training
        self.predicted_vals = []
        self.target_vals = []
        self.logit_probs_theta = []
        self.logit_probs_pi = []
        self.joint_actions = []
        self.epsilon = epsilon

        self.loss_module = nn.MSELoss()
        self.loss_module_f = nn.CrossEntropyLoss()

    def step(self, obs, eval=False):
        graph_batch, obs_new, n_hid, n_ob = self.prep_graph(obs, self.model_hiddens)
        graph_logit, n_hid = self.model_network(graph_batch, obs_new, n_hid)
        self.model_hiddens = n_hid

        prob_acts = dist.Categorical(logits=graph_logit).probs
        all_probs = -np.ones([obs.shape[0] * obs.shape[1], 8])
        reshaped_obs = np.reshape(obs, [obs.shape[0] * obs.shape[1], -1])

        all_probs[reshaped_obs[:, 0] != 0] = prob_acts.detach().numpy()
        added_obs = np.reshape(all_probs, [-1, all_probs.shape[-1]])

        q_graph_batch, obs_out, hiddens = self.prep(obs, self.hiddens, added_obs=added_obs)
        self.graph_structure = q_graph_batch
        out, hiddens = self.dqn_net(self.graph_structure, obs_out, hiddens)
        self.hiddens = hiddens

        acts = torch.argmax(out, dim=-1).tolist()
        if not eval:
            acts = [a if random.random() > self.epsilon else
                    random.randint(0, 7) for a in acts]
            action_tensors = torch.Tensor(acts)[:, None]
            self.predicted_vals.append(torch.gather(out, -1, action_tensors.long()))

            first_idxes = [0]
            offset = 0
            for graph_size in graph_batch.batch_num_nodes[:-1]:
                offset += graph_size
                first_idxes.append(offset)

            included_indices = [a for a in list(range(graph_logit.shape[0])) if not (a in first_idxes)]
            self.logit_probs_theta.append(graph_logit[included_indices,:])

        return acts


    def compute_target(self, obs, rewards, actions, dones, next_obs, add_storage=True):
        graph_batch, model_obs, n_hid, n_ob, acts = self.prep_graph(next_obs, self.model_hiddens, with_acts=True)
        graph_logit, n_hid_updated = self.model_network(graph_batch, model_obs, n_hid)

        prob_acts = dist.Categorical(logits=graph_logit).probs
        all_probs = -np.ones([next_obs.shape[0] * next_obs.shape[1], 8])
        reshaped_obs = np.reshape(next_obs, [next_obs.shape[0] * next_obs.shape[1], -1])

        all_probs[reshaped_obs[:, 0] != 0] = prob_acts.detach().numpy()
        added_obs = np.reshape(all_probs, [-1, all_probs.shape[-1]])

        graph_struc, obs_out_crit, hiddens_critic = self.prep(next_obs, self.target_hiddens, added_obs=added_obs)
        if self.graph_structure is None:
            self.graph_structure = graph_struc
        out, hid = self.target_dqn_net(self.graph_structure, obs_out_crit, hiddens_critic)
        self.target_hiddens = hid
        if add_storage:
            graph_batch, model_obs, n_hid, n_ob = self.prep_graph(obs, self.model_hiddens_pi, with_acts=False)
            add_acts = torch.eye(self.act_dims)[torch.Tensor(acts).long(), :]
            graph_logit, self.model_hiddens_pi = self.model_network(graph_batch, model_obs, n_hid, mode="pi",
                                                             add_acts=add_acts)
            rew_t = torch.Tensor(rewards)[:, None]
            dones = torch.Tensor(dones)[:, None]
            targets = rew_t + self.args['gamma'] * (1 - dones) * torch.max(out, dim=-1, keepdim=True)[0]
            self.target_vals.append(targets)

            zero_indexes, offset = [0], 0
            num_nodes = graph_batch.batch_num_nodes
            all_num_nodes = sum(num_nodes)

            for a in num_nodes[:-1]:
                offset += a
                zero_indexes.append(offset)

            non_zero_indices_list = [k for k in range(all_num_nodes) if not (k in zero_indexes)]
            non_zero_indices = torch.Tensor(non_zero_indices_list).long()
            self.logit_probs_pi.append(graph_logit[non_zero_indices, :])
            self.joint_actions.extend([x for idx, x in enumerate(acts) if idx in non_zero_indices_list])

    def prep_graph(self, obs, hiddens, with_acts=False):
        graph_list = []
        num_agents = (obs[:,:,0] != 0).sum(axis=-1)
        prev_existing_agents_data = obs[obs[:, :, -1] != -1]
        cur_existing_agents_data = obs[obs[:, :, 0] != 0]

        prev_existing_agents_and_alive_flag = prev_existing_agents_data[:, 0] != 0
        cur_existing_agents_and_prev_existing_flag = cur_existing_agents_data[:, -1] != -1

        for num_agent in num_agents:
            num_agent = int(num_agent)
            graph_ob = dgl.DGLGraph()
            graph_ob.add_nodes(num_agent)
            if num_agent > 1:
                edge_pairs = [(a, b) for a in range(num_agent) for b in range(num_agent) if a != b]
                if len(edge_pairs) > 0:
                    src, dst = zip(*edge_pairs)
                    graph_ob.add_edges(src, dst)
            graph_list.append(graph_ob)

        graph_batch = dgl.batch(graph_list)

        # Parse inputs into node inputs
        num_nodes = graph_batch.batch_num_nodes
        n_ob = torch.Tensor(cur_existing_agents_data[:, 1:-1]).float()
        u_ob = torch.zeros((len(num_agents), 0)).float()

        # Create filters to decide which hidden vectors to maintain
        # For newly added agents, hiddens set to zeros
        # For remaining agents, hiddens continues from prev timestep
        node_filter = torch.tensor(prev_existing_agents_and_alive_flag, dtype=torch.bool)
        complete_new_filter = torch.tensor(cur_existing_agents_and_prev_existing_flag, dtype=torch.bool)

        current_node_offsets, offset = [0], 0
        for cur_num_node in num_nodes[:-1]:
            offset += cur_num_node
            current_node_offsets.append(offset)

        # Create action vectors for opponent modelling
        if with_acts:
            acts = prev_existing_agents_data[:, -1].astype(int).tolist()

        # Filter hidden vectors for remaining agents
        # Add zero vectors for newly added agents
        n_hid = (torch.zeros([1, graph_batch.number_of_nodes(), self.dim_lstm_out]),
                 torch.zeros([1, graph_batch.number_of_nodes(), self.dim_lstm_out]))

        # checks to not make it empty
        if not (hiddens is None):
            collected_hiddens = (hiddens[0][:, node_filter, :], hiddens[1][:, node_filter, :])
            n_hid[0][:, complete_new_filter, :] = collected_hiddens[0]
            n_hid[1][:, complete_new_filter, :] = collected_hiddens[1]

        batch_num_nodes = graph_batch.batch_num_nodes
        add_obs = torch.cat([feat.view(1, -1).repeat(r_num, 1) for
                             feat, r_num in zip(u_ob, batch_num_nodes)], dim=0)
        model_obs = torch.cat([n_ob, add_obs], dim=-1)

        if with_acts:
            return graph_batch, model_obs, n_hid, n_ob, acts

        return graph_batch, model_obs, n_hid, n_ob

    def prep(self, obs, hiddens, added_obs):
        graph_list = []
        for batch in range(obs.shape[0]):
            graph_ob = dgl.DGLGraph()
            graph_ob.add_nodes(obs.shape[1])
            edge_pairs = [
                (a, b) for a in range(obs.shape[1]) for b in range(obs.shape[1]) if a != b
                and obs[batch][a][0] != 0 and obs[batch][b][0] != 0
            ]
            if len(edge_pairs) > 0:
                src, dst = zip(*edge_pairs)
                graph_ob.add_edges(src, dst)
            graph_list.append(graph_ob)

        graph_batch = dgl.batch(graph_list)

        obs_copy = np.copy(obs)
        dead_agent_data = obs_copy[obs_copy[:, :, 0] == 0]
        obs_copy[obs_copy[:, :, 0] == 0] = -np.ones_like(dead_agent_data)
        obs_copy = obs_copy[:, :, 1:-1]

        obs_data = torch.Tensor(np.reshape(obs_copy, (-1, obs_copy.shape[-1]))).float()
        added_obs = torch.Tensor(added_obs).float()
        obs_out = torch.cat([obs_data, added_obs],
                            dim=-1)

        if hiddens is None:
            hiddens = (torch.zeros([1, obs.shape[0]*obs.shape[1], self.dim_lstm_out]),
                       torch.zeros([1, obs.shape[0]*obs.shape[1], self.dim_lstm_out]))

        else:
            hiddens_new = (torch.zeros([1, obs.shape[0] * obs.shape[1], self.dim_lstm_out]),
                       torch.zeros([1, obs.shape[0] * obs.shape[1], self.dim_lstm_out]))
            filter_idxes = torch.tensor(
                np.bitwise_and(obs[:,:,0] != 0, obs[:,:,-1] != -1).reshape(-1), dtype=torch.bool
            )
            hiddens_new[0][:, filter_idxes, :] = hiddens[0][:, filter_idxes, :]
            hiddens_new[1][:, filter_idxes, :] = hiddens[1][:, filter_idxes, :]

        return graph_batch, obs_out, hiddens

    def reset(self, filter):
        if filter is None:
            self.hiddens = None
            self.target_hiddens = None
            self.model_hiddens = None
            self.model_hiddens_pi = None

            self.predicted_vals = []
            self.target_vals = []
            self.logit_probs_theta = []
            self.logit_probs_pi = []
            self.joint_actions = []
        else:
            final_filter = []
            for a in filter:
                final_filter.extend([a] * 10)
            filter_t = 1 - torch.Tensor(final_filter).view(-1, 1)
            self.hiddens = (self.hiddens[0] * filter_t, self.hiddens[1] * filter_t)
            if not self.target_hiddens is None:
                self.target_hiddens = (self.target_hiddens[0] * filter_t, self.target_hiddens[1] * filter_t)

    def load_parameters(self, filename):
        self.dqn_net.load_state_dict(torch.load(filename))
        self.target_dqn_net.state_dict(torch.load(filename+"_target_dqn"))
        self.model_network.state_dict(torch.load(filename+"_model"))
        #self.optimizer.state_dict(torch.load(filename+"_optim")["state"])
        self.target_dqn_net.eval()

    def save_parameters(self, filename):
        torch.save(self.dqn_net.state_dict(), filename)
        torch.save(self.target_dqn_net.state_dict(), filename+"_target_dqn")
        torch.save(self.model_network.state_dict(), filename+"_model")
        torch.save(self.optimizer.state_dict(), filename+"_optim")

    def set_epsilon(self, eps):
        self.epsilon = eps

    def update(self):
        self.optimizer.zero_grad()
        pred_tensor = torch.cat(self.predicted_vals, dim = 0)
        target_tensor = torch.cat(self.target_vals, dim = 0)

        joint_actions = torch.Tensor(self.joint_actions).long()
        loss_pred = 0
        if len(self.logit_probs_pi) != 0 and len(self.logit_probs_theta) != 0:
            #joint_logit_pi = torch.cat(self.logit_probs_pi, dim=0)
            joint_logit_theta = torch.cat(self.logit_probs_theta, dim=0)

            #dist_caregorical_pi = dist.Categorical(logits=joint_logit_pi)
            #dist_categorical_theta = dist.Categorical(logits=joint_logit_theta)

            #pi_loss = self.loss_module_f(joint_logit_pi, joint_actions)
            theta_cross_entropy = self.loss_module_f(joint_logit_theta, joint_actions)
            #theta_kl_loss = -torch.sum(torch.log(dist_categorical_theta.probs) *
            #                           dist_caregorical_pi.probs.detach(), dim=-1).mean()

            loss_pred = theta_cross_entropy

        loss = self.loss_module(pred_tensor, target_tensor.detach()) + self.args['weight_predict'] * loss_pred
        loss.backward()

        self.optimizer.step()

        soft_copy(self.target_dqn_net, self.dqn_net, self.args['tau'])
        self.predicted_vals = []
        self.target_vals = []
        self.logit_probs_theta = []
        self.logit_probs_pi = []
        self.joint_actions = []

        self.hiddens = (self.hiddens[0].detach(), self.hiddens[1].detach())
        self.model_hiddens = (self.model_hiddens[0].detach(), self.model_hiddens[1].detach())
        self.model_hiddens_pi = (self.model_hiddens_pi[0].detach(), self.model_hiddens_pi[1].detach())

class MRFAgent(object):
    def __init__(self, args=None, optimizer=None, device=None, writer=None,
                 epsilon=1.0, added_u_dim=0, mode="train", gumbel_temp=None):

        self.args = args
        self.added_u_dim = added_u_dim

        self.edge_filt = self.args['edge_filt']
        self.pair_comp = self.args['pair_comp']
        self.f_train_method = self.args['f_train_method']
        self.q_train_method = self.args['q_train_method']
        self.writer = writer
        self.num_updates = 0

        self.update_potentials = 0

        self.num_same_updates = 0
        self.graph_learning = False

        self.gumbel_temp = gumbel_temp

        # Initialize neural network dimensions
        self.dim_lstm_out = 100
        self.device = device
        if self.device is None:
            self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.dqn_net = LSTMMRF(2, self.added_u_dim, 100, 100, 100, 70,
                                      5, pair_comp=self.pair_comp,
                                      edge_filt=self.edge_filt, f_train_method=self.f_train_method,
                                      q_train_method=self.q_train_method).to(self.device)
        self.target_dqn_net = LSTMMRF(2, self.added_u_dim, 100, 100, 100, 70,
                                            5, pair_comp=self.pair_comp,
                                            edge_filt=self.edge_filt, f_train_method=self.f_train_method,
                                            q_train_method=self.q_train_method).to(self.device)

        hard_copy(self.target_dqn_net, self.dqn_net)
        self.mode = mode

        # Initialize hidden states for prediction
        self.hiddens = None
        self.hiddens_u = None
        self.target_hiddens = None
        self.target_hiddens_u = None
        self.RFMOut = None
        self.RFMOutU = None
        self.graph = None
        self.last_obs = None
        self.edge_u_vals = None
        self.edge_f_vals = None
        self.act_max = None

        # Set params for Ad Hoc BPTT
        self.optimizer = optimizer
        if self.optimizer is None:
            self.optimizer = optim.Adam(self.dqn_net.parameters(), lr=self.args['lr'])

        self.targ_vals = []
        self.struct_act_logits = []
        self.pred_vals = []
        self.f_graph_penalty = []
        self.log_probs = []
        self.num_edges_u = []
        self.p_values=[]
        self.edge_logits = []

        self.reward_list = []
        self.done_list = []

        if self.edge_filt=="gumbel":
            self.gumbel_logits = []
            self.gumbel_logits_u = []

        self.epsilon = epsilon
        self.loss_module = nn.MSELoss()

    def step(self, obs, eval=False):
        p_graph, n_ob, u_ob, n_hiddens, n_hiddens_u, heur_graph = self.prep(
            obs, self.hiddens, self.hiddens_u, heur=True
        )

        self.graph = p_graph
        out, feats, hids, feats_u, hids_u, predicted_vals = self.dqn_net(
            self.graph, n_ob, n_ob, g_repr=u_ob, g_repr_u=u_ob,
            hidden_n=n_hiddens, hidden_n_u=n_hiddens_u,
            gumbel_temp=self.gumbel_temp, graph_learning=self.graph_learning,
            target_edges = heur_graph
        )

        self.hiddens = hids
        self.hiddens_u = hids_u
        self.RFMOut = feats
        self.RFMOutU = feats_u

        acts = torch.argmax(out[0], dim=-1).tolist()
        self.act_max = acts

        if not eval:
                acts = [a if random.random() > self.epsilon else random.randint(0, 4) for a in acts]
                #self.act_max = acts
                self.num_edges_u.append(out[2])
                self.edge_logits.append(out[-3])
                self.edge_u_vals = out[2]
                self.gumbel_logits_u.append(out[1])
                self.edge_f_vals = out[-1]
                self.p_values.append(predicted_vals)

        return acts

    def compute_target_u(self, rewards, done, n_obs, nn_obs, add_storage=True, mrf_mode="inference"):

        p_graph, n_ob, u_ob, n_hiddens, n_hiddens_u = self.prep(
            n_obs, self.target_hiddens, self.target_hiddens_u, with_acts=False
        )

        op_acts_target = None

        if add_storage and nn_obs is None:
            out = torch.zeros(rewards.shape[0], 1)
        else:
            if add_storage:
                op_acts_target = self.prep_nn_obs(nn_obs, self.act_max)

            out, _, target_hid, _, target_hid_u, predicted_vals = self.target_dqn_net(
                p_graph, n_ob, n_ob,
                g_repr=u_ob, g_repr_u=u_ob,
                hidden_n=n_hiddens, hidden_n_u=n_hiddens_u,
                evaluate=True, mrf_mode=mrf_mode,
                gumbel_temp=self.gumbel_temp,
                joint_acts=op_acts_target, target_edges=self.edge_u_vals,
                target_edges_f = self.edge_f_vals
            )

            self.target_hiddens = target_hid
            self.target_hiddens_u = target_hid_u

        if add_storage:
            rew_t = torch.Tensor(rewards)[:, None].to(self.device)
            dones = torch.Tensor(done)[:, None].to(self.device)
            targets = rew_t + self.args['gamma'] * (1 - dones) * out[-1]
            self.targ_vals.append(targets)

    def compute_target(self, acts, n_obs):
        _, _, _, _, _, op_acts = self.prep(
            n_obs, self.target_hiddens, self.target_hiddens_u,
            with_acts=True, add_acts=acts
        )

        self.last_obs = n_obs
        out = self.dqn_net(
            self.graph, self.RFMOut[1], self.RFMOutU[1],
            edge_feat=self.RFMOut[0], edge_feat_u=self.RFMOutU[0],
            reverse_edge_feat=self.RFMOut[2], reverse_edge_feat_u=self.RFMOutU[2],
            mrf_mode="no_rfm", joint_acts=op_acts, gumbel_temp=self.gumbel_temp,
            target_edges=self.edge_u_vals, target_edges_f=self.edge_f_vals
        )

        self.log_probs.extend(out[0])
        self.f_graph_penalty.extend(out[1])
        self.gumbel_logits.append(out[2])
        self.pred_vals.append(out[3])

    def add_rds(self, rewards, dones):
        rew_t = torch.Tensor(rewards)[:, None].to(self.device)
        dones = torch.Tensor(dones)[:, None].to(self.device)
        self.reward_list.append(rew_t)
        self.done_list.append(dones)

    def detach_hiddens(self):
        self.hiddens = (self.hiddens[0].detach(), self.hiddens[1].detach())
        self.hiddens_u = (self.hiddens_u[0].detach(), self.hiddens_u[1].detach())

    def is_close(self, point1, point2, point3, point4):
        is_close = (abs(point1[0]-point2[0]) + abs(point1[1]-point2[1])) < self.args["dist_threshold"]
        is_close_enemy11 = (abs(point1[0]-point3[0]) + abs(point1[1]-point3[1])) < self.args["dist_threshold"]
        is_close_enemy12 = (abs(point1[0]-point4[0]) + abs(point1[1]-point4[1])) < self.args["dist_threshold"]  
        is_close_enemy21 = (abs(point2[0]-point3[0]) + abs(point2[1]-point3[1])) < self.args["dist_threshold"]
        is_close_enemy22 = (abs(point2[0]-point4[0]) + abs(point2[1]-point4[1])) < self.args["dist_threshold"]

        return 1-int(is_close and (is_close_enemy11 or is_close_enemy12 or is_close_enemy21 or is_close_enemy22))
 
    def prep(self, obs, hiddens, hiddens_u, with_acts=False, add_acts=None, heur=False):
        if self.graph is None:
            self.graph = []
            for ob in obs:
                num_agents = (len(ob) - 11) // 3
                graph_ob = dgl.DGLGraph()
                graph_ob.add_nodes(num_agents)
                src, dst = zip(*[(a, b) for a in range(num_agents) for b in range(num_agents) if a != b])
                graph_ob.add_edges(src, dst)
                self.graph.append(graph_ob)

            self.graph = dgl.batch(self.graph)

        num_nodes = self.graph.batch_num_nodes[0]
        n_ob = torch.cat([torch.Tensor([a[2 * idx:2 * idx + 2]]).float() for a in obs
                          for idx in range(num_nodes)], dim=0)
        if heur:
            all_supposed_edges = []
            for ob in obs:
                num_agents = (len(ob) - 11) // 3
                is_connected = [self.is_close((ob[2*a], ob[2*a+1]),(ob[2*b], ob[2*b+1]),(ob[2*num_agents], ob[2*num_agents+1]),(ob[2*num_agents+2], ob[2*num_agents+3])) 
                                for a in range(num_agents) for b in range(num_agents) if a != b]
                all_supposed_edges.extend(is_connected)
            nn_edges = torch.eye(2)[torch.Tensor(all_supposed_edges).long(),:]

        u_ob = torch.cat([torch.Tensor(k[2 * num_nodes:-(num_nodes - 1)]).float()[None, :] for k in obs],
                         dim=0)

        if with_acts:
            first_acts, latter_acts = np.array(add_acts).reshape(len(add_acts),-1), obs[:,-(num_nodes-1):]
            acts_data = np.concatenate((first_acts, latter_acts), axis=-1)
            acts = [p for k in acts_data for p in k]

        if hiddens is None:
            n_hid = (torch.zeros([1, self.graph.number_of_nodes(), self.dim_lstm_out]),
                     torch.zeros([1, self.graph.number_of_nodes(), self.dim_lstm_out]))

        else:
            n_hid = hiddens

        if hiddens_u is None:
            n_hid_u = (torch.zeros([1, self.graph.number_of_nodes(), self.dim_lstm_out]),
                     torch.zeros([1, self.graph.number_of_nodes(), self.dim_lstm_out]))

        else:
            n_hid_u = hiddens_u

        if with_acts:
            return self.graph, n_ob, u_ob, n_hid, n_hid_u, acts

        if heur :
            return self.graph, n_ob, u_ob, n_hid, n_hid_u, nn_edges
        return self.graph, n_ob, u_ob, n_hid, n_hid_u

    def prep_nn_obs(self, nn_obs, add_acts):
        num_nodes = self.graph.batch_num_nodes[0]
        first_acts, latter_acts = np.array(add_acts).reshape(len(add_acts), -1), nn_obs[:, -(num_nodes - 1):]
        acts_data = np.concatenate((first_acts, latter_acts), axis=-1)
        acts = [p for k in acts_data for p in k]

        return acts

    def reset(self):
        self.hiddens = None
        self.hiddens_u = None
        self.target_hiddens = None
        self.target_hiddens_u = None
        self.RFMOut = None
        self.RFMOutU = None
        self.graph = None
        self.last_obs = None
        self.act_max = None
        self.edge_u_vals = None
        self.edge_f_vals = None

        self.targ_vals = []
        self.struct_act_logits = []
        self.pred_vals = []
        self.f_graph_penalty = []
        self.log_probs = []
        self.num_edges_u = []
        self.p_values = []
        self.edge_logits = []
        self.reward_list = []
        self.done_list = []

        if self.edge_filt == "gumbel":
            self.gumbel_logits = []
            self.gumbel_logits_u = []

    def load_parameters(self, filename):
        self.dqn_net.load_state_dict(torch.load(filename))
        self.target_dqn_net.state_dict(torch.load(filename + "_target_dqn"))

    def save_parameters(self, filename):
        torch.save(self.dqn_net.state_dict(), filename)
        torch.save(self.target_dqn_net.state_dict(), filename + "_target_dqn")

    def set_epsilon(self, eps):
        self.epsilon = eps

    def set_gumbel_temp(self, temp):
        self.gumbel_temp = temp

    def update(self):
        self.optimizer.zero_grad()
        pred_tensor = torch.cat(self.pred_vals, dim=0)
        target_tensor = torch.cat(self.targ_vals, dim=0)
        joint_log_prob = torch.cat(self.log_probs, dim=0)

        loss_pred = joint_log_prob.mean()
        val_loss = self.loss_module(pred_tensor, target_tensor.detach())

        loss = val_loss - self.args['weight_predict'] * loss_pred
        f_pens = torch.cat(self.f_graph_penalty, dim=0).mean()
        self.writer.add_scalar('loss/f_pens', f_pens, self.num_updates)

        if self.edge_filt == "gumbel":
            gumbel_mean_logit_tensor = torch.cat(self.gumbel_logits, dim=0)
            gumbel_mean = (gumbel_mean_logit_tensor ** 2).mean()

            logit_sign = torch.sum(gumbel_mean_logit_tensor[:, 0] > gumbel_mean_logit_tensor[:, 1]) / (
                        0.0 + gumbel_mean_logit_tensor.shape[0])

            loss += self.args["weight_predict"] * self.args['gumbel_regularizer'] * gumbel_mean
            self.writer.add_scalar('loss/gumbel_mean_sign', logit_sign, self.num_updates)
            self.writer.add_scalar('loss/gumbel_mean', gumbel_mean, self.num_updates)

        self.writer.add_scalar('loss/q_loss', val_loss, self.num_updates)
        self.writer.add_scalar('loss/pseudolikelihood', loss_pred, self.num_updates)

        loss.backward()
        self.optimizer.step()

        soft_copy(self.target_dqn_net, self.dqn_net, self.args['tau'])
        self.target_dqn_net.hard_copy_fs(self.dqn_net)

        self.last_obs = None
        self.targ_vals = []
        self.struct_act_logits = []
        self.pred_vals = []
        self.f_graph_penalty = []
        self.log_probs = []
        self.num_edges_u = []
        self.p_values = []
        self.edge_logits = []
        self.reward_list = []
        self.done_list = []

        if self.edge_filt == "gumbel":
            self.gumbel_logits = []
            self.gumbel_logits_u = []

        self.num_updates += 1
        
