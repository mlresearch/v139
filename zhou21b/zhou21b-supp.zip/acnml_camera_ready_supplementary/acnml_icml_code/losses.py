import torch
import torch.nn.functional as F
import copy
from itertools import chain
import time
import numpy as np

from torch import nn
from torch import Tensor
from typing import List, Tuple, Dict, Union, Callable

def cross_entropy(model, input, target):
    # standard cross-entropy loss function

    output = model(input)

    loss = F.cross_entropy(output, target)

    return loss, output

def entropy(model, input):
    # standard cross-entropy loss function

    output = model(input)

    logits = F.log_softmax(output)
    probs = torch.exp(logits)

    return -torch.sum(logits * probs), output

def _del_nested_attr(obj: nn.Module, names: List[str]) -> None:
    """
    Deletes the attribute specified by the given list of names.
    For example, to delete the attribute obj.conv.weight,
    use _del_nested_attr(obj, ['conv', 'weight'])
    """
    if len(names) == 1:
        delattr(obj, names[0])
    else:
        _del_nested_attr(getattr(obj, names[0]), names[1:])

def _set_nested_attr(obj: nn.Module, names: List[str], value: Tensor) -> None:
    """
    Set the attribute specified by the given list of names to value.
    For example, to set the attribute obj.conv.weight,
    use _del_nested_attr(obj, ['conv', 'weight'], value)
    """
    if len(names) == 1:
        setattr(obj, names[0], value)
    else:
        _set_nested_attr(getattr(obj, names[0]), names[1:], value)

def load_weights(mod: torch.nn.Module, names, params) -> None:
    """
    Reload a set of weights so that `mod` can be used again to perform a forward pass.
    Note that the `params` are regular Tensors (that can have history) and so are left
    as Tensors. This means that mod.parameters() will still be empty after this call.
    """
    for name, p in zip(names, params):
        _set_nested_attr(mod, name.split("."), p)

def extract_weights(mod):
    """
    This function removes all the Parameters from the model and
    return them as a tuple as well as their original attribute names.
    The weights must be re-loaded with `load_weights` before the model
    can be used again.
    Note that this function modifies the model in place and after this
    call, mod.parameters() will be empty.
    """
    orig_params = tuple(mod.parameters())
    # Remove all the parameters in the model
    names = []
    for name, p in list(mod.named_parameters()):
        _del_nested_attr(mod, name.split("."))
        names.append(name)

    # Make params regular Tensors instead of nn.Parameter
    params = tuple(p.detach().requires_grad_() for p in orig_params)
    return params, names

# def inject_params_forward(params, model, x):
def inject_params_forward(names, model, x, *new_params):
    load_weights(model, names, new_params)
    out = model(x)
    return out

def custom_einsummer(jac, p):
    # print("einsum", jac.shape, p.shape)
    # print(p.shape, jac.shape)
    if len(jac.shape) == 2:
        return torch.matmul(jac, p)
    if len(jac.shape) == 3:
        return (jac * p).sum(axis=(-2,-1))
    if len(jac.shape) == 4:
        return (jac * p).sum(axis=(-3, -2,-1))
    if len(jac.shape) == 5:
        return (jac * p).sum(axis=(-4, -3, -2,-1))
    else:
        return (jac * p).sum(axis=-1)

def jac_diff(jacs, new_params, init_params):

    # diffs = [(jac * (p-old_p)) for jac, p, old_p in zip(jacs, new_params, init_params)]
    # diffs = [(jac * p) for jac, p in zip(jacs, new_params)]
    # results = []
    # for d in diffs:
        # print(d.shape)
        # if len(d.shape) == 4:
            # results.append(d.sum(axis=(2,3))[0])
        # elif len(d.shape) == 3:
            # results.append(d.sum(axis=2)[0])
    results = [custom_einsummer(jac, p) for jac, p in zip(jacs, new_params)]
    # print([r.shape for r in results])
    return sum(results)

def linearized_nml_ce(model, map_model, input, target, update_bn_fn, nml_scale=1., n_steps=5, use_v2=False):
    all_logits = []
    all_linearized_logits = []
    # model.eval()
    # model.var_clamp = 0.00000000001
    mu_list, var_list, _ = model.generate_mean_var_covar()
    model.eval()
    model.var_clamp = 0.00000000001

    map_params = list(map_model.parameters())
    reset_optimizer = torch.optim.SGD(map_model.parameters(), lr=1)
    reset_optimizer.zero_grad()
    for param, mu, var in zip(map_params, mu_list, var_list):
        param.grad = -mu + param.data
    reset_optimizer.step()

    new_model = copy.deepcopy(map_model)
    new_params = list(new_model.parameters())

    jac_model = copy.deepcopy(map_model)
    param_vals, param_names = extract_weights(jac_model)

    reset_optimizer = torch.optim.SGD(new_model.parameters(), lr=1)
    sgd_optimizer = torch.optim.SGD(new_model.parameters(), lr=1.)
    new_params = list(new_model.parameters())
    # for p in new_params:
        # # print(p.requires_grad)
        # p.requires_grad = True
    new_params = [p.reshape(-1).detach() for p in new_params]
    mu_list = [p.reshape(-1) for p in mu_list]
    var_list = [p.reshape(-1) for p in var_list]

    # new_params  = [torch.cat(new_params.detach(), axis=-1)]
    # mu_list = [torch.cat(mu_list, axis=-1)]
    # var_list = [torch.cat(var_list, axis=-1)]
    count = 0
    # proposed_labels = torch.eye(10).cuda()
    proposed_labels = torch.tensor([i for i in range(10)]).cuda()
    start_t = time.time()
    for i, x in enumerate(input):
        count += 1
        print(count)
        x = x[None] # input[i].flatten()[None] # x[None]
        # x = input[i].flatten()[None] # x[None]
        logits = []
        linearized_logits = []
        start_datapoint = time.time()
        init_prediction = map_model(x).detach()

        custom_forward = lambda *p: inject_params_forward(param_names, jac_model, x, *p)
        # compute jac here
        # really fast, only takes 0.03s per datapoint
        jac_time = time.time()
        if True: # i == 0:
            jac = torch.autograd.functional.jacobian(custom_forward, param_vals)
            print("jac_time x 100 v0", (time.time() - jac_time) * 100)
            # jac = [j[0] for j in jac]
            jac = [j[0].reshape((10,-1)) for j in jac]
            # jac = [torch.cat(jac, axis=-1)]
        # print(jac.shape)
        # for j in jac:
            # print(j.shape)
            print("jac_time x 100", (time.time() - jac_time) * 100)
        start_afterjac = time.time()
        # print(jac)
        # print(len(jac))
        
        # for x in jac:
            # print(x.shape)

        # for x, p in zip(jac, new_params):
            # print((x*p).sum(axis=(-1, -2)))
        # print(jac_diff(jac, new_params, new_params))
        for j in range(10):
            proposed_label = proposed_labels[j:j+1]
            # reset_optimizer.zero_grad()
            # directly set data here
            # resetting takes negligible time?
            for param, mu, var in zip(new_params, mu_list, var_list):
                # param.grad = -mu + param.data
                param.data -= param.data
            # reset_optimizer.step()
            # more iterations here
            for i in range(5):
                t0 = time.time()

                # jac forward takes 0.12s # 0.352 vs 0.477
                linear_predicted_change = jac_diff(jac, new_params, map_params).detach()
                new_logits = linear_predicted_change + init_prediction
                # print(new_logits.requires_grad)
                new_logits.requires_grad = True
                linearized_loss = F.cross_entropy(new_logits, proposed_label)

                # loss, output = cross_entropy(new_model, x, proposed_label)
                # kl_loss = bnn_log_prob(new_params, mu_list, var_list)
                # kl_loss = model.compute_logprob(new_params, mvc, diag=True)
                combined_loss = nml_scale * linearized_loss # - 2 * kl_loss
                # sgd_optimizer.zero_grad()

                # loss.backward()
                # (-kl_loss).backward()
                # print(i, combined_loss)
                combined_loss.backward()
                # print(new_logits.grad)
                logit_grad = new_logits.grad[0]
                # print("Forward and grad time", (time.time() - t0) * 5 * 10 * 100)

                t0 = time.time()

                # backwards pass takes down 0.3s???
                # actual gradient computation takes 0.23s
                for param, j, mu, var in zip(new_params, jac, mu_list, var_list):
                    jj = j
                    import ipdb; ipdb.set_trace()
                    # grad = torch.matmul(j.T, logit_grad)
                    # print(param.grad)
                    # print(mu.shape)
                    # print(var.shape)

                    # param.grad += (param - mu) / var
                    # param.grad *= var / 2 # - mu + param.data)
                    # param.grad += (param - mu) / 2
                    # param.data /= 2
                    # param.data -= (torch.matmul(j.T, logit_grad) * var) / 2
                    # param.data -= (torch.matmul(j.T, logit_grad) * var + param) / 2
                    param.data -= (torch.matmul(j.T, logit_grad).T * var + param) / 2
                    # pass
                    # param.grad = (param.grad * var / 2) + (param - mu) / 2 # - mu + param.data)
                    #  param.grad = (param.data - mu)
                # print("backward time", (time.time() - t0) * 5 * 10 * 100)

            # kl_loss = bnn_log_prob(new_params, mu_list, var_list)
            # print("kl loss", -kl_loss)
            loss, output = 0., 0 # cross_entropy(new_model, x, proposed_label)
            linear_predicted_change = jac_diff(jac, new_params, map_params)
            new_logits = linear_predicted_change + init_prediction
            linearized_loss = F.cross_entropy(new_logits, proposed_label).detach()
            # print(linearized_loss)
            real_logits = 0 # new_model(x)
            # print("Real logits", real_logits)
            # print("New logits", new_logits)
            # print("Diff", new_logits - real_logits)
            # orig_ce, _ = cross_entropy(map_model, x, proposed_label)
            # print("ce loss", loss)
            # print("orig ce loss", orig_ce)
            logits.append(-loss) 
            linearized_logits.append(-linearized_loss) 
            # del orig_ce
            # torch.cuda.empty_cache()
            # print(torch.cuda.memory_summary())
            # del new_optimizer
            # del sgd_optimizer
        print("Datapoint Time", time.time() - start_datapoint)
        # print(linearized_logits)
        print("Datapoint Time v2", time.time() - start_datapoint)
        all_logits.append(logits)
        all_linearized_logits.append(linearized_logits)
        print("Datapoint Time v3", time.time() - start_datapoint)
        print("Datapoint Time v4", time.time() - start_afterjac)
        # all_logits.append(torch.tensor(logits))
        # all_linearized_logits.append(torch.tensor(linearized_logits))
    print(time.time() - start_t)

    all_logits = torch.stack(all_logits).cuda()
    all_linearized_logits = torch.stack(all_linearized_logits).cuda()

    normalized_logits = F.log_softmax(all_logits, dim=-1)
    normalized_linearized_logits = F.log_softmax(all_linearized_logits, dim=-1)
    # import ipdb; ipdb.set_trace()
    nml_probs = torch.exp(normalized_logits)
    nml_entropies = (-nml_probs * normalized_logits).sum(dim=-1)
    print("NML Entropy", nml_entropies.mean())
    nml_comps = torch.log(torch.exp(all_logits).sum(dim=-1))
    print("NML Comps", nml_comps.mean())
    nml_ce = F.cross_entropy(normalized_logits, target)
    # nml_ce, nml_acc = F.cross_entropy(normalized_logits, target)
    print("NML CE", nml_ce)
    # print("NML Acc", nml_acc)
    nml_probs = torch.exp(normalized_linearized_logits)
    nml_entropies = (-nml_probs * normalized_linearized_logits).sum(dim=-1)
    print("Lin NML Entropy", nml_entropies.mean())
    nml_comps = torch.log(torch.exp(all_linearized_logits).sum(dim=-1))
    print("Lin NML Comps", nml_comps.mean())
    nml_ce = F.cross_entropy(normalized_linearized_logits, target)
    print("Linearized NML CE", nml_ce)
    print("Linearized NML Acc", nml_acc)

    # final_loss = F.cross_entropy(all_logits, target)
    # model.sample(0)
    # print("MAP v1:", F.cross_entropy(model(input), target))
    # print("MAP v2:", F.cross_entropy(map_model(input), target))
    # print("NML Loss", final_loss)

    map_logits = map_model(input.flatten(1))
    map_logits = F.log_softmax(map_logits, dim=-1)
    map_probs = torch.exp(map_logits)
    map_entropies = (-map_probs * map_logits).sum(dim=-1)
    map_ce, map_acc = logit_cross_entropy(map_logits, target)
    print("MAP Entropy", map_entropies.mean())
    print("MAP CE", map_ce)
    print("MAP Acc", map_acc)

    marg_ce, marg_acc = logit_cross_entropy(marginal_logits, target)
    print("Marg CE", marg_ce)
    print("Marg Acc", marg_acc)

    del new_model
    del reset_optimizer
    del sgd_optimizer
    # final_loss = F.cross_entropy(all_logits, target)
    # model.sample(0)
    # print("MAP v1:", F.cross_entropy(model(input), target))
    # print("MAP v2:", F.cross_entropy(map_model(input), target))
    # print("NML Loss", final_loss)
# <<<<<<< Updated upstream
    # return F.cross_entropy(all_logits, target), all_logits
# =======
    print(time.time() - start_t)
    return F.cross_entropy(all_linearized_logits, target).detach(), all_linearized_logits.detach()
# >>>>>>> Stashed changes

def nml_ce_linear(model, map_model, input, target, update_bn_fn, nml_scale=1., use_v2=False):
    verbose = False
    all_logits = []
    model.eval()
    model.var_clamp = 0.00000000001
    # map_model = copy.deepcopy(erm_model)
    # map_model.eval()
    mu_list, var_list, covar_list = model.generate_mean_var_covar()

    mvc = (mu_list, var_list, covar_list)
    # print(F.cross_entropy(model(input), target))


    new_model = map_model
    # new_model = copy.deepcopy(map_model)
    new_model.eval()
    reset_optimizer = torch.optim.SGD(new_model.parameters(), lr=1)
    sgd_optimizer = torch.optim.SGD(new_model.parameters(), lr=1)
    new_params = list(new_model.parameters())
    count = 0
    # proposed_labels = torch.eye(10).cuda()
    proposed_labels = torch.tensor([i for i in range(10)]).cuda()
    reset_optimizer.zero_grad()
    for param, mu, var in zip(new_params, mu_list, var_list):
        param.grad = -mu + param.data
    reset_optimizer.step()
    for i, x in enumerate(input):
        count += 1
        x = input[i:i+1] # x[None]
        logits = []
        start = time.time()
        for j in range(10):
            proposed_label = proposed_labels[j:j+1]
            if verbose:
                reset_optimizer.zero_grad()
                for param, mu, var in zip(new_params, mu_list, var_list):
                    param.grad = -mu + param.data
                reset_optimizer.step()


            loss, output = cross_entropy(new_model, x, proposed_label)
            orig_ce = np.array(loss.detach().cpu())
            # kl_loss = model.compute_logprob(new_params, mvc, diag=True)
            combined_loss = nml_scale * loss # - 2 * kl_loss
            sgd_optimizer.zero_grad()
            # loss.backward()
            # (-kl_loss).backward()
            combined_loss.backward()

            post_adapt_loss = loss
            for param, mu, var in zip(new_params, mu_list, var_list):
                g = param.grad
                post_adapt_loss -= (g**2 * var /  2).sum()
                
                if verbose:
                    param.grad += (param - mu) / var
                    param.grad *= var / 2 # - mu + param.data)
                # param.grad = (param.grad * var / 2) + (param - mu) / 2 # - mu + param.data)
                #  param.grad = (param.data - mu)

            # grad_norm = torch.nn.utils.clip_grad_norm(new_model.parameters(), 1000)
            # if verbose:
                # if (i % 5 == 0 or i < 10):
                    # print("itr {}, ce: {}, kl: {}".format(i, loss, -kl_loss))# kl_loss = model.compute_logprob(diag=True)
                    # print("ce grad norm: {}".format(grad_norm))

            if verbose:
                sgd_optimizer.step()
                kl_loss = model.compute_logprob(new_params, mvc, diag=True)
                print("kl loss", -kl_loss.detach())
            if verbose:
                # orig_ce, _ = cross_entropy(map_model, x, proposed_label)
                loss, output = cross_entropy(new_model, x, proposed_label)
                print("ce loss", loss.detach())
                print("linear approx ce", post_adapt_loss.detach())
                print("orig ce loss", orig_ce)
                print("")
            logits.append(-post_adapt_loss) 
            # del orig_ce
            # torch.cuda.empty_cache()
            # print(torch.cuda.memory_summary())
        if verbose:
            print("Datapoint Time", time.time() - start)
            import ipdb; ipdb.set_trace()
        all_logits.append(torch.tensor(logits))
    all_logits = torch.stack(all_logits).cuda()

    normalized_logits = F.log_softmax(all_logits, dim=-1)
    # import ipdb; ipdb.set_trace()
    nml_probs = torch.exp(normalized_logits)
    nml_entropies = (-nml_probs * normalized_logits).sum(dim=-1)
    print("NML Entropy", nml_entropies.mean())
    nml_comps = torch.log(torch.exp(all_logits).sum(dim=-1))
    print("NML Comps", nml_comps.mean())
    map_logits = map_model(input)
    map_logits = F.log_softmax(map_logits, dim=-1)
    map_probs = torch.exp(map_logits)
    map_entropies = (-map_probs * map_logits).sum(dim=-1)
    print("MAP Entropy", map_entropies.mean(), flush=True)

    # final_loss = F.cross_entropy(all_logits, target)
    # model.sample(0)
    # print("MAP v1:", F.cross_entropy(model(input), target))
    # print("MAP v2:", F.cross_entropy(map_model(input), target))
    # print("NML Loss", final_loss)
    return F.cross_entropy(all_logits, target), all_logits

def nml_kfac_ce(model, input, target, update_bn_fn, nml_scale=1., n_steps=10, verbose=False):
    all_logits = []
    model.eval()
    model.net.eval()
    # params = list(model.net.parameters())
    kfac_params = model.get_kfac_trainable_params()
    params = kfac_params
    mu_kfac_params = model.trainable_mean_state_params
    mu_list = mu_kfac_params

    count = 0
    # For better stability with KFAC-Laplace, we use more gradient steps with a smaller step size
    sgd_optimizer = torch.optim.SGD(params, lr=0.25)
    proposed_labels = torch.tensor([i for i in range(10)]).cuda()

    def get_kl():
        kl_loss = 0.
        sgd_optimizer.zero_grad()
        for param, mu in zip(params, mu_list):
            param.grad += param - mu
        # model.step(False, True)
        model.step(False, True, use_inv=False)
        for param, mu in zip(params, mu_list):
            kl_loss += (1 / nml_scale) * 0.5 * (param.grad * (param - mu)).sum()  
            kl_loss += (1 / nml_scale) * 0.5 * model.eps * ((param - mu) * (param - mu)).sum()
        return kl_loss

    for i, x in enumerate(input):
        count += 1
        x = input[i:i+1] # x[None]
        logits = []
        start = time.time()
        for j in range(n_steps):
            proposed_label = proposed_labels[j:j+1]
            model.net.load_state_dict(model.mean_state)

            for i in range(n_steps):
                loss, output = cross_entropy(model.net, x, proposed_label)
                if i == 0:
                    orig_ce = loss
                if verbose:
                    kl_loss = get_kl()
                    # kl_loss = model.compute_logprob(params, mvc, diag=True)

                # correct nml temp really should be 1/N
                combined_loss = nml_scale * loss # - 2 * kl_loss
                sgd_optimizer.zero_grad()
                # loss.backward()
                # (-kl_loss).backward()
                combined_loss.backward()

                # really should be scaling here
                # applies preconditioner 
                model.step(False, True, use_inv=True)

                for param, mu in zip(params, mu_list):
                    param.grad += (param - mu) # / 2
                """
                for param, mu, var in zip(new_params, mu_list, var_list):
                    param.grad += (param - mu) / var
                    param.grad *= var / 2 # - mu + param.data)
                    # param.grad = (param.grad * var / 2) + (param - mu) / 2 # - mu + param.data)
                    #  param.grad = (param.data - mu)
                """

                # grad_norm = torch.nn.utils.clip_grad_norm(new_model.parameters(), 1000)
                sgd_optimizer.step()
                if verbose:
                    if (i % 5 == 0 or i < 10):
                        print("itr {}, ce: {}, kl: {}".format(i, loss, -kl_loss))# kl_loss = model.compute_logprob(diag=True)
                        # print("ce grad norm: {}".format(grad_norm))

            if verbose:
                kl_loss = get_kl()
                # kl_loss = model.compute_logprob(params, mvc, diag=True)
                print("kl loss", -kl_loss)
            loss, output = cross_entropy(model.net, x, proposed_label)
            if verbose:
                # orig_ce, _ = cross_entropy(map_model, x, proposed_label)
                print("ce loss", loss)
                print("orig ce loss", orig_ce)
                print("")
            logits.append(-loss) 
            # del orig_ce
            # torch.cuda.empty_cache()
            # print(torch.cuda.memory_summary())
        if verbose:
            print("Datapoint Time", time.time() - start, flush=True)
            import ipdb; ipdb.set_trace()
        all_logits.append(torch.tensor(logits))
    all_logits = torch.stack(all_logits).cuda()

    normalized_logits = F.log_softmax(all_logits, dim=-1)
    # import ipdb; ipdb.set_trace()
    nml_probs = torch.exp(normalized_logits)
    nml_entropies = (-nml_probs * normalized_logits).sum(dim=-1)
    print("NML Entropy", nml_entropies.mean())
    nml_comps = torch.log(torch.exp(all_logits).sum(dim=-1))
    print("NML Comps", nml_comps.mean())
    model.net.load_state_dict(model.mean_state)
    map_logits = model.net(input)
    map_logits = F.log_softmax(map_logits, dim=-1)
    map_probs = torch.exp(map_logits)
    map_entropies = (-map_probs * map_logits).sum(dim=-1)
    print("MAP Entropy", map_entropies.mean(), flush=True)

    # final_loss = F.cross_entropy(all_logits, target)
    # model.sample(0)
    # print("MAP v1:", F.cross_entropy(model(input), target))
    # print("MAP v2:", F.cross_entropy(map_model(input), target))
    # print("NML Loss", final_loss)
    return F.cross_entropy(all_logits, target), all_logits

def nmlv2_kfac_ce(model, input, target, update_bn_fn, nml_scale=1., n_steps=10):
    verbose = False
    # verbose = True
    all_logits = []
    model.eval()
    model.net.eval()
    # params = list(model.net.parameters())
    kfac_params = model.get_kfac_trainable_params()
    params = kfac_params
    mu_kfac_params = model.trainable_mean_state_params
    mu_list = mu_kfac_params

    sgd_optimizer = torch.optim.SGD(params, lr=0.5)
    count = 0
    # proposed_labels = torch.eye(10).cuda()
    proposed_labels = torch.tensor([i for i in range(10)]).cuda()
    def get_kl():
        kl_loss = 0.
        sgd_optimizer.zero_grad()
        for param, mu in zip(params, mu_list):
            param.grad += param - mu
        # model.step(False, True)
        model.step(False, True, use_inv=False)
        for param, mu in zip(params, mu_list):
            kl_loss += (1 / nml_scale) * 0.5 * (param.grad * (param - mu)).sum()  
            kl_loss += (1 / nml_scale) * 0.5 * 5e-2 * ((param - mu) * (param - mu)).sum()
            # kl_loss += (1 / nml_scale) * 0.5 * (param.grad * (param - mu)).sum()
        return kl_loss
    for i, x in enumerate(input):
        count += 1
        x = input[i:i+1] # x[None]
        logits = []
        start = time.time()
        for j in range(10):
            proposed_label = proposed_labels[j:j+1]
            model.net.load_state_dict(model.mean_state)
            """
            reset_optimizer.zero_grad()
            for param, mu, var in zip(new_params, mu_list, var_list):
                param.grad = -mu + param.data
            reset_optimizer.step()
            """
            # import ipdb; ipdb.set_trace()
            # model.log_prob()
            for i in range(n_steps):
                loss, output = cross_entropy(model.net, x, proposed_label)
                if i == 0:
                    orig_ce = loss
                if verbose:
                    kl_loss = get_kl()
                    # kl_loss = model.compute_logprob(params, mvc, diag=True)

                # correct nml temp really should be 1/N
                combined_loss = nml_scale * loss # - 2 * kl_loss
                sgd_optimizer.zero_grad()
                # loss.backward()
                # (-kl_loss).backward()
                combined_loss.backward()

                # really should be scaling here
                # applies preconditioner 
                model.step(False, True, use_inv=True)

                for param, mu in zip(params, mu_list):
                    param.grad += (param - mu) # / 2
                """
                for param, mu, var in zip(new_params, mu_list, var_list):
                    param.grad += (param - mu) / var
                    param.grad *= var / 2 # - mu + param.data)
                    # param.grad = (param.grad * var / 2) + (param - mu) / 2 # - mu + param.data)
                    #  param.grad = (param.data - mu)
                """

                # grad_norm = torch.nn.utils.clip_grad_norm(new_model.parameters(), 1000)
                sgd_optimizer.step()
                if verbose:
                    if (i % 5 == 0 or i < 10):
                        print("itr {}, ce: {}, kl: {}".format(i, loss, -kl_loss))# kl_loss = model.compute_logprob(diag=True)
                        # print("ce grad norm: {}".format(grad_norm))

            if verbose:
                kl_loss = get_kl()
                # kl_loss = model.compute_logprob(params, mvc, diag=True)
                print("kl loss", -kl_loss)
            loss, output = cross_entropy(model.net, x, proposed_label)
            if verbose:
                # orig_ce, _ = cross_entropy(map_model, x, proposed_label)
                print("ce loss", loss)
                print("orig ce loss", orig_ce)
                print("")
            logits.append(-loss) 
            # del orig_ce
            # torch.cuda.empty_cache()
            # print(torch.cuda.memory_summary())
        if verbose:
            print("Datapoint Time", time.time() - start, flush=True)
            import ipdb; ipdb.set_trace()
        all_logits.append(torch.tensor(logits))
    all_logits = torch.stack(all_logits).cuda()

    normalized_logits = F.log_softmax(all_logits, dim=-1)
    # import ipdb; ipdb.set_trace()
    nml_probs = torch.exp(normalized_logits)
    nml_entropies = (-nml_probs * normalized_logits).sum(dim=-1)
    print("NML Entropy", nml_entropies.mean())
    nml_comps = torch.log(torch.exp(all_logits).sum(dim=-1))
    print("NML Comps", nml_comps.mean())
    model.net.load_state_dict(model.mean_state)
    map_logits = model.net(input)
    map_logits = F.log_softmax(map_logits, dim=-1)
    map_probs = torch.exp(map_logits)
    map_entropies = (-map_probs * map_logits).sum(dim=-1)
    print("MAP Entropy", map_entropies.mean(), flush=True)

    # final_loss = F.cross_entropy(all_logits, target)
    # model.sample(0)
    # print("MAP v1:", F.cross_entropy(model(input), target))
    # print("MAP v2:", F.cross_entropy(map_model(input), target))
    # print("NML Loss", final_loss)
    return F.cross_entropy(all_logits, target), all_logits

def maxent_ce(model, map_model, input, target, update_bn_fn, test_weight=1., n_steps=20):
    # verbose = False
    verbose = True
    all_logits = []
    model.eval()
    model.var_clamp = 0.00000000001
    # map_model = copy.deepcopy(erm_model)
    # map_model.eval()
    mu_list, var_list, covar_list = model.generate_mean_var_covar()

    mvc = (mu_list, var_list, covar_list)
    new_model = map_model
    # new_model = copy.deepcopy(map_model)
    new_model.eval()
    reset_optimizer = torch.optim.SGD(new_model.parameters(), lr=1)
    sgd_optimizer = torch.optim.SGD(new_model.parameters(), lr=1)
    new_params = list(new_model.parameters())
    count = 0
    for i, x in enumerate(input):
        count += 1
        x = input[i:i+1] # x[None]
        logits = []
        start = time.time()
        # proposed_label = proposed_labels[j:j+1]
        # set to copy?
        reset_optimizer.zero_grad()
        for param, mu, var in zip(new_params, mu_list, var_list):
            param.grad = -mu + param.data
        reset_optimizer.step()
        for i in range(n_steps):
            loss, output = entropy(new_model, x)
            if i == 0:
                orig_ent = loss
            if verbose:
                kl_loss = model.compute_logprob(new_params, mvc, diag=True)
            combined_loss = -test_weight * loss # - 2 * kl_loss
            sgd_optimizer.zero_grad()
            combined_loss.backward()

            for param, mu, var in zip(new_params, mu_list, var_list):
                param.grad = (param.grad *  var  + (param - mu)) / 2
                # param.grad *= var / 2 # - mu + param.data)

            # grad_norm = torch.nn.utils.clip_grad_norm(new_model.parameters(), 1000)
            sgd_optimizer.step()
            if verbose:
                if (i % 5 == 0 or i < 10):
                    print("itr {}, ce: {}, kl: {}".format(i, loss, -kl_loss))# kl_loss = model.compute_logprob(diag=True)
                    # print("ce grad norm: {}".format(grad_norm))

        # if usev2
        if verbose:
            kl_loss = model.compute_logprob(new_params, mvc, diag=True)
            print("kl loss", -kl_loss)
        # loss, output = cross_entropy(new_model, x, proposed_label)
        loss, output = entropy(new_model, x)
        if verbose:
            # orig_ce, _ = cross_entropy(map_model, x, proposed_label)
            print("ent loss", loss)
            print("orig ent loss", orig_ent)
            print("")
        # del orig_ce
        # torch.cuda.empty_cache()
        # print(torch.cuda.memory_summary())
        if verbose:
            print("Datapoint Time", time.time() - start)
        all_logits.append(output[0])
    all_logits = torch.stack(all_logits).cuda().detach()

    normalized_logits = F.log_softmax(all_logits, dim=-1)
    # import ipdb; ipdb.set_trace()
    nml_probs = torch.exp(normalized_logits)
    nml_entropies = (-nml_probs * normalized_logits).sum(dim=-1)
    print(n_steps)
    print("NML Entropy", nml_entropies.mean())
    nml_comps = torch.log(torch.exp(all_logits).sum(dim=-1))
    print("NML Comps", nml_comps.mean())
    map_logits = map_model(input)
    map_logits = F.log_softmax(map_logits, dim=-1)
    map_probs = torch.exp(map_logits)
    map_entropies = (-map_probs * map_logits).sum(dim=-1)
    print("MAP Entropy", map_entropies.mean(), flush=True)

    # final_loss = F.cross_entropy(all_logits, target)
    # model.sample(0)
    # print("MAP v1:", F.cross_entropy(model(input), target))
    # print("MAP v2:", F.cross_entropy(map_model(input), target))
    # print("NML Loss", final_loss)
    return F.cross_entropy(all_logits, target), all_logits

def nml_ce(model, map_model, input, target, update_bn_fn, nml_scale=1., n_steps=5, use_v2=False):
    verbose = False
    # verbose = True
    all_logits = []
    model.eval()
    model.var_clamp = 0.00000000001
    # map_model = copy.deepcopy(erm_model)
    # map_model.eval()
    mu_list, var_list, covar_list = model.generate_mean_var_covar()

    mvc = (mu_list, var_list, covar_list)
    # print(F.cross_entropy(model(input), target))


    new_model = map_model
    # new_model = copy.deepcopy(map_model)
    new_model.eval()
    reset_optimizer = torch.optim.SGD(new_model.parameters(), lr=1)
    sgd_optimizer = torch.optim.SGD(new_model.parameters(), lr=1)
    # sgd_optimizer = torch.optim.SGD(new_model.parameters(), lr=0.25)
    new_params = list(new_model.parameters())
    count = 0
    # proposed_labels = torch.eye(10).cuda()
    proposed_labels = torch.tensor([i for i in range(10)]).cuda()
    import ipdb; ipdb.set_trace()
    total_start = time.time()
    for i, x in enumerate(input):
        count += 1
        x = input[i:i+1] # x[None]
        logits = []
        start = time.time()
        for j in range(10):
            proposed_label = proposed_labels[j:j+1]
            reset_optimizer.zero_grad()
            for param, mu, var in zip(new_params, mu_list, var_list):
                param.grad = -mu + param.data
            reset_optimizer.step()
            for i in range(n_steps):
                loss = 0
                # this forward pass is also 0.07s # 1/5
                loss, output = cross_entropy(new_model, x, proposed_label)
                # if i == 0:
                    # orig_ce = loss
                if verbose:
                    kl_loss = model.compute_logprob(new_params, mvc, diag=True)
                combined_loss = nml_scale * loss # - 2 * kl_loss

                # zeroing out grads takes 0.02s
                sgd_optimizer.zero_grad()
                # loss.backward()
                # (-kl_loss).backward()

                # backward pass takes 0.11s
                combined_loss.backward()

                # this loop takes around 0.125s (1/3 of time)
                for param, mu, var in zip(new_params, mu_list, var_list):
                    param.grad += (param - mu) / var
                    param.grad *= var / 2 # - mu + param.data)
                    # param.grad = (param.grad * var / 2) + (param - mu) / 2 # - mu + param.data)
                    #  param.grad = (param.data - mu)

                # grad_norm = torch.nn.utils.clip_grad_norm(new_model.parameters(), 1000)
                # stepping takes anohter 0.02
                sgd_optimizer.step()
                if verbose:
                    if (i % 5 == 0 or i < 10):
                        print("itr {}, ce: {}, kl: {}".format(i, loss, -kl_loss))# kl_loss = model.compute_logprob(diag=True)
                        # print("ce grad norm: {}".format(grad_norm))

            # if usev2
            if use_v2 or verbose:
                kl_loss = model.compute_logprob(new_params, mvc, diag=True)
            if verbose:
                print("kl loss", -kl_loss)
            # loss, output = 0, 0 # cross_entropy(new_model, x, proposed_label)
            loss, output = cross_entropy(new_model, x, proposed_label)
            if verbose:
                # orig_ce, _ = cross_entropy(map_model, x, proposed_label)
                print("ce loss", loss)
                print("orig ce loss", orig_ce)
                print("")
            if use_v2:
                logits.append(-loss - kl_loss / nml_scale) 
            else:
                logits.append(-loss) 
            # del orig_ce
            # torch.cuda.empty_cache()
            # print(torch.cuda.memory_summary())
        if verbose:
            print("Datapoint Time", time.time() - start)
        print("Datapoint Time", time.time() - start)
        all_logits.append(torch.tensor(logits))
    all_logits = torch.stack(all_logits).cuda()

    normalized_logits = F.log_softmax(all_logits, dim=-1)
    # import ipdb; ipdb.set_trace()
    nml_probs = torch.exp(normalized_logits)
    nml_entropies = (-nml_probs * normalized_logits).sum(dim=-1)
    print(n_steps)
    print("NML Entropy", nml_entropies.mean())
    nml_comps = torch.log(torch.exp(all_logits).sum(dim=-1))
    print("NML Comps", nml_comps.mean())
    map_logits = map_model(input)
    map_logits = F.log_softmax(map_logits, dim=-1)
    map_probs = torch.exp(map_logits)
    map_entropies = (-map_probs * map_logits).sum(dim=-1)
    print("MAP Entropy", map_entropies.mean(), flush=True)
    print("Total time", time.time() - total_start)
    import ipdb; ipdb.set_trace()

    # final_loss = F.cross_entropy(all_logits, target)
    # model.sample(0)
    # print("MAP v1:", F.cross_entropy(model(input), target))
    # print("MAP v2:", F.cross_entropy(map_model(input), target))
    # print("NML Loss", final_loss)
    return F.cross_entropy(all_logits, target), all_logits



def adversarial_cross_entropy(
    model, input, target, lossfn=F.cross_entropy, epsilon=0.01
):
    # loss function based on algorithm 1 of "simple and scalable uncertainty estimation using
    # deep ensembles," lakshminaraynan, pritzel, and blundell, nips 2017,
    # https://arxiv.org/pdf/1612.01474.pdf
    # note: the small difference bw this paper is that here the loss is only backpropped
    # through the adversarial loss rather than both due to memory constraints on preresnets
    # we can change back if we want to restrict ourselves to VGG-like networks (where it's fine).

    # scale epsilon by min and max (should be [0,1] for all experiments)
    # see algorithm 1 of paper
    scaled_epsilon = epsilon * (input.max() - input.min())

    # force inputs to require gradient
    input.requires_grad = True

    # standard forwards pass
    output = model(input)
    loss = lossfn(output, target)

    # now compute gradients wrt input
    loss.backward(retain_graph=True)

    # now compute sign of gradients
    inputs_grad = torch.sign(input.grad)

    # perturb inputs and use clamped output
    inputs_perturbed = torch.clamp(
        input + scaled_epsilon * inputs_grad, 0.0, 1.0
    ).detach()
    # inputs_perturbed.requires_grad = False

    input.grad.zero_()
    # model.zero_grad()

    outputs_perturbed = model(inputs_perturbed)

    # compute adversarial version of loss
    adv_loss = lossfn(outputs_perturbed, target)

    # return mean of loss for reasonable scalings
    return (loss + adv_loss) / 2.0, output


def masked_loss(y_pred, y_true, void_class=11.0, weight=None, reduce=True):
    # masked version of crossentropy loss

    el = torch.ones_like(y_true) * void_class
    mask = torch.ne(y_true, el).long()

    y_true_tmp = y_true * mask

    loss = F.cross_entropy(y_pred, y_true_tmp, weight=weight, reduction="none")
    loss = mask.float() * loss

    if reduce:
        return loss.sum() / mask.sum()
    else:
        return loss, mask


def seg_cross_entropy(model, input, target, weight=None):
    output = model(input)

    # use masked loss function
    loss = masked_loss(output, target, weight=weight)

    return {"loss": loss, "output": output}


def seg_ale_cross_entropy(model, input, target, num_samples=50, weight=None):
    # requires two outputs for model(input)

    output = model(input)
    mean = output[:, 0, :, :, :]
    scale = output[:, 1, :, :, :].abs()

    output_distribution = torch.distributions.Normal(mean, scale)

    total_loss = 0

    for _ in range(num_samples):
        sample = output_distribution.rsample()

        current_loss, mask = masked_loss(sample, target, weight=weight, reduce=False)
        total_loss = total_loss + current_loss.exp()
    mean_loss = total_loss / num_samples

    return {"loss": mean_loss.log().sum() / mask.sum(), "output": mean, "scale": scale}
