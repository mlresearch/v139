import argparse
import os, sys
import time
import tabulate

import torch
import torch.nn.functional as F
import torchvision
import numpy as np

from swag import data, models, utils, losses
from swag.posteriors import SWAG, KFACLaplace

from record_stats import save_statistics


parser = argparse.ArgumentParser(description="SGD/SWA training")
parser.add_argument(
    "--dir",
    type=str,
    default=None,
    required=True,
    help="training directory (default: None)",
)

parser.add_argument(
    "--dataset", type=str, default="CIFAR10", help="dataset name (default: CIFAR10)"
)
parser.add_argument(
    "--data_path",
    type=str,
    default='datasets',
    # required=True,
    metavar="PATH",
    help="path to datasets location (default: None)",
)
parser.add_argument(
    "--use_test",
    dest="use_test",
    action="store_true",
    help="use test dataset instead of validation (default: False)",
)
parser.add_argument(
    "--use_stl",
    dest="use_stl",
    action="store_true",
    help="use ood STL10 test dataset instead (default: False)",
)
parser.add_argument(
    "--use_cifar_c",
    dest="use_cifar_c",
    action="store_true",
    help="use corrupted CIFAR test dataset instead (default: False)",
)
parser.add_argument(
    "--corruption_type",
    type=str,
    required=False,
)
parser.add_argument(
    "--corruption_level",
    type=int,
    required=False,
)
parser.add_argument(
    "--eval_kfac_nml",
    dest="eval_kfac_nml",
    action="store_true",
    help="Evaluate ACNML with KFAC Laplace (default: False)",
)
parser.add_argument(
    "--eval_kfac_bayes",
    dest="eval_kfac_bayes",
    action="store_true",
    help="Evaluate Bayesian marginalization with KFAC Laplace (default: False)",
)
parser.add_argument("--split_classes", type=int, default=None)
parser.add_argument(
    "--batch_size",
    type=int,
    default=128,
    metavar="N",
    help="input batch size (default: 128)",
)
parser.add_argument(
    "--num_workers",
    type=int,
    default=8,
    metavar="N",
    help="number of workers (default: 4)",
)
parser.add_argument(
    "--model",
    type=str,
    default=None,
    required=True,
    metavar="MODEL",
    help="model name (default: None)",
)

parser.add_argument(
    "--resume",
    type=str,
    default=None,
    metavar="CKPT",
    help="checkpoint to resume training from (default: None)",
)

parser.add_argument(
    "--lr_init",
    type=float,
    default=0.01,
    metavar="LR",
    help="initial learning rate (default: 0.01)",
)
parser.add_argument(
    "--momentum",
    type=float,
    default=0.9,
    metavar="M",
    help="SGD momentum (default: 0.9)",
)
parser.add_argument(
    "--nml_temp",
    type=float,
    default=1.,
    help="NML temp",
)
parser.add_argument(
    "--bayes_scale",
    type=float,
    default=1.,
    help="Bayes scaling temp",
)
parser.add_argument(
    "--wd", type=float, default=1e-4, help="weight decay (default: 1e-4)"
)

parser.add_argument("--swa", action="store_true", help="swa usage flag (default: off)")
parser.add_argument(
    "--swa_start",
    type=float,
    default=161,
    metavar="N",
    help="SWA start epoch number (default: 161)",
)
parser.add_argument(
    "--swa_lr", type=float, default=0.02, metavar="LR", help="SWA LR (default: 0.02)"
)
parser.add_argument(
    "--swa_c_epochs",
    type=int,
    default=1,
    metavar="N",
    help="SWA model collection frequency/cycle length in epochs (default: 1)",
)
parser.add_argument("--cov_mat", action="store_true", help="save sample covariance")
parser.add_argument(
    "--max_num_models",
    type=int,
    default=20,
    help="maximum number of SWAG models to save",
)

parser.add_argument(
    "--swa_resume",
    type=str,
    default=None,
    metavar="CKPT",
    help="checkpoint to restor SWA from (default: None)",
)
parser.add_argument(
    "--loss",
    type=str,
    default="CE",
    help="loss to use for training model (default: Cross-entropy)",
)

parser.add_argument(
    "--seed", type=int, default=1, metavar="S", help="random seed (default: 1)"
)
parser.add_argument("--no_schedule", action="store_true", help="store schedule")

args = parser.parse_args()

args.device = None
if torch.cuda.is_available():
    args.device = torch.device("cuda")
else:
    args.device = torch.device("cpu")

print("Preparing directory %s" % args.dir)
os.makedirs(args.dir, exist_ok=True)
with open(os.path.join(args.dir, "command.sh"), "w") as f:
    f.write(" ".join(sys.argv))
    f.write("\n")

torch.backends.cudnn.benchmark = True
torch.manual_seed(args.seed)
torch.cuda.manual_seed(args.seed)

print("Using model %s" % args.model)
model_cfg = getattr(models, args.model)

print("Loading dataset %s from %s" % (args.dataset, args.data_path))
# split loaders
# split_loaders, num_classes = data.loaders(
    # args.dataset,
    # args.data_path,
    # args.batch_size,
    # args.num_workers,
    # model_cfg.transform_train,
    # model_cfg.transform_test,
    # use_validation=True,
    # split_classes=args.split_classes,
# )
loaders, num_classes = data.loaders(
    args.dataset,
    args.data_path,
    args.batch_size,
    args.num_workers,
    model_cfg.transform_train,
    model_cfg.transform_test,
    use_validation=not args.use_test,
    split_classes=args.split_classes,
)
train_loaders, num_classes = data.loaders(
    args.dataset,
    args.data_path,
    128,
    args.num_workers,
    model_cfg.transform_train,
    model_cfg.transform_test,
    use_validation=not args.use_test,
    split_classes=args.split_classes,
)

if args.use_stl:
    ood_dataset = 'STL10'
    print("Loading dataset %s from %s" % (ood_dataset, args.data_path))
    stl_loaders, ood_num_classes = data.loaders(
        ood_dataset,
        args.data_path,
        args.batch_size,
        args.num_workers,
        model_cfg.transform_train,
        model_cfg.transform_test,
        use_validation=not args.use_test,
        split_classes=args.split_classes,
    )

if args.use_cifar_c:
    cifar10c_loaders = data.load_cifar10_c(args.data_path, args.corruption_type, args.corruption_level, args.batch_size, args.num_workers, model_cfg.transform_test)

print("Preparing model", flush=True)
print(*model_cfg.args)
model = model_cfg.base(*model_cfg.args, num_classes=num_classes, **model_cfg.kwargs)
model.to(args.device)


if args.cov_mat:
    args.no_cov_mat = False
else:
    args.no_cov_mat = True
if args.swa:
    print("SWAG training")
    swag_model = SWAG(
        model_cfg.base,
        no_cov_mat=args.no_cov_mat,
        max_num_models=args.max_num_models,
        *model_cfg.args,
        num_classes=num_classes,
        **model_cfg.kwargs
    )
    swag_model.to(args.device)
else:
    print("SGD training")




# use a slightly modified loss function that allows input of model
if args.loss == "CE":
    criterion = losses.cross_entropy
    # criterion = F.cross_entropy
elif args.loss == "adv_CE":
    criterion = losses.adversarial_cross_entropy

optimizer = torch.optim.SGD(
    model.parameters(), lr=args.lr_init, momentum=args.momentum, weight_decay=args.wd
)

start_epoch = 0

print("Resume training from %s" % args.resume)
checkpoint = torch.load(args.resume)
start_epoch = checkpoint["epoch"]
model.load_state_dict(checkpoint["state_dict"])
optimizer.load_state_dict(checkpoint["optimizer"])

data_size = len(loaders["train"].dataset)
# deal with batch norm when it's not VGG
if args.eval_kfac_bayes:
    eps = 5e-4
else:
    eps = 5e-2
kfac_model = KFACLaplace(model, eps=eps, alpha=.1, data_size=data_size, use_batch_norm=False)
# for i in range(args.N):
    # print("%d/%d" % (i + 1, args.N))
# if args.method == "KFACLaplace":
    ## KFAC Laplace needs one forwards pass to load the KFAC model at the beginning
# kfac_model.net.load_state_dict(kfac_model.mean_state)

kfac_model.net.train()

print("Starting KFAC computation", flush=True)
# even more?
utils.compute_kfac(train_loaders['train'], kfac_model, losses.cross_entropy, n_batches=20)
"""
t_input, t_target = next(iter(loaders["train"]))
t_input, t_target = (
    t_input.cuda(non_blocking=True),
    t_target.cuda(non_blocking=True),
)
loss, _ = losses.cross_entropy(kfac_model.net, t_input, t_target)
loss.backward(create_graph=True)
kfac_model.step(update_params=False)
"""
kfac_model.eval()
print("KFAC computed", flush=True)

"""
checkpoint = torch.load(args.swa_resume)
swag_model = SWAG(
    model_cfg.base,
    no_cov_mat=args.no_cov_mat,
    max_num_models=args.max_num_models,
    # loading=True,
    *model_cfg.args,
    num_classes=num_classes,
    **model_cfg.kwargs
)
swag_model.to(args.device)
swag_model.load_state_dict(checkpoint["state_dict"])
"""

# columns = ["ep", "lr", "tr_loss", "tr_acc", "te_loss", "te_acc", "time", "mem_usage"]
# if args.swa:
    # columns = columns[:-2] + ["swa_te_loss", "swa_te_acc"] + columns[-2:]
    # columns = columns[:-2] + ["nml_te_loss", "nml_te_acc"] + columns[-2:]
    # swag_res = {"loss": None, "accuracy": None}
    # nml_res = {"loss": None, "accuracy": None}

def nll(logits, labels):
    labels = labels.astype(int)
    idx = (np.arange(labels.size), labels)
    nll = -np.mean(logits[idx])
    return nll

def labels(loader, model):
    labels = []
    for _, target in loader:
        labels.append(target.numpy())
    return np.concatenate(labels)

def inputs(loader):
    inputs = []
    for input, _ in loader:
        inputs.append(input.numpy())
    return np.concatenate(inputs)

sgd_ens_preds = None
sgd_targets = None
n_ensembled = 0.0


# def update_bn(model): utils.bn_update(split_loaders["train"], model)
def update_bn(model): utils.bn_update(loaders["train"], model)

# drop prefix and rely on directory
prefix = "{}/".format(args.dir, args.model, args.seed)
# swag_model.sample(0.)
# update_bn(swag_model)
if args.use_test:
    test_str = 'test'
else:
    test_str = 'val'

test_labels = labels(loaders['test'], model)
if args.use_stl:
    stl_labels = labels(stl_loaders['test'], model)
if args.use_cifar_c:
    cifar_c_labels = labels(cifar10c_loaders['test'], model).astype(int)
    cifar_c_str = "cifar_{}{}".format(args.corruption_type, args.corruption_level)

# sgd_logits_cifar = np.log(utils.predict(loaders["test"], model)['predictions'])
# criterion = losses.cross_entropy
# sgd_res = utils.eval(loaders["test"], model, criterion)
# save_statistics("{}sgd_results_cifar{}.pkl".format(prefix, test_str), np.array(sgd_logits_cifar), test_labels)

def eval_sgd(test_loader, train_loader, labels, ds_name):
    sgd_logits = np.log(utils.predict(test_loader, model)['predictions'])
    save_statistics("{}sgd_results_{}.pkl".format(prefix, ds_name), np.array(sgd_logits), labels)

def eval_sgd_dropout(test_loader, train_loader, labels, ds_name):
    sgd_logits = np.log(utils.predict(test_loader, model)['predictions'])
    save_statistics("{}sgd_results_{}.pkl".format(prefix, ds_name), np.array(sgd_logits), labels)

def eval_kfac_bayes(test_loader, train_loader, labels, ds_name):
    scale = args.bayes_scale
    marginal_logits = utils.marginal_kfac_laplace(test_loader, kfac_model, K=30, scale=scale)
    save_statistics('{}{}scale_marginal_{}.pkl'.format(prefix, scale, ds_name), marginal_logits, labels)

def eval_kfac_nml(test_loader, train_loader, labels, ds_name):
    final_nml_res, nml_logits = utils.eval_kfac_nml(test_loader, kfac_model, losses.nml_kfac_ce, update_bn, run_all=True, nml_temp=args.nml_temp / data_size)
    # save_statistics('{}cnml_results_{}lossweight_{}.pkl'.format(prefix, args.nml_temp, ds_name), nml_logits.cpu().numpy(), labels)
    save_statistics('{}testdiffwd_cnml_results_{}lossweight_{}.pkl'.format(prefix, args.nml_temp, ds_name), nml_logits.cpu().numpy(), labels)

train_loader = loaders['train']
if args.use_stl:
    test_loader = stl_loaders['test']
    labels = stl_labels
    ds_name = 'stl10'
elif args.use_cifar_c:
    test_loader = cifar10c_loaders['test']
    labels = cifar_c_labels
    ds_name = cifar_c_str
else:
    test_loader = loaders['test']
    labels = test_labels
    ds_name = 'cifar{}'.format(test_str)

if args.eval_kfac_bayes:
    eval_kfac_bayes(test_loader, train_loader, labels, ds_name)
elif args.eval_kfac_nml:
    eval_kfac_nml(test_loader, train_loader, labels, ds_name)
else:
    eval_sgd(test_loader, train_loader, labels, ds_name)
