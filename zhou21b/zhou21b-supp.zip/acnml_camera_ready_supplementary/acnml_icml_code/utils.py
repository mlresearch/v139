import itertools
import torch
import os
import copy
from datetime import datetime
import math
import numpy as np
import scipy
import tqdm

from swag import losses

import torch.nn.functional as F


def flatten(lst):
    tmp = [i.contiguous().view(-1, 1) for i in lst]
    return torch.cat(tmp).view(-1)


def unflatten_like(vector, likeTensorList):
    # Takes a flat torch.tensor and unflattens it to a list of torch.tensors
    #    shaped like likeTensorList
    outList = []
    i = 0
    for tensor in likeTensorList:
        # n = module._parameters[name].numel()
        n = tensor.numel()
        outList.append(vector[:, i : i + n].view(tensor.shape))
        i += n
    return outList


def LogSumExp(x, dim=0):
    m, _ = torch.max(x, dim=dim, keepdim=True)
    return m + torch.log((x - m).exp().sum(dim=dim, keepdim=True))

def np_marginal_logits(x, dim=0):
    K = len(x)
    return np.log(np.sum(x, axis=0) / K)

def np_nml_logits(logits, dim=0):
    max_logits = np.amax(logits, axis=0)
    nml_logits = max_logits - scipy.special.logsumexp(max_logits, axis=-1, keepdims=True)
    # normalized_probs = max_probs / np.sum(max_probs, axis=-1, keepdims=True)
    return nml_logits # np.log(normalized_probs)

def np_cnml_logits(logits, train_ll, dim=0):
    # train_ll = train_ll / 1000 # for working with train set
    max_indices = np.argmax(logits + train_ll[:, None, None], axis=0)
    max_logits = np.take_along_axis(logits, max_indices[None], axis=0)[0]
    print(max_indices[:100])
    print(train_ll)
    nml_logits = max_logits - scipy.special.logsumexp(max_logits, axis=-1, keepdims=True)
    # normalized_probs = max_probs / np.sum(max_probs, axis=-1, keepdims=True)
    return nml_logits # np.log(normalized_probs)

def select_best_member(logits, labels):
    correct_label_logits = np.take_along_axis(logits, labels[None, :, None], axis=-1)
    best_indices = np.argmax(correct_label_logits, axis=0)
    best_logits = np.take_along_axis(logits, best_indices[None], axis=0)[0]
    return best_logits

def adjust_learning_rate(optimizer, lr):
    for param_group in optimizer.param_groups:
        param_group["lr"] = lr
    return lr


def save_checkpoint(dir, epoch, name="checkpoint", **kwargs):
    state = {"epoch": epoch}
    state.update(kwargs)
    filepath = os.path.join(dir, "%s-%d.pt" % (name, epoch))
    torch.save(state, filepath)

def update_precond(
    loader,
    model, 
    criterion,
    preconditioner,
):
    for i, (input, target) in enumerate(loader):
        if cuda:
            input = input.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)

        loss, output = criterion(model, input, target)

        optimizer.zero_grad()
        loss.backward()
        preconditioner.update_stats()
        # optimizer.step()
    preconditioner.compute_invs()

def train_epoch(
    loader,
    model,
    criterion,
    optimizer,
    cuda=True,
    regression=False,
    verbose=False,
    subset=None,
    preconditioner=None,
):
    loss_sum = 0.0
    correct = 0.0
    verb_stage = 0

    num_objects_current = 0
    num_batches = len(loader)

    model.train()

    if subset is not None:
        num_batches = int(num_batches * subset)
        loader = itertools.islice(loader, num_batches)

    if verbose:
        loader = tqdm.tqdm(loader, total=num_batches)

    for i, (input, target) in enumerate(loader):
        if cuda:
            input = input.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)

        loss, output = criterion(model, input, target)

        optimizer.zero_grad()
        loss.backward()
        if preconditioner is not None:
            preconditioner.step()
        optimizer.step()

        loss_sum += loss.data.item() * input.size(0)

        if not regression:
            pred = output.data.argmax(1, keepdim=True)
            correct += pred.eq(target.data.view_as(pred)).sum().item()

        num_objects_current += input.size(0)

        if verbose and 10 * (i + 1) / num_batches >= verb_stage + 1:
            print(
                "Stage %d/10. Loss: %12.4f. Acc: %6.2f"
                % (
                    verb_stage + 1,
                    loss_sum / num_objects_current,
                    correct / num_objects_current * 100.0,
                )
            )
            verb_stage += 1

    return {
        "loss": loss_sum / num_objects_current,
        "accuracy": None if regression else correct / num_objects_current * 100.0,
    }


def eval(loader, model, criterion, cuda=True, regression=False, verbose=False):
    loss_sum = 0.0
    correct = 0.0
    num_objects_total = len(loader.dataset)

    model.eval()

    with torch.no_grad():
        if verbose:
            loader = tqdm.tqdm(loader)
        for i, (input, target) in enumerate(loader):
            if cuda:
                input = input.cuda(non_blocking=True)
                target = target.cuda(non_blocking=True)

            loss, output = criterion(model, input, target)

            loss_sum += loss.item() * input.size(0)

            if not regression:
                pred = output.data.argmax(1, keepdim=True)
                correct += pred.eq(target.data.view_as(pred)).sum().item()

    return {
        "loss": loss_sum / num_objects_total,
        "accuracy": None if regression else correct / num_objects_total * 100.0,
        "loss_sum": loss_sum
    }

def naive_cnml_logit(loader, new_x, model, erm_model, criterion, n_epochs=10):
    model.sample(0)
    map_model = copy.deepcopy(erm_model)
    # todo decide what to do here
    sgd_optimizer = torch.optim.SGD(map_model.parameters(), lr=0.001)
    logits = []
    batch_size = 128
    dataset_size = 45000
    for proposed_label in range(10):
        new_model = copy.deepcopy(map_model)
        for input, target in loader:
            combined_input = torch.cat(input, new_x[None])
            combined_labels = torch.cat(target, proposed_label[None])
            # todo finish this
            logits = new_model(combined_input)
            loss = F.cross_entropy(logits[:-1], combined_labels[-1])
            loss += 1 / dataset_size * F.cross_entropy(logits[-1:], combined_labels[-1:])
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        new_model.eval()
        final_logits = new_model(new_x[None])
        logits.append(final_logits[proposed_label])
    return np.array(logits)

def set_model_to_map(swag_model, map_model):
    sgd_optimizer = torch.optim.SGD(map_model.parameters(), lr=1)
    sgd_optimizer.zero_grad()
    new_params = list(map_model.parameters())
    mu_list, var_list, covar_list = swag_model.generate_mean_var_covar()
    for param, mu, var in zip(new_params, mu_list, var_list):
        # param.grad = (param.grad * var / 2 - mu + param.data)
        param.grad = (param.data - mu)
    sgd_optimizer.step()


def eval_kfac_nml(loader, model, criterion, update_bn_fn=None, cuda=True, regression=False, verbose=False, run_all=False, nml_temp=1.):
    loss_sum = 0.0
    correct = 0.0
    num_objects_total = len(loader.dataset)

    all_logits = []
    import time
    # update_bn_fn(model)
    # model.eval()
    # model.sample(0)

    # map_model = copy.deepcopy(erm_model)
    # sgd_optimizer = torch.optim.SGD(map_model.parameters(), lr=1)
    # sgd_optimizer.zero_grad()
    # new_params = list(map_model.parameters())
    # mu_list, var_list, covar_list = model.generate_mean_var_covar()
    # for param, mu, var in zip(new_params, mu_list, var_list):
        # # param.grad = (param.grad * var / 2 - mu + param.data)
        # param.grad = (param.data - mu)
    # sgd_optimizer.step()
    # update_bn_fn(map_model)
    # map_model.eval()

    # with torch.no_grad():
    if verbose:
        loader = tqdm.tqdm(loader)
    for i, (input, target) in enumerate(loader):
        start = time.time()
        if cuda:
            input = input.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)

        loss, output = criterion(model, input, target, update_bn_fn, nml_temp)
        all_logits.append(output)

        loss_sum += loss.item() * input.size(0)


        if not regression:
            pred = output.data.argmax(1, keepdim=True)
            correct += pred.eq(target.data.view_as(pred)).sum().item()

        print("Current Itr", i+1)
        print("Current Avg Loss", loss_sum / ((i+1) * 32))
        print("Current Acc", correct / ((i+1) * 32))
        print("Time", time.time() - start)
        if i > 0 and not run_all:
            break
    # can look at output to compute comps and entropies
    all_logits = torch.cat(all_logits)
    return {
        "loss": loss_sum / num_objects_total,
        "accuracy": None if regression else correct / num_objects_total * 100.0,
        # "loss": loss_sum / num_objects_total,
        # "accuracy": None if regression else correct / num_objects_total * 100.0,
    }, all_logits

def eval_maxent(loader, model, erm_model, criterion, update_bn_fn=None, cuda=True, regression=False, verbose=False, run_all=False, test_weight=1.):
    verbose = True
    loss_sum = 0.0
    correct = 0.0
    num_objects_total = len(loader.dataset)

    all_logits = []
    import time
    update_bn_fn(model)
    model.eval()
    model.sample(0)

    map_model = copy.deepcopy(erm_model)
    sgd_optimizer = torch.optim.SGD(map_model.parameters(), lr=1)
    sgd_optimizer.zero_grad()
    new_params = list(map_model.parameters())
    mu_list, var_list, covar_list = model.generate_mean_var_covar()
    for param, mu, var in zip(new_params, mu_list, var_list):
        # param.grad = (param.grad * var / 2 - mu + param.data)
        param.grad = (param.data - mu)
    sgd_optimizer.step()
    update_bn_fn(map_model)
    map_model.eval()

    # with torch.no_grad():
    if verbose:
        loader = tqdm.tqdm(loader)
    for i, (input, target) in enumerate(loader):
        start = time.time()
        if cuda:
            input = input.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)

        loss, output = criterion(model, map_model, input, target, update_bn_fn, test_weight)
        all_logits.append(output)

        loss_sum += loss.item() * input.size(0)


        if not regression:
            pred = output.data.argmax(1, keepdim=True)
            correct += pred.eq(target.data.view_as(pred)).sum().item()

        print("Current Itr", i+1)
        print("Current Avg Loss", loss_sum / ((i+1) * 32))
        print("Current Acc", correct / ((i+1) * 32))
        print("Time", time.time() - start)
        if i > 0 and not run_all:
            break
    # can look at output to compute comps and entropies
    all_logits = torch.cat(all_logits)
    return {
        "loss": loss_sum / num_objects_total,
        "accuracy": None if regression else correct / num_objects_total * 100.0,
        # "loss": loss_sum / num_objects_total,
        # "accuracy": None if regression else correct / num_objects_total * 100.0,
    }, all_logits
def eval_nml(loader, model, erm_model, criterion, update_bn_fn=None, cuda=True, regression=False, verbose=False, run_all=False, nml_temp=1., use_v2=False):
    loss_sum = 0.0
    correct = 0.0
    num_objects_total = len(loader.dataset)

    all_logits = []
    import time
    update_bn_fn(model)
    model.eval()
    model.sample(0)

    map_model = copy.deepcopy(erm_model)
    sgd_optimizer = torch.optim.SGD(map_model.parameters(), lr=1)
    sgd_optimizer.zero_grad()
    new_params = list(map_model.parameters())
    mu_list, var_list, covar_list = model.generate_mean_var_covar()
    for param, mu, var in zip(new_params, mu_list, var_list):
        # param.grad = (param.grad * var / 2 - mu + param.data)
        param.grad = (param.data - mu)
    sgd_optimizer.step()
    # update_bn_fn(map_model)
    map_model.eval()

    # with torch.no_grad():
    if verbose:
        loader = tqdm.tqdm(loader)
    for i, (input, target) in enumerate(loader):
        start = time.time()
        if cuda:
            input = input.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)

        loss, output = criterion(model, map_model, input, target, update_bn_fn, nml_temp, use_v2=use_v2)
        all_logits.append(output)

        loss_sum += loss.item() * input.size(0)


        if not regression:
            pred = output.data.argmax(1, keepdim=True)
            correct += pred.eq(target.data.view_as(pred)).sum().item()

        print("Current Itr", i+1)
        print("Current Avg Loss", loss_sum / ((i+1) * 32))
        print("Current Acc", correct / ((i+1) * 32))
        print("Time", time.time() - start)
        if i > 0 and not run_all:
            break
    # can look at output to compute comps and entropies
    all_logits = torch.cat(all_logits)
    return {
        "loss": loss_sum / num_objects_total,
        "accuracy": None if regression else correct / num_objects_total * 100.0,
        # "loss": loss_sum / num_objects_total,
        # "accuracy": None if regression else correct / num_objects_total * 100.0,
    }, all_logits

# garbage?
def marginal_kfac(loader, model, scale=1., K=30):
    for i in range(K):
        # print("%d/%d" % (i + 1, args.N))
        # if args.method == "KFACLaplace":
            # ## KFAC Laplace needs one forwards pass to load the KFAC model at the beginning
            # model.net.load_state_dict(model.mean_state)

            # if i == 0:
                # model.net.train()

                # loss, _ = losses.cross_entropy(model.net, t_input, t_target)
                # loss.backward(create_graph=True)
                # model.step(update_params=False)
        model.net.load_state_dict(model.mean_state)
        model.sample(scale=scale, cov=True)
        for input, target in tqdm.tqdm(loader):
            input = input.cuda(non_blocking=True)
            ##TODO: is this needed?
            # if args.method == 'Dropout':
            #    model.apply(train_dropout)

        if args.method == "KFACLaplace":
            output = model.net(input)
        else:
            output = model(input)

        with torch.no_grad():
            predictions[k : k + input.size()[0]] += (
                F.softmax(output, dim=1).cpu().numpy()
            )
        targets[k : (k + target.size(0))] = target.numpy()
        k += input.size()[0]

    print("Accuracy:", np.mean(np.argmax(predictions, axis=1) == targets))
    #nll is sum over entire dataset
    print("NLL:", nll(predictions / (i + 1), targets))

def marginal_swag(loader, train_loader, model, diag=False, scale=1., K=30):
    all_predictions = []
    for i in range(K):
        print("Model sample #{}".format(i))

        model.sample(scale, cov=not diag)
        bn_update(train_loader, model)
        all_predictions.append(predict(loader, model)["predictions"])
    all_predictions = np.stack(all_predictions)
    marginal_logits = np_marginal_logits(all_predictions)
    return marginal_logits

def cheating_ensemble_swag(loader, train_loader, model, diag=False, scale=1., K=30):
    all_predictions = []
    for i in range(K):
        print("Model sample #{}".format(i))

        model.sample(scale, cov=not diag)
        bn_update(train_loader, model)
        all_predictions.append(predict(loader, model)["predictions"])
    all_labels = []
    for _, labels in loader:
        all_labels.append(labels.cpu().numpy())
    all_labels = np.concatenate(all_labels)
    all_predictions = np.stack(all_predictions)
    all_logits = np.log(all_predictions)

    best_logits = select_best_member(all_logits, all_labels)

    return best_logits

def cnml_ensemble_swag(loader, train_loader, model, diag=False, scale=1., K=30, use_train_loss=True, use_posterior=False):
    all_predictions = []
    approx_train_lls = []
    if use_posterior:
        mvc = model.generate_mean_var_covar()
    for i in range(K):
        print("Model sample #{}".format(i))

        model.sample(scale, cov=not diag)
        bn_update(train_loader, model)
        all_predictions.append(predict(loader, model)["predictions"])
        if use_train_loss:
            train_loss = eval(train_loader, model, losses.cross_entropy)['loss_sum']
            approx_train_lls.append(-train_loss)
        elif use_posterior:
            posterior_ll = model.compute_logprob(mvc=mvc, block=True)
            approx_train_lls.append(posterior_ll)
    all_predictions = np.stack(all_predictions)
    all_logits = np.log(all_predictions)

    if use_train_loss or use_posterior:
        approx_train_lls = np.array(approx_train_lls)
        cnml_logits = np_cnml_logits(all_logits, approx_train_lls)
    else:
        cnml_logits = np_nml_logits(all_logits)
    return cnml_logits


    cnml_logits = np_nml_logits(all_logits)
    return cnml_logits

# assumes model is set to train mode for dropout layers
# todo debug this
def marginal_dropout(loader, train_loader, model, K=30):
    all_predictions = []
    for i in range(K):
        print("Model sample #{}".format(i))

        # model.sample(scale, cov=not diag)
        bn_update(train_loader, model)
        model.apply(train_dropout)

        all_predictions.append(predict(loader, model, seed=i)["predictions"])
    all_predictions = np.stack(all_predictions)
    marginal_logits = np_marginal_logits(all_predictions)
    return marginal_logits

def marginal_kfac_laplace(loader, model, scale=1., K=30):
    all_predictions = []

    # model_copy = copy.deepcopy(model)
    # create precond?

    for i in range(K):
        torch.manual_seed(i)
        print("Model sample #{}".format(i), flush=True)
        model.net.load_state_dict(model.mean_state)
        model.sample(scale=scale, cov=True)
        # bn_update(train_loader, model)
        all_predictions.append(predict(loader, model.net)["predictions"])
    all_predictions = np.stack(all_predictions)
    marginal_logits = np_marginal_logits(all_predictions)
    return marginal_logits



def predict(loader, model, verbose=False, seed=None):
    predictions = list()
    targets = list()

    model.eval()

    if verbose:
        loader = tqdm.tqdm(loader)

    offset = 0
    with torch.no_grad():
        for input, target in loader:
            input = input.cuda(non_blocking=True)
            output = model(input)

            if seed:
                torch.manual_seed(seed)

            batch_size = input.size(0)
            predictions.append(F.softmax(output, dim=1).cpu().numpy())
            targets.append(target.numpy())
            offset += batch_size

    return {"predictions": np.vstack(predictions), "targets": np.concatenate(targets)}

def compute_kfac(loader, kfac_model, loss_fn, n_batches=None):
    # model.eval()
    optimizer = torch.optim.SGD(kfac_model.net.parameters(), lr=1)
    count = 0
    for input, target in loader:
        if n_batches is not None and count == n_batches:
            break
        count += 1
        t_input, t_target = (
            input.cuda(non_blocking=True),
            target.cuda(non_blocking=True),
        )
        loss, _ = loss_fn(kfac_model.net, t_input, t_target)
        loss.backward(create_graph=True)
        kfac_model.step(update_params=False)
        optimizer.zero_grad()


def moving_average(net1, net2, alpha=1):
    for param1, param2 in zip(net1.parameters(), net2.parameters()):
        param1.data *= 1.0 - alpha
        param1.data += param2.data * alpha


def _check_bn(module, flag):
    if issubclass(module.__class__, torch.nn.modules.batchnorm._BatchNorm):
        flag[0] = True


def check_bn(model):
    flag = [False]
    model.apply(lambda module: _check_bn(module, flag))
    return flag[0]


def reset_bn(module):
    if issubclass(module.__class__, torch.nn.modules.batchnorm._BatchNorm):
        module.running_mean = torch.zeros_like(module.running_mean)
        module.running_var = torch.ones_like(module.running_var)


def _get_momenta(module, momenta):
    if issubclass(module.__class__, torch.nn.modules.batchnorm._BatchNorm):
        momenta[module] = module.momentum


def _set_momenta(module, momenta):
    if issubclass(module.__class__, torch.nn.modules.batchnorm._BatchNorm):
        module.momentum = momenta[module]

def train_dropout(m):
    if type(m) == torch.nn.modules.dropout.Dropout:
        m.train()


def bn_update(loader, model, verbose=False, subset=None, **kwargs):
    """
        BatchNorm buffers update (if any).
        Performs 1 epochs to estimate buffers average using train dataset.

        :param loader: train dataset loader for buffers average estimation.
        :param model: model being update
        :return: None
    """
    if not check_bn(model):
        return
    model.train()
    momenta = {}
    model.apply(reset_bn)
    model.apply(lambda module: _get_momenta(module, momenta))
    n = 0
    num_batches = len(loader)

    with torch.no_grad():
        if subset is not None:
            num_batches = int(num_batches * subset)
            loader = itertools.islice(loader, num_batches)
        if verbose:

            loader = tqdm.tqdm(loader, total=num_batches)
        for input, _ in loader:
            input = input.cuda(non_blocking=True)
            input_var = torch.autograd.Variable(input)
            b = input_var.data.size(0)

            momentum = b / (n + b)
            for module in momenta.keys():
                module.momentum = momentum

            model(input_var, **kwargs)
            n += b

    model.apply(lambda module: _set_momenta(module, momenta))


def inv_softmax(x, eps=1e-10):
    return torch.log(x / (1.0 - x + eps))


def predictions(test_loader, model, seed=None, cuda=True, regression=False, **kwargs):
    # will assume that model is already in eval mode
    # model.eval()
    preds = []
    targets = []
    for input, target in test_loader:
        if seed is not None:
            torch.manual_seed(seed)
        if cuda:
            input = input.cuda(non_blocking=True)
        output = model(input, **kwargs)
        if regression:
            preds.append(output.cpu().data.numpy())
        else:
            probs = F.softmax(output, dim=1)
            preds.append(probs.cpu().data.numpy())
        targets.append(target.numpy())
    return np.vstack(preds), np.concatenate(targets)


def schedule(epoch, lr_init, epochs, swa, swa_start=None, swa_lr=None):
    t = (epoch) / (swa_start if swa else epochs)
    lr_ratio = swa_lr / lr_init if swa else 0.01
    if t <= 0.5:
        factor = 1.0
    elif t <= 0.9:
        factor = 1.0 - (1.0 - lr_ratio) * (t - 0.5) / 0.4
    else:
        factor = lr_ratio
    return lr_init * factor
