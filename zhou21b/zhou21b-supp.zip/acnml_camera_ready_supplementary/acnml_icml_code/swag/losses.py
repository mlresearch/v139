import torch
import torch.nn.functional as F
import copy
from itertools import chain
import time
import numpy as np


def cross_entropy(model, input, target):
    # standard cross-entropy loss function

    output = model(input)

    loss = F.cross_entropy(output, target)

    return loss, output

def nml_kfac_ce(model, input, target, update_bn_fn, nml_scale=1., n_steps=10):
    verbose = False
    # verbose = True
    all_logits = []
    model.eval()
    model.net.eval()
    # params = list(model.net.parameters())
    kfac_params = model.get_kfac_trainable_params()
    params = kfac_params
    mu_kfac_params = model.trainable_mean_state_params
    mu_list = mu_kfac_params
    sgd_optimizer = torch.optim.SGD(params, lr=0.25)
    count = 0
    proposed_labels = torch.tensor([i for i in range(10)]).cuda()
    def get_kl():
        kl_loss = 0.
        sgd_optimizer.zero_grad()
        for param, mu in zip(params, mu_list):
            param.grad += param - mu
        # model.step(False, True)
        model.step(False, True, use_inv=False)
        for param, mu in zip(params, mu_list):
            kl_loss += (1 / nml_scale) * 0.5 * (param.grad * (param - mu)).sum()  
            kl_loss += (1 / nml_scale) * 0.5 * model.eps * ((param - mu) * (param - mu)).sum()
            # kl_loss += (1 / nml_scale) * 0.5 * 5e-2 * ((param - mu) * (param - mu)).sum()
            # kl_loss += (1 / nml_scale) * 0.5 * (param.grad * (param - mu)).sum()
        return kl_loss
    for i, x in enumerate(input):
        count += 1
        x = input[i:i+1] # x[None]
        logits = []
        start = time.time()
        for j in range(10):
            proposed_label = proposed_labels[j:j+1]
            model.net.load_state_dict(model.mean_state)
            for i in range(n_steps):
                loss, output = cross_entropy(model.net, x, proposed_label)
                if i == 0:
                    orig_ce = loss
                if verbose:
                    kl_loss = get_kl()

                combined_loss = nml_scale * loss 
                sgd_optimizer.zero_grad()
                combined_loss.backward()

                # applies preconditioner to test point gradients
                model.step(False, True, use_inv=True)

                # preconditioner cancels out covariance in the posterior
                for param, mu in zip(params, mu_list):
                    param.grad += (param - mu) # / 2

                sgd_optimizer.step()
                if verbose:
                    if (i % 5 == 0 or i < 10):
                        print("itr {}, ce: {}, kl: {}".format(i, loss, -kl_loss))# kl_loss = model.compute_logprob(diag=True)
                        # print("ce grad norm: {}".format(grad_norm))

            if verbose:
                kl_loss = get_kl()
                # kl_loss = model.compute_logprob(params, mvc, diag=True)
                print("kl loss", -kl_loss)
            loss, output = cross_entropy(model.net, x, proposed_label)
            if verbose:
                # orig_ce, _ = cross_entropy(map_model, x, proposed_label)
                print("ce loss", loss)
                print("orig ce loss", orig_ce)
                print("")
            logits.append(-loss) 
            # del orig_ce
            # torch.cuda.empty_cache()
            # print(torch.cuda.memory_summary())
        if verbose:
            print("Datapoint Time", time.time() - start, flush=True)
            import ipdb; ipdb.set_trace()
        all_logits.append(torch.tensor(logits))
    all_logits = torch.stack(all_logits).cuda()

    normalized_logits = F.log_softmax(all_logits, dim=-1)
    # import ipdb; ipdb.set_trace()
    nml_probs = torch.exp(normalized_logits)
    nml_entropies = (-nml_probs * normalized_logits).sum(dim=-1)
    print("NML Entropy", nml_entropies.mean())
    nml_comps = torch.log(torch.exp(all_logits).sum(dim=-1))
    print("NML Comps", nml_comps.mean())
    model.net.load_state_dict(model.mean_state)
    map_logits = model.net(input)
    map_logits = F.log_softmax(map_logits, dim=-1)
    map_probs = torch.exp(map_logits)
    map_entropies = (-map_probs * map_logits).sum(dim=-1)
    print("MAP Entropy", map_entropies.mean(), flush=True)

    return F.cross_entropy(all_logits, target), all_logits

def nml_ce(model, map_model, input, target, update_bn_fn, nml_scale=1., n_steps=5, use_v2=False):
    verbose = False
    # verbose = True
    all_logits = []
    model.eval()
    model.var_clamp = 0.00000000001
    # map_model = copy.deepcopy(erm_model)
    # map_model.eval()
    mu_list, var_list, covar_list = model.generate_mean_var_covar()

    mvc = (mu_list, var_list, covar_list)
    # print(F.cross_entropy(model(input), target))


    new_model = map_model
    # new_model = copy.deepcopy(map_model)
    new_model.eval()
    reset_optimizer = torch.optim.SGD(new_model.parameters(), lr=1)
    sgd_optimizer = torch.optim.SGD(new_model.parameters(), lr=1)
    new_params = list(new_model.parameters())
    count = 0
    # proposed_labels = torch.eye(10).cuda()
    proposed_labels = torch.tensor([i for i in range(10)]).cuda()
    for i, x in enumerate(input):
        count += 1
        x = input[i:i+1] # x[None]
        logits = []
        start = time.time()
        for j in range(10):
            proposed_label = proposed_labels[j:j+1]
            reset_optimizer.zero_grad()
            for param, mu, var in zip(new_params, mu_list, var_list):
                param.grad = -mu + param.data
            reset_optimizer.step()
            for i in range(n_steps):
                loss, output = cross_entropy(new_model, x, proposed_label)
                if i == 0:
                    orig_ce = loss
                if verbose:
                    kl_loss = model.compute_logprob(new_params, mvc, diag=True)
                combined_loss = nml_scale * loss # - 2 * kl_loss
                sgd_optimizer.zero_grad()
                combined_loss.backward()

                for param, mu, var in zip(new_params, mu_list, var_list):
                    param.grad += (param - mu) / var
                    param.grad *= var / 2 # - mu + param.data)

                sgd_optimizer.step()
                if verbose:
                    if (i % 5 == 0 or i < 10):
                        print("itr {}, ce: {}, kl: {}".format(i, loss, -kl_loss))# kl_loss = model.compute_logprob(diag=True)

            # if usev2
            if use_v2 or verbose:
                kl_loss = model.compute_logprob(new_params, mvc, diag=True)
            if verbose:
                print("kl loss", -kl_loss)
            loss, output = cross_entropy(new_model, x, proposed_label)
            if verbose:
                # orig_ce, _ = cross_entropy(map_model, x, proposed_label)
                print("ce loss", loss)
                print("orig ce loss", orig_ce)
                print("")
            if use_v2:
                logits.append(-loss - kl_loss / nml_scale) 
            else:
                logits.append(-loss) 
            # del orig_ce
            # torch.cuda.empty_cache()
            # print(torch.cuda.memory_summary())
        if verbose:
            print("Datapoint Time", time.time() - start)
        all_logits.append(torch.tensor(logits))
    all_logits = torch.stack(all_logits).cuda()

    normalized_logits = F.log_softmax(all_logits, dim=-1)
    # import ipdb; ipdb.set_trace()
    nml_probs = torch.exp(normalized_logits)
    nml_entropies = (-nml_probs * normalized_logits).sum(dim=-1)
    print(n_steps)
    print("NML Entropy", nml_entropies.mean())
    nml_comps = torch.log(torch.exp(all_logits).sum(dim=-1))
    print("NML Comps", nml_comps.mean())
    map_logits = map_model(input)
    map_logits = F.log_softmax(map_logits, dim=-1)
    map_probs = torch.exp(map_logits)
    map_entropies = (-map_probs * map_logits).sum(dim=-1)
    print("MAP Entropy", map_entropies.mean(), flush=True)

    # final_loss = F.cross_entropy(all_logits, target)
    # model.sample(0)
    # print("MAP v1:", F.cross_entropy(model(input), target))
    # print("MAP v2:", F.cross_entropy(map_model(input), target))
    # print("NML Loss", final_loss)
    return F.cross_entropy(all_logits, target), all_logits



def adversarial_cross_entropy(
    model, input, target, lossfn=F.cross_entropy, epsilon=0.01
):
    # loss function based on algorithm 1 of "simple and scalable uncertainty estimation using
    # deep ensembles," lakshminaraynan, pritzel, and blundell, nips 2017,
    # https://arxiv.org/pdf/1612.01474.pdf
    # note: the small difference bw this paper is that here the loss is only backpropped
    # through the adversarial loss rather than both due to memory constraints on preresnets
    # we can change back if we want to restrict ourselves to VGG-like networks (where it's fine).

    # scale epsilon by min and max (should be [0,1] for all experiments)
    # see algorithm 1 of paper
    scaled_epsilon = epsilon * (input.max() - input.min())

    # force inputs to require gradient
    input.requires_grad = True

    # standard forwards pass
    output = model(input)
    loss = lossfn(output, target)

    # now compute gradients wrt input
    loss.backward(retain_graph=True)

    # now compute sign of gradients
    inputs_grad = torch.sign(input.grad)

    # perturb inputs and use clamped output
    inputs_perturbed = torch.clamp(
        input + scaled_epsilon * inputs_grad, 0.0, 1.0
    ).detach()
    # inputs_perturbed.requires_grad = False

    input.grad.zero_()
    # model.zero_grad()

    outputs_perturbed = model(inputs_perturbed)

    # compute adversarial version of loss
    adv_loss = lossfn(outputs_perturbed, target)

    # return mean of loss for reasonable scalings
    return (loss + adv_loss) / 2.0, output


def masked_loss(y_pred, y_true, void_class=11.0, weight=None, reduce=True):
    # masked version of crossentropy loss

    el = torch.ones_like(y_true) * void_class
    mask = torch.ne(y_true, el).long()

    y_true_tmp = y_true * mask

    loss = F.cross_entropy(y_pred, y_true_tmp, weight=weight, reduction="none")
    loss = mask.float() * loss

    if reduce:
        return loss.sum() / mask.sum()
    else:
        return loss, mask


def seg_cross_entropy(model, input, target, weight=None):
    output = model(input)

    # use masked loss function
    loss = masked_loss(output, target, weight=weight)

    return {"loss": loss, "output": output}


def seg_ale_cross_entropy(model, input, target, num_samples=50, weight=None):
    # requires two outputs for model(input)

    output = model(input)
    mean = output[:, 0, :, :, :]
    scale = output[:, 1, :, :, :].abs()

    output_distribution = torch.distributions.Normal(mean, scale)

    total_loss = 0

    for _ in range(num_samples):
        sample = output_distribution.rsample()

        current_loss, mask = masked_loss(sample, target, weight=weight, reduce=False)
        total_loss = total_loss + current_loss.exp()
    mean_loss = total_loss / num_samples

    return {"loss": mean_loss.log().sum() / mask.sum(), "output": mean, "scale": scale}
