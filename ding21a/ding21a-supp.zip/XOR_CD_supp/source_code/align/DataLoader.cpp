#include <string>
#include <fstream>
#include <iostream>
#include <dirent.h>
#include "seq.h"
using namespace std;

int main(int argc, char **argv) {
	string seqname = argv[1];
	string TGTPath = "/scratch/brown/ding274/align_data/TGT_BC100/";

	SEQUENCE* Sequence = new SEQUENCE(seqname, TGTPath , 0 ,0);

	ofstream outfile;
	string outfilename = "/scratch/brown/ding274/df_align/feature_set/" + seqname + ".txt";
	outfile.open(outfilename, ios::out);

	for (int i=0; i<(int)Sequence->sequence.size(); i++){
		for (int j=0; j<8; j++){
			outfile << Sequence->SS8[i][j] << " ";
		}
		for (int j=0; j<3; j++){
			outfile << Sequence->acc_our_10_42[i][j] << " ";
		}
		for (int j=0; j<20; j++){
			outfile << Sequence->EmissionScore[i][j] << " ";
		}
		for (int j=0; j<10; j++){
			outfile << Sequence->ProfHMM[i][j] << " ";
		}
		outfile << endl;
	}
}