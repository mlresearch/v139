import numpy as np
import string
import os

deepalign_path = "/scratch/brown/ding274/align_data/Alignment_DeepAlign/"
training_set_path = "/scratch/brown/ding274/df_align/training_set/"
feature_set_path = "/scratch/brown/ding274/df_align/feature_set/"

root = os.listdir(deepalign_path)

for file in root:
    with open(deepalign_path + file, 'r') as f:
        S1_name = f.readline()[1:]
        S1_seq = f.readline()
        S2_name = f.readline()[1:]
        S2_seq = f.readline()
        S1_seq = S1_seq.replace('-', '')
        S2_seq = S2_seq.replace('-', '')
    
    if (len(S1_seq) <= 200 and len(S2_seq) <= 200):
        print("S1: " + S1_name + "\tS2: " + S2_name)
        if (file not in os.listdir(training_set_path)):
            os.system("cp " + deepalign_path + file + " " + training_set_path)
        if (S1_name + ".txt" not in os.listdir(feature_set_path)):
            os.system("./DataLoader " + S1_name)
        if (S2_name + ".txt" not in os.listdir(feature_set_path)):
            os.system("./DataLoader " + S2_name)
