#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
// #include "seq.h"
using namespace std;

void Dp(int N1, int N2, string S, string T, vector< vector<double> > pair_score, vector<double> Sgap, vector<double> Tgap) {
    vector<double> tmp(N2+1, 0);
    vector< vector<double> > DP(N1+1, tmp);
    for (int i=1; i<=N1; i++) {
        DP[i][0] = DP[i-1][0] + Sgap[i-1];
    }
    cout << "DP matrix:" << endl;
    printf("%5.1f  ", DP[0][0]);
    for (int j=1; j<=N2; j++) {
        DP[0][j] = DP[0][j-1] + Tgap[j-1];
        printf("%5.1f  ", DP[0][j]);
    }
    cout << endl;
    for (int i=1; i<=N1; i++) {
        printf("%5.1f  ", DP[i][0]);
        for (int j=1; j<=N2; j++) {
            double tmp = max(Tgap[i-1] + DP[i][j-1], Sgap[i-1] + DP[i-1][j]);
            DP[i][j] = max(pair_score[i-1][j-1] + DP[i-1][j-1], tmp);
            printf("%5.1f  ", DP[i][j]);
        }
        cout << endl;
    }
    // from DP to find the alignment
    string compS="", compT="";
    for (int i=N1, j=N2; i>0 || j>0; ) {
        if (i>0 && j>0 && DP[i][j] == DP[i-1][j-1] + pair_score[i-1][j-1]) {
            compS = S[i-1] + compS;
            compT = T[j-1] + compT;
            i--, j--;
        } else if (i>0 && DP[i][j] == Sgap[i-1] + DP[i-1][j]) {
            compS = S[i-1] + compS;
            compT = "-" + compT;
            i--;
        } else if (j>0 && DP[i][j] == Tgap[j-1] + DP[i][j-1]) {
            compS = "-" + compS;
            compT = T[j-1] + compT;
            j--;
        } else {
            cout << "ERROR!\t i=" << i << "; j=" << j << endl;
        }
    }
    cout << "print alignment:" << endl;
    cout << compS << endl << endl << compT << endl;
}

int main () {
    // test
    int N1 = 10, N2 = 5;
    string S = "0123456789";
    string T = "ABCDE";
    vector<double> tmp(N2, 5);
    vector< vector<double> > pair_score(N1, tmp);
    vector<double> Sgap(N1, -2);
    vector<double> Tgap(N2, -2);
    Dp(N1, N2, S, T, pair_score, Sgap, Tgap);
}