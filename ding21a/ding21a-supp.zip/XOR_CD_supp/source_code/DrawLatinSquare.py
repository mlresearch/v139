import numpy as np 
import matplotlib.pyplot as plt
import argparse
import math
from numpy.core.fromnumeric import var
import scipy.io as scio
from mpl_toolkits.mplot3d import Axes3D
import random
from random import choice, shuffle
from copy import deepcopy

def bin2dec(samples, n):
    total_size = len(samples)
    test_squares = []
    for sam in range(total_size):
        square = np.zeros((n,n))
        sample = samples[sam]
        flag = 1
        for k in range(n*n):
            term = sample[k*n : (k+1)*n]
            if term.sum() != 1:
                flag = 0
                break
            else:
                row = k//n
                col = k%n
                square[row, col] = list(term).index(1)
        if flag == 1:
            test_squares.append(square)
    return test_squares


def dec2bin(squares, n):
    total_size = len(squares)
    squares = squares.reshape(total_size, -1)
    training_data = np.zeros((total_size, np.power(n,3)))
    for sam in range(total_size):
        for k in range(n*n):
            training_data[sam, int(n*k+squares[sam, k])] = 1
    return training_data
 
def rls(n):
    if n <= 0:
        return []
    else:
        symbols = list(range(n))
        square = _rls(symbols)
        return _shuffle_transpose_shuffle(square)
 
 
def _shuffle_transpose_shuffle(matrix):
    square = deepcopy(matrix)
    shuffle(square)
    trans = list(zip(*square))
    shuffle(trans)
    return trans
 
 
def _rls(symbols):
    n = len(symbols)
    if n == 1:
        return [symbols]
    else:
        sym = choice(symbols)
        symbols.remove(sym)
        square = _rls(symbols)
        square.append(square[0].copy())
        for i in range(n):
            square[i].insert(i, sym)
        return square
        
def _to_text(square):
    if square:
        width = max(len(str(sym)) for row in square for sym in row)
        txt = '\n'.join(' '.join(f"{sym:>{width}}" for sym in row) for row in square)
    else:
        txt = ''
    return txt

def check_latin(square):
    transpose = list(zip(*square))
    if (_check_rows(square) and _check_rows(transpose)):
        return True
    else:
        return False
 
def _check(square):
    transpose = list(zip(*square))
    assert _check_rows(square) and _check_rows(transpose), \
        "Not a Latin square"
 
def _check_rows(square):
    # if not square:
    #     return True
    set_row0 = set(square[0])
    return all(len(row) == len(set(row)) and set(row) == set_row0
               for row in square)

def drawLS(file, LatinSquare):
    fig, ax =plt.subplots(1,1,figsize=(4,4))
    collabel=tuple(['_' for _ in range(len(LatinSquare))])
    ax.axis('tight')
    ax.axis('off')
    the_table = ax.table(cellText=LatinSquare,cellLoc='center',fontsize=10, bbox = [0,0,1,1])

    plt.savefig('figs/' + file + '.pdf')
    plt.show()

def var_score(square):
    balance_value = []
    length = len(square)
    for i in range(length-1):
        for j in range(i+1, length):
            distance = 0
            for line in range(length):
                arr = list(square[line])
                distance += np.abs(arr.index(i) - arr.index(j))
            balance_value.append(distance)
    # print('balance_value:\t', balance_value)
    variance = np.var(balance_value)
    return variance

def compute_vars(squares):
    length = len(squares)
    vars = {}
    for i in range(length):
        square = squares[i]
        var_square = var_score(square)
        if var_square in vars.keys():
            vars[var_square] += 1
        else:
            vars[var_square] = 1
    return vars

def generate_data(n, n_samples=500):
    squares = np.zeros((n_samples, n, n))
    vars = {}
    for num in range(n_samples):
        square = rls(n)
        _check(square)
        squares[num] = square
        var_square = var_score(square)
        if var_square in vars.keys():
            vars[var_square] += 1
        else:
            vars[var_square] = 1 
    return squares, vars
    

def CliqueModel(fp, n):
    nbvar = np.power(n, 3)
    with open(fp, 'w+') as f:
        f.write("MARKOV\n")
        f.write(str(nbvar) + "\n")
        for i in range(nbvar):
            f.write("2 ")
        f.write("\n")
        # 
        # latin square model
        n_constraints = int(nbvar*(nbvar-1)/2)
        f.write(str(n_constraints) + '\n')
        constraints = []
        for i in range(nbvar-1):
            for j in range(i+1, nbvar):
                var_set = [i,j]
                constraints.append(var_set)
                string = ''
                f.write(str(len(var_set)) + '\n')
                for var in var_set:
                    string = string + str(var) + ' '
                f.write(string + '\n')
        f.write('\n')
        for i in range(n_constraints):
            var_set = constraints[i]
            tablesize = int(math.pow(2,len(var_set)))
            f.write(str(tablesize) + '\n')
            string = ''
            for j in range(tablesize):
                string = string + '1 ' # str(np.random.uniform(0.1, 1, 1)[0]) + ' '
            f.write(string + '\n')

def SimpleModel(fp, n):
    nbvar = np.power(n, 3)
    with open(fp, 'w+') as f:
        f.write("MARKOV\n")
        f.write(str(nbvar) + "\n")
        for i in range(nbvar):
            f.write("2 ")
        f.write("\n")
        # 
        # latin square model
        n_constraints = int(nbvar)
        f.write(str(n_constraints) + '\n')
        constraints = []
        for i in range(nbvar):
            var_set = [i]
            constraints.append(var_set)
            string = ''
            f.write(str(len(var_set)) + '\n')
            for var in var_set:
                string = string + str(var) + ' '
            f.write(string + '\n')
        f.write('\n')
        for i in range(n_constraints):
            var_set = constraints[i]
            tablesize = int(math.pow(2,len(var_set)))
            f.write(str(tablesize) + '\n')
            string = ''
            for j in range(tablesize):
                string = string + str(np.random.uniform(0.1, 1, 1)[0]) + ' '
            f.write(string + '\n')

### To draw data for training
if __name__=='__main__':
    for n in range(5,6):
        print("generate {}*{} Latin square\n".format(n,n))
        # squares, vars = generate_data(n=n, n_samples=500)
        # SimpleModel("../latin/model/latin_{:d}_train.uai".format(n), n)
        # np.save("../latin/data/latin_{:d}_train.npy".format(n), squares)
        # np.save("../latin/data/latin_{:d}_train_var.npy".format(n), vars)

        ## draw latin and print varince
        square = rls(n)
        print(_to_text(square))
        # drawLS('LS_'+str(len(square)), np.array(square))
        print('variance=', var_score(square))

        # ### test bin2dec and dec2bin
        # print("origin:\n", squares)
        # bin=dec2bin(squares, n)
        # print("bin:\n", bin)
        # dec=bin2dec(bin, n)
        # print("dec:\n", dec)

