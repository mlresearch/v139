import os
import sys
import random
import argparse

def walkandInvoke():
        parser = argparse.ArgumentParser(description="Walks through the data folder and triggers parafly script")
        parser.add_argument("-job", type=str, default='latin', help="dataset folder")
        parser.add_argument('-q', '--queue', type=str, default="queue", help="slurm queue")
        parser.add_argument('-fr', type=int, default="5", help="scale from where")
        parser.add_argument('-to', type=int, default="11", help="scale to where")
        args = parser.parse_args()
        # datadir = "/home/name/XOR-CD/%sdata/%s/" % (args.job.lower(), args.job.lower())
        modeldir = "/home/name/XOR-CD/%s/model/" % (args.job)

        for i in range(args.fr, args.to):
            filename = "{}_{:d}_train.uai".format(args.job, i)
            command = "python runSlurm.py {} {} -job {} --queue {}".format(filename, modeldir, args.job, args.queue)
            print(command)
            os.system(command)

if __name__ == "__main__":
    walkandInvoke()

# python runSlurm.py latin_5_train.uai /home/name/XOR-CD/%s/model/ -job latin --queue queue