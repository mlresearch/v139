import sys
import math
import os
import argparse

parser = argparse.ArgumentParser(description='XOR Contrasitive Diverfence')

parser.add_argument("infile", help="Graphical model (in UAI format)")
parser.add_argument("modelfolder", help="Folder where models are stored")
parser.add_argument('-job', default='latin', help="SAT or UAI or SEQ or latin")
parser.add_argument('-q', '--queue', type=str, default="queue", help="qsub queue")
parser.add_argument('-t', '--timeout', type=int, help="Timeout for each instance", default=14400)
args = parser.parse_args()

fname_extended = args.infile
print(fname_extended)
fname = os.path.splitext(fname_extended)[0]
outputdir = os.path.abspath(args.modelfolder+'/'+fname+'_model/')

parafileName = "%s_script.txt" % (fname)
# rerunfile = "%s/%s" % (outputdir, "rerun.txt")
# if not os.path.exists(rerunfile): # failed, need to be rerun
#     sys.exit(0)
f = open(parafileName, 'w')

modelxor = "%s_xor.uai " % (fname)
cpname =  modelxor
if os.path.exists(outputdir):
    sys.exit(0)
    
os.system("mkdir "+ outputdir)
cmdline = ("python main.py --filename %s --job %s && cp %s %s\n") % (fname_extended, args.job, cpname, outputdir)
f.write(cmdline)
f.close()

uaifile = "%s/model/" % (args.job) + fname_extended
datafile = "%s/data/" % (args.job) + fname + ".npy"
core_num = 2
sname = fname+"Launch.sh"
f = open(sname, 'w')
f.write("#!/bin/bash\n")
f.write("#SBATCH -p normal\n")
f.write("#SBATCH -A {}\n".format(args.queue))
f.write("#SBATCH -N 1\n")
f.write("#SBATCH -n {:d}\n".format(core_num))
# f.write("#SBATCH --exclusive\n")
f.write("#SBATCH -J %s\n" % (fname))
f.write("#SBATCH --time=20:00:00\n")
f.write("\n")

f.write("cd $SLURM_SUBMIT_DIR\n")
# f.write("module load utilities gcc/6.3.0\n")
# f.write("module load utilities boost\n")
f.write("module load utilities parafly\n")
f.write("basedir=/home/name/XOR-CD\n")
f.write("TMPDIR=/tmp\n")
f.write("C2D=c2d_linux\n")
f.write("ACEDIR=$TMPDIR/ace_v3.0_linux86\n")
f.write("cp %s $TMPDIR/\n" % (sname))
f.write("cp %s $TMPDIR/\n" % (parafileName))
f.write("cp $basedir/src/PAWS/paws $TMPDIR/paws\n")
f.write("cp $basedir/%s $TMPDIR/%s\n" % (uaifile, fname_extended))
f.write("cp $basedir/%s $TMPDIR/%s\n" % (datafile, fname + ".npy"))
f.write("cp $basedir/src/loaduai.py $TMPDIR/\n")
f.write("cp $basedir/src/mrf.py $TMPDIR/\n")
f.write("cp $basedir/src/AceSample.py $TMPDIR/\n")
f.write("cp $basedir/src/DrawLatinSquare.py $TMPDIR/\n")
f.write("cp $basedir/src/HamiltonCycle.py $TMPDIR/\n")
f.write("cp $basedir/src/main.py $TMPDIR/\n")
f.write("cp -r $basedir/src/pyGM $TMPDIR/\n")
f.write("cd $TMPDIR\n")
f.write("module load anaconda/5.1.0-py36\n")
f.write("conda create --name py36 python=3.6\n")
f.write("source activate py36\n")
f.write("conda install --name numpy scipy matplotlib pandas sortedcontainers\n")
f.write("echo 0 > empty.uai.evid\n")
f.write("export LD_LIBRARY_PATH=$ACEDIR\n")
f.write("export ACEDIR=$ACEDIR\n")
f.write("export C2D=$C2D\n")

f.write("ParaFly -c %s_script.txt -CPU 1 -failed_cmds rerun.txt\n" % (fname))
f.write("cp %s %s\n" % (cpname, outputdir))
f.write("cp rerun.txt %s" % (outputdir))
f.close()

os.system("sbatch {}".format(sname))
# os.system("qsub -q %s -l walltime=20:00:00,nodes=1:ppn=1,naccesspolicy=singleuser %s" % (args.queue, sname))
