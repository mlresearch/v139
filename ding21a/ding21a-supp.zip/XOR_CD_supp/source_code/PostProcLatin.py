import numpy as np 
import matplotlib.pyplot as plt
import argparse
import math
from numpy.core.fromnumeric import var
import scipy.io as scio
from mpl_toolkits.mplot3d import Axes3D
import random
from random import choice, shuffle
from copy import deepcopy

def showLatinVariance():
    for n in range(3,6):
        # squares=np.load("../latin/data/latin_{:d}_train_var.npy".format(n), allow_pickle=True)
        vars=np.load("../latin/data/latin_{:d}_train_var.npy".format(n), allow_pickle=True).item()
        print("n=", n, ", vars= \n")
        print(vars, "\n")

def showHamiltonDistance():
    for n in range(5,11):
        # squares=np.load("../latin/data/latin_{:d}_train_var.npy".format(n), allow_pickle=True)
        distances=np.load("../latin/data/hamilton_{:d}_train_var.npy".format(n), allow_pickle=True).item()
        print("n=", n, ", distances= \n")
        print(distances, "\n")

if __name__=='__main__':
    showLatinVariance()
    # showHamiltonDistance()
