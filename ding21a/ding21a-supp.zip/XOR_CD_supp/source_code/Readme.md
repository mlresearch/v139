# XOR-CD

>  Repo for XOR-CD

### Requirements

* Python 3:
    * numpy
    * matplotlib
    * argparse
    * scipy

> Install by executing the command: pip3 install --user numpy matplotlib argparse scipy

* PAWS:

  > download from [Embed and Project: Discrete Sampling with Universal Hashing](https://cs.stanford.edu/~ermon/code/srcPAWS.zip)
  
  > change paths in both *Makefile* and *paws.cpp*
  
  > make
  
  > chmod u+x ./paws

* ACE:

  > download from [ACE: adaptive cluster expansion for maximum entropy graphical model inference](http://reasoning.cs.ucla.edu/ace/)
  
  > unzip the package
  
