import numpy as np 
import matplotlib.pyplot as plt
import argparse
import math
from numpy.core.fromnumeric import var
import scipy.io as scio
from mpl_toolkits.mplot3d import Axes3D
import random
from random import choice, shuffle
from copy import deepcopy

def ham_bin2dec(samples, n):
    total_size = len(samples)
    test_cycles = []
    for sam in range(total_size):
        cycle = np.zeros(n)
        sample = samples[sam]
        flag = 1
        for k in range(n):
            term = sample[k*n : (k+1)*n]
            if term.sum() != 1:
                flag = 0
                break
            else:
                cycle[k] = list(term).index(1)
        if flag == 1:
            test_cycles.append(cycle)
    return test_cycles


def ham_dec2bin(cycles, n):
    total_size = len(cycles)
    training_data = np.zeros((total_size, np.power(n,2)))
    for sam in range(total_size):
        for k in range(n):
            training_data[sam, int(n*k+cycles[sam, k])] = 1
    return training_data

def generateHamilton(n, n_samples=500):
    cycle = np.array(range(n))
    cycles = np.zeros((n_samples, n))
    for num in range(n_samples):
        shuffle(cycle)
        cycles[num] = cycle
    return cycles

def distance(cycle):
    tmp = np.zeros(cycle.shape)
    tmp[0:-1]=cycle[1:]
    tmp[-1] = cycle[0]
    dis = np.sum(np.abs(tmp-cycle))
    return dis

def compute_distance(cycles):
    length = len(cycles)
    vars = {}
    for i in range(length):
        cycle = cycles[i]
        dis = distance(cycle)
        if dis in vars.keys():
            vars[dis] += 1
        else:
            vars[dis] = 1
    return vars

def check_hamilton(cycle):
    return len(cycle) == len(set(cycle))

def SimpleModel(fp, n):
    nbvar = np.power(n, 2)
    with open(fp, 'w+') as f:
        f.write("MARKOV\n")
        f.write(str(nbvar) + "\n")
        for i in range(nbvar):
            f.write("2 ")
        f.write("\n")
        # 
        # latin square model
        n_constraints = int(nbvar)
        f.write(str(n_constraints) + '\n')
        constraints = []
        for i in range(nbvar):
            var_set = [i]
            constraints.append(var_set)
            string = ''
            f.write(str(len(var_set)) + '\n')
            for var in var_set:
                string = string + str(var) + ' '
            f.write(string + '\n')
        f.write('\n')
        for i in range(n_constraints):
            var_set = constraints[i]
            tablesize = int(math.pow(2,len(var_set)))
            f.write(str(tablesize) + '\n')
            string = ''
            for j in range(tablesize):
                string = string + str(np.random.uniform(0.1, 1, 1)[0]) + ' '
            f.write(string + '\n')

### To draw data for training
if __name__=='__main__':
    for n in range(5,11):
        print("\ngenerate {} nodes Hamilton Cycle".format(n,n))
        cycles = generateHamilton(n=n, n_samples=1)
        distances = compute_distance(cycles)
        SimpleModel("../hamilton/model/hamilton_{:d}_train.uai".format(n), n)
        np.save("../hamilton/data/hamilton_{:d}_train.npy".format(n), cycles)
        np.save("../hamilton/data/hamilton_{:d}_train_var.npy".format(n), distances)

