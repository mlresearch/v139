# import torch
# import torch.nn as nn
# from torch.autograd import Variable
# import torch.optim as optim
from sys import stderr
from matplotlib.pyplot import flag
import numpy as np
from scipy import stats
from numpy.linalg import inv
import scipy.io as scio
import scipy.stats as st
import argparse
import copy
import math
import os
import sys
from pyGM.messagepass import LBP
from pyGM.graphmodel import GraphModel, eliminationOrder
from pyGM.factor import Factor
from mrf import MRF
from loaduai import readUai, writeUai
from DrawLatinSquare import check_latin, compute_vars, bin2dec, dec2bin
from HamiltonCycle import check_hamilton, compute_distance, ham_bin2dec, ham_dec2bin

NUM_EPOCHS = 1000
NUM_SAMPLES = 100
LAMDA = 10

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Discrete MRF')
    parser.add_argument(
        '--filename', default='latin_3_train.uai', help='name must be specified')
    parser.add_argument('--job', default='latin',
                        help='name must be specified')
    args = parser.parse_args()
    filename = args.filename
    job = args.job
    print(filename + "\n", flush=True)

    factors, dims = readUai(filename)
    mrf_xor = MRF(factors, dims, filename, job)
    initials = np.load(os.path.splitext(filename)[
                       0] + ".npy")  # transfer to binary
    total_size = len(initials)
    n = initials.shape[1]
    if job == "latin":
        training_data = dec2bin(initials, n)
    elif job == "hamilton":
        training_data = ham_dec2bin(initials, n)
    else:
        print("job unrecognized!", flush=True)
        exit(0)

    for epoch in range(NUM_EPOCHS):
        print('epoch [{}/{}]'.format(epoch, NUM_EPOCHS), flush=True)
        # test every 10 epochs
        if epoch % 10 == 0:
            writeUai('{}_xor.uai'.format(filename[:-4]), mrf_xor.factors)

            # Compute precision and distribution
            test_smaples = mrf_xor.XOR_Sampling(
                5 * NUM_SAMPLES)  # transfer to decimal

            if job == "latin":
                test_squares = bin2dec(test_smaples, n)
                acc = 0
                for i in range(len(test_squares)):
                    if check_latin(test_squares[i]):
                        acc += 1
                vars = compute_vars(test_squares)
                print("\ntesting: [(latin)/(square)/(samples)]", flush=True)
                print('precision [ {} / {} / {} ]:\n'.format(acc,
                                                             len(test_squares), NUM_SAMPLES), flush=True)
                print('xor:\n variance distribution: {}\n'.format(vars), flush=True)

            elif job == "hamilton":
                test_cycles = ham_bin2dec(test_smaples, n)
                acc = 0
                for i in range(len(test_cycles)):
                    if check_hamilton(test_cycles[i]):
                        acc += 1
                distances = compute_distance(test_cycles)
                print("\ntesting: [(hamilton)/(nodes)/(samples)]", flush=True)
                print('precision [ {} / {} / {} ]:\n'.format(acc,
                                                             len(test_cycles), NUM_SAMPLES), flush=True)
                print('xor:\n distance distribution: {}\n'.format(
                    distances), flush=True)

        # training
        if epoch > 50:
            lamda = LAMDA / 200
        elif epoch > 20:
            lamda = LAMDA / 100
        else:
            lamda = LAMDA
        idxs = np.random.choice(range(0, total_size),
                                NUM_SAMPLES, replace=False)
        print('[xor]: updating', flush=True)
        mrf_xor.CD(training_data[idxs], 'xor',
                   lamda=lamda, n_samples=NUM_SAMPLES)
