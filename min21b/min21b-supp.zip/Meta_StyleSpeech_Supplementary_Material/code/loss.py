'''
This is a pseudo-code to help you understand the paper.
'''

import torch
import torch.nn as nn

class StyleSpeechLoss(nn.Module):
    """ StyleSpeech Loss """
    def __init__(self):
        super(StyleSpeechLoss, self).__init__()
        self.mse_loss = nn.MSELoss()
        self.mae_loss = nn.L1Loss()


    def forward(self, mel, mel_target, log_d_predicted, log_d_target, 
                    p_predicted, p_target, e_predicted, e_target, src_mask, mel_mask):
        log_d_target.requires_grad = False
        p_target.requires_grad = False
        e_target.requires_grad = False
        mel_target.requires_grad = False
        
        mel = mel.masked_select(mel_mask.unsqueeze(-1))
        mel_target = mel_target.masked_select(mel_mask.unsqueeze(-1))

        log_d_predicted = log_d_predicted.masked_select(src_mask)
        log_d_target = log_d_target.masked_select(src_mask)
        p_predicted = p_predicted.masked_select(src_mask)
        p_target = p_target.masked_select(src_mask)
        e_predicted = e_predicted.masked_select(src_mask)
        e_target = e_target.masked_select(src_mask)

        # mel, duration, pitch, energy loss
        mel_loss = self.mae_loss(mel, mel_target)
        d_loss = self.mse_loss(log_d_predicted, log_d_target)
        p_loss = self.mse_loss(p_predicted, p_target)
        e_loss = self.mse_loss(e_predicted, e_target)

        return mel_loss, d_loss, p_loss, e_loss


class GANLoss(nn.Module):
    def __init__(self):
        super(GANLoss, self).__init__()
        self.criterion = nn.MSELoss()
        
    def forward(self, r, valid, mask=None):
        if mask is not None:
            r = r.masked_select(mask)
        if valid:
            valid = torch.ones(r.size(), requires_grad=False).to(r.device)
            loss = self.criterion(r, valid)
        else:
            fake = torch.zeros(r.size(), requires_grad=False).to(r.device)
            loss = self.criterion(r, fake)
        return loss
