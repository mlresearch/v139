'''
This is a pseudo-code to help you understand the paper.
'''

import torch.nn as nn
from torch.nn import functional as F
from transformer.SubLayers import MultiHeadAttention, PositionwiseFeedForward
from transformer.Modules import AdaptiveLayerNorm

class FFTBlock(nn.Module):
    """FFT Block"""
    def __init__(self, d_model,d_inner,
                    n_head, d_k, d_v, fft_conv1d_kernel_size, style_dim, dropout=0.1):
        super(FFTBlock, self).__init__()

        self.slf_attn = MultiHeadAttention(
            n_head, d_model, d_k, d_v, dropout=dropout)
        self.adaln_0 = AdaptiveLayerNorm(d_model, style_dim)
 
        self.pos_ffn = PositionwiseFeedForward(
            d_model, d_inner, fft_conv1d_kernel_size, dropout=dropout)
        self.adaln_1 = AdaptiveLayerNorm(d_model, style_dim)

    def forward(self, enc_input, style_code, mask=None, slf_attn_mask=None):
        # multi-head self attn
        enc_output, enc_slf_attn = self.slf_attn(
            enc_input, enc_input, enc_input, mask=slf_attn_mask)
        # SALN
        enc_output = self.adaln_0(enc_output, style_code)
        enc_output = enc_output.masked_fill(mask.unsqueeze(-1), 0)

        # position wise FF
        enc_output = self.pos_ffn(enc_output)
        # SALN
        enc_output = self.adaln_1(enc_output, style_code)
        enc_output = enc_output.masked_fill(mask.unsqueeze(-1), 0)

        return enc_output, enc_slf_attn

