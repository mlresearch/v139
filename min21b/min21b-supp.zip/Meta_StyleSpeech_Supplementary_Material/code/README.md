# Meta-StyleSpeech : Multi-Style Adaptive Text-to-Speech Generation

This is a pseudo-code to help you understand the paper.

## Code Description

* hparams.py : All the hyper-parameters we use for the experiments.

* train.py : The code for training StyleSpeech.
* train_episodic.py : The code for training Meta-StyleSpeech.
* loss.py : The losses to train Meta-StyleSpeech and StyleSpeech.

* models/ : The codes for StyleSpeech, Discriminators(Phoneme & Style) and Variance Adaptor. 
    * stylespeech.py : The implementation of StyleSpeech.
    * discriminator.py : The implementation of Phoneme discriminator and Style discriminator.
    * variance_adaptor.py : The implementation of variance adaptor.
  
* mel_style_encoder/ : The codes for Mel-Style Encoder.
    * Models.py : The implementation of Mel-Style Encoder.
    * Modules.py : The implementation of backbone modules for Mel-Style Encoder.
  
* transformer/ : The implementation of backbone modules for StyleSpeech.
