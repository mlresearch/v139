'''
This is a pseudo-code to help you understand the paper.
'''

import torch
import torch.nn as nn
from models.stylespeech import StyleSpeech
from models.discriminator import Discriminator
from dataset import prepare_dataloader
import hparams as hp

def main():
    torch.manual_seed(0)

    # Define model
    model = StyleSpeech().cuda()
    discriminator = Discriminator().cuda()

    # Optimizer
    G_optim = torch.optim.Adam(model.parameters(), betas=hp.betas, eps=hp.eps, weight_decay=hp.weight_decay)
    G_optim = ScheduledOptim(G_optim, hp.decoder_hidden, hp.n_warm_up_step, current_step)
    D_optim = torch.optim.Adam(discriminator.parameters(), lr=0.0002, betas=hp.betas, eps=hp.eps, weight_decay=hp.weight_decay)
    # Loss
    Loss = model.get_criterion()
    adversarial_loss = discriminator.get_criterion()

    # Get dataset
    data_loader, data_sampler = prepare_dataloader("train.txt", shuffle=True, batch_size=hp.meta_batch_size) 

    model.train()
    current_step = 0
    while current_step < hp.max_train_step:
        for idx, batch in enumerate(data_loader):
            ###### Support Speech ######
            G_optim.zero_grad()
            # Get support speech & text
            sid, text, mel_target, D, log_D, f0, energy, \
                    src_len, mel_len, max_src_len, max_mel_len = model.parse_batch(batch)
            src = model.acoustic_adaptor.length_regulator(text.unsqueeze(-1), D)[0].squeeze(-1).detach()
            # Reconstruct support speech
            mel_output, style_code, log_duration_output, f0_output, energy_output, src_mask, mel_mask, _  = model(
                    text, src_len, mel_target, mel_len, D, f0, energy, max_src_len, max_mel_len)
            # Reconstruction loss    
            mel_loss, d_loss, f_loss, e_loss = Loss(mel_output,  mel_target, 
                    log_duration_output, log_D, f0_output, f0, energy_output, energy, ~src_mask, ~mel_mask)

            ###### Query Speech ######
            # Get query text - random permutation
            perm_idx = torch.randperm(text.shape[0])
            q_text, q_D, q_src_len = text[perm_idx], D[perm_idx], src_len[perm_idx]
            # Generate query speech
            q_mel_output, q_log_duration_output, _, _, q_src_mask, q_mel_mask, q_mel_len = model.inference(style_code, q_text, q_src_len)
            # Legulate length of query src
            q_duration_rounded = torch.clamp(torch.round(torch.exp(q_log_duration_output.detach())-hp.log_offset), min=0)
            q_duration_rounded = q_duration_rounded.masked_fill(q_src_mask, 0).long()
            q_src = model.acoustic_adaptor.length_regulator(q_text.unsqueeze(-1), q_duration_rounded)[0].squeeze(-1)
            ## Adverserial loss    
            t_val, s_val, _= discriminator(q_mel_output, q_src, style_code.detach(), sid, q_mel_mask)
            t_g_adv = adversarial_loss(t_val, valid=True)
            s_g_adv = adversarial_loss(s_val, valid=True)
            ## Total loss
            alpha = 10.0
            total_loss = alpha*mel_loss + d_loss + f_loss + e_loss + t_g_adv + s_g_adv
            ## Backward
            total_loss.backward()
            ## Clipping gradients to avoid gradient explosion
            nn.utils.clip_grad_norm_(model.parameters(), hp.grad_clip_thresh)
            ## Update weights
            G_optim.step_and_update_lr()
          
            ###### Discriminator ######
            D_optim.zero_grad()
            ## Real
            real_t_pred, real_s_pred, d_ce_loss = discriminator(
                                mel_target, src, style_code.detach(), sid, mask=mel_mask)
            t_real_adv = adversarial_loss(real_t_pred, valid=True) ##
            s_real_adv = adversarial_loss(real_s_pred, valid=True) ##
            d_real_loss = t_real_adv + s_real_adv
            ## Fake
            fake_t_pred, fake_s_pred, _ = discriminator(q_mel_output.detach(), q_src, style_code, sid, mask=q_mel_mask)
            t_fake_adv = adversarial_loss(fake_t_pred, valid=False) ##
            s_fake_adv = adversarial_loss(fake_s_pred, valid=False) ##
            d_fake_loss = t_fake_adv + s_fake_adv
            ## Total Loss
            D_loss = d_real_loss + d_fake_loss + d_ce_loss
            ## Backward
            D_loss.backward()
            ## Update weights
            D_optim.step()

            current_step += 1

if __name__ == "__main__":
    main()
