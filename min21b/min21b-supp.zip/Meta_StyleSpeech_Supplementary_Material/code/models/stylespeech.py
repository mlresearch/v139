'''
This is a pseudo-code to help you understand the paper.
'''

import torch
import torch.nn as nn
import numpy as np
from transformer.Models import Encoder, Decoder
from mel_style_encoder.Models import MelStyleEncoder
from models.variance_adaptor import VarianceAdaptor
from loss import StyleSpeechLoss
from utils import get_mask_from_lengths
import hparams as hp

class StyleSpeech(nn.Module):
    ''' StyleSpeech '''
    def __init__(self):
        super(StyleSpeech, self).__init__()
        self.style_encoder = MelStyleEncoder()
        
        self.encoder = Encoder()

        self.variance_adaptor = VarianceAdaptor()

        self.decoder = Decoder()
 
    def parse_batch(self, batch):
        sid = torch.from_numpy(batch["sid"]).long().cuda()
        text = torch.from_numpy(batch["text"]).long().cuda()
        mel_target = torch.from_numpy(batch["mel_target"]).float().cuda()
        D = torch.from_numpy(batch["D"]).long().cuda()
        log_D = torch.from_numpy(batch["log_D"]).float().cuda()
        f0 = torch.from_numpy(batch["f0"]).float().cuda()
        energy = torch.from_numpy(batch["energy"]).float().cuda()
        src_len = torch.from_numpy(batch["src_len"]).long().cuda()
        mel_len = torch.from_numpy(batch["mel_len"]).long().cuda()
        max_src_len = np.max(batch["src_len"]).astype(np.int32)
        max_mel_len = np.max(batch["mel_len"]).astype(np.int32)
        return sid, text, mel_target, D, log_D, f0, energy, src_len, mel_len, max_src_len, max_mel_len

    def forward(self, src_seq, src_len, mel_target, mel_len=None, 
                    d_target=None, p_target=None, e_target=None, max_src_len=None, max_mel_len=None):
        src_mask = get_mask_from_lengths(src_len, max_src_len)
        mel_mask = get_mask_from_lengths(mel_len, max_mel_len) if mel_len is not None else None

        # Extract style vector
        style_code = self.style_encoder(mel_target, mel_mask)

        # Phoneme encoding
        encoder_output = self.encoder(src_seq, style_code, src_mask)
        # Variance adaptor
        if d_target is not None:
            # training
            variance_adaptor_output, d_prediction, p_prediction, e_prediction, _, _ = self.variance_adaptor(
                    encoder_output, src_mask, mel_len, mel_mask, d_target, p_target, e_target, max_mel_len)
        else:
            # inference
            variance_adaptor_output, d_prediction, p_prediction, e_prediction, mel_len, mel_mask = self.variance_adaptor(
                    encoder_output, style_code, src_mask, mel_len, mel_mask, d_target, p_target, e_target, max_mel_len)
        # Mel-spectrogram deocoding
        decoder_output = self.decoder(variance_adaptor_output, style_code, mel_mask)
        
        return decoder_output, style_code, d_prediction, p_prediction, e_prediction, src_mask, mel_mask, mel_len

    def inference(self, style_code, src_seq, src_len=None, max_src_len=None):
        src_mask = get_mask_from_lengths(src_len, max_src_len)
  
        # Phoneme encoding
        encoder_output = self.encoder(src_seq, style_code, src_mask)
        # Variance adaptor
        variance_adaptor_output, d_prediction, p_prediction, \
                e_prediction, mel_len, mel_mask = self.variance_adaptor(encoder_output, style_code, src_mask)
        # Mel-spectrogram deocoding
        decoder_output = self.decoder(variance_adaptor_output, style_code, mel_mask)

        return decoder_output, d_prediction, p_prediction, e_prediction, src_mask, mel_mask, mel_len
    
    def get_style_code(self, mel_target, mel_len=None, max_mel_len=None):
        mel_mask = get_mask_from_lengths(mel_len, max_mel_len) if mel_len is not None else None
        style_code = self.style_encoder(mel_target, mel_mask)
        return style_code

    def get_criterion(self):
        return StyleSpeechLoss()

