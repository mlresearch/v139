'''
This is a pseudo-code to help you understand the paper.
'''

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils import spectral_norm
from text.symbols import symbols
from transformer.Modules import ScaledDotProductAttention
from transformer.Models import get_sinusoid_encoding_table
from loss import GANLoss
import hparams as hp

def dot_product_metric(a, b):
    n = a.size(0)
    m = b.size(0)
    a = a.unsqueeze(1).expand(n, m, -1)
    b = b.unsqueeze(0).expand(n, m, -1)
    logits = (a*b).sum(dim=2)
    return logits


class Discriminator(nn.Module):
    ''' Discriminator '''
    def __init__(self):
        super(Discriminator, self).__init__()

        self.style_D = StyleDiscriminator(hp.D_style_dim, hp.style_dim)
        self.text_D = TextDiscriminator(hp.D_phoneme_dim)

    def forward(self, mels, srcs, style_codes, sids, mask):
        t_val = self.text_D(mels, srcs, mask)
        s_val, ce_loss = self.style_D(mels, style_codes, sids, mask)
        return t_val, s_val, ce_loss   
    
    def get_criterion(self):
        return GANLoss()


class StyleDiscriminator(nn.Module):
    ''' Style Discriminator '''
    def __init__(self, hidden_dim, style_dim):
        super(StyleDiscriminator, self).__init__()
        # style prototypes
        self.S = nn.Embedding(hp.n_speakers, style_dim)

        self.mel_prenet = nn.Sequential(
            Linear(hp.n_mel_channels, hidden_dim, use_spectral_norm=True),
            nn.LeakyReLU(0.1),
            Linear(hidden_dim, hidden_dim, use_spectral_norm=True),
            nn.LeakyReLU(0.1),
        )

        convs = nn.ModuleList()
        for _ in range(2):
            convs.append(nn.Sequential(
                Conv1d(hidden_dim, hidden_dim, 
                        kernel_size=5, use_spectral_norm=True),
                nn.LeakyReLU(0.1)))
        self.convs = convs
        self.slf_attn = MultiHeadSelfAttention(hidden_dim, hidden_dim, hidden_dim, use_spectral_norm=True)
        self.fc = Linear(hidden_dim, hidden_dim, use_spectral_norm=True)

        self.V = Linear(style_dim, hidden_dim, use_spectral_norm=True)
        self.w = nn.Parameter(torch.ones(1))
        self.b = nn.Parameter(torch.zeros(1))

        self.ce_loss = nn.CrossEntropyLoss()

    def temporal_avg_pool(self, xs, mask):
        xs = xs.masked_fill(mask.unsqueeze(-1), 0)
        len_ = (~mask).sum(dim=1).unsqueeze(1)
        xs = torch.sum(xs, dim=1)
        xs = torch.div(xs, len_)
        return xs

    def forward(self, mels, style_codes, sids, mask, debug=False):
        # Style prototypes
        style_prototypes = self.S(torch.arange(hp.n_speakers).cuda())
        logit = dot_product_metric(style_codes, style_prototypes)
        ## cls loss
        ce_loss = self.ce_loss(logit, sids)

        # Style discriminator
        xs = self.mel_prenet(mels)
        xs = xs.transpose(1,2)
        for conv in self.convs:
            residual = xs
            xs = conv(xs)
            xs = xs + residual
        xs = xs.transpose(1,2)

        xs = xs.masked_fill(mask.unsqueeze(-1), 0)
        xs = self.slf_attn(xs, mask=mask)
        xs = self.fc(xs)

        # Style validation
        hs = self.temporal_avg_pool(xs, mask)
        ps = self.S(sids)
        s_val = self.w * (torch.sum(self.V(ps)*hs, dim=1)) + self.b
        return s_val, ce_loss


class TextDiscriminator(nn.Module):
    ''' Text Discriminator '''
    def __init__(self, hidden_dim):
        super(TextDiscriminator, self).__init__()
        self.hidden_dim = hidden_dim

        self.mel_prenet = nn.Sequential(
            Linear(hp.n_mel_channels, hidden_dim, use_spectral_norm=True),
            nn.LeakyReLU(0.1),
            Linear(hidden_dim, hidden_dim, use_spectral_norm=True),
            nn.LeakyReLU(0.1),
        )

        n_src_vocab = len(symbols)+1
        self.T = spectral_norm(nn.Embedding(n_src_vocab, hidden_dim, padding_idx=0))
        n_position = hp.max_seq_len + 1
        self.position_enc = nn.Parameter(
                get_sinusoid_encoding_table(n_position, hidden_dim).unsqueeze(0), requires_grad = False)

        self.fcs = nn.Sequential(
            Linear(hidden_dim*2, 512, use_spectral_norm=True),
            nn.LeakyReLU(0.1),
            Linear(512, 512, use_spectral_norm=True),
            nn.LeakyReLU(0.1),
            Linear(512, 512, use_spectral_norm=True),
            nn.LeakyReLU(0.1),
            Linear(512, 1, use_spectral_norm=True),
        )

    def forward(self, mels, srcs, mask):
        batch_size, max_len = mels.shape[0], mels.shape[1]

        xs = self.mel_prenet(mels)
        srcs = self.T(srcs)
        # position encoding
        if srcs.shape[1] > hp.max_seq_len:
            srcs = srcs + get_sinusoid_encoding_table(srcs.shape[1], self.hidden_dim)[:srcs.shape[1], :].unsqueeze(0).expand(batch_size, -1, -1).to(srcs.device)
        else:
            srcs = srcs + self.position_enc[:, :max_len, :].expand(batch_size, -1, -1)

        xs = torch.cat((xs, srcs), dim=-1)
        xs = self.fcs(xs).squeeze(-1)

        # Temporal average pooling
        mel_len = (~mask).sum(-1)
        xs = xs.masked_fill(mask, 0.)
        t_val = torch.div(torch.sum(xs, dim=1), mel_len)
        return t_val


class Linear(nn.Module):
    def __init__(self, in_channels, out_channels, use_spectral_norm=True):
        super(Linear, self).__init__()
        self.fc = nn.Linear(in_channels, out_channels)

        if use_spectral_norm:
            self.fc = spectral_norm(self.fc)
            
    def forward(self, x):
        x = self.fc(x)
        return x


class Conv1d(nn.Module):
    def __init__(self, in_channels, out_channels, 
                kernel_size=3, stride=1, padding=None, use_spectral_norm=True):
        super(Conv1d, self).__init__()
        if padding is None:
            padding = int((kernel_size - 1) / 2)
        self.conv = nn.Conv1d(in_channels, out_channels, 
                        kernel_size=kernel_size, stride=stride, padding=padding)
        
        if use_spectral_norm:
            self.conv = spectral_norm(self.conv)
            
    def forward(self, x):
        x = self.conv(x)
        return x


class MultiHeadSelfAttention(nn.Module):
    ''' Multi-Head SelfAttention module '''

    def __init__(self, d_model=128, d_out=128, d_unit=128, n_head=2, drop_out=0., use_spectral_norm=True):
        super().__init__()
        self.n_head = n_head
        self.d_unit = d_unit // n_head
        self.drop_out = drop_out

        self.w_qs = nn.Linear(d_model, n_head * self.d_unit)
        self.w_ks = nn.Linear(d_model, n_head * self.d_unit)
        self.w_vs = nn.Linear(d_model, n_head * self.d_unit)
        
        self.attention = ScaledDotProductAttention(temperature=np.power(d_model, 0.5))
        self.fc = nn.Linear(n_head*self.d_unit, d_out)

        if use_spectral_norm:
            self.w_qs = spectral_norm(self.w_qs)
            self.w_ks = spectral_norm(self.w_ks)
            self.w_vs = spectral_norm(self.w_vs)
            self.fc = spectral_norm(self.fc)

    def forward(self, x, mask=None):
        d_unit, n_head = self.d_unit, self.n_head

        residual = x

        sz_b, len_, _ = x.size()
        q = self.w_qs(x).view(sz_b, len_, n_head, d_unit)
        k = self.w_ks(x).view(sz_b, len_, n_head, d_unit)
        v = self.w_vs(x).view(sz_b, len_, n_head, d_unit)
        q = q.permute(2, 0, 1, 3).contiguous().view(-1, len_, d_unit)  # (n*b) x lq x dk
        k = k.permute(2, 0, 1, 3).contiguous().view(-1, len_, d_unit)  # (n*b) x lk x dk
        v = v.permute(2, 0, 1, 3).contiguous().view(-1, len_, d_unit)  # (n*b) x lv x dv

        if mask is not None:
            slf_mask = mask.unsqueeze(1).expand(-1, len_, -1)
            slf_mask = slf_mask.repeat(n_head, 1, 1)  # (n*b) x .. x ..
        else:
            slf_mask = None
        x, _ = self.attention(q, k, v, mask=slf_mask)

        x = x.view(n_head, sz_b, len_, d_unit)
        x = x.permute(1, 2, 0, 3).contiguous().view(sz_b, len_, -1)  # b x lq x (n*dv)
        x = F.dropout(self.fc(x), self.drop_out)

        x = residual + x
        x = x.masked_fill(mask.unsqueeze(-1), 0)
        return x