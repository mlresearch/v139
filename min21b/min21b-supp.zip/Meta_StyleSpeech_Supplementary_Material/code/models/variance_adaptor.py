'''
This is a pseudo-code to help you understand the paper.
'''

import torch
import torch.nn as nn
import torch.nn.functional as F
import hparams as hp
import utils

class VarianceAdaptor(nn.Module):
    """ Variance Adaptor """
    def __init__(self):
        super(VarianceAdaptor, self).__init__()
        # Duration
        self.duration_predictor = VariancePredictor(hp.decoder_hidden, hp.variance_predictor_filter_size, 
                                                            hp.variance_predictor_kernel_size, 1, 2)
        # Pitch
        self.pitch_predictor = VariancePredictor(hp.decoder_hidden, hp.variance_predictor_filter_size, 
                                                            hp.variance_predictor_kernel_size, 1, 2)
        self.pitch_embedding = Conv(1, hp.decoder_hidden, 9)
        # Energy
        self.energy_predictor = VariancePredictor(hp.decoder_hidden, hp.variance_predictor_filter_size, 
                                                            hp.variance_predictor_kernel_size, 1, 2)
        self.energy_embedding = Conv(1, hp.decoder_hidden, 9)
        
        # Length regulator
        self.length_regulator = LengthRegulator()
        self.dropout = nn.Dropout(hp.variance_predictor_dropout)
    
    def forward(self, x, src_mask, mel_len=None, mel_mask=None, 
                        duration_target=None, pitch_target=None, energy_target=None, max_len=None):

        log_duration_prediction = self.duration_predictor(x, src_mask)

        pitch_prediction = self.pitch_predictor(x, src_mask) 
        if pitch_target is not None:
            pitch_embedding = self.pitch_embedding(pitch_target.unsqueeze(2))
        else:
            pitch_embedding = self.pitch_embedding(pitch_prediction.unsqueeze(2))

        energy_prediction = self.energy_predictor(x, src_mask)
        if energy_target is not None:
            energy_embedding = self.energy_embedding(energy_target.unsqueeze(2))
        else:
            energy_embedding = self.energy_embedding(energy_prediction.unsqueeze(2))

        x = x + self.dropout(pitch_embedding) + self.dropout(energy_embedding)
        
        if duration_target is not None:
            x, mel_len = self.length_regulator(x, duration_target, max_len)
        else:
            duration_rounded = torch.clamp(torch.round(torch.exp(log_duration_prediction)-hp.log_offset), min=1)
            duration_rounded = duration_rounded.masked_fill(src_mask, 0)
            x, mel_len = self.length_regulator(x, duration_rounded)
            mel_mask = utils.get_mask_from_lengths(mel_len)

        return x, log_duration_prediction, pitch_prediction, energy_prediction, mel_len, mel_mask
        

class LengthRegulator(nn.Module):
    """ Length Regulator """

    def __init__(self):
        super(LengthRegulator, self).__init__()

    def LR(self, x, duration, max_len):
        output = list()
        mel_len = list()
        for batch, expand_target in zip(x, duration):
            expanded = self.expand(batch, expand_target)
            output.append(expanded)
            mel_len.append(expanded.shape[0])

        if max_len is not None:
            output = utils.pad(output, max_len)
        else:
            output = utils.pad(output)

        return output, torch.LongTensor(mel_len).cuda()

    def expand(self, batch, predicted):
        out = list()
        for i, vec in enumerate(batch):
            expand_size = predicted[i].item()
            out.append(vec.expand(int(expand_size), -1))
        out = torch.cat(out, 0)

        return out

    def forward(self, x, duration, max_len=None):
        output, mel_len = self.LR(x, duration, max_len)
        return output, mel_len


class VariancePredictor(nn.Module):
    """ Variance Predictor """
    def __init__(self, input_size, filter_size, kernel_size, output_size, n_layers=2, dropout=0.5):
        super(VariancePredictor, self).__init__()

        convs = [Conv(input_size, filter_size, kernel_size)]
        for _ in range(n_layers-1):
            convs.append(Conv(filter_size, filter_size, kernel_size))
        self.convs = nn.ModuleList(convs)
        self.lns = nn.ModuleList([nn.LayerNorm(filter_size) for _ in range(n_layers)])
        self.linear_layer = nn.Linear(filter_size, output_size)
        self.dropout = dropout

    def forward(self, encoder_output, mask):
        out = encoder_output

        for conv, ln in zip(self.convs, self.lns):
            out = F.relu(conv(out))
            out = ln(out)
            out = F.dropout(out, self.dropout)
        
        out = self.linear_layer(out)
        if mask is not None:
            out = out.masked_fill(mask.unsqueeze(-1), 0)
        return out.squeeze(-1)


class Conv(nn.Module):
    """ Convolution Module """
    def __init__(self,
                 in_channels, out_channels,
                 kernel_size=1, stride=1,
                 padding=None, dilation=1, bias=True):
        super(Conv, self).__init__()

        if padding is None:
            assert(kernel_size % 2 == 1)
            padding = int(dilation * (kernel_size - 1) / 2)

        self.conv = nn.Conv1d(in_channels,out_channels,
                              kernel_size=kernel_size,
                              stride=stride,
                              padding=padding,
                              dilation=dilation,
                              bias=bias)

    def forward(self, x):
        x = x.transpose(1, 2)
        x = self.conv(x)
        x = x.transpose(1, 2)
        return x
