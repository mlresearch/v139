'''
This is a pseudo-code to help you understand the paper.
'''

# Dataset
dataset = "LibriTTS"
n_speakers = 1141

# Text
text_cleaners = ['english_cleaners']

# Audio and mel
sampling_rate = 16000
filter_length = 1024
hop_length = 256
win_length = 1024

max_wav_value = 32768.0
n_mel_channels = 80
mel_fmin = 0.0
mel_fmax = 8000.0

max_seq_len = 1000

# StyleSpeech
encoder_layer = 4
encoder_head = 2
encoder_hidden = 256
decoder_layer = 4
decoder_head = 2
decoder_hidden = 256
enc_fft_conv1d_filter_size = 1024
dec_fft_conv1d_filter_size = 1024
fft_conv1d_kernel_size = (9, 1)
encoder_dropout = 0.1
decoder_dropout = 0.1
style_dim = 128

# Varaiance Adaptor
variance_predictor_filter_size = 256
variance_predictor_kernel_size = 3
variance_predictor_dropout = 0.5
log_offset = 1. # Log-scaled duration

# Discriminator
D_phoneme_dim = 256
D_style_dim = 128

# Optimizer
batch_size = 48
meta_batch_size = 20
max_train_step = 100000
n_warm_up_step = 4000
grad_clip_thresh = 1.0

betas = (0.9, 0.98)
eps = 1e-9
weight_decay = 0.


