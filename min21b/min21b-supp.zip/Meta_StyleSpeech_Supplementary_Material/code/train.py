'''
This is a pseudo-code to help you understand the paper.
'''

import torch
import numpy as np
from models.stylespeech import StyleSpeech
from dataset import prepare_dataloader
import hparams as hp

def main():
    torch.manual_seed(0)

    # Define model
    model = StyleSpeech().cuda()

    # Optimizer
    optimizer = torch.optim.Adam(model.parameters(), betas=hp.betas, eps=hp.eps, weight_decay=hp.weight_decay)
    scheduled_optim = ScheduledOptim(optimizer, hp.decoder_hidden, hp.n_warm_up_step, current_step)
    # Loss
    Loss = model.get_criterion()

    # Get dataset
    data_loader, data_sampler = prepare_dataloader("train.txt", shuffle=True, batch_size=hp.batch_size) 
    
    model.train()
    current_step = 0
    while current_step < hp.max_train_step:
        for idx, batch in enumerate(data_loader):
            # Get Data
            sid, text, mel_target, D, log_D, f0, energy, \
                    src_len, mel_len, max_src_len, max_mel_len = model.parse_batch(batch) 
            # Forward
            scheduled_optim.zero_grad()
            mel_output, style_code, log_duration_output, f0_output, energy_output, src_mask, mel_mask, _  = model(
                    text, src_len, mel_target, mel_len, D, f0, energy, max_src_len, max_mel_len)
            mel_loss, d_loss, f_loss, e_loss = Loss(mel_output, mel_target, 
                    log_duration_output, log_D, f0_output, f0, energy_output, energy, ~src_mask, ~mel_mask)
            # Total loss
            total_loss =  mel_loss + d_loss + f_loss + e_loss
            # Backward
            total_loss.backward()
            # Clipping gradients to avoid gradient explosion
            nn.utils.clip_grad_norm_(model.parameters(), hp.grad_clip_thresh)
            # Update weights
            scheduled_optim.step_and_update_lr()

            current_step += 1

if __name__ == "__main__":
    main()
