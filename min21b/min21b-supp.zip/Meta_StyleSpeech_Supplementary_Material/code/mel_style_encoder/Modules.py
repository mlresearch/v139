'''
This is a pseudo-code to help you understand the paper.
'''

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

class ScaledDotProductAttention(nn.Module):
    ''' Scaled Dot-Product Attention '''

    def __init__(self, temperature):
        super().__init__()
        self.temperature = temperature
        self.softmax = nn.Softmax(dim=2)

    def forward(self, q, k, v, mask=None):

        attn = torch.bmm(q, k.transpose(1, 2))
        attn = attn / self.temperature

        if mask is not None:
            attn = attn.masked_fill(mask, -np.inf)

        attn = self.softmax(attn)

        output = torch.bmm(attn, v)
        return output, attn


class MultiHeadSelfAttention(nn.Module):
    ''' Multi-Head SelfAttention module '''

    def __init__(self, d_model=128, d_out=128, d_unit=128, n_head=2, drop_out=0.2):
        super().__init__()
        self.n_head = n_head
        self.d_unit = d_unit // n_head
        self.drop_out = drop_out

        self.w_qs = nn.Linear(d_model, n_head * self.d_unit)
        self.w_ks = nn.Linear(d_model, n_head * self.d_unit)
        self.w_vs = nn.Linear(d_model, n_head * self.d_unit)
        
        self.attention = ScaledDotProductAttention(temperature=np.power(d_model, 0.5))
        self.fc = nn.Linear(n_head*self.d_unit, d_out)

    def forward(self, x, mask=None):
        d_unit, n_head = self.d_unit, self.n_head

        residual = x

        sz_b, len_, _ = x.size()
        q = self.w_qs(x).view(sz_b, len_, n_head, d_unit)
        k = self.w_ks(x).view(sz_b, len_, n_head, d_unit)
        v = self.w_vs(x).view(sz_b, len_, n_head, d_unit)
        q = q.permute(2, 0, 1, 3).contiguous().view(-1, len_, d_unit)  # (n*b) x lq x dk
        k = k.permute(2, 0, 1, 3).contiguous().view(-1, len_, d_unit)  # (n*b) x lk x dk
        v = v.permute(2, 0, 1, 3).contiguous().view(-1, len_, d_unit)  # (n*b) x lv x dv

        if mask is not None:
            slf_mask = mask.unsqueeze(1).expand(-1, len_, -1)
            slf_mask = slf_mask.repeat(n_head, 1, 1)  # (n*b) x .. x ..
        else:
            slf_mask = None
        x, _ = self.attention(q, k, v, mask=slf_mask)

        x = x.view(n_head, sz_b, len_, d_unit)
        x = x.permute(1, 2, 0, 3).contiguous().view(sz_b, len_, -1)  # b x lq x (n*dv)
        x = F.dropout(self.fc(x), self.drop_out)

        x = residual + x
        x = x.masked_fill(mask.unsqueeze(-1), 0)
        return x