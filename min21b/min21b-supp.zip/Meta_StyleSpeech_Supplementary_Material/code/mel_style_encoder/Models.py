'''
This is a pseudo-code to help you understand the paper.
'''

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from transformer.Modules import Mish
from mel_style_encoder.Modules import MultiHeadSelfAttention, ConvNorm
import hparams as hp

drop_out = hp.encoder_dropout

class FCPrepool(nn.Module):
    ''' FCPrepool'''
    def __init__(self, in_dim, out_dim, n_layers=2):
        super(FCPrepool, self).__init__()
        fcs = [nn.Linear(in_dim, out_dim)]
        for _ in range(n_layers-1):
            fcs.append(nn.Linear(out_dim, out_dim))
        self.fcs = nn.ModuleList(fcs)
        self.mish = Mish()
        self.dropout = nn.Dropout(drop_out)

    def forward(self, x):
        for fc in self.fcs:
            x = fc(x)
            x = self.dropout(self.mish(x))
        return x


class Conv1dGLU(nn.Module):
    '''
    Conv1d + GLU(Gated Linear Unit) with residual connection.
    '''
    def __init__(self, in_channels=128, out_channels=128, kernel_size=5, padding=None):
        super(Conv1dGLU, self).__init__()
        if padding is None:
            assert(kernel_size % 2 == 1)
            padding = int((kernel_size - 1) / 2)

        self.conv1 = nn.Conv1d(in_channels, 2*out_channels, 
                            kernel_size=kernel_size, padding=padding)
        self.dropout = nn.Dropout(drop_out)
            
    def forward(self, x):
        residual = x
        x = self.conv1(x)
        x1, x2 = torch.split(x, split_size_or_sections = 128, dim = 1)
        x = x1 * torch.sigmoid(x2)
        x = residual + self.dropout(x)
        x *= math.sqrt(0.5)
        return x


class MelStyleEncoder(nn.Module):
    ''' MelStyleEncoder '''
    def __init__(self, 
            in_dim=hp.n_mel_channels, 
            hidden_dim=hp.style_dim, 
            n_head=2):
        super(MelStyleEncoder, self).__init__()
        self.spectral = FCPrepool(in_dim, hidden_dim, n=2)

        self.temporal = nn.Sequential(
            Conv1dGLU(hidden_dim, hidden_dim),
            Conv1dGLU(hidden_dim, hidden_dim),
        )
        self.slf_attn = MultiHeadSelfAttention(hidden_dim, hidden_dim, hidden_dim, n_head) 
        self.fc = nn.Linear(hidden_dim, hidden_dim)
    
    def temporal_avg_pool(self, x, mask=None):
        if mask is None:
            out = torch.mean(x, dim=1)
        else:
            len_ = (~mask).sum(dim=1).unsqueeze(1)
            x = x.masked_fill(mask.unsqueeze(-1), 0)
            x = x.sum(dim=1)
            out = torch.div(x, len_)
        return out

    def forward(self, xs, mask=None):
        max_len = xs.shape[1]
        # Spectral processing
        xs = self.spectral(xs)
        # Temporal processing
        xs = xs.transpose(1,2)
        xs = self.temporal(xs)
        xs = xs.transpose(1,2)
        # Self-attention
        slf_attn_mask = mask.unsqueeze(1).expand(-1, max_len, -1)
        xs = self.slf_attn(xs, mask=slf_attn_mask)
        xs = self.fc(xs)

        # Temporal average pooling
        w = self.temporal_avg_pool(xs, mask)
        return w
