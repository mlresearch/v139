from .parallel import DataParallelModel, DataParallelCriterion

__all__ = ["DataParallelModel", "DataParallelCriterion"]