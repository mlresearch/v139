from .mylog import mylog

__all__ = ["mylog"]
