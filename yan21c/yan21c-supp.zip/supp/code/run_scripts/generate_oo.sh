#!/usr/bin/env bash
python preprocessing/gen_json_oo_train.py
python preprocessing/gen_json_oo_test.py