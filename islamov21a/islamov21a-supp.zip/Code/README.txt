This is implementation of our methods on Python (3.6.9).

Here you can find implementations of the following methods:
- Newton's method
- NEWTON-STAR
- NEWTON-LEARN 1
- NEWTON-LEARN 2
- CUBIC-NEWTON-LEARN
- DINGO
- BFGS
- ADIANA
- DIANA
- DCGD

See example notebooks if you want to run implemented methods. All instructions are written in these notebooks.
See Requirements.txt in order to check versions of Python libraries.

Remark: we used implementation of BFGS which was coded by other people.
