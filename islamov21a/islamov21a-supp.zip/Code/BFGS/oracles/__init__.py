from .base import BaseSmoothOracle
from .logistic import LogRegL2Oracle, create_log_reg_oracle
