# -*- coding: utf-8 -*-
import numpy as np
import matplotlib.pyplot as plt
import pickle
from utils import colors


thresh = 0.25
num_exps = 100

with open("num_params.pkl", "rb") as f:
    n_parameters = pickle.load(f)

with open("all_trajs_ADAM.pkl", "rb") as f:
    results = pickle.load(f)
traj_heads = []
traj_ends = []
for exps in results:
    traj_head = [exp[0] for exp in exps]
    traj_end = [exp[1] for exp in exps]
    traj_ends.append(traj_end)
    traj_heads.append(traj_head)

adam_heads = traj_heads
adam_ends = traj_ends

with open("all_trajs_RMSProp.pkl", "rb") as f:
    results = pickle.load(f)
traj_heads = []
traj_ends = []
for exps in results:
    traj_head = [exp[0] for exp in exps]
    traj_end = [exp[1] for exp in exps]
    traj_ends.append(traj_end)
    traj_heads.append(traj_head)

rmsprop_heads = traj_heads
rmsprop_ends = traj_ends

with open("all_trajs_LBFGS.pkl", "rb") as f:
    results = pickle.load(f)
traj_heads = []
traj_ends = []
for exps in results:
    traj_head = [exp[0] for exp in exps]
    traj_end = [exp[1] for exp in exps]
    traj_ends.append(traj_end)
    traj_heads.append(traj_head)

lbfgs_heads = traj_heads
lbfgs_ends = traj_ends

# Calculate
traj_ends = adam_ends
freqs = []
for i in range(len(n_parameters)):
    case_thresh = thresh / n_parameters[i]
    freq = np.sum(np.array(traj_ends[i]) < case_thresh)
    freqs.append(freq)
adam_freqs = freqs

traj_ends = lbfgs_ends
freqs = []
for i in range(len(n_parameters)):
    case_thresh = thresh / n_parameters[i]
    freq = np.sum(np.array(traj_ends[i]) < case_thresh)
    freqs.append(freq)
lbfgs_freqs = freqs

traj_ends = rmsprop_ends
freqs = []
for i in range(len(n_parameters)):
    case_thresh = thresh / n_parameters[i]
    freq = np.sum(np.array(traj_ends[i]) < case_thresh)
    freqs.append(freq)
rmsprop_freqs = freqs

###### Figure 2 and 7 ***
for i, n in enumerate(n_parameters):
    plt.figure()
    _ = plt.hist(rmsprop_heads[i], bins=50,color=colors[6], label='At initialization')
    _ = plt.hist(rmsprop_ends[i], bins=50,color=colors[1], label='At convergence')
    plt.legend()
    plt.axvline(thresh/n, color='k', linestyle='--')
    plt.grid(axis='y')
    plt.xlabel('Loss function: {}-parameter'.format(n))
    plt.ylabel('Frequency')
    plt.savefig("dist_RMSProp_{}.png".format(n))

###### Figure 3
for i,n in enumerate(n_parameters):
    plt.figure()
    cs = plt.hist(adam_ends[i], bins=50, alpha=.8, color=colors[0], label="Adam".format(n))
    cs = plt.hist(rmsprop_ends[i], bins=50,alpha=.8, color=colors[1], label="RMSProp".format(n))
    cs = plt.hist(lbfgs_ends[i], bins=50,alpha=.8, color=colors[2], label="L-BFGS".format(n))
    plt.axvline(thresh/n, color='k', linestyle='--')
    plt.grid(axis='y')
    plt.legend()
    plt.ylabel("Frequency")
    plt.xlabel("Loss function: {}-parameter".format(n))
    plt.savefig("dist_{}.png".format(n))

###### Figure 4: Decay
plt.figure()
plt.plot(n_parameters, np.array(adam_freqs) / num_exps, color=colors[0], marker='x', linestyle='dashed',
     linewidth=2, markersize=10, label='Adam')
plt.plot(n_parameters, np.array(rmsprop_freqs) / num_exps, color=colors[1], marker='x', linestyle='dashed',
     linewidth=2, markersize=10, label='RMSProp')
plt.plot(n_parameters, np.array(lbfgs_freqs) / num_exps, color=colors[2], marker='x', linestyle='dashed',
     linewidth=2, markersize=10, label='L-BFGS')

plt.yscale('log')
plt.legend()
plt.xlabel('Number of parameters')
plt.ylabel('Prob.')
plt.grid(True, "both",ls='-')
plt.savefig("prob_decay.png")
