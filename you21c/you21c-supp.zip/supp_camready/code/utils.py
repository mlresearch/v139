import torch
from torch import optim
import numpy as np

# colorblind-friendly colors
colors = ['#377eb8', '#ff7f00', '#4daf4a',
                  '#f781bf', '#a65628', '#984ea3',
                  '#999999', '#e41a1c', '#dede00']

# construction parameters
phi1 = np.pi / 2
phi2 = np.pi / 6
theta_star = 0.01 * np.pi
s = np.sin(2*theta_star)
c = np.cos(2*theta_star)

# loss function of p-parameter construction
def loss_func(theta):
    theta = (2*theta-.75)*np.pi
    out = ((2*theta).sin() - s).pow(2) * .5 + ((2*theta).cos() - c).pow(2) * 0.125
    return out.mean()

# Training
def run_pytorch_exp(n_param, device, num_epochs=100, num_exps=1000, lr=1, opt_method=optim.RMSprop, traj_flag=False):
    '''
    n_param: number of parameters in the construction;
    num_epochs: number of iteration for each trial;
    num_exps: number of trials;
    lr: initial learning rate;
    opt_method: optimizer;
    traj_flag: save the training loss at each step is set to 'True',
                and save only the loss at initialization and at convergence if set to 'False'
    '''

    # Save trajectory for each of the experiments
    trajs = []
    solutions = []
    for exp_id in range(num_exps):
        # trajectory for a single experiment
        trajectory = []
        # Uniform random initialization
        theta = torch.rand(n_param, 1, device=device, dtype=torch.float, requires_grad=True)
        # Set optimizer
        optimizer = opt_method([theta], lr=lr)

        for epoch_id in range(num_epochs):
            loss = loss_func(theta)
            if epoch_id == 0 or traj_flag == True:
                trajectory.append(loss.item()) # save the training loss to the trajectory

            def closure():
                optimizer.zero_grad()
                loss = loss_func(theta)
                loss.backward()
                return loss

            optimizer.step(closure)

        # Calculating the function value at convergence
        loss = loss_func(theta)
        trajectory.append(loss.item())

        solutions.append(theta.data)
        trajs.append(trajectory)

    return trajs, solutions
