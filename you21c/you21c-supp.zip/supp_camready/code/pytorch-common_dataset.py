#!/usr/bin/env python
# coding: utf-8

from torch_utils.model_utils import get_1layer, Encoder, OneLayerAnsatz, Energy
import numpy as np
import torch
from torch import optim
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 15})

# colorblind-friendly colors
colors = [
        '#377eb8', '#ff7f00', '#4daf4a',
        '#f781bf', '#a65628', '#984ea3',
        '#999999', '#e41a1c', '#dede00'
        ]

torch.manual_seed(666)

use_cuda = False
device = 'cpu'
if torch.cuda.is_available():
    use_cuda = True
if use_cuda:
    device = "cuda"

# generating classical, linearly separable dataset
def generate_linear_separable_data(num_samples, qnn_num_params):
    '''
    Inputs:
        num_samples: number of feature-label pairs in the dataset
        qnn_num_params: number of parameters (p) of QNN instance
    Outputs:
        x: (num_samples, 1, 2 * qnn_num_params)
        y: (num_samples,)

    '''
    x = np.random.uniform(0, 2 * np.pi, size=(num_samples, 1, 2 * qnn_num_params))
    w = np.random.randn(x.shape[-1], 1)
    y = x.reshape(num_samples, 2 * qnn_num_params) @ w
    y[y > 0] = 1.0
    y[y <= 0] = 0.0
    return x,y

def run_pytorch_exp(x, y, encoder, ansatz, energy, device, num_epochs=100, num_exps=1000, lr=1, opt_method=optim.Adam, traj_flag=False):
    '''
    x: classical feature vectors
    y: labels
    encoder: quantum encoder that encode x into quantum states
    ansatz: quantum neural network that maps input states to output states
    energy: observable/measurement on the output state
    device: cpu or gpu
    num_epochs: number of iteration for each trial;
    num_exps: number of trials;
    lr: initial learning rate;
    opt_method: optimizer;
    traj_flag: save the training loss at each step is set to 'True',
                and save only the loss at convergence if set to 'False'
    '''

    # Save trajectory for each of the experiments
    if traj_flag:
        trajs = torch.zeros(num_epochs + 1, num_exps, device=device, dtype=torch.float)
    # Uniform random initialization
    ansatz.reset_parameters(num_init=num_exps)
    if device == 'cuda':
        x,y = x.cuda(), y.cuda()
        encoder = encoder.cuda()
        ansatz = ansatz.cuda()
        energy = energy.cuda()

    # Set optimizer
    optimizer = opt_method(ansatz.parameters(), lr=lr)
    encoded_states = encoder(x).transpose(0,1).detach()
    print(encoded_states.device)
    for epoch_id in range(num_epochs):
        optimizer.zero_grad()
        #encoded_states = encoder(x).transpose(0,1)
        output_states = ansatz(encoded_states)
        pred = energy(output_states)
        loss = torch.mean((pred - y) ** 2, axis=0)
        loss.sum().backward()
        optimizer.step()

        # Calculating the function value at convergence
        if traj_flag:
            trajs[epoch_id,:] = loss.detach()
    encoded_states = encoder(x).transpose(0,1)
    output_states = ansatz(encoded_states)
    pred = energy(output_states)
    loss = torch.mean((pred - y) ** 2, axis=0)
    if traj_flag:
        trajs[-1,:] = loss.detach()
        trajs = trajs.detach().cpu().numpy().T
        final_vals = None
    else:
        trajs = None
        final_vals = loss.detach().cpu().numpy()
    return trajs, final_vals

def random_classification(num_qubits, num_samples):
    # Setting up the QNN
    parameterized_ops, observable, encoder_ops, input_state = get_1layer(num_qubits)
    encoder = Encoder(encoder_ops, 1, input_state)
    ansatz = OneLayerAnsatz(parameterized_ops, 1)
    energy = Energy(observable)

    # Setting up the Data
    x,y = generate_linear_separable_data(num_samples, num_qubits)
    x = torch.tensor(x, dtype=torch.float)
    y = torch.tensor(y, dtype=torch.float)

    print(device)
    trajs, _ = run_pytorch_exp(
            x, y, encoder, ansatz, energy, device=device,
            num_epochs=2000, num_exps=70, lr=0.01, opt_method=optim.RMSprop,
            traj_flag=True
            )
    return trajs

def plot_dist(trajs, n_param, name=None):
    plt.figure()
    _ = plt.hist(trajs[:,-1], bins=50, color=colors[n_param // 2 - 1], label='At convergence')
    plt.legend()
    plt.grid(axis='y')
    plt.xlabel('Loss function: {}-parameter'.format(n_param))
    plt.ylabel('Frequency')
    if name is None:
        plt.show()
    else:
        plt.savefig("common_dist_RMSProp_{}.png".format(n_param))


if __name__ == '__main__':

    traj_dict = {}
    num_samples = 100
    list_num_qubits = [2,4,6,8]

    for num_qubits in list_num_qubits:
        trajs = random_classification(num_qubits, num_samples=num_samples)
        traj_dict[num_qubits] = trajs
        plot_dist(traj_dict[num_qubits], num_qubits, name=True)

    range_iter = range(500, 2000)
    plt.figure()
    for idx, num_qubits in enumerate(list_num_qubits):
        trajs = traj_dict[num_qubits][:,range_iter] # num_trajs x (num_iters + 1)
        for traj in trajs:
            plt.plot(range_iter, traj, c=colors[idx], alpha=0.2)
    plt.xlabel('Num of iterations')
    plt.ylabel('Loss function')
    plt.grid()
    plt.savefig("common_curve_RMSProp.png")
