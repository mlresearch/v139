#!/usr/bin/env python
# coding: utf-8

import torch
from torch import optim, nn
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 12})

# colorblind-friendly colors
colors = ['#377eb8', '#ff7f00', '#4daf4a',
                  '#f781bf', '#a65628', '#984ea3',
                  '#999999', '#e41a1c', '#dede00']

# construction parameters
phi1 = np.pi / 2
phi2 = np.pi / 6
theta_star = 0.01 * np.pi
S = np.sin(2*theta_star)
C = np.cos(2*theta_star)
THRESH = .25

class LOSS_FUNC(nn.Module):
    def __init__(self, n_param, std):
        super(LOSS_FUNC, self).__init__()
        label_noise_s = np.random.randn(n_param, 1) * std
        label_noise_c = np.random.randn(n_param, 1) * std
        self.register_buffer('noise_s', torch.tensor(label_noise_s, dtype=torch.float))
        self.register_buffer('noise_c', torch.tensor(label_noise_c, dtype=torch.float))
    def forward(self, theta):
        theta = (2 * theta - .75) * np.pi
        out = ((2 * theta).sin() - S - self.noise_s) ** 2 * .5 +              ((2 * theta).cos() - C - self.noise_c) ** 2 * .125
        return out.mean(axis=0)


# Training
def run_pytorch_exp(loss_func, n_param, device, num_epochs=100, num_exps=1000, lr=1, opt_method=optim.RMSprop, traj_flag=False):
    '''
    loss_func: nn.Module, realization of a random loss function with noisy label
    n_param: number of parameters
    device: cpu or gpu
    num_epochs: number of iteration for each trial;
    num_exps: number of trials;
    lr: initial learning rate;
    opt_method: optimizer;
    traj_flag: save the training loss at each step is set to 'True',
                and save only the loss at convergence if set to 'False'
    '''

    # Save trajectory for each of the experiments
    if traj_flag:
        trajs = torch.zeros(num_epochs + 1, num_exps, device=device, dtype=torch.float)
    # Uniform random initialization
    theta = torch.rand(n_param, num_exps, device=device, dtype=torch.float, requires_grad=True)
    # Set optimizer
    optimizer = opt_method([theta], lr=lr)
    for epoch_id in range(num_epochs):
        optimizer.zero_grad()
        loss = loss_func(theta)
        loss.sum().backward()
        optimizer.step()

        # Calculating the function value at convergence
        if traj_flag:
            trajs[epoch_id,:] = loss.detach()
    loss = loss_func(theta)
    if traj_flag:
        trajs[-1,:] = loss.detach()
        trajs = trajs.detach().cpu().numpy().T
        final_vals = None
    else:
        trajs = None
        final_vals = loss.detach().cpu().numpy()
    return trajs, final_vals


torch.manual_seed(222)
device = torch.device('cpu')
num_epochs = 500
num_exps = 10000
lr = 0.01
opt_method=optim.RMSprop

stds = [1e-3, 5e-3, 1e-2, 5e-2,1e-1]
n_parameters = list(range(8,19))
probs = []

for std_id, std in enumerate(stds):
    freqs = []
    for idx, n_param in enumerate(n_parameters):
        loss_func = LOSS_FUNC(n_param, std=std)
        trajs, final_vals =            run_pytorch_exp(loss_func, n_param, device, num_epochs, num_exps, lr, opt_method, traj_flag=False)

        freq = np.sum(final_vals < THRESH / n_param)
        freqs.append(freq / num_exps)
    probs.append(np.array(freqs))

plt.figure()
plt.yscale('log')
for std_id, std in enumerate(stds):
    plt.plot(n_parameters, probs[std_id], color=colors[std_id + 4], marker='x', linestyle='dashed',
         linewidth=2, markersize=10, label=r'$\sigma$={:.0e}'.format(std))
plt.legend()
plt.xlabel('Num. of Parameters')
plt.ylabel('Prob.')
plt.grid(True, "both",ls='-')
plt.savefig('noisy_prob_rmsprop.png')


torch.manual_seed(777)
device = torch.device('cpu')
num_epochs = 500
num_exps = 5000
lr = 0.01
opt_method=optim.Adam

n_param = 16
std = 1e-1
loss_func = LOSS_FUNC(n_param, std=std)
trajs, final_vals =    run_pytorch_exp(loss_func, n_param, device, num_epochs, num_exps, lr, opt_method, traj_flag=True)

plt.figure()
_ = plt.hist(trajs[:,0], bins=50, color=colors[6], label='At initialization')
_ = plt.hist(trajs[:,-1], bins=50, color=colors[1], label='At convergence')
plt.legend()
plt.axvline(THRESH/n_param, color='k', linestyle='--')
plt.grid(axis='y')
plt.xlabel('Function values'.format(n_param))
plt.ylabel('Frequency')
plt.savefig("noisy_dist_rmsprop_{}.png".format(n_param))
