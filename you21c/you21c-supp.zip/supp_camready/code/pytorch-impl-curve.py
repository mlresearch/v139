# -*- coding: utf-8 -*-
import torch
from torch import optim
import numpy as np
import matplotlib.pyplot as plt

from utils import run_pytorch_exp, colors
torch.manual_seed(123)


#plot the training curve
def plot_curves(trajs, color_='b', name=None):
    plt.figure()
    trajs = np.array(trajs) # num_trajs x (num_iters + 1)
    for traj in trajs:
        plt.plot(range(len(traj)), traj, c=color_, alpha=0.2)
    plt.xlabel('Num of iterations')
    plt.ylabel('Loss function')
    plt.grid()
    plt.savefig(name+".png")

n_qubits=32
device = torch.device("cpu")

n_parameters = [2, 4, 6, 8, 10, 12, 14, 16] # size of instances
num_epochs = 100             # number of iterations for training per trial
num_exps = 100               # number of trials
lr = 0.01                    # initial learning rate

for n_param in n_parameters:
    trajs, _ = run_pytorch_exp(n_param, device, num_epochs, num_exps, \
                               lr, opt_method=optim.Adam, traj_flag=True)
    plot_curves(trajs, colors[0], name="curve_adam_{}".format(n_param))

    trajs, _ = run_pytorch_exp(n_param, device, num_epochs, num_exps, \
                               lr, opt_method=optim.RMSprop, traj_flag=True)
    plot_curves(trajs, colors[1], name="curve_rmsprop_{}".format(n_param))

    trajs, _ = run_pytorch_exp(n_param, device, num_epochs, num_exps, \
                               lr, opt_method=optim.LBFGS, traj_flag=True)
    plot_curves(trajs, colors[2], name="curve_lbfgs_{}".format(n_param))
