# -*- coding: utf-8 -*-
import torch
from torch import optim
import numpy as np
import matplotlib.pyplot as plt
import pickle

from utils import run_pytorch_exp, colors


device = torch.device("cpu")
n_parameters = list(range(8,19))
num_epochs = 200
num_exps = 5000
lr = 0.01


all_trajs_adam = []
all_trajs_rmsprop = []
all_trajs_lbfgs = []

for n_param in n_parameters:
    print("Number of Parameters: {}".format(n_param))
    trajs, _ = run_pytorch_exp(n_param, device, num_epochs, num_exps,\
                                   lr, opt_method=optim.Adam, traj_flag=False)
    all_trajs_adam.append(trajs)


    trajs, _ = run_pytorch_exp(n_param, device, num_epochs, num_exps,\
                                   lr, opt_method=optim.RMSprop, traj_flag=False)
    all_trajs_rmsprop.append(trajs)

    trajs, _ = run_pytorch_exp(n_param, device, num_epochs, num_exps,\
                                   lr, opt_method=optim.LBFGS, traj_flag=False)
    all_trajs_lbfgs.append(trajs)


with open("all_trajs_ADAM.pkl", "wb") as f:
    pickle.dump(all_trajs_adam, f)
with open("all_trajs_RMSProp.pkl", "wb") as f:
    pickle.dump(all_trajs_rmsprop, f)
with open("all_trajs_LBFGS.pkl", "wb") as f:
    pickle.dump(all_trajs_lbfgs, f)
with open("num_params.pkl", "wb") as f:
    pickle.dump(n_parameters, f)
