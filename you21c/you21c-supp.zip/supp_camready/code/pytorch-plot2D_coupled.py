import numpy as np
import torch

shift = .8
theta_star = np.array([np.pi / 50, np.pi / 50])
def loss_func(theta):
    x,y = 2 * theta[0], 2 * theta[1]
    x0,y0 = 2 * theta_star[0], 2 * theta_star[1]
    out = (np.sin(x) - np.sin(x0)) ** 2 + (np.sin(y) - np.sin(y0))** 2
    out += 1 / 16 * ((np.cos(x) - np.cos(x0))**2 + 1.5 * (np.cos(y) - np.cos(y0))**2)
    out += 1 / 8 * (np.cos(x) * np.cos(y) - np.cos(x0) * np.cos(y0))**2
    return out / (1 + 1 + 1/16 + 1.5/16 + 1/8)


grid_size = 100
XX = (np.linspace(0,1, grid_size) * 2 - shift) * np.pi
YY = (np.linspace(0,1, grid_size) * 2 - shift) * np.pi
ZZ = np.zeros((grid_size, grid_size))
for i in range(grid_size):
    for j in range(grid_size):
        ZZ[i, j] = loss_func((np.array([XX[i], YY[j]])))

XXX, YYY = np.meshgrid(XX, YY)

opt_params = theta_star

import matplotlib
import matplotlib.pyplot as plt
from matplotlib import ticker,cm
scaling_fac = 1.2
lev_exp = np.arange(np.floor(np.log10(ZZ.min()) / np.log10(scaling_fac)-1),
                   np.ceil(np.log10(ZZ.max())/np.log10(scaling_fac)+1))
levs = np.power(scaling_fac, lev_exp)

fig, ax = plt.subplots()
CS = ax.contour(XXX, YYY, ZZ, levels=30,cmap=cm.coolwarm)
cbar = fig.colorbar(CS)

ax.scatter(opt_params[0], opt_params[1], marker='*', c='black', s=15)
ax.scatter(opt_params[0]+np.pi, opt_params[1], marker='*', c='black', s=15)
ax.scatter(opt_params[0], opt_params[1]+np.pi, marker='*', c='black', s=15)
ax.scatter(opt_params[0]+np.pi, opt_params[1]+np.pi, marker='*', c='black', s=15)

ax.set_xlabel(r'$\theta_1$')
ax.set_ylabel(r'$\theta_2$')

plt.savefig("contour2d_coupled.png")
