import numpy as np
import torch
from torch import nn

_CTYPE=torch.cfloat
_RTYPE=torch.float
from torch_utils.complex_linalg_utils import cmm, cexpj, expjm, batch_expjm, expectation
from torch_utils.numpy_gate_utils import tensor, _x,_y, _z, _cnot, _cz

class Energy(nn.Module):
    def __init__(self, observable):
        super(Energy, self).__init__()
        self.register_buffer('ob', torch.tensor(observable, dtype=_CTYPE))
        vals, vecs = np.linalg.eigh(observable)
        self.optimal_value = vals[0]

    def forward(self, state):
        return expectation(state, self.ob) - self.optimal_value

class PlaceholderLoss(nn.modules.loss._Loss):
    def __init__(self, size_average=None, reduce=None, reduction: str = 'mean') -> None:
        super(PlaceholderLoss, self).__init__(size_average, reduce, reduction)
    def forward(self, input: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        if self.reduction == 'mean':
            return torch.mean(input)
        elif self.reduction == 'sum':
            return torch.sum(input)
        else:
            raise ValueError("reduction for PlaceholderLoss should be either 'mean' or 'sum'.")

class OneLayerAnsatz(nn.Module):
    '''
    Operations allow batching of M sets of parameters and N different input states:
    params: (M, num_layers, num_ops)
    input: (N, 1, dim, 1)
    output: (N, M, dim, 1)
    '''

    def __init__(self, parameterized_ops, num_layers):
        super(OneLayerAnsatz, self).__init__()
        self.num_layers = num_layers
        self.num_ops = len(parameterized_ops)

        # register parameterized ops
        for op_ind, op in enumerate(parameterized_ops):
            d, v = np.linalg.eigh(op)
            self.register_buffer('op_d'+str(op_ind), torch.tensor(d, dtype=_RTYPE))
            self.register_buffer('op_v'+str(op_ind), torch.tensor(v, dtype=_CTYPE))

        # register parameters
        self.register_parameter('params', None)


    def forward(self, state):
        for layer_ind in range(self.num_layers):
            for op_ind in range(self.num_ops):
                state = batch_expjm(state,
                        -self.params[:,layer_ind, op_ind],
                        [getattr(self, 'op_d'+str(op_ind)), getattr(self, 'op_v'+str(op_ind))]
                        )
        return state

    def reset_parameters(self, num_init=1):
        self.params = nn.Parameter(torch.Tensor(
            num_init, self.num_layers, self.num_ops))
        nn.init.uniform_(self.params, a=0, b= 2 * np.pi)

class Encoder(nn.Module):
    def __init__(self, parameterized_ops, num_layers, input_state):
        super(Encoder, self).__init__()
        self.num_layers = num_layers
        self.num_ops = len(parameterized_ops)

        for op_ind, op in enumerate(parameterized_ops):
            d, v = np.linalg.eigh(op)
            self.register_buffer('op_d'+str(op_ind), torch.tensor(d, dtype=_RTYPE))
            self.register_buffer('op_v'+str(op_ind), torch.tensor(v, dtype=_CTYPE))
        # register input state
        self.register_buffer('input', torch.tensor(input_state, dtype=_CTYPE))

    def forward(self, x):
        state = self.input
        for layer_ind in range(self.num_layers):
            for op_ind in range(self.num_ops):
                state = batch_expjm(state,
                        -x[:,layer_ind, op_ind],
                        [getattr(self, 'op_d'+str(op_ind)), getattr(self, 'op_v'+str(op_ind))]
                        )
        return state

def get_1layer(num_qubits):
    dim = 2 ** num_qubits

    parameterized_ops = []
    for l in range(num_qubits):
        local_gate = [np.eye(2)] * num_qubits
        local_gate[l] = _z
        local_gate = tensor(local_gate)
        parameterized_ops.append(local_gate)

    m = _y + np.eye(2)
    observable = tensor([m] * num_qubits)

    encoder_ops = []
    for l in range(num_qubits):
        local_gate = [np.eye(2)] * num_qubits
        local_gate[l] = _x
        local_gate = tensor(local_gate)
        encoder_ops.append(local_gate)
    for l in range(num_qubits):
        local_gate = [np.eye(2)] * num_qubits
        local_gate[l] = _y
        local_gate = tensor(local_gate)
        encoder_ops.append(local_gate)


    input_state = tensor([np.array([1.0, 0.0])] * num_qubits)
    input_state = input_state.reshape(1,1,dim,1)

    return parameterized_ops, observable, encoder_ops, input_state
