# Exponentially Many Local Minima in Quantum Neural Networks

This repository contains code for generating figures for *Exponentially Many Local Minima in Quantum Neural Networks*.

## Contents

1. Run `python pytorch-plot2D.py` to generate the visualization of the 2-dimensional landscape in Figure 8;
2. Run `python pytorch-impl-curve.py` to generate the training curves in Figure 6;
3. Run `python pytorch-impl-dist.py` to generate `.pkl` files containing the function values at initialization and at convergence; then Run `python pytorch-impl-dist-plot.py`  to generate Figure 2,3,4,7
4. Run `python pytorch-noisy_label.py` to generate Figure 9;
5. Run `pytorch-common_dataset.py` to generate Figure 5, 10.

## Dependencies

* numpy 1.18.1
* pytorch 1.3.1
* matplotlib 3.1.1 
