import numpy as np
from pyreadr import read_r
import pandas as pd
from functions import data_prep, witness, test
import matplotlib.pyplot as plt

lalonde = pd.DataFrame.to_numpy(read_r("lalonde.rds")[None])
lasubset1 = pd.DataFrame.to_numpy(read_r("lasubset1.rds")[None])
lasubset4 = pd.DataFrame.to_numpy(read_r("lasubset4.rds")[None])
Z = lalonde[:, 11]
n = len(Z)
Y = np.reshape(lalonde[:, 8], [-1, 1])
X = lalonde[:, [0, 1, 2, 3, 4, 5, 6, 7]]
lasubset1 = lasubset1[:, range(8)]
lasubset4 = lasubset4[:, range(8)]

sigma_X_t = np.array([1.0, 1.0, 0.1, 0.1, 0.1, 0.1, 100.0, 100.0])
sigma_X = np.array([50, 50, 0.1, 0.1, 0.1, 0.1, 100.0, 100.0])
sigma_Y = 5000.0
sigma_Y_t = 500.0
lamb = 0.1
lamb_t = 0.001
n_perm = 150

y_args = np.reshape(np.linspace(0, 40000, 1000), [-1, 1])

X_c, X_t, Y_c, Y_t, W_c, W_t = data_prep(X, Y, Z, sigma_X_t, lamb_t)
p_value = test(X, Y, Z, X_c, X_t, Y_c, Y_t, W_c, W_t, sigma_X_t, sigma_Y_t, n, lamb_t, n_perm)

X_c, X_t, Y_c, Y_t, W_c, W_t = data_prep(X, Y, Z, sigma_X, lamb)
wit_lasubset1 = witness(lasubset1, y_args, X_c, X_t, Y_c, Y_t, W_c, W_t, sigma_X, sigma_Y)
wit_lasubset4 = witness(lasubset4, y_args, X_c, X_t, Y_c, Y_t, W_c, W_t, sigma_X, sigma_Y)

print(p_value)

fig, axes = plt.subplots(1, 1)
axes.plot(y_args, wit_lasubset1, color="blue", label="With high school diploma (CATE=4367)")
axes.plot(y_args, wit_lasubset4, color="red", label="Without high school diploma (CATE=-120)")
axes.hlines(0, -1000, 40000, color="black")
axes.set_title("LaLonde Dataset: Witness Functions")
axes.set_xlabel("Real income in 1978, in 1982 dollars")
handles, labels = axes.get_legend_handles_labels()
axes.legend([handles[10]] + [handles[35]], [labels[10]] + [labels[35]])
plt.show()
