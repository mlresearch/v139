import numpy as np
import matplotlib.pyplot as plt
from pyreadr import read_r
import pandas as pd
from functions import kernel_matrix, data_prep, witness, var_regression, test

np.random.seed(27)

#  Load the covariate data
X = pd.DataFrame.to_numpy(read_r("x.rds")[None])
Z = np.reshape(pd.DataFrame.to_numpy(read_r("z.rds")[None]), -1)
n = len(Z)

#  Set the hyper-parameters
sigma_X_t = np.insert(10.0 * np.ones(24), 6, 0.0001)
sigma_Y_t = 10.0
lamb_t = 0.1
sigma_X_w = np.insert(50.0 * np.ones(24), 6, 0.0001)
sigma_Y_w = 1.0
lamb_w = 10
sigma_X_v = np.tile(np.insert(20.0 * np.ones(24), 6, 0.00001), 2)
lamb_v = 0.001
n_perm = 150
alpha = 0.05
n_sim = 500
n_repeat = 100
reject = np.zeros(3)
std_estimate_0 = np.zeros((n_repeat, 3, np.sum(Z)))
std_estimate_1 = np.zeros((n_repeat, 3, np.sum(Z)))
rms0 = np.zeros((n_repeat, 3))
rms1 = np.zeros((n_repeat, 3))
wit_a = np.zeros((1000, 3))
wit_b = np.zeros((1000, 3))
wit_true_a = np.zeros((1000, 3))
wit_true_b = np.zeros((1000, 3))
y_args = np.zeros((1000, 3))
coefficients = [0, 0.1, 0.2, 0.3, 0.4]

for j in range(3):
    for i in range(n_repeat):
        #  Sample random coefficients
        Beta_c = np.random.choice(coefficients, size=6, replace=True, p=[0.5, 0.125, 0.125, 0.125, 0.125])
        Beta_d = np.random.choice(coefficients, size=19, replace=True, p=[0.6, 0.1, 0.1, 0.1, 0.1])
        Beta = np.hstack((Beta_c, Beta_d))

        #  Simulate the parallel mean response surfaces
        mean0 = X @ Beta
        mean1 = X @ Beta + 4

        #  Simulate the realisations of the outcomes. There are 3 settings.
        #  If setting == 0, then the standard deviation is constant at 1.
        #  If setting == 1, then the standard deviation is constant at 20.
        #  If setting == 2, then the standard deviation is 20 for sex == 0 and 1 for sex == 1.
        setting = j
        sex = X[:, 6]
        if setting == 0:
            std = np.ones(n)
        elif setting == 1:
            std = 20 * np.ones(n)
        else:
            std = (1 - sex) * 20 + sex
        Y0 = np.random.normal(mean0, std)
        Y1 = np.random.normal(mean1, std)
        Y = np.reshape((1 - Z) * Y0 + Z * Y1, [-1, 1])

        #  Hypothesis testing
        X_c, X_t, Y_c, Y_t, W_c, W_t = data_prep(X, Y, Z, sigma_X_t, lamb_t)
        p_value = test(X, Y, Z, X_c, X_t, Y_c, Y_t, W_c, W_t, sigma_X_t, sigma_Y_t, n, lamb_t, n_perm)
        if p_value < alpha:
            reject[j] += 1 / n_repeat
        print(j, i, p_value)

        #  Conditional standard deviation using U-statistic regression
        X_c, X_t, Y_c, Y_t, W_c, W_t = data_prep(X, Y, Z, sigma_X_w, lamb_v)
        std_estimate_0[i, j, :] = np.reshape(np.sqrt(var_regression(X_t, X_c, Y_c, sigma_X_v, lamb_v)), -1)
        std_estimate_1[i, j, :] = np.reshape(np.sqrt(var_regression(X_t, X_t, Y_t, sigma_X_v, lamb_v)), -1)
        rms0[i, j] = np.sqrt(np.nanmean(np.power(std_estimate_0[i, j, :] - std[np.array(Z, dtype=bool)], 2)))
        rms1[i, j] = np.sqrt(np.nanmean(np.power(std_estimate_1[i, j, :] - std[np.array(Z, dtype=bool)], 2)))

    #  Randomly choose points a and b, from the treatment group, so that a has sex == 0 and b has sex == 1.
    a_index = np.random.choice(np.where(Z * (1 - sex))[0])
    b_index = np.random.choice(np.where(Z * sex)[0])
    a = np.reshape(X[a_index, :], [1, -1])
    b = np.reshape(X[b_index, :], [1, -1])

    #  Witness Functions
    X_c, X_t, Y_c, Y_t, W_c, W_t = data_prep(X, Y, Z, sigma_X_w, lamb_w)
    y_args[:, j] = np.linspace(np.min(Y), np.max(Y), 1000)
    wit_a[:, j] = np.reshape(witness(a, np.reshape(y_args[:, j], [-1, 1]), X_c, X_t, Y_c, Y_t, W_c, W_t, sigma_X_w,
                                     sigma_Y_w), -1)
    wit_b[:, j] = np.reshape(witness(b, np.reshape(y_args[:, j], [-1, 1]), X_c, X_t, Y_c, Y_t, W_c, W_t, sigma_X_w,
                                     sigma_Y_w), -1)
    y0_sim_a = np.reshape(np.random.normal(mean0[a_index], std[a_index], size=n_sim), [-1, 1])
    y1_sim_a = np.reshape(np.random.normal(mean1[a_index], std[a_index], size=n_sim), [-1, 1])
    wit_true_a[:, j] = np.mean(kernel_matrix(np.reshape(y_args[:, j], [-1, 1]), y1_sim_a, sigma=sigma_Y_w) -
                               kernel_matrix(np.reshape(y_args[:, j], [-1, 1]), y0_sim_a, sigma=sigma_Y_w), axis=1)
    y0_sim_b = np.reshape(np.random.normal(mean0[b_index], std[b_index], size=n_sim), [-1, 1])
    y1_sim_b = np.reshape(np.random.normal(mean1[b_index], std[b_index], size=n_sim), [-1, 1])
    wit_true_b[:, j] = np.mean(kernel_matrix(np.reshape(y_args[:, j], [-1, 1]), y1_sim_b, sigma=sigma_Y_w) -
                               kernel_matrix(np.reshape(y_args[:, j], [-1, 1]), y0_sim_b, sigma=sigma_Y_w), axis=1)

rms0_mean = np.nanmean(rms0, axis=0)
rms1_mean = np.nanmean(rms1, axis=0)
rms0_std = np.nanstd(rms0, axis=0)
rms1_std = np.nanstd(rms1, axis=0)

np.savez("ihdp_new.npz", reject=reject, y_args=y_args, wit_a=wit_a, wit_true_a=wit_true_a, wit_b=wit_b,
         wit_true_b=wit_true_b, std_estimate_0=std_estimate_0, std_estimate_1=std_estimate_1, rms0=rms0, rms1=rms1,
         rms0_mean=rms0_mean, rms1_mean=rms1_mean, rms0_std=rms0_std, rms1_std=rms1_std)

fig, axes = plt.subplots(1, 4)
axes[0].bar([r"$P_{Y_0|X}$ vs $P_{Y_0|X}$", r"$P_{Y_1|X}$ vs $P_{Y_1|X}$", r"$P_{Y_0|X}$ vs $P_{Y_1|X}$"], reject)
axes[0].set_title("Hypothesis Test")
axes[0].set_ylabel("Proportions of tests rejected")
axes[0].set_xlabel("Hypothesis")
axes[1].plot(y_args[:, 0], 100 * wit_a[:, 0], label=r"Estimated Witness at $\mathbf{a}$", color="black")
axes[1].plot(y_args[:, 0], 100 * wit_true_a[:, 0], label=r"True Witness at $\mathbf{a}$", linestyle="--", color="black")
axes[1].plot(y_args[:, 0], 100 * wit_b[:, 0], label=r"Estimated Witness at $\mathbf{b}$", color="red")
axes[1].plot(y_args[:, 0], 100 * wit_true_b[:, 0], label=r"True Witness at $\mathbf{b}$", linestyle="--", color="red")
bottom, top = axes[1].get_ylim()
axes[1].set_title("Witness Functions for Setting 0")
axes[1].legend()
axes[2].plot(y_args[:, 1], 100 * wit_a[:, 1], label=r"Estimated Witness at $\mathbf{a}$", color="black")
axes[2].plot(y_args[:, 1], 100 * wit_true_a[:, 1], label=r"True Witness at $\mathbf{a}$", linestyle="--", color="black")
axes[2].plot(y_args[:, 1], 100 * wit_b[:, 1], label=r"Estimated Witness at $\mathbf{b}$", color="red")
axes[2].plot(y_args[:, 1], 100 * wit_true_b[:, 1], label=r"True Witness at $\mathbf{b}$", linestyle="--", color="red")
axes[2].set_ylim(bottom, top)
axes[2].set_title("Witness Functions for Setting 1")
axes[2].legend()
axes[3].plot(y_args[:, 2], 100 * wit_a[:, 2], label=r"Estimated Witness at $\mathbf{a}$", color="black")
axes[3].plot(y_args[:, 2], 100 * wit_true_a[:, 2], label=r"True Witness at $\mathbf{a}$", linestyle="--", color="black")
axes[3].plot(y_args[:, 2], 100 * wit_b[:, 2], label=r"Estimated Witness at $\mathbf{b}$", color="red")
axes[3].plot(y_args[:, 2], 100 * wit_true_b[:, 2], label=r"True Witness at $\mathbf{b}$", linestyle="--", color="red")
axes[3].set_ylim(bottom, top)
axes[3].set_title("Witness Functions for Setting 2")
axes[3].legend()
plt.show()
