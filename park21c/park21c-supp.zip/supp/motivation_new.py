import numpy as np
import matplotlib.pyplot as plt
from functions import data_prep, witness, var_regression, test

np.random.seed(23)
#  Generate the data
# X = np.random.uniform(0, 1, size=n)
# where = np.random.choice(n, int(n / 2), replace=False)
# Z = np.zeros(n)
# Z[where] = 1
# Y = (Z == 0) * (5 * X + 3 + (X < threshold) * std * np.random.normal(size=n) +
#                 (X > threshold) * (std + std_slope * (X - threshold)) * np.random.normal(size=n))\
#     + (Z == 1) * (4 * X + (X < threshold) * std * np.random.normal(size=n) +
#                   (X > threshold) * (std + std_slope * (X - threshold)) * np.random.normal(size=n))
# X_c, X_t, Y_c, Y_t, W_c, W_t = data_prep(X, Y, Z, sigma_X_w, lamb)

#  Set the hyper parameters
n = 1000
std = 1
std_slope = 7
threshold = 0.3
reject = np.zeros(3)
n_perm = 150
n_test = 100
alpha = 0.05
sigma_X_w = 0.7
sigma_X_v = 0.3
sigma_X_t = 0.5
sigma_Y_w = 1.0
sigma_Y_t = 1.0
lamb_t = 0.1
lamb_w = 0.00001
lamb_v = 0.001

#  Hypothesis Testing
for q in range(3):
    for s in range(n_test):
        #  Generate the data
        where = np.random.choice(n, int(n / 2), replace=False)
        Z = np.zeros(n)
        Z[where] = 1
        X = np.reshape(np.random.uniform(0, 1, size=n), [-1, 1])
        #  If q == 0, outcome is generated from Y_0|X for both groups.
        if q == 0:
            Y = 5 * X + 4 + (X < threshold) * std * np.random.normal(size=[n, 1]) + \
                (X > threshold) * (std + std_slope * (X - threshold)) * np.random.normal(size=[n, 1])
        #  If q == 1, outcome is generated from Y_1|X for both groups.
        elif q == 1:
            Y = 4 * X + (X < threshold) * std * np.random.normal(size=[n, 1]) + \
                (X > threshold) * (std + std_slope * (X - threshold)) * np.random.normal(size=[n, 1])
        #  If q == 2, outcome is generated from Y_0|X for the control group and from Y_1|X for the treatment group.
        else:
            Y = np.reshape((Z == 0), [-1, 1]) * (5 * X + 3 + (X < threshold) * std * np.random.normal(size=[n, 1]) +
                                                 (X > threshold) * (std + std_slope * (X - threshold)) * np.random.normal(size=[n, 1]))\
                + np.reshape((Z == 1), [-1, 1]) * (4 * X + (X < threshold) * std * np.random.normal(size=[n, 1]) +
                                                   (X > threshold) * (std + std_slope * (X - threshold)) * np.random.normal(size=[n, 1]))
        X_c, X_t, Y_c, Y_t, W_c, W_t = data_prep(X, Y, Z, sigma_X_t, lamb_t)
        p_value = test(X, Y, Z, X_c, X_t, Y_c, Y_t, W_c, W_t, sigma_X_t, sigma_Y_t, n, lamb_t, n_perm, 0.5 * np.ones(n))
        if p_value < alpha:
            reject[q] += 1 / n_test
        print(q, s, p_value)

#  Conditional Witness Function
x_args = np.reshape(np.linspace(0, 1, 100), [-1, 1])
y_args = np.reshape(np.flip(np.linspace(np.min(Y), np.max(Y), 100)), [-1, 1])
X_c, X_t, Y_c, Y_t, W_c, W_t = data_prep(X, Y, Z, sigma_X_w, lamb_w)
wit = witness(x_args, y_args, X_c, X_t, Y_c, Y_t, W_c, W_t, sigma_X_w, sigma_Y_w)

#  Variance Regression
X_c, X_t, Y_c, Y_t, W_c, W_t = data_prep(X, Y, Z, sigma_X_v, lamb_v)
var_hat_0 = var_regression(x_args, X_c, Y_c, sigma_X_v, lamb_v)
var_hat_1 = var_regression(x_args, X_t, Y_t, sigma_X_v, lamb_v)

np.savez("motivation_new.npz", x_args=x_args, y_args=y_args, threshold=threshold, std=std, X_c=X_c, X_t=X_t, Y_c=Y_c,
         Y_t=Y_t, n=n, reject=reject, wit=wit, var_hat_0=var_hat_0, var_hat_1=var_hat_1, std_slope=std_slope)

fig, axes = plt.subplots(1, 4)
axes[0].scatter(X_c, Y_c, marker="o", alpha=0.7, label=r'$Y_0$')
axes[0].scatter(X_t, Y_t, marker="x", alpha=0.7, label=r'$Y_1$')
axes[0].plot(x_args, 5 * x_args + 3, color="blue", label=r"$\mathbb{E}[Y_0|X]$")
axes[0].plot(x_args, 4 * x_args, color="red", label=r"$\mathbb{E}[Y_1|X]$")
axes[0].legend()
axes[0].set_ylabel(r'$Y$')
axes[0].set_xlabel(r'$X$')
axes[0].set_title("(a) Data")
left, right = axes[0].get_ylim()
axes[1].bar([r"$P_{Y_0|X}$ vs $P_{Y_0|X}$", r"$P_{Y_1|X}$ vs $P_{Y_1|X}$", r"$P_{Y_0|X}$ vs $P_{Y_1|X}$"], reject)
axes[1].set_title("(b) Hypothesis Test")
axes[1].set_ylabel("Proportions of tests rejected")
axes[1].set_xlabel("Hypothesis")
im = axes[2].imshow(wit, cmap="inferno_r", interpolation="nearest",
                    extent=[x_args[0, 0], x_args[-1, 0], y_args[-1, 0], y_args[0, 0]], aspect="auto")
axes[2].figure.colorbar(im, ax=axes[2])
axes[2].set_title("(c) Conditional Witness Function")
axes[2].set_xlabel(r'$X$')
axes[2].set_ylabel(r'$Y$')
axes[3].plot(x_args, (x_args < threshold) * std + (x_args >= threshold) * (std + std_slope * (x_args - threshold)),
             color="black", label="True std")
axes[3].plot(x_args, np.sqrt(var_hat_0), color="red", linestyle="dotted", label=r"Estimated std$(Y_0|X)$")
axes[3].plot(x_args, np.sqrt(var_hat_1), color="blue", linestyle="--", label=r"Estimated std$(Y_1|X)$")
axes[3].set_ylim(0, right)
axes[3].set_title("(d) Conditional Standard Deviation")
axes[3].set_xlabel(r"$X$")
handles, labels = axes[3].get_legend_handles_labels()
handles = [handles[0], handles[1], handles[2]]
labels = [labels[0], labels[1], labels[2]]
axes[3].legend(handles, labels)
plt.show()
