Guideline to run the experiments:
1. Run Demo_GenData_hpc.m, to get the graph
2. Run grid_settings.m, to get the Graph, Shur_Complement in each site, and the original SC.
3. Run sparsify_settings.jl, to get the approximation quality.
4. For experiment results visualization, can refer to create*figure*.m files