# PATHS
# Source Paths
TEST_PATH = './'
TRAIN_PATH = './'
VAL_PATH = './'
SCALE_PATH = './imagedatabase/scale/'
# destination Paths
IMAGES_PATH = './imagedatabase/'
IMAGEDATABASE_EXISTS = False
TEST_SET = './'

# LABELS
EMOTION = {'1' : 'neutral', '2' : 'calm' , '3':'happy', '4':'sad', '5' :'angry',
           '6' : 'fearful', '7' : 'disgust', '8' : 'surprised'}
EMOTION_INTENSITY = {'01' : 'normal', '02' : 'strong'}

# PREPROCESSING
DIST_FRAMES = 15
OFFSET = 50
DIM = [100,100,1]

# TRAINING
BATCH = 24
lr = 0.001
DECAY = 1e-6
MOMENTUM = 0.9
PATIENCE = 50
EPOCHS = 2

# INFER
FINAL_MODEL = './trainedACT.h5'

#EXRACT INFO
INPUT_P1 = './Input-P1-0'
INPUT_P0 = './Input-P0-0'
TEST_VIDEO = './02-01-03-01-01-02-05.mp4'

