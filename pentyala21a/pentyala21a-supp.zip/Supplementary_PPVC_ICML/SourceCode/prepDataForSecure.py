

from tensorflow.keras.models import load_model
import numpy as np
import GlobalVars as G

import pathlib

import sys
import logging
import traceback
import cv2
from mtcnn import MTCNN
import numpy as np
from tensorflow.keras.models import load_model
from keras_preprocessing.image import img_to_array
from collections import Counter
import sklearn.metrics as sm
import os
import sys
from os import listdir
from os.path import isfile, join
import tensorflow as tf
import keract
import keras.backend as K



# load the model
model = load_model(G.FINAL_MODEL)
print(model.summary())


def get_parameters():
       for layer in model.layers:
            #if layer.name == 'conv2d':
                if len(layer.get_weights()) > 0:
                    weights = layer.get_weights()[0]
                    #with open('FinalWithApproxSMCVPR.txt', 'a+') as outfile:
                    with open(G.INPUT_P1, 'a+') as outfile:
                        #outfile.write('# Weights shape: {0}\n'.format(weights.shape))
                        
                        # only for 4 d array
                        if (weights.shape == 4):
                            for y in range(0,weights.shape[0]):
                                for x in range(0, weights.shape[1]):
                                    for in_c in range(0, weights.shape[2]):
                                        #for out_c in range(0, weights.shape[3]):
                                            #outfile.write('# kernel for {0}th filter for {1}th input feature map\n'.format(out_c + 1,in_c + 1))
                                            np.savetxt(outfile,weights[y,x,in_c,:], delimiter='\n',fmt='%14.13f')
                                            #outfile.write("\n")
                            #for i in range(0,weights.shape[3]):
                                #for j in range(0, weights.shape[2]):
                                    #outfile.write('# kernel for {0}th filter for {1}th input feature map\n'.format(i+1,j+1))
                                    #np.savetxt(outfile, weights[:,:,j,i], delimiter='\n', fmt='%14.13f')
                                # ht , wt, in ch, op ch
                            # eg conv: 5,5,1,32
                        # we give as (32,5,5,1)

                        else:
                            #print(weights.shape)
                            for i in range(0,weights.shape[0]):
                                    #outfile.write('# Weights for {0}th node in current layer - FC\n'.format(i+1))
                                    np.savetxt(outfile, weights[i,:],delimiter='\n', fmt='%14.13f')
                        outfile.close()

                    bias = layer.get_weights()[1]
                    with open(G.INPUT_P1, 'a+') as outfile:
                        np.savetxt(outfile, bias, delimiter='\n', fmt='%14.13f')
                    outfile.close()


def get_video_content():
    faces_to_infer = []
    faces_left = []
    detector = MTCNN()
    try:
        vid_reader = cv2.VideoCapture(G.TEST_VIDEO)
        print(vid_reader.get(cv2.CAP_PROP_FRAME_COUNT))
        #cv2.CAP_PROP
        frame_num = 0
        count = 0
        while True:
            grabbed = vid_reader.grab()
            if grabbed:
                vid_frame = vid_reader.retrieve()[1]
                vid_frame_gray = cv2.cvtColor(vid_frame, cv2.COLOR_BGR2GRAY)
                faces = detector.detect_faces(vid_frame)
                if faces is not None and len(faces) != 0:
                    if faces[0]['confidence'] > 0.98:
                        rows, cols = vid_frame_gray.shape[:2]
                        rightEyeCenter = faces[0]['keypoints']['right_eye']
                        leftEyeCenter = faces[0]['keypoints']['left_eye']
                        dY = rightEyeCenter[1] - leftEyeCenter[1]
                        dX = rightEyeCenter[0] - leftEyeCenter[0]
                        angle = np.degrees(np.arctan2(dY, dX)) - 360

                        # To align face rotate frame, and crop face and resize to 299,299
                        transform_Matrix = cv2.getRotationMatrix2D((cols / 2, rows / 2), angle, 1)
                        frame_rotated = cv2.warpAffine(vid_frame, transform_Matrix, (cols, rows))
                        if len(frame_rotated) == 0:
                            logging.warning("Rotated Frame is empty")

                        faces_rot = detector.detect_faces(frame_rotated)
                        if faces_rot is not None and len(faces_rot) != 0:
                            if faces_rot[0]['confidence'] > 0.98:
                                (x, y, w, h) = faces_rot[0]['box']
                                face_frame = cv2.resize(frame_rotated[y - 0:y + h + 0,
                                                        x - 0:x + w + 0],
                                                        (48, 48),
                                                        # (10,10),
                                                        interpolation=cv2.INTER_CUBIC)
                                face_frame = cv2.cvtColor(face_frame, cv2.COLOR_BGR2GRAY)
                                face_frame = img_to_array(face_frame)
                                if frame_num % 15 == 0:
                                    faces_to_infer.append(face_frame)
                                    count = count+1
                                else:
                                    faces_left.append(face_frame)

                                face_frame = np.array(face_frame, dtype="float32") / 255.0
                                face_frame = np.expand_dims(face_frame, axis=0)
                                #with open("ForQuant/alice/" + str(path_to_video[-24:-4]) + ".txt", 'a') as outfile:
                                with open(G.INPUT_P0, 'a') as outfile:
                                    for i in range(0, face_frame.shape[1]):
                                        for j in range(0, face_frame.shape[2]):
                                            np.savetxt(outfile, face_frame[0, i, j, :], fmt='%14.13f',
                                                       delimiter='\n')


                    else:
                        logging.warning("No face detected in " + "frame num: " + str(frame_num) + str(path_to_video))

            else:
                break
            frame_num += 1
        print("Total frames ", frame_num, count, faces_left.__len__(), faces_to_infer.__len__())
        logging.warning("Preprocessed video")
    except:
        logging.error("Exception raised in pre_process_video: " + str(sys.exc_info()[1]))
        traceback.print_exc()
    return faces_to_infer, frame_num


    get_parameters()
    get_video_content()

