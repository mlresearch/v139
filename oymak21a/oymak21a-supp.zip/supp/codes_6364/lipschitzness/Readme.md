# Lipschitzness verification for paper Generalization Guarantees for Neural Architecture Search with Train-Validation Split

## This code is used to generate Figure 1 in this paper.

To run the code, you need newest pytorch and using command

```
python train.py --epsilon [the architecture epsilon] --epoch [training epoch] --batch_size [batch size] --lr [learning rate] --model_file [if you have a initialization, in our experiment we force all the width-k model starting from the same initialization] --width [model width]
```