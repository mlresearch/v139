import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import os,sys
from numpy.lib.function_base import _rot90_dispatcher
# lr-> validation size
network_type_list=['10000_train_final_1','10000_train_final_2','10000_train_final_3','10000_train_final_4','10000_train_final_5']
result_list=[]
for network_type in network_type_list:
    input_path=f'results/{network_type}/'
    result={}
    for root,dir,file_list in os.walk(input_path):
        #print(root,dir,file_list)
        for filename in file_list:
            #print(root,dir,filename)
            if dir!=[] and filename!='config.yaml':
                lr=root.split('/')[-2]
                stage=root.split('/')[-1]
                if not lr in result:
                    result[lr]={}
                if not stage in result[lr]:
                    result[lr][stage]={}
                #print(lr,stage,filename)
                error=[]
                print(filename)
                with open(root+'/'+filename, 'r') as f:
                    for line in f:
                        eles=line.split(' ')
                        epoch=int(eles[0].split('/')[0])
                        while epoch-1>=len(error):
                            error.append(0.)
                        error[epoch-1]=(float(eles[1]))
                    while 49>=len(error):
                        error.append(0.)
                    #print(error)
                result[lr][stage][filename.split('.')[0]]=error
    result_list.append(result)

result=result_list[0]

for lr in result:
    for stage in result[lr]:
        for type in result[lr][stage]:
            result[lr][stage][type]=np.array(result[lr][stage][type])/len(result_list)

for curr_result in result_list[1:]:
    for lr in curr_result:
        #print(curr_result[lr])
        for stage in curr_result[lr]:
            for type in curr_result[lr][stage]:
                result[lr][stage][type]+=np.array(curr_result[lr][stage][type])/len(result_list)
                #print(curr_result[lr][stage][type]/len(result_list))
#print(result)
output_path=f'results/figures/'
if not os.path.exists(output_path):
    os.makedirs(output_path,exist_ok=True)


plt.cla()
legend=[]

lr_list=[]
for lr in result:
    if lr not in lr_list:
        lr_list.append(int(lr))
lr_list=np.sort(lr_list)
int_lr_list=lr_list
lr_list=[str(x) for x in lr_list]
print(lr_list)
#print(result)

color=['tab:blue','tab:brown','tab:orange','tab:pink','tab:green','tab:gray','tab:red','tab:purple','tab:cyan','tab:olive']
legend=[]
epoch_list=[9,19,29,39,49]
for epoch in epoch_list:
    legend.append(f'Epoch: {epoch+1}')
    line=np.zeros((len(network_type_list),len(lr_list)-1))
    for network_type in network_type_list:
        i=network_type_list.index(network_type)
        print(i)
        for lr in lr_list[:-1]:
            j=lr_list.index(lr)
            print(j)
            line[i,j]=result_list[i][lr]['search']['test_log'][epoch]-result_list[i][lr]['search']['val_log'][epoch]
            #line.append(result[lr]['search']['test_log'][epoch]-result[lr]['search']['val_log'][epoch])
    mean=np.mean(line,axis=0)
    std=np.std(line,axis=0)/np.sqrt(len(result_list))
    plt.errorbar(int_lr_list[:-1],mean,linestyle='-',linewidth=3,color=color[epoch_list.index(epoch)],yerr=std,elinewidth=1,capsize=3)
plt.xscale('log')
plt.xticks(int_lr_list[:-1],fontsize=15)
plt.yticks(fontsize=15)

plt.legend(legend,fontsize=15)
plt.grid('--')
plt.xscale('log')
ax1=plt.axes()
ax1.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
plt.savefig(f'{output_path}/test_val.pdf')


lr_list=[]
for lr in result:
    if lr not in lr_list:
        lr_list.append(int(lr))
lr_list=np.sort(lr_list)
lr_list=[str(x) for x in lr_list]
lr_list=lr_list[:-1]

plt.cla()
legend=[]
color=['tab:blue','tab:brown','tab:orange','tab:pink','tab:green','tab:gray','tab:red','tab:purple','tab:cyan','tab:olive']
for stage in result[lr]:
    for state in ['test','val','train']:

       
        
        for lr in lr_list:
            line=[]
            for network_type in network_type_list:
                
                i=network_type_list.index(network_type)
                print(result_list[i][lr][stage][f'{state}_log'])
                line.append(result_list[i][lr][stage][f'{state}_log'])
            mean=np.mean(line,axis=0)
            std=np.std(line,axis=0)/np.sqrt(len(result_list))
            print(line)
            if state=='val':
                plt.plot(mean,linestyle='--',color=color[lr_list.index(lr)])
                legend.append(f'Val size: {lr}')
            elif state=='test':
                plt.plot(mean,linestyle='-',color=color[lr_list.index(lr)])
                #legend.append(lr+' test')
            elif state=='train':
                plt.plot(mean,linestyle=(0,(1,5)),color=color[lr_list.index(lr)])
                #legend.append(lr+' train')
        
        #plt.title(f'{stage} {state} error')
        if stage=='eval' and state=='train':
            plt.ylim((0,15))
            #plt.xlim((0,300))
            #plt.yscale('log')
        if stage=='eval' and state=='test':
            plt.ylim((20,40))
            #plt.xlim((0,300))
            #plt.yscale('log')

plt.legend(legend,fontsize=14, ncol=2)
plt.xticks(fontsize=17)
plt.yticks(fontsize=17)
#plt.ylim(bottom=0)
plt.grid('--')

plt.savefig(f'{output_path}/val_test.pdf')
        

# #print(result)     
