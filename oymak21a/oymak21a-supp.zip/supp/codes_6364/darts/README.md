# This code is modified from the paper [Are Labels Necessary for Neural Architecture Search?](https://arxiv.org/abs/2003.12056) where they have distributed DARTS training codes



In addition to installing PyTorch with CUDA support, run:

```
pip install -r requirements.txt
export PYTHONPATH=.
```

Then please follow [`DATA.md`](docs/DATA.md) to set up the datasets.

All experiments need at least 2 Nvidia GTX2080Ti, if you are using GPUs with smaller memory, the provided configs may result in out-of-memory error. 


The script folder has all the scripts for 5 runs experiments, and Visualization_paper generates Figure 2 in the paper after running all scripts in scripts folder.

