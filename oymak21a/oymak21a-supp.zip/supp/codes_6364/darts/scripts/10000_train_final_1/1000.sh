#!/bin/bash -l
#SBATCH --nodes=1
#SBATCH --cpus-per-task=6
#SBATCH --mem=16G
#SBATCH --time=12:0:0
#SBATCH --partition=gpu
#SBATCH --gres=gpu:2
#SBATCH --job-name=1000_10000_train_final_1
#SBATCH --output=results/10000_train_final_1/1000//logs/search.txt
#SBATCH --exclude=node01,node03,node08,node09,node10
source ~/.bashrc
conda activate pytorch
export PYTHONPATH=.
python tools/train_net.py --cfg configs/search_phase/10000_train_final_1//1000.yaml OUT_DIR results/10000_train_final_1/1000/search/ TRAIN.WEIGHTS scripts/model_init.pyth OPTIM.ARCH_INTERVAL 1