#!/bin/bash -l
#SBATCH --nodes=1
#SBATCH --cpus-per-task=6
#SBATCH --mem=16G
#SBATCH --time=12:0:0
#SBATCH --partition=gpu
#SBATCH --gres=gpu:2
#SBATCH --job-name=500_10000_train_final_5
#SBATCH --output=results/10000_train_final_5/500//logs/search.txt
#SBATCH --exclude=node02,node03,node04
source ~/.bashrc
conda activate pytorch
export PYTHONPATH=.
python tools/train_net.py --cfg configs/search_phase/10000_train_final_5//500.yaml OUT_DIR results/10000_train_final_5/500/search/ TRAIN.WEIGHTS scripts/model_init.pyth OPTIM.ARCH_INTERVAL 1