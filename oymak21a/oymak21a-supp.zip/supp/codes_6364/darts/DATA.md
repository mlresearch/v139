# Setting Up Data Paths

Expected datasets structure for CIFAR-10:

```
cifar10
|_ data_batch_1
|_ data_batch_2
|_ data_batch_3
|_ data_batch_4
|_ data_batch_5
|_ test_batch
|_ ...
```

Symlink CIFAR-10:

```
ln -s /path/cifar10 /path/unnas/pycls/datasets/data/cifar10
```
