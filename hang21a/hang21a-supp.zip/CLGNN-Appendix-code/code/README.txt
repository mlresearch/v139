Implementation of Collective Learning-GNN in PyTorch

Requirements:

    PyTorch 1.2.0
    Python 3.6

Usage:

    for unlabeled test data: python train_unlabeled.py -h
    for partially-labeled test data: python train_labeled.py -h

A full list of parameters is shown in help message.

e.g. for testing GCN and CL-GCN on unlabeled and partially-labeled data::
python train_unlabeled.py --model_choice gcn_rand --dataset cora
python train_labeled.py --model_choice gcn_rand --dataset cora



