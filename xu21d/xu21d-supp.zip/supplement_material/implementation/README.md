# Rethinking Neural vs. Matrix-Factorization Collaborative Filtering - the Theoretical Perspectives

### Preparation
We have put the `ml-100k.zip` downloaded from [grouplens](https://grouplens.org/datasets/movielens/100k/) under the 
`data` folder. All the `python` scripts should be ran under the `code` folder.

```bash
# Recommend use anaconda or vritualenv before installing
pip install -r requirements.txt

mkdir -p logs 
mkdir -p results
cd code

python preprocess.py $MIN_CNT # set it according to experiment setting, to decide if to remove infrequenty items

python transductive_preprocess.py # generate the training, validation and testing positive user-item interaction data
```

### Transductive settings

```bash
python transductive_train.py # experiments for Figure 3

python nuc_svm_vs_MF.py # experiments for Figure 2

python kernel_vs_CF.py # experiments for Figure 1

```

### Inductive settings

```bash
# Train the relevance and explosure models
python inductive_fit.py

# Populate and cache the model's output for every use-item pair
python inductive_weight.py

# Run the inductive experiments on semi-synthetic data
python inductive_exp.py
```

#### Notes
1. Results for inductive CF taks are saved under `results/metrics` with names like `simulation_v{version_number}.csv`
2. Results for transductive CF tasks, including the tasks in Section 3 and 4, are saved under ./log with the file name indicating the type of experiment and the timestamp.
3. It takes realtively long time to run the inductive experiments because of repeated runs.
4. It takes extremely long time to run the transductive experiments and the experiments in Section 3 and 4, because it can take several thousand epochs to converge, and the nuclear-norm max-margin problem as well as the kernel SVM can take a long time to solve.


