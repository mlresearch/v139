import numpy as np
import argparse
import os 
import logging

import tensorflow as tf 
from tensorflow import keras
from tensorflow.keras import layers
from models import MF_model, Neural_model
from datetime import datetime
import pandas as pd
from tensorflow.data import Dataset
from tensorflow.keras.callbacks import History 
from ranking_eval import transductive_eval



def exp_loss(y_true, y_pred):
    y_true = tf.cast(y_true, y_pred.dtype)    
    tol_loss = tf.exp(-1. * y_true * y_pred)
    return tf.reduce_mean(tol_loss)


def log_loss(y_true, y_pred):
    y_true = tf.cast(y_true, y_pred.dtype)
    tol_loss = tf.math.log(1 + tf.exp(-1. * y_true * y_pred))
#     tol_loss = tf.math.log(1 + tf.exp(-tf.multiply(y_true, y_pred)))
    return tf.reduce_mean(tol_loss)



def create_data(df):
    feat_data = Dataset.from_tensor_slices((df.user.values, df.item.values))
    label_data = Dataset.from_tensor_slices(df.label.values)
    return Dataset.zip((feat_data, label_data)).batch(512).shuffle(10)


def get_dat(purposes = ["train", "validation"]):
    
    options = set(["train", "validation", "test"])
    assert len(set(purposes).intersection(options)) == len(purposes)
    
    info = open("../data/all_positive_dat.txt", "r").readlines()
    info = info[0].strip().split(",")
    num_user, num_item = int(info[0]), int(info[1])
    
    names = ['user', 'item', 'label']
    dtypes = {'user': 'int', 'item': 'int', 'label': 'int'}
    tr_df = pd.read_csv('../data/transductive_train.txt',
                        header=None,
                        sep='\t',
                        names=names,
                        dtype=dtypes)
    val_df = pd.read_csv('../data/transductive_val.txt',
                        header=None,
                        sep='\t',
                        names=names,
                        dtype=dtypes)
    te_df = pd.read_csv('../data/transductive_test.txt',
                        header=None,
                        sep='\t',
                        names=names,
                        dtype=dtypes)

    if "test" in purposes:
        return (num_user, num_item, tr_df, val_df, te_df)
    else:
        return (num_user, num_item, tr_df, val_df)

        


def MF_train(latent_dim, epochs, lr, log_dir, 
             every_epoch = 20, 
             top_K = 20, 
             loss = "log_loss", 
             n_thread = 1, **kwargs):
        
    num_user, num_item, tr_df, val_df = get_dat(["train", "validation"])
    
    tr_data, val_data = create_data(tr_df), create_data(val_df)
    
    mf_model = MF_model(num_user, num_item, latent_dim, **kwargs)
    
    if loss == "log_loss":
        mf_model.compile(optimizer=keras.optimizers.SGD(lr), loss=log_loss)
    else:
        mf_model.compile(optimizer=keras.optimizers.SGD(lr), loss=exp_loss)
        
    
    history = History()
    user_emb_fro_list, item_emb_fro_list, pred_mat_nuc_list = [], [], []
    train_loss_list, val_loss_list = [], []
    hr_list, ndcg_list, auc_list = [], [], []
    margin_list = []
    
    for epoch in range(epochs):
        history = mf_model.fit(tr_data, epochs=1, validation_data=val_data, verbose=0)
        
        trn_loss, val_loss = history.history['loss'][0], history.history['val_loss'][0]
    
        tmp_user_emb = mf_model.layers[2].get_weights()[0]
        tmp_item_emb = mf_model.layers[3].get_weights()[0]
        tmp_score_mat = np.matmul(tmp_user_emb, tmp_item_emb.T)

        user_emb_fro = np.linalg.norm(tmp_user_emb, "fro")
        item_emb_fro = np.linalg.norm(tmp_item_emb, "fro")
        pred_mat_nuc = np.linalg.norm(tmp_score_mat, "nuc")
        
        tr_pred = mf_model([np.array(tr_df.user.values), np.array(tr_df.item.values)]).numpy().flatten()
        tr_acc = np.sum((tr_pred >= 0).flatten() == (tr_df.label.values > 0)) / len(tr_pred)
        
        val_pred = mf_model([np.array(val_df.user.values), np.array(val_df.item.values)]).numpy().flatten()
        val_acc = np.sum((val_pred >= 0).flatten() == (val_df.label.values > 0)) / len(val_pred)
        
        logging.info("trn_loss:{}, val_loss:{}, trn_acc:{}, val_acc:{}, u_emb_fro:{}, i_emb_fro:{}, p_mat_nuc:{}".format(
            trn_loss, val_loss, tr_acc, val_acc, user_emb_fro, item_emb_fro, pred_mat_nuc))
        
        if epoch % every_epoch == 0 or epoch == (every_epoch-1):
            hr, ndcg, auc = transductive_eval(mf_model, top_K, n_thread, eval_on = "validation")
            logging.info("ranking@{} hr:{}, ndcg:{}, auc:{}".format(top_K, hr, ndcg, auc))
            tr_margin = tr_pred * tr_df.label.values
            hr_list.append(hr)
            ndcg_list.append(ndcg)
            auc_list.append(auc)
            margin_list.append(tr_margin)
            
        user_emb_fro_list.append(user_emb_fro)
        item_emb_fro_list.append(item_emb_fro)
        pred_mat_nuc_list.append(pred_mat_nuc)
        train_loss_list.append(trn_loss)
        val_loss_list.append(val_loss)
      
    common_metric_df = pd.DataFrame({"trn_loss":train_loss_list, "val_loss":val_loss_list, "u_emb_fro":user_emb_fro_list, "i_emb_fro":item_emb_fro_list, "p_mat_nuc":pred_mat_nuc_list})
    rank_metric_df = pd.DataFrame({"HR":hr_list, "NDCG":ndcg_list, "AUC":auc_list})
    margin_arr = np.array(margin_list)
    
    mf_model.save_weights(log_dir + "MCF_model")
    
    return (common_metric_df, rank_metric_df, margin_arr)



def NCF_train(latent_dim, hidden_dims, epochs, lr, log_dir, 
              combine = "concat",
              every_epoch = 20, 
              top_K = 20, 
              loss = "log_loss", 
              n_thread = 1, **kwargs):
        
    num_user, num_item, tr_df, val_df = get_dat(["train", "validation"])
    
    tr_data, val_data = create_data(tr_df), create_data(val_df)
    
    ncf_model = Neural_model(num_user, num_item, latent_dim, hidden_dims, combine, **kwargs)
    
    if loss == "log_loss":
        ncf_model.compile(optimizer=keras.optimizers.SGD(lr), loss=log_loss)
    else:
        ncf_model.compile(optimizer=keras.optimizers.SGD(lr), loss=exp_loss)
        
    
    history = History()
    user_emb_fro_list, item_emb_fro_list, dense_fro_list = [], [], []
    train_loss_list, val_loss_list = [], []
    hr_list, ndcg_list, auc_list = [], [], []
    margin_list = []
    
    for epoch in range(epochs):
        history = ncf_model.fit(tr_data, epochs=1, validation_data=val_data, verbose=0)
        
        trn_loss, val_loss = history.history['loss'][0], history.history['val_loss'][0]
    
        tmp_user_emb = ncf_model.layers[2].get_weights()[0]
        tmp_item_emb = ncf_model.layers[3].get_weights()[0]
        dense_weights, dense_fro = [], []
        for i in range(5, len(ncf_model.layers)):
            dense_weights.append(ncf_model.layers[i].get_weights()[0])
        

        user_emb_fro = np.linalg.norm(tmp_user_emb, "fro")
        item_emb_fro = np.linalg.norm(tmp_item_emb, "fro")
        for w in dense_weights:
            dense_fro.append(np.linalg.norm(w, "fro"))
        
        tr_pred = ncf_model([np.array(tr_df.user.values), np.array(tr_df.item.values)]).numpy().flatten()
        tr_acc = np.sum((tr_pred >= 0).flatten() == (tr_df.label.values > 0)) / len(tr_pred)
        
        val_pred = ncf_model([np.array(val_df.user.values), np.array(val_df.item.values)]).numpy().flatten()
        val_acc = np.sum((val_pred >= 0).flatten() == (val_df.label.values > 0)) / len(val_pred)
        
        logging.info("trn_loss:{}, val_loss:{}, trn_acc:{}, val_acc:{}, u_emb_fro:{}, i_emb_fro:{}, dense_fro:{}".format(
            trn_loss, val_loss, tr_acc, val_acc, user_emb_fro, item_emb_fro, dense_fro))
        
        if epoch % every_epoch == 0 or epoch == (every_epoch-1):
            hr, ndcg, auc = transductive_eval(ncf_model, top_K, n_thread, eval_on = "validation")
            logging.info("ranking@{} hr:{}, ndcg:{}, auc:{}".format(top_K, hr, ndcg, auc))
            tr_margin = tr_pred * tr_df.label.values
            hr_list.append(hr)
            ndcg_list.append(ndcg)
            auc_list.append(auc)
            margin_list.append(tr_margin)
            
        user_emb_fro_list.append(user_emb_fro)
        item_emb_fro_list.append(item_emb_fro)
        dense_fro_list.append(dense_fro)
        train_loss_list.append(trn_loss)
        val_loss_list.append(val_loss)
      
    common_metric_df = pd.DataFrame({"trn_loss":train_loss_list, "val_loss":val_loss_list, "u_emb_fro":user_emb_fro_list, "i_emb_fro":item_emb_fro_list, "dense_fro":dense_fro_list})
    rank_metric_df = pd.DataFrame({"HR":hr_list, "NDCG":ndcg_list, "AUC":auc_list})
    margin_arr = np.array(margin_list)
    
    ncf_model.save_weights(log_dir + "NCF_model")
    
    return (common_metric_df, rank_metric_df, margin_arr)
    
    
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, default="MCF", choices=["MCF", "NCF"])
    parser.add_argument("--latent_dim", type=int, default=32)
    parser.add_argument("--hidden_dims", nargs="+", type=int, default=[16])
    parser.add_argument("--epochs", type=int, default=1000)
    parser.add_argument("--lr", type=float, default=0.1)
    parser.add_argument("--top_K", type=int, default=20)
    parser.add_argument("--n_thread", type=int, default=1)
    parser.add_argument("--epoch_every", type=int, default=20)
    parser.add_argument("--init_scale", type=float, default=1.)
    parser.add_argument("--emb_regs", nargs="+", type=float, default=[0.,0.])
    parser.add_argument("--ffn_reg", type=float, default=0.)
    parser.add_argument("--combine", type=str, default="concat", choices=["concat", "add"])
    parser.add_argument("--GPU", type=int, default=1)
    
    args = parser.parse_args()
    log_dir = '../logs/transductive-' + datetime.now().strftime("%Y%m%d-%H%M%S") + '-' + args.model + "/"
    os.system("mkdir " + log_dir)
    
    logging.basicConfig(filename=log_dir + 'train.log', level=logging.DEBUG)
    if args.model == "MCF":
        logging.info("latent_dim:{}, epochs:{}, lr:{}, top_K:{}, epoch_every:{}, init_scale:{}, emb_reg:{}".format(
            args.latent_dim, args.epochs, args.lr, args.top_K, args.epoch_every, args.init_scale, args.emb_regs))
    else:
        logging.info("latent_dim:{}, FFN_dims:{}, combine:{}, epochs:{}, lr:{}, top_K:{}, epoch_every:{}, init_scale:{}, emb_reg:{}, ffn_reg:{}".format(
            args.latent_dim, args.hidden_dims, args.combine, args.epochs, args.lr, args.top_K, args.epoch_every, args.init_scale, args.emb_regs, args.ffn_reg))
    
    gpus = tf.config.experimental.list_physical_devices('GPU')
    if gpus:
        try:
            tf.config.experimental.set_memory_growth(gpus[args.GPU], True)
            tf.config.experimental.set_visible_devices(gpus[args.GPU], 'GPU')
            logical_gpus = tf.config.experimental.list_logical_devices('GPU')
#             print(len(gpus), "Physical GPUs,", len(logical_gpus), "Logical GPU")
        except RuntimeError as e:
            print(e)
        
    if args.model == "MCF":
        common_metric_df, rank_metric_df, margin_arr = MF_train(args.latent_dim, args.epochs, args.lr, log_dir, args.epoch_every, args.top_K, emb_init_scale=args.init_scale, regs=args.emb_regs)
    if args.model == "NCF":
        common_metric_df, rank_metric_df, margin_arr = NCF_train(args.latent_dim, args.hidden_dims, args.epochs, args.lr, log_dir, args.combine, args.epoch_every, args.top_K, emb_init_scale=args.init_scale, emb_regs=args.emb_regs, FFN_reg=args.ffn_reg)
        
    common_metric_df.to_csv(log_dir+"common_metric.csv", sep = "\t")
    rank_metric_df.to_csv(log_dir+"ranking_metric_"+str(args.top_K)+".csv", sep = "\t")
    np.save(log_dir+"margin_every_" + str(args.epoch_every) + ".npy", margin_arr)
    
        