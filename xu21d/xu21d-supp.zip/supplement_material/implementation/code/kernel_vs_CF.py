import cvxpy as cvx
import numpy as np
import time
import pandas as pd
import random
import matplotlib.pyplot as plt
import os

import argparse
import os
import logging
from datetime import datetime

from sklearn.kernel_ridge import KernelRidge
from sklearn.svm import SVC

from ranking_eval import transductive_eval

from models import MF_model, Neural_model, min_nuc_svm, kernel_svm
from utils import log_loss, generate_sample_dat

import tensorflow as tf
from tensorflow import keras
from tensorflow.data import Dataset
from tensorflow.keras import layers
from tensorflow.keras.callbacks import History


def create_dat(dat):
    dat = np.array(dat)
    feat_data = Dataset.from_tensor_slices((dat[:,0], dat[:,1]))
    label_data = Dataset.from_tensor_slices(dat[:,2])
    return Dataset.zip((feat_data, label_data)).batch(512).shuffle(10)


def compute_acc(model, dat):
    pred = model([np.array(dat)[:,0], np.array(dat)[:,1]]).numpy().flatten()
    acc = np.sum((pred >= 0).flatten() == (np.array(dat)[:,2] > 0)) / len(pred)
    return acc


def main(n_user, n_item, dir_loc,
         size_list = [4000, 5000, 6000, 7000],
         latent_dim = 16,
         hidden_dims = [8],
         epochs = 3000,
         lr = 0.1,
         top_K = 10,
         n_thread = 1,
         emb_init_scale = 0.5):

    n_user, n_item, train_dat_f, val_dat_f, dat_file = generate_sample_dat(n_item_sample = n_item, n_user_sample = n_user)
    assert size_list[-1] < len(train_dat_f)
    random.shuffle(train_dat_f)

    K_res_list, MF_res_list, NCF_add_res_list, NCF_concat_res_list = [], [], [], []

    # experiment with multiple types of kernel, incuding the impact on K_CF from different initializations
    kernel_list = [[0.3183, 0.6591, 0.6591, 0.7268],
                   [0.3183, 0.3878, 0.3878, 1],
                   [0.3183, 0.7756, 0.7756, 1],
                   [0, 0.6591-0.3183, 0.6591-0.3183, 0.7268-0.3183],
                   [0, 0.7756-0.3183, 0.7756-0.3183, 1-0.3183],
                   [0, 1, 1, 2],
                   [0, 1, 0.5, 1.5],
                   [0, 1, 0.75, 1.75],
                   [0, 1, 1.25, 2.25],
                   [0, 1, 1.5, 2.5]]

    for size in size_list:

        for kernel in kernel_list:
            kernel_CF = kernel_svm(n_user, n_item, train_dat_f[:size], method = "svm", kernel_vals = kernel, reg=5)
            kernel_CF.fit()
            val_accu = kernel_CF.eval_accu(val_dat_f)
            trn_accu = kernel_CF.eval_accu(train_dat_f[:size])
            hr, ndcg, auc = transductive_eval(kernel_CF, 10, 1, "test", dat_file)
            K_res = [trn_accu, val_accu, hr, ndcg, auc]
            K_res_list.append(K_res)


        tr_data, val_data = create_dat(train_dat_f[:size]), create_dat(val_dat_f)

        mf_model = MF_model(n_user, n_item, latent_dim, emb_init_scale)
        mf_model.compile(optimizer=keras.optimizers.SGD(lr), loss=log_loss)
        mf_model.fit(tr_data, epochs=epochs, validation_data=val_data, verbose=0)
        tr_acc = compute_acc(mf_model, train_dat_f[:size])
        val_acc = compute_acc(mf_model, val_dat_f)
        hr, ndcg, auc = transductive_eval(mf_model, top_K, n_thread, "test", dat_file)
        MF_res_list.append([tr_acc, val_acc, hr, ndcg, auc])


        ncf_add_model = Neural_model(n_user, n_item, latent_dim, hidden_dims,
                         method="add",
                         emb_init_scale=emb_init_scale)
        ncf_add_model.compile(optimizer=keras.optimizers.SGD(lr), loss=log_loss)
        ncf_add_model.fit(tr_data, epochs=epochs, validation_data=val_data, verbose=0)
        tr_acc = compute_acc(ncf_add_model, train_dat_f[:size])
        val_acc = compute_acc(ncf_add_model, val_dat_f)
        hr, ndcg, auc = transductive_eval(ncf_add_model, top_K, n_thread, "test", dat_file)
        NCF_add_res_list.append([tr_acc, val_acc, hr, ndcg, auc])


        ncf_concat_model = Neural_model(n_user, n_item, latent_dim, hidden_dims,
                         method="add",
                         emb_init_scale=emb_init_scale)
        ncf_concat_model.compile(optimizer=keras.optimizers.SGD(lr), loss=log_loss)
        ncf_concat_model.fit(tr_data, epochs=epochs, validation_data=val_data, verbose=0)
        tr_acc = compute_acc(ncf_concat_model, train_dat_f[:size])
        val_acc = compute_acc(ncf_concat_model, val_dat_f)
        hr, ndcg, auc = transductive_eval(ncf_concat_model, top_K, n_thread, "test", dat_file)
        NCF_concat_res_list.append([tr_acc, val_acc, hr, ndcg, auc])

    np.save(dir_loc + "kernel_list.npy", np.array(kernel_list))
    np.save(dir_loc + "kernel_res.npy", np.array(K_res_list))
    np.save(dir_loc + "MF_res.npy", np.array(MF_res_list))
    np.save(dir_loc + "NCF_add_res.npy", np.array(NCF_add_res_list))
    np.save(dir_loc + "NCF_concat_res.npy", np.array(NCF_concat_res_list))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_user", type=int, default=50)
    parser.add_argument("--n_item", type=int, default=200)
    parser.add_argument("--latent_dim", type=int, default=16)
    parser.add_argument("--hidden_dims", nargs="+", type=int, default=[8])
    parser.add_argument("--size_list", nargs="+", type=int, default=[4000,5000,6000,7000])
    parser.add_argument("--epochs", type=int, default=3000)
    parser.add_argument("--init_scale", type=float, default=0.5)
    parser.add_argument("--lr", type=float, default=0.1)
    parser.add_argument("--top_K", type=int, default=10)
    parser.add_argument("--n_thread", type=int, default=1)
    parser.add_argument("--GPU", type=int, default=0)

    args = parser.parse_args()
    log_dir = '../logs/kernel_vs_CF-' + datetime.now().strftime("%Y%m%d-%H%M%S") + "/"
    os.system("mkdir " + log_dir)

    logging.basicConfig(filename=log_dir + 'train.log', level=logging.DEBUG)
    logging.info("n_user:{}, n_item:{}, latent_dim:{}, hidden_dims:{}, size_list:{}, epochs:{}, lr:{}, top_K:{}, init_scale:{}".format(
        args.n_user, args.n_item, args.latent_dim, args.hidden_dims, args.size_list, args.epochs, args.lr, args.top_K, args.init_scale))


    gpus = tf.config.experimental.list_physical_devices('GPU')
    if gpus:
        try:
            tf.config.experimental.set_memory_growth(gpus[args.GPU], True)
            tf.config.experimental.set_visible_devices(gpus[args.GPU], 'GPU')
            logical_gpus = tf.config.experimental.list_logical_devices('GPU')
#             print(len(gpus), "Physical GPUs,", len(logical_gpus), "Logical GPU")
        except RuntimeError as e:
            print(e)

    main(args.n_user, args.n_item, log_dir, args.size_list,
         args.latent_dim,
         args.hidden_dims,
         args.epochs,
         args.lr,
         args.top_K,
         args.n_thread,
         args.init_scale)
