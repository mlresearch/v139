import cvxpy as cvx
import numpy as np
import tensorflow as tf
from sklearn.kernel_ridge import KernelRidge
from sklearn.svm import SVC
from tensorflow import keras
from tensorflow.keras import layers

from utils import mat_unit_norm


def MF_model(num_users, num_items, latent_dim,
             intercept=False,
             regs=(0, 0),
             emb_init_scale=1):

    user_input = keras.Input(shape=(1,), dtype='int32', name='user_input')
    item_input = keras.Input(shape=(1,), dtype='int32', name='item_input')

    U_intercept = layers.Embedding(input_dim=num_users, output_dim=1, name='user_intercept',
                                   embeddings_initializer=keras.initializers.Zeros(),
                                   embeddings_regularizer=tf.keras.regularizers.l2(l=regs[0]), input_length=1,
                                   trainable=intercept)

    I_intercept = layers.Embedding(input_dim=num_items, output_dim=1, name='item_intercept',
                                   embeddings_initializer=keras.initializers.Zeros(),
                                   embeddings_regularizer=tf.keras.regularizers.l2(l=regs[1]), input_length=1,
                                   trainable=intercept)

    U_Embedding = layers.Embedding(input_dim=num_users, output_dim=latent_dim, name='user_embedding',
                                   embeddings_initializer=keras.initializers.RandomNormal(stddev=emb_init_scale),
                                   embeddings_regularizer=tf.keras.regularizers.l2(l=regs[0]), input_length=1,
                                   trainable=True)

    I_Embedding = layers.Embedding(input_dim=num_items, output_dim=latent_dim, name='item_embedding',
                                   embeddings_initializer=keras.initializers.RandomNormal(stddev=emb_init_scale),
                                   embeddings_regularizer=tf.keras.regularizers.l2(l=regs[1]), input_length=1,
                                   trainable=True)

    U_latent, U_intercept = U_Embedding(user_input), tf.squeeze(U_intercept(user_input), axis=-1)
    I_latent, I_intercept = I_Embedding(item_input), tf.squeeze(I_intercept(item_input), axis=-1)

    dot_prod = tf.reduce_sum(tf.multiply(U_latent, I_latent), axis=-1)
    intercept = tf.add(U_intercept, I_intercept)

    score = tf.add(dot_prod, intercept)

    model = keras.Model(inputs=[user_input, item_input],
                        outputs=score, name="MCF")

    return model


def MF_modelV2(num_users, num_items, latent_dim,
             intercept=False,
             regs=(0, 0),
             emb_init_scale=1):
    user_input = keras.Input(shape=(1,), dtype='int32', name='user_input')
    item_input = keras.Input(shape=(1,), dtype='int32', name='item_input')

    U_intercept = layers.Embedding(input_dim=num_users, output_dim=1, name='user_intercept',
                                   embeddings_initializer=keras.initializers.Zeros(),
                                   embeddings_regularizer=tf.keras.regularizers.l2(l=regs[0]), input_length=1,
                                   trainable=intercept)

    I_intercept = layers.Embedding(input_dim=num_items, output_dim=1, name='item_intercept',
                                   embeddings_initializer=keras.initializers.Zeros(),
                                   embeddings_regularizer=tf.keras.regularizers.l2(l=regs[1]), input_length=1,
                                   trainable=intercept)

    U_Embedding = layers.Embedding(input_dim=num_users, output_dim=latent_dim, name='user_embedding',
                                   embeddings_initializer=keras.initializers.GlorotNormal(),
                                   embeddings_regularizer=tf.keras.regularizers.l2(l=regs[0]), input_length=1,
                                   trainable=True)

    I_Embedding = layers.Embedding(input_dim=num_items, output_dim=latent_dim, name='item_embedding',
                                   embeddings_initializer=keras.initializers.GlorotNormal(),
                                   embeddings_regularizer=tf.keras.regularizers.l2(l=regs[1]), input_length=1,
                                   trainable=True)

    U_latent, U_intercept = U_Embedding(user_input), tf.squeeze(U_intercept(user_input), axis=-1)
    I_latent, I_intercept = I_Embedding(item_input), tf.squeeze(I_intercept(item_input), axis=-1)

    dot_prod = tf.reduce_sum(tf.multiply(U_latent, I_latent), axis=-1)
    intercept = tf.add(U_intercept, I_intercept)

    score = tf.add(dot_prod, intercept)

    model = keras.Model(inputs=[user_input, item_input],
                        outputs=score, name="MCF")

    return model


def Neural_model(num_users, num_items, latent_dim, FFN_dim,
                 method="concat",
                 emb_regs=(0, 0),
                 FFN_reg=0,
                 emb_init_scale=1.,
                 emb_initializer=None,
                 FFN_initializer=None):
    if type(FFN_dim) is not list:
        raise ValueError("FFN_dim must be list.")

    assert method in ["add", "concat"]

    user_input = keras.Input(shape=(1,), dtype='int32', name='user_input')
    item_input = keras.Input(shape=(1,), dtype='int32', name='item_input')

    U_Embedding = layers.Embedding(input_dim=num_users, output_dim=latent_dim, name='user_embedding',
                                   embeddings_initializer=keras.initializers.RandomNormal(stddev=emb_init_scale),
                                   embeddings_regularizer=tf.keras.regularizers.l2(l=emb_regs[0]), input_length=1, trainable=True)

    I_Embedding = layers.Embedding(input_dim=num_items, output_dim=latent_dim, name='item_embedding',
                                   embeddings_initializer=keras.initializers.RandomNormal(stddev=emb_init_scale),
                                   embeddings_regularizer=tf.keras.regularizers.l2(l=emb_regs[1]), input_length=1, trainable=True)

    U_latent, I_latent = U_Embedding(user_input), I_Embedding(item_input)

    if method == "add":
        latent = tf.add(U_latent, I_latent)
    else:
        latent = tf.concat([U_latent, I_latent], axis=-1)

    for layer_id, dim in enumerate(FFN_dim):
        latent = layers.Dense(dim, use_bias=False, activation="relu",
                              kernel_regularizer=tf.keras.regularizers.l2(l=FFN_reg),
                              name="FFN_layer_" + str(layer_id))(latent)

    score = layers.Dense(1, use_bias=False, activation=None,
                         kernel_regularizer=tf.keras.regularizers.l2(l=FFN_reg),
                         name="FFN_layer_" + str(len(FFN_dim)))(latent)

    model = keras.Model(inputs=[user_input, item_input],
                        outputs=score, name="NCF")

    return model


class min_nuc_svm:
    def __init__(self, num_user, num_item, train_dat):

        X = cvx.Variable(shape=[num_user, num_item])
        objective = cvx.Minimize(cvx.norm(X, 'nuc'))
        constraints = []
        for ob in train_dat:
            constraints.append(ob[-1] * X[ob[0],ob[1]] >= 1)

        problem = cvx.Problem(objective, constraints)
        problem.solve(verbose=False)
        self.val = problem.value
        self.mat = np.array(X.value)


    def predict(self, user_item, verbose):
        res = []
        user, item = user_item[0], user_item[1]
        for i in range(len(user)):
            res.append(self.mat[user[i], item[i]])
        return np.array(res)

    def eval_accu(self, eval_dat):
        res = np.zeros(len(eval_dat))
        for i,dat in enumerate(eval_dat):
            if dat[-1] * self.mat[dat[0], dat[1]] >= 0:
                res[i] = 1
        return np.mean(res)

    def get_nuc_val(self):
        return self.val

    def get_normalized_margin(self, dat):
        X = self.mat / self.val
        res = [X[i,j] * l for i,j,l in dat]
        return res



class kernel_svm:
    def __init__(self, n_user, n_item, train_dat, method = "svm", kernel_vals = [0., 1., 1., 2.], reg=1e-3):
        assert len(kernel_vals) == 4
        assert method in ["svm", "reg"]

        self.y = [int(dat[-1]>0) for dat in train_dat]
        self.n_user = n_user
        self.n_item = n_item

        self.pred = None
        self.accu = 0
        self.train_dat = train_dat
        self.kernel_vals = kernel_vals
        self.method = method
        self.K = np.zeros((len(train_dat), len(train_dat))) + self.kernel_vals[0]

        self._construct()
        if method == "svm":
            self.model = SVC(C=reg, kernel="precomputed")
        else:
            self.model = KernelRidge(alpha=reg, kernel="precomputed")


    def _construct(self):
        for i,dat1 in enumerate(self.train_dat):
            for j,dat2 in enumerate(self.train_dat):
                if i >= j:
                    continue
                self.K[i,j] = self.kernel_vals[1] * int(dat1[0] == dat2[0]) + self.kernel_vals[2] * int(dat1[1] == dat2[1])
        self.K += self.K.T
        self.K += np.eye(len(self.train_dat)) * self.kernel_vals[3]

    def predict(self, user_item, verbose):
        res = []
        user, item = user_item[0], user_item[1]
        for i in range(len(user)):
            res.append(self.pred[user[i], item[i]])
        return np.array(res)


    def eval_accu(self, eval_dat):
        res = np.zeros(len(eval_dat))
        for i,dat in enumerate(eval_dat):
            if dat[-1] * self.pred[dat[0], dat[1]] >= 0:
                res[i] = 1
        return np.mean(res)


    def fit(self):
        self.model.fit(self.K, self.y)
        self._predict_all()

    def _predict_all(self):
        all_dat = [[u, i] for u in range(self.n_user) for i in range(self.n_item)]
        pred_K = np.zeros((len(all_dat), len(self.train_dat))) + self.kernel_vals[0]
        for i,dat1 in enumerate(all_dat):
            for j,dat2 in enumerate(self.train_dat):
                if dat1[0] == dat2[0] and dat1[1] != dat2[1]:
                    pred_K[i,j] = self.kernel_vals[1]
                if dat1[0] != dat2[0] and dat1[1] == dat2[1]:
                    pred_K[i,j] = self.kernel_vals[2]
                if dat1[0] == dat2[0] and dat1[1] == dat2[1]:
                    pred_K[i,j] = self.kernel_vals[3]

        if self.method == "svm":
            pred = self.model.decision_function(pred_K)
        else:
            pred = self.model.predict(pred_K)

        self.pred = np.array(pred).reshape((self.n_user, self.n_item))
        if self.method == "reg":
            self.pred -= 0.5


    def _predict(self, eval_dat, compute_accu = True):
        pred_K = np.zeros((len(eval_dat), len(self.train_dat))) + self.kernel_vals[0]
        new_y = np.array([int(dat[2] > 0) for dat in eval_dat])
        for i,dat1 in enumerate(eval_dat):
            for j,dat2 in enumerate(self.train_dat):
                if dat1[0] == dat2[0] and dat1[1] != dat2[1]:
                    pred_K[i,j] = self.kernel_vals[1]
                if dat1[0] != dat2[0] and dat1[1] == dat2[1]:
                    pred_K[i,j] = self.kernel_vals[2]
                if dat1[0] == dat2[0] and dat1[1] == dat2[1]:
                    pred_K[i,j] = self.kernel_vals[3]

        self.pred = self.model.predict(pred_K)
        if compute_accu:
            if self.method == "svm":
                self.accu = np.sum(self.pred == new_y) / len(new_y)
            else:
                self.accu = np.sum((self.pred >= 0.5) == new_y) / len(new_y)

    def _eval_accu(self):
        return self.accu
