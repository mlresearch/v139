import os
from datetime import datetime

import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from tensorflow.data import Dataset

from models import Neural_model, MF_modelV2

ML100_PATH = '../data/ml-100k'

def create_data(df):
    feat_data = Dataset.from_tensor_slices((df.user.values, df.item.values))
    label_data = Dataset.from_tensor_slices(df.label.values)
    return Dataset.zip((feat_data, label_data)).batch(512).shuffle(10)

#eval_data = create_data(te_df)

def translate_to_prob(logit_model):
    prob_out = tf.nn.sigmoid(logit_model.output)
    return keras.Model(inputs=logit_model.inputs, outputs=prob_out)

def expo_train(model: keras.Model, tr_data: Dataset, val_data: Dataset, postfix='', save=False):
    model_name = model.name
    model = translate_to_prob(model)
    logdir = '../logs/inductive-expo/' + datetime.now().strftime("%Y%m%d-%H%M%S") + '-' + model.name + postfix
    filepath = f'../results/inductive-expo-{model_name}' + postfix
    callback = [keras.callbacks.EarlyStopping(
    monitor='val_loss', min_delta=0, patience=3, verbose=0,
    mode='auto', baseline=None, restore_best_weights=False
    )]
    if save:
      callback.extend([
        keras.callbacks.TensorBoard(log_dir=logdir),
        tf.keras.callbacks.ModelCheckpoint(
            filepath, monitor='val_loss', verbose=0, save_best_only=True,
        )])

    model.compile(optimizer=keras.optimizers.Adam(learning_rate=0.001),
              loss=keras.losses.BinaryCrossentropy(from_logits=False),
              metrics=['accuracy', 'AUC'])

    model.fit(tr_data, epochs=100, validation_data=val_data, callbacks=callback, verbose=0)
    print(model.evaluate(val_data, verbose=0))

def rel_train(model: keras.Model, tr_data: Dataset, val_data: Dataset, postfix='', save=False):
    logdir = '../logs/inductive-rel/' + datetime.now().strftime("%Y%m%d-%H%M%S") + '-' + model.name + postfix
    filepath = f'../results/inductive-rel-{model.name}' + postfix
    callback = [keras.callbacks.EarlyStopping(
    monitor='val_loss', min_delta=0, patience=3, verbose=0,
    mode='auto', baseline=None, restore_best_weights=False
    )]
    if save:
      callback.extend([
        keras.callbacks.TensorBoard(log_dir=logdir),
        tf.keras.callbacks.ModelCheckpoint(
            filepath, monitor='val_loss', verbose=0, save_best_only=True,
        )])
    model.compile(optimizer=keras.optimizers.Adam(learning_rate=0.001),
              loss='mse',
              metrics=['mse'])
    model.fit(tr_data, epochs=100, validation_data=val_data, callbacks=callback, verbose=0)
    print(model.evaluate(val_data, verbose=0))

def main():
    names = ['user', 'item', 'label', 'ts']
    dtype = {'user': int, 'item': int, 'label': float, 'ts': float}

    rel_tr_df = pd.read_csv(os.path.join(ML100_PATH, 'u1.base'), sep='\t', names=names, dtype=dtype, header=None)
    rel_tr_df.user -= 1
    rel_tr_df.item -= 1
    rel_te_df = pd.read_csv(os.path.join(ML100_PATH, 'u1.test'), sep='\t', names=names, dtype=dtype, header=None)
    rel_te_df.user -= 1
    rel_te_df.item -= 1

    info = open("../data/all_positive_dat.txt", "r").readlines()
    info = info[0].strip().split(",")
    num_user, num_item = int(info[0]), int(info[1])

    names = ['user', 'item', 'label']
    dtypes = {'user': 'int', 'item': 'int', 'int': 'int'}
    tr_df = pd.read_csv('../data/transductive_train.txt',
                        header=None,
                        sep='\t',
                        names=names,
                        dtype=dtypes)
    val_df = pd.read_csv('../data/transductive_val.txt',
                         header=None,
                         sep='\t',
                         names=names,
                         dtype=dtypes)

    rel_tr_data = create_data(rel_tr_df)
    rel_val_data = create_data(rel_te_df)

    tr_data = create_data(tr_df)
    val_data = create_data(val_df)

    print('Training models')
    mf_model = MF_modelV2(num_user, num_item, 32, regs=(0, 0))
    expo_train(mf_model, tr_data, val_data)

    ncf_model = Neural_model(num_user, num_item, 32, [8])
    expo_train(ncf_model, tr_data, val_data)

    rel_mf_model = MF_modelV2(num_user, num_item, 32, regs=(0, 0))
    rel_train(rel_mf_model, rel_tr_data, rel_val_data)

    rel_ncf_model = Neural_model(num_user, num_item, 32, [8])
    rel_train(rel_ncf_model, rel_tr_data, rel_val_data)

    print('Creating exposure weight')
    def create_and_cache(model, name):
        mat = np.zeros((num_user, num_item))
        for uid in range(num_user):
            iids = np.arange(num_item)
            uids = np.zeros(num_item) + uid
            mat[uid, :] = model.predict((uids, iids)).flatten()
        np.save(f'../results/cache/{name}.npy', mat)

    if not os.path.isdir('../results/cache'):
        os.mkdir('../results/cache')
    create_and_cache(rel_mf_model, 'rel_mf_mat')
    create_and_cache(rel_ncf_model, 'rel_ncf_mat')
    create_and_cache(mf_model, 'expo_mf_mat')
    create_and_cache(ncf_model, 'expo_ncf_mat')


if __name__ == '__main__':
    main()

