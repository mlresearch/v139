import cvxpy as cvx
import numpy as np
import time
import pandas as pd
import random
import matplotlib.pyplot as plt
import os

import argparse
import os 
import logging
from datetime import datetime

from sklearn.kernel_ridge import KernelRidge
from sklearn.svm import SVC

from ranking_eval import transductive_eval

from models import MF_model, Neural_model, min_nuc_svm, kernel_svm
from utils import log_loss, generate_sample_dat

import tensorflow as tf 
from tensorflow import keras
from tensorflow.data import Dataset
from tensorflow.keras import layers
from tensorflow.keras.callbacks import History 



def create_dat(dat):
    dat = np.array(dat)
    feat_data = Dataset.from_tensor_slices((dat[:,0], dat[:,1]))
    label_data = Dataset.from_tensor_slices(dat[:,2])
    return Dataset.zip((feat_data, label_data)).batch(512).shuffle(10)


def main(n_user, n_item, dir_loc,
         size_list = [4000, 5000, 6000, 7000], 
         latent_dim = 16,
         epochs = 3000,
         every_epoch = 10,
         lr = 0.1,
         top_K = 10,
         n_thread = 1,
         emb_init_scale = 0.5):

    n_user, n_item, train_dat_f, val_dat_f, dat_file = generate_sample_dat(n_item_sample = n_item, n_user_sample = n_user)
    assert size_list[-1] < len(train_dat_f)
    random.shuffle(train_dat_f)
    
    optimal_nuc_list, MF_nuc_list = [], []
    nuc_accu_list, nuc_trn_accu_list, nuc_hr_list, nuc_ndcg_list, nuc_auc_list, nuc_margin_list = [], [], [], [], [], []
    MF_accu_list, MF_accu_trn_list, MF_hr_list, MF_ndcg_list, MF_auc_list, MF_margin_list, MF_trnloss_list, MF_valloss_list = [], [], [], [], [], [], [], []

    for size in size_list:

        min_nuc_CF = min_nuc_svm(n_user, n_item, train_dat_f[:size])
        hr, ndcg, auc = transductive_eval(min_nuc_CF, top_K, n_thread, "test", dat_file)
        
        nuc_accu_list.append(min_nuc_CF.eval_accu(val_dat_f))
        nuc_trn_accu_list.append(min_nuc_CF.eval_accu(train_dat_f[:size]))
        nuc_hr_list.append(hr)
        nuc_ndcg_list.append(ndcg)
        nuc_auc_list.append(auc)
        optimal_nuc_list.append(min_nuc_CF.get_nuc_val())
        nuc_margin_list.append(min_nuc_CF.get_normalized_margin(train_dat_f[:size]))


        mf_model = MF_model(n_user, n_item, latent_dim, emb_init_scale=emb_init_scale)
        tr_data, val_data = create_dat(train_dat_f[:size]), create_dat(val_dat_f)

        mf_model.compile(optimizer=keras.optimizers.SGD(lr), loss=log_loss)

        history = History()
        pred_mat_nuc_list = []
        train_loss_list, val_loss_list = [], []
        mf_margin_list, mf_hr_list, mf_ndcg_list, mf_auc_list, mf_acc_list, mf_acc_trn_list = [], [], [], [], [], []

        for epoch in range(epochs):
            history = mf_model.fit(tr_data, epochs=1, validation_data=val_data, verbose=0)

            trn_loss, val_loss = history.history['loss'][0], history.history['val_loss'][0]

            tmp_user_emb = mf_model.layers[2].get_weights()[0]
            tmp_item_emb = mf_model.layers[3].get_weights()[0]
            tmp_score_mat = np.matmul(tmp_user_emb, tmp_item_emb.T)
            pred_mat_nuc = np.linalg.norm(tmp_score_mat, "nuc")

            tr_pred = mf_model([np.array(train_dat_f[:size])[:,0], np.array(train_dat_f[:size])[:,1]]).numpy().flatten()
            tr_acc = np.sum((tr_pred >= 0).flatten() == (np.array(train_dat_f[:size])[:,2] > 0)) / len(tr_pred)

            val_pred = mf_model([np.array(val_dat_f)[:,0], np.array(val_dat_f)[:,1]]).numpy().flatten()
            val_acc = np.sum((val_pred >= 0).flatten() == (np.array(val_dat_f)[:,2] > 0)) / len(val_pred)

            if epoch % every_epoch == 0 or epoch == (every_epoch-1):
                margin = tr_pred * np.array(train_dat_f[:size])[:,2]
                hr, ndcg, auc = transductive_eval(mf_model, top_K, n_thread, "test", dat_file)
                mf_margin_list.append(margin)
                mf_hr_list.append(hr)
                mf_ndcg_list.append(ndcg)
                mf_auc_list.append(auc)
                pred_mat_nuc_list.append(pred_mat_nuc)
                train_loss_list.append(trn_loss)
                val_loss_list.append(val_loss)
                mf_acc_list.append(val_acc)
                mf_acc_trn_list.append(tr_acc)
                
        MF_nuc_list.append(pred_mat_nuc_list)    
        MF_accu_list.append(mf_acc_list)
        MF_accu_trn_list.append(mf_acc_trn_list)
        MF_hr_list.append(mf_hr_list)
        MF_ndcg_list.append(mf_ndcg_list)
        MF_auc_list.append(mf_auc_list)
        MF_margin_list.append(mf_margin_list)
        MF_trnloss_list.append(train_loss_list)
        MF_valloss_list.append(val_loss_list)
        
    np.save(dir_loc + "MF_nuc.npy", np.array(MF_nuc_list))
    np.save(dir_loc + "MF_val_accu.npy", np.array(MF_accu_list))
    np.save(dir_loc + "MF_trn_accu.npy", np.array(MF_accu_trn_list))
    np.save(dir_loc + "MF_hr.npy", np.array(MF_hr_list))
    np.save(dir_loc + "MF_ndcg.npy", np.array(MF_ndcg_list))
    np.save(dir_loc + "MF_auc.npy", np.array(MF_auc_list))
    np.save(dir_loc + "MF_margin.npy", np.array(MF_margin_list))
    np.save(dir_loc + "MF_trnloss.npy", np.array(MF_trnloss_list))
    np.save(dir_loc + "MF_valloss.npy", np.array(MF_valloss_list))
    
    np.save(dir_loc + "nuc_val.npy", np.array(optimal_nuc_list))
    np.save(dir_loc + "nuc_val_accu.npy", np.array(nuc_accu_list))
    np.save(dir_loc + "nuc_trn_accu.npy", np.array(nuc_trn_accu_list))
    np.save(dir_loc + "nuc_hr.npy", np.array(nuc_hr_list))
    np.save(dir_loc + "nuc_ndcg.npy", np.array(nuc_ndcg_list))
    np.save(dir_loc + "nuc_auc.npy", np.array(nuc_auc_list))
    np.save(dir_loc + "nuc_margin.npy", np.array(nuc_margin_list))
    
    
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_user", type=int, default=50)
    parser.add_argument("--n_item", type=int, default=200)
    parser.add_argument("--latent_dim", type=int, default=16)
    parser.add_argument("--size_list", nargs="+", type=int, default=[4000,5000,6000,7000])
    parser.add_argument("--epochs", type=int, default=3000)
    parser.add_argument("--init_scale", type=float, default=0.5)
    parser.add_argument("--lr", type=float, default=0.1)
    parser.add_argument("--top_K", type=int, default=10)
    parser.add_argument("--n_thread", type=int, default=1)
    parser.add_argument("--epoch_every", type=int, default=10)
    parser.add_argument("--GPU", type=int, default=0)
    
    args = parser.parse_args()
    log_dir = '../logs/nuc_svm_vs_MF-' + datetime.now().strftime("%Y%m%d-%H%M%S") + "/"
    os.system("mkdir " + log_dir)
    
    logging.basicConfig(filename=log_dir + 'train.log', level=logging.DEBUG)
    logging.info("n_user:{}, n_item:{}, latent_dim:{}, size_list:{}, epochs:{}, epoch_every:{}, lr:{}, top_K:{}, init_scale:{}".format(
        args.n_user, args.n_item, args.latent_dim, args.size_list, args.epochs, args.epoch_every, args.lr, args.top_K, args.init_scale))
    
    
    gpus = tf.config.experimental.list_physical_devices('GPU')
    if gpus:
        try:
            tf.config.experimental.set_memory_growth(gpus[args.GPU], True)
            tf.config.experimental.set_visible_devices(gpus[args.GPU], 'GPU')
            logical_gpus = tf.config.experimental.list_logical_devices('GPU')
#             print(len(gpus), "Physical GPUs,", len(logical_gpus), "Logical GPU")
        except RuntimeError as e:
            print(e)
            
    main(args.n_user, args.n_item, log_dir, args.size_list, 
         args.latent_dim,
         args.epochs,
         args.epoch_every,
         args.lr,
         args.top_K,
         args.n_thread,
         args.init_scale)
