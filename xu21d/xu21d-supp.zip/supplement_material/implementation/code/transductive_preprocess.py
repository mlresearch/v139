import argparse
import random

import numpy as np


def construct_small_dat(n_user_sample, n_item_sample, dat_file, write_file_prefix):

    f = open(dat_file, "r").readlines()
    n_user, n_item = int(f[0].strip().split(",")[0]), int(f[0].strip().split(",")[1])
    user_item_dict = {}
    item_pop_dict = {}
    for dat in f[1:]:
        dat = dat.strip().split("\t")
        for item in dat[1:]:
            try:
                item_pop_dict[item] += 1
            except KeyError:
                item_pop_dict[item] = 1
        user_item_dict[dat[0]] = set(dat[1:])
        
    unnor_p = np.array(list(item_pop_dict.values()))
    items_selected = set(np.random.choice(list(item_pop_dict.keys()), n_item_sample, replace=False, p=unnor_p/np.sum(unnor_p)))
#     items_selected = set([k for k, v in sorted(item_pop_dict.items(), key=lambda item: item[1])][-n_item_sample:])

    user_item_score = {}
    for user in list(user_item_dict.keys()):
        score = len(items_selected.intersection(set(user_item_dict[user])))
        if score > 0:
            user_item_score[user] = score 
            
    if len(user_item_score) <= n_user_sample:
        users_selected = set(list(user_item_score.keys()))
    else:
#         users_selected = set([k for k, v in sorted(user_item_score.items(), key=lambda item: item[1])][-n_user_sample:])
        unnor_p = np.array(list(user_item_score.values()))
        users_selected = set(np.random.choice(list(user_item_score.keys()), n_user_sample, replace = False, p=unnor_p/np.sum(unnor_p)))
        
    uid_2_index = dict(zip(list(users_selected), list(range(len(users_selected)))))
    iid_2_index = dict(zip(list(items_selected), list(range(len(items_selected)))))
    
    write_file = write_file_prefix + str(len(users_selected)) + "_" + str(len(items_selected)) + ".txt"
    with open(write_file, "w") as f1:
        _ = f1.writelines(str(len(users_selected)) + "," + str(len(items_selected)) + "\n")
        for dat in f[1:]:
            dat = dat.strip().split("\t")
            if not dat[0] in users_selected:
                continue
            iids = list(map(str, [iid_2_index[item] for item in dat[1:] if item in items_selected]))
            _ = f1.writelines(str(uid_2_index[dat[0]]) + "\t" + "\t".join(iids) + "\n")
        
        
        
        

def main(N_NEG, dat_file):

    f = open(dat_file, "r").readlines()
    n_user, n_item = int(f[0].strip().split(",")[0]), int(f[0].strip().split(",")[1])

    all_items = set(list(map(str, list(range(n_item)))))

    with open("../data/transductive_train.txt", "w") as f1, \
    open("../data/transductive_val.txt", "w") as f2, \
    open("../data/transductive_test.txt", "w") as f3:
#         user_item_info = str(n_user) + "," + str(n_item) + "\n"
#         _ = f1.writelines(user_item_info)
#         _ = f2.writelines(user_item_info)
#         _ = f3.writelines(user_item_info)
        for dat in f[1:]:
            dat = dat.strip().split("\t")
            n_interaction = len(dat)-1
            uid, train_dat, val_dat, test_dat = dat[0], dat[1:-2], dat[-2], dat[-1]
            all_neg = list(all_items.difference(set(dat[1:])))
            sampled_neg = np.random.choice(list(all_neg), min(n_interaction * N_NEG, len(all_neg)), replace = False)
            train_dat_f = []
            for item in train_dat:
                train_dat_f.append(uid + "\t" + item + "\t" + "1" + "\n")
            for item in sampled_neg[:(-2 * N_NEG)]:
                train_dat_f.append(uid + "\t" + item + "\t" + "-1" + "\n")

            random.shuffle(train_dat_f)
            for d_line in train_dat_f:
                _ = f1.writelines(d_line)

            _ = f2.writelines(uid + "\t" + val_dat + "\t" + "1" + "\n")
            for item in sampled_neg[(-2 * N_NEG): (-1 * N_NEG)]:
                _ = f2.writelines(uid + "\t" + item + "\t" + "-1" + "\n")

            _ = f3.writelines(uid + "\t" + test_dat + "\t" + "1" + "\n")
            for item in sampled_neg[(-1 * N_NEG):]:
                _ = f3.writelines(uid + "\t" + item + "\t" + "-1" + "\n")

            
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", type=str, default="generate_label", choices=["generate_label", "downsample"])
    parser.add_argument("--n_neg", type=int, default=3)
    parser.add_argument("--dat_file", type=str, default="../data/all_positive_dat.txt")
    parser.add_argument("--sample_file_prefix", type=str, default="../data/sampled_positive_")
    parser.add_argument("--n_item_sample", type=int, default=200)
    parser.add_argument("--n_user_sample", type=int, default=50)
    
    args = parser.parse_args()
    
    if args.task == "generate_label":
#         random.seed(23333)
#         np.random.seed(23333)

        main(args.n_neg, args.dat_file)
    else:
        construct_small_dat(args.n_user_sample, args.n_item_sample, args.dat_file, args.sample_file_prefix)
    
    print("done")
    