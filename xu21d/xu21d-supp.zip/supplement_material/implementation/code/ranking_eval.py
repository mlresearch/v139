import multiprocessing
import numpy as np
import multiprocessing

import numpy as np


# from tqdm import tqdm

# _model = None 
# _user_list = None
# _pos_list = None 
# _neg_list = None
# _K = None

def transductive_eval(model, K, n_thread, eval_on = "validation",
                      all_positive_dat_file = "../data/all_positive_dat.txt"):
    global _model 
    global _user_list
    global _pos_list 
    global _neg_list 
    global _K 
    
    f = open(all_positive_dat_file, "r").readlines()
    n_items = int(f[0].split(",")[0])
    item_set = set(list(range(n_items)))
    
    user_list, pos_list, neg_list = [], [], []
    for line in f[1:]:
        line = list(map(int, line.strip().split("\t")))
        user_list.append(line[0])
        if eval_on == "test":
            pos_list.append(line[-1])
            user_hist = set(line[1:])
        else:
            pos_list.append(line[-2])
            user_hist = set(line[1:-1])
        neg_list.append(list(item_set.difference(user_hist)))

    _model = model
    _user_list = user_list
    _pos_list = pos_list
    _neg_list = neg_list
    _K = K
    
    HR, NDCG, AUC = [], [], []
    if n_thread > 1:
        pool = multiprocessing.Pool(processes = n_thread)
        res = pool.map(single_eval, _user_list)
        pool.close()
        pool.join()
        
        HR = [r[0] for r in res]
        NDCG = [r[1] for r in res]
        AUC = [r[2] for r in res]
        
        return (np.mean(HR), np.mean(NDCG), np.mean(AUC))
    
    for uid in _user_list:
        (hr, ndcg, auc) = single_eval(uid)
        HR.append(hr)
        NDCG.append(ndcg)
        AUC.append(auc)
    
    return (np.mean(HR), np.mean(NDCG), np.mean(AUC))
    
    
def single_eval(uid):
    pos = _pos_list[uid]
    negs = _neg_list[uid]
    all_items = negs + [pos] 
    map_item_score = {}
    users = np.full(len(all_items), uid, dtype = 'int32')
    predictions = _model.predict([users, np.array(all_items)], verbose=0)
    
    predictions = predictions.flatten()

    reco = [x[0] for x in sorted(list(zip(all_items, predictions)), key=lambda x:x[1])][::-1]
    
    HR = hit_rate(pos, reco[:_K])
    NDCG = normalized_dcg(pos, reco[:_K])
    AUC = area_under_curve(pos, reco)
    
    return (HR, NDCG, AUC)
    
    
def hit_rate(target, reco_list):
    return int(target in reco_list)


def normalized_dcg(target, reco_list):
    for pos, item in enumerate(reco_list):
        if item == target:
            return np.log(2) / np.log(pos+2)
       
    return 0

def area_under_curve(target, reco_list):
    for ind, item in enumerate(reco_list):
        if item == target:
            return (len(reco_list)-ind-1) * 1.0 / (len(reco_list)-1)
      
        
    