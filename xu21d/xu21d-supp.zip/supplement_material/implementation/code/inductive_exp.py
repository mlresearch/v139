# %%

import os

import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from tqdm import tqdm

from models import MF_modelV2, Neural_model

# %%
info = open("../data/all_positive_dat.txt", "r").readlines()
info = info[0].strip().split(",")
num_user, num_item = int(info[0]), int(info[1])

expo_ncf_mat = np.load('../results/cache/expo_ncf_mat.npy')
expo_mf_mat = np.load('../results/cache/expo_mf_mat.npy')
rel_mf_mat = np.load('../results/cache/rel_mf_mat.npy')
rel_ncf_mat = np.load('../results/cache/rel_ncf_mat.npy')

np.random.seed(12345)
tf.random.set_seed(12345)


# %%
def create_data(df):
    feat_data = tf.data.Dataset.from_tensor_slices((df.user.values, df.item.values))
    label_data = tf.data.Dataset.from_tensor_slices(df.label.values)
    return tf.data.Dataset.zip((feat_data, label_data)).batch(512).shuffle(10)


def rel_train(model: keras.Model, tr_data: tf.data.Dataset, val_data: tf.data.Dataset, postfix='', save=True):
    callback = [keras.callbacks.EarlyStopping(
        monitor='val_loss', min_delta=0, patience=3, verbose=0,
        mode='auto', baseline=None, restore_best_weights=False
    )]
    model.compile(optimizer=keras.optimizers.Adam(learning_rate=0.001),
                  loss='mse',
                  metrics=['mse'])
    model.fit(tr_data, epochs=100, validation_data=val_data, callbacks=callback)


def sigomid(x):
    return np.exp(x) / (1 + np.exp(x))


def create_sample_data(expo, rel, default_expo_prob=0.06, num_pair=100, beta=0.5, squash=3, mu=3, p=2):
    candidate = np.arange(num_item)
    out = []
    for u in range(num_user):
        model_expo_prob = sigomid(expo[u, :])
        assert (model_expo_prob.min() >= 0 and model_expo_prob.max() <= 1)

        model_expo_ind = np.random.random(num_item) <= model_expo_prob
        default_expo_ind = np.random.random(num_item) <= default_expo_prob
        mix_ind = np.random.random(num_item) <= beta
        expo_ind = np.zeros(num_item).astype(np.int)
        expo_ind[mix_ind > 0] = model_expo_ind[mix_ind > 0]
        expo_ind[mix_ind <= 0] = default_expo_ind[mix_ind <= 0]
        # The true exposure probability is a mixture between model and the default
        true_expo_prob = beta * model_expo_prob + (1 - beta) * default_expo_prob
        assert (true_expo_prob.min() >= 0 and true_expo_prob.max() <= 1)
        true_expo_weight = 1 / true_expo_prob

        click_score = rel[u, :]
        click_prob = sigomid((click_score - mu)) ** p
        rel_ind = np.random.random() <= click_prob
        click_ind = rel_ind * expo_ind
        pos_item = np.argwhere(click_ind > 0)
        neg_item = np.argwhere((click_ind <= 0) & (expo_ind > 0))
        # assert(num_neg * len(pos_item) < len(neg_item))
        np.random.shuffle(pos_item)
        np.random.shuffle(neg_item)

        for idx in range(len(pos_item)):
            pos = pos_item[idx][0]
            out.append((u, pos, 1, true_expo_weight[pos]))

        for idx in range(len(neg_item)):
            neg = neg_item[idx][0]
            out.append((u, neg, 0, true_expo_weight[neg]))

    df = pd.DataFrame(out, columns=['user', 'item', 'label', 'expo_weight'])
    print(f'df size: {df.shape[0]}, label-mean: {df.label.mean()}')
    return df


# %%

def translate_to_prob(logit_model):
    prob_out = tf.nn.sigmoid(logit_model.output)
    return keras.Model(inputs=logit_model.inputs, outputs=prob_out)


def mf_create_func():
    logit_model = MF_modelV2(num_user, num_item, 32, regs=(0, 0))
    return translate_to_prob(logit_model)


def ncf_create_func():
    logit_model = Neural_model(num_user, num_item, 32, [8])
    return translate_to_prob(logit_model)


def generate_rank(model):
    mat = np.zeros((num_user, num_item))
    for uid in tqdm(range(num_user)):
        iids = np.arange(num_item)
        uids = np.zeros(num_item) + uid
        mat[uid, :] = model.predict((uids, iids)).flatten()
    rank_mat = np.zeros((num_user, num_item)).astype(np.int)
    for uid in range(num_user):
        rank_mat[uid, :] = mat[uid, :].argsort()[::-1]
    return rank_mat


def weighted_accuracy(model: keras.Model, df: pd.DataFrame):
    predict = model.predict((df.user.values, df.item.values)) > 0.5
    predict = predict.flatten()
    acc = df.label.values == predict
    weight = df.expo_weight.values
    weight = weight / weight.sum()
    return (acc * weight).sum(), acc.mean()


def weighted_rank_auc(rank_mat: np.ndarray, df: pd.DataFrame):
    auc, weight = [], []
    item_size = rank_mat.shape[1]
    for user, item, expo_weight in zip(df.user, df.item, df.expo_weight):
        for cand_item_idx in range(item_size):
            if item == rank_mat[user, cand_item_idx]:  # target == recommendation
                auc.append((item_size - cand_item_idx) / item_size)
                weight.append(expo_weight)
                break
    auc = np.asarray(auc)
    weight = np.asarray(weight)
    return (auc * weight).sum() / weight.sum(), auc.mean()


def create_data_obj(expo, rel, beta):
    out = {}
    out['tr_data'] = create_data(create_sample_data(expo, rel, beta=beta))
    # val_df = create_data(create_sample_data(expo, rel, beta=beta))
    out['te_df'] = create_sample_data(expo, rel, beta=beta)
    out['val_data'] = create_data(out['te_df'])
    out['te_positive_df'] = out['te_df'][out['te_df'].label > 0]
    return out


def run_exp(model_create_func, data_obj):
    tr_data = data_obj['tr_data']
    # val_df = create_data(create_sample_data(expo, rel, beta=beta))
    te_df = data_obj['te_df']
    val_data = data_obj['val_data']
    te_positive_df = data_obj['te_positive_df']

    model = model_create_func()
    callback = [keras.callbacks.EarlyStopping(
        monitor='val_loss', min_delta=0, patience=3, verbose=0,
        mode='auto', baseline=None, restore_best_weights=False
    )]
    model.compile(optimizer=keras.optimizers.Adam(learning_rate=0.001),
                  loss=keras.losses.BinaryCrossentropy(from_logits=False),
                  metrics=['accuracy', 'AUC'])
    model.fit(tr_data, epochs=100, validation_data=val_data, callbacks=callback, verbose=0)
    print('generate rank eval')
    rank_mat = generate_rank(model)
    unbiased_auc, biased_auc = weighted_rank_auc(rank_mat, te_positive_df)
    print('unbiased acc eval')
    unbiased_acc, biased_acc = weighted_accuracy(model, te_df)
    print(f'Biased - rank auc: {biased_auc}, acc: {biased_acc}')
    print(f'Unbiased - rank auc: {unbiased_auc}, acc: {unbiased_acc}')

    out = unbiased_auc, biased_auc, unbiased_acc, biased_acc
    return out


# %%
def full_exp(num_steps=5, repeat=10):
    result = []
    exp_id = 0
    for _ in range(repeat):
        for beta in np.linspace(0, 1, num_steps):
            # share data object and exp_id to compute stable lift
            mf_data = create_data_obj(expo_mf_mat, rel_mf_mat, beta=beta)
            ncf_data = create_data_obj(expo_ncf_mat, rel_ncf_mat, beta=beta)

            print('beta: {beta}'.format(beta=beta))
            metric = run_exp(mf_create_func, mf_data)
            result.append((exp_id, beta, 'MF_Data', 'MF', *metric))
            metric = run_exp(ncf_create_func, mf_data)
            result.append((exp_id, beta, 'MF_Data', 'NCF', *metric))

            exp_id += 1
            metric = run_exp(mf_create_func, ncf_data)
            result.append((exp_id, beta, 'NCF_Data', 'MF', *metric))
            metric = run_exp(ncf_create_func, ncf_data)
            result.append((exp_id, beta, 'NCF_Data', 'NCF', *metric))
    return pd.DataFrame(result,
                        columns=['exp_id', 'beta', 'source', 'model', 'unbiased_rank_auc', 'rank_auc', 'unbiased_acc',
                                 'acc'])


# %%
print('Running experiments')
simulation_metrics = full_exp()

# %%
version_num = len(next(os.walk('../results/metrics'))[2])

simulation_metrics.to_csv(f'../results/metrics/simulation_v{version_num}.csv', index=None)

# %%
