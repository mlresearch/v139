import os

import numpy as np
import tensorflow as tf


def generate_sample_dat(n_item_sample=200, n_user_sample=50, N_NEG=4):
    
    cmd = "python transductive_preprocess.py --task downsample --n_item_sample {} --n_user_sample {}".format(n_item_sample, n_user_sample)
    os.system(cmd)
    dat_file = "../data/sampled_positive_{}_{}.txt".format(n_user_sample, n_item_sample)


    f = open(dat_file, "r").readlines()
    n_user, n_item = int(f[0].strip().split(",")[0]), int(f[0].strip().split(",")[1])

    all_items = set(list(range(n_item)))
    train_dat_f, val_dat_f = [], []
    for dat in f[1:]:
        dat = list(map(int, dat.strip().split("\t")))
        n_interaction = len(dat)-1
        uid, train_dat, val_dat = dat[0], dat[1:-1], dat[-1]
        all_neg = list(all_items.difference(set(dat[1:])))
        sampled_neg = np.random.choice(list(all_neg), min(n_interaction * N_NEG, len(all_neg)), replace = False)
        for item in train_dat:
            train_dat_f.append([uid, item, 1])
        for item in sampled_neg[:(-1 * N_NEG)]:
            train_dat_f.append([uid, item, -1])

        val_dat_f.append([uid, item, 1])
        for item in sampled_neg[(-1 * N_NEG):]:
            val_dat_f.append([uid, item, -1])
            
    return (n_user, n_item, train_dat_f, val_dat_f, dat_file)


class mat_unit_norm(tf.keras.constraints.Constraint):

    def __init__(self, ref_value=1):
        self.ref_value = ref_value
    
    def __call__(self, w):
        Norm = tf.norm(w, ord = "fro")
        return w * self.ref_value / Norm

    def get_config(self):
        return {'ref_value': self.ref_value}


def exp_loss(y_true, y_pred):
    y_true = tf.cast(y_true, y_pred.dtype)    
    tol_loss = tf.exp(-1. * y_true * y_pred)
    return tf.reduce_mean(tol_loss)


def log_loss(y_true, y_pred):
    y_true = tf.cast(y_true, y_pred.dtype)
    tol_loss = tf.math.log(1 + tf.exp(-1. * y_true * y_pred))
#     tol_loss = tf.math.log(1 + tf.exp(-tf.multiply(y_true, y_pred)))
    return tf.reduce_mean(tol_loss)
