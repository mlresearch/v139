import argparse
import os

import numpy as np


def remove_infrequent_item(MIN_CNT):

    users, items = [], []
    item_cnt_dict = dict()
    with open("../data/ml-100k/u.data", "r") as f:
        for line in f:
            line = line.strip().split("\t")
            users.append(line[0])
            items.append(line[1])
            try:
                item_cnt_dict[line[1]] += 1
            except KeyError:
                item_cnt_dict[line[1]] = 1

    users, items = set(users), set(items)
    n_user, n_item = len(users), len(items)

    print("#users: {}, #items:{}".format(n_user, n_item))
    print("item with less than {} counts: {}".format(MIN_CNT, np.sum(np.array(list(item_cnt_dict.values())) < MIN_CNT)))

    user_id_map = dict(zip(list(users), list(range(n_user))))
    valid_items = [k for k,v in item_cnt_dict.items() if v >= MIN_CNT]
    item_id_map = dict(zip(list(valid_items), list(range(len(valid_items)))))

    user_item_time_dict = dict()
    with open("../data/ml-100k/u.data", "r") as f:
        for line in f:
            line = line.strip().split("\t")
            if not ((int(line[2]) > 0) and (line[1] in valid_items)): # only keep positive rating and valid items
                continue
            try:
                user_item_time_dict[user_id_map[line[0]]].append([item_id_map[line[1]], line[3]])
            except KeyError:
                user_item_time_dict[user_id_map[line[0]]] = [[item_id_map[line[1]], line[3]]]

    with open("../data/all_positive_dat.txt", "w") as f:
        _ = f.writelines(str(len(user_id_map)) + "," + str(len(item_id_map)) + "\n")
        for uid in sorted(list(user_item_time_dict.keys())):
            sorted_items = [x[0] for x in sorted(user_item_time_dict[uid], key = lambda x:x[1])]
            _ = f.writelines(str(uid) + "\t" + "\t".join(list(map(str, sorted_items))) + "\n")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("min_cnt", type=int, default=3)
    args = parser.parse_args()
    
    if not os.path.isdir("../data/ml-100k"):
        os.system('cp ../data/ml-100k.zip ../data/ml-100k_.zip')
        os.system("unzip ../data/ml-100k.zip -d ../data/.")
        os.system('mv ../data/ml-100k_.zip ../data/ml-100k.zip')
    
    
    remove_infrequent_item(args.min_cnt)
    print("done")