#%%
import numpy as np
from tensorflow import keras

#%%

info = open("../data/all_positive_dat.txt", "r").readlines()
info = info[0].strip().split(",")
num_user, num_item = int(info[0]), int(info[1])

expo_model_mf = keras.models.load_model('../results/inductive-expo-MCF')
expo_model_ncf = keras.models.load_model('../results/inductive-expo-NCF')
rel_model_mf = keras.models.load_model('../results/inductive-rel-MCF')
rel_model_ncf = keras.models.load_model('../results/inductive-rel-NCF')
#%%

#%%
print('Creating exposure weight')
def create_and_cache(model, name):
    mat = np.zeros((num_user, num_item))
    for uid in range(num_user):
        iids = np.arange(num_item)
        uids = np.zeros(num_item) + uid
        mat[uid, :] = model.predict((uids, iids)).flatten()
    np.save(f'../results/cache/{name}.npy', mat)

create_and_cache(rel_model_mf, 'rel_mf_mat')
create_and_cache(rel_model_ncf, 'rel_ncf_mat')
create_and_cache(expo_model_mf, 'expo_mf_mat')
create_and_cache(expo_model_ncf, 'expo_ncf_mat')


