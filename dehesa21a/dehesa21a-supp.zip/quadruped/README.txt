Dependencies:
- Python 3
- TensorFlow 1.x
- NumPy
- Pandas
- numpy-quaternion
- SciPy
- Matplotlib
- Seaborn

Due to limitations in the size of the supplementary material accepted at ICML 2021, the data and user study videos must be downloaded from an external link.

In order to run the experiments, please download the compressed file `quadruped_data.zip` from https://researchdata.bath.ac.uk/752/ , uncompress it and copy the directory `data` to this directory. You will need a Bash shell environment to run the experiments. The quadruped locomotion experiments can be run with:

    > ./run_eval.sh

After running the experiments, the evaluation results will be found under the `eval` directory, with error statistics for the different models on each evaluation dataset.

The directory `user_study` contains information about the user study. The file `study_results.jasp` contains the data and analysis of the questionnaire answers. It can be consulted with the open source tool JASP (https://jasp-stats.org/). The videos for the user study can be found in the aforementioned compressed file `quadruped_data.zip`, under `user_study`. The video files `gfnn_3x3_linear-7x7.flv` and `mann_8.flv` show respectively the performance of the GFNN and MANN models in the evaluation environment that was shown to the study participants. Runtime traces of the performance of these and other models can be found under `traces`.
