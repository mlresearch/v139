Grid-Functioned Neural Networks
===============================
July 2021

This is the supplementary material for the paper "Grid-Functioned Neural Networks" submitted to the Thirty-eighth International Conference on Machine Learning (ICML 2021). See the original document for details.

The material includes the document `ICML2021_GFNN_SupplementaryMaterial.pdf`, which expands on the topics discussed in the paper, and two directories, `gfnn` and `quadruped`, containing the data and code for the presented experimental results. See the additional documentation within the directories for more details.
