Dependencies:
- Python 3
- TensorFlow 1.x
- NumPy
- Pandas
- Matplotlib
- Seaborn

You will need a Bash shell environment to run the experiments. The experiments for the Rosenbrock, Ackley and Ackley (small region) problems can be run with:

    > for p in "ackley" "ackleysmall" "rosenbrock"; do ./run_eval.sh "${p}"; done

The experiments for the Ackley (revised) problem can be run with:

    > ./run_eval_ackley-revised.sh

After running the experiments, the results will be found under the `eval` directory, within the subdirectory correspoding to each problem. The trained models and training logs will be under `train`, and the resulting figures under `results`. Each of the results subdirectories includes a figure and a spreadsheet with the aggregated results of different subsets of the trained models.
