from batch_q import load_Q
from models import DiagGaussian, LogisticRegression, FullGaussianStruct
import torch
import matplotlib.pyplot as plt
import numpy as np
from tqdm import tqdm
import argparse
import pickle
import sys




def loss_KL(Q, P, N):
	Q.make_dist(N)
	Z = Q.sample_rep()
	log_P = P.log_prob(Z)
	log_Q = Q.log_prob_frozen(Z)
	loss = log_Q - log_P
	return loss

def loss_KL_nofrozen(Q, P, N):
	Q.make_dist(N)
	Z = Q.sample_rep()
	log_P = P.log_prob(Z)
	log_Q = Q.log_prob(Z)
	loss = log_Q - log_P
	return loss

def loss_alpha(Q, P, N, alpha):
	Q.make_dist(N)
	Z = Q.sample_rep()
	alog_P = alpha * P.log_prob(Z)
	alog_Q = alpha * Q.log_prob_frozen(Z)
	aux = alog_P - alog_Q
	aux = aux.exp()
	aux = aux
	loss = aux / alpha / (alpha - 1.) 
	return loss

def loss_alpha_nofrozen(Q, P, N, alpha):
	Q.make_dist(N)
	Z = Q.sample_rep()
	alog_P = alpha * P.log_prob(Z)
	alog_Q = alpha * Q.log_prob(Z)
	aux = alog_P - alog_Q
	aux = aux.exp()
	aux = aux
	loss = aux / alpha / (alpha - 1.) 
	return loss

def loss(Q, P, N, alpha, seed = None):
	if seed is not None:
		torch.manual_seed(seed)
	if alpha == 0:
		return loss_KL(Q, P, N)
	else:
		return loss_alpha(Q, P, N, alpha)


def grad_KL(Q, P, N):
	loss = loss_KL(Q, P, N).sum()
	loss_grads = torch.autograd.grad(loss, Q.parameters())
	return (loss_grads[0], loss_grads[1]), loss

def grad_KL_rep(Q, P, N):
	loss = loss_KL_nofrozen(Q, P, N).sum()
	loss_grads = torch.autograd.grad(loss, Q.parameters())
	return (loss_grads[0], loss_grads[1]), loss

def grad_alpha(Q, P, N, alpha):
	loss = loss_alpha(Q, P, N, alpha).sum()
	loss_aux = loss * (1 - alpha)
	loss_grads = torch.autograd.grad(loss_aux, Q.parameters())
	return (loss_grads[0], loss_grads[1]), loss

def grad_alpha_rep(Q, P, N, alpha):
	loss = loss_alpha_nofrozen(Q, P, N, alpha).sum()
	loss_grads = torch.autograd.grad(loss, Q.parameters())
	return (loss_grads[0], loss_grads[1]), loss

def grad(Q, P, N, alpha, rep = False):
	if alpha == 0:
		if not rep:
			return grad_KL(Q, P, N)
		else:
			return grad_KL_rep(Q, P, N)
	else:
		if not rep:
			return grad_alpha(Q, P, N, alpha)
		else:
			return grad_alpha_rep(Q, P, N, alpha)


def get_name():
	return '%i_%i_%i.pkl' % (ID, N, rep)



args_parser = argparse.ArgumentParser(description = 'Process arguments to run')
args_parser.add_argument('-iters', type = int, default = 1000, help = 'Number of iterations.')
args_parser.add_argument('-dim', type = int, default = 10, help = 'Dimension.')
args_parser.add_argument('-Ns', type = int, default = [100], nargs = '+', help = 'Samples to estimate loss.')
args_parser.add_argument('-N_loss', type = int, default = 50000, help = 'Samples to estimate gradient.')
args_parser.add_argument('-run_cluster', type = int, default = 0, help = '1: true, 0: false.')
args_parser.add_argument('-id', type = int, default = -1, help = 'ID.')
args_parser.add_argument('-seed', type = int, default = 1, help = 'Random seed to use.')
args_parser.add_argument('-lr', type = float, default = 0.01, help = 'Learning rate.')
args_parser.add_argument('-alpha', type = float, default = 0., help = 'Alpha.')
args_parser.add_argument('-reps', type = int, default = 5, help = 'Repetitions.')
run_info = vars(args_parser.parse_args())


dim = run_info['dim']
Ns = run_info['Ns']
N_loss = run_info['N_loss']
lr = run_info['lr']
ID = run_info['id']
alpha = run_info['alpha']
iters = run_info['iters']
run_cluster = run_info['run_cluster'] == 1
seed_orig = run_info['seed']
reps = run_info['reps']

torch.set_num_threads(2)


seed_orig += 1
for N in Ns:
	print('N', N)
	run_info['N'] = N
	seed = seed_orig

	P = DiagGaussian(dim)
	Q = load_Q('diag', P.dim)

	run_info['results'] = {}

	diverged = False
	
	try:
		losses = []
		beta1 = 0.9
		beta2 = 0.999
		eps = 1e-8
		m = 0
		v = 0

		for i in range(iters):
			# Info progress
			if i % 250 == 0:
				print(i)
			# Track loss
			seed += 1
			aux = (Q.mean.detach() - P.mean)
			losss = aux @ aux
			aux = (Q.logdiag.detach().exp() - P.logdiag.exp())
			losss += aux @ aux
			losses.append(losss / dim)

			# To run SGD
			# Compute gradient
			gs, _ = grad(Q, P, N, alpha, rep = False)
			# Optimization step
			# Q.mean -= lr * gs[0].mean(dim = 0)
			Q.logdiag -= lr * gs[1].mean(dim = 0)

			# # # To run Adam
			# gs, _ = grad(Q, P, N, alpha, rep = False)
			# grad_scale = gs[1].mean(dim = 0)
			# m = beta1 * m + (1. - beta1) * grad_scale
			# v = (1 - beta2) * v + beta2 * (grad_scale * grad_scale)
			# mhat = m / (1 - beta1 ** (i + 1))
			# vhat = v / (1 - beta2 ** (i + 1))
			# Q.logdiag -= lr * mhat / (eps + vhat.sqrt())

		run_info['results']['losses'] = losses


	except Exception as e:
		diverged = True
		print('Sth failed!', e)
		print('Sth failed!', file = sys.stderr)
		print(e, file = sys.stderr)

	run_info['results']['diverged'] = diverged

	plt.figure()
	plt.title('dim: %i, N: %i, $\\alpha$: %.3f' % (dim, N, alpha))
	plt.semilogx([i + 1 for i in range(len(losses))], losses, color = 'k')
	plt.ylabel('Loss', fontsize = 20)
	plt.xlabel('Iteration', fontsize = 20)
	plt.yticks(fontsize = 14)
	plt.xticks(fontsize = 14)
	plt.ylim([-0.1, 1.1])
	plt.tight_layout()
	plt.show()














