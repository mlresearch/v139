from batch_q import load_Q
from models import DiagGaussian, LogisticRegression, FullGaussianStruct, LinearRegression
import torch
import matplotlib.pyplot as plt
import numpy as np
from tqdm import tqdm
import argparse
import pickle
import sys


# import seaborn as sns
# plt.rc("axes.spines", top = False, right = False)


def loss_KL(Q, P, N, seed):
	torch.manual_seed(seed)
	Q.make_dist(N)
	Z = Q.sample_rep()
	log_P = P.log_prob(Z)
	log_Q = Q.log_prob_frozen(Z)
	loss = log_Q - log_P
	return loss

def loss_alpha(Q, P, N, alpha, seed):
	torch.manual_seed(seed)
	Q.make_dist(N)
	Z = Q.sample_rep()
	alog_P = alpha * P.log_prob(Z)
	alog_Q = alpha * Q.log_prob_frozen(Z)
	aux = alog_P - alog_Q
	aux = aux.exp()
	aux = aux
	loss = aux / alpha / (alpha - 1.) 
	return loss

def loss(Q, P, N, alpha, seed):
	if alpha == 0:
		return loss_KL(Q, P, N, seed)
	else:
		return loss_alpha(Q, P, N, alpha, seed)


def grad_KL(Q, P, N, seed):
	loss = loss_KL(Q, P, N, seed).sum()
	loss_grads = torch.autograd.grad(loss, Q.parameters())
	return (loss_grads[0], loss_grads[1]), loss

def grad_alpha(Q, P, N, alpha, seed):
	loss = loss_alpha(Q, P, N, alpha, seed).sum()
	loss_aux = loss * (1 - alpha)
	loss_grads = torch.autograd.grad(loss_aux, Q.parameters())
	return (loss_grads[0], loss_grads[1]), loss

def grad(Q, P, N, alpha, seed):
	if alpha == 0:
		return grad_KL(Q, P, N, seed)
	else:
		return grad_alpha(Q, P, N, alpha, seed)


def get_name():
	return '%i_%i_%i_%i.pkl' % (ID, N, r, seed_orig)


args_parser = argparse.ArgumentParser(description = 'Process arguments to run')
args_parser.add_argument('-iters', type = int, default = 1000, help = 'Number of iterations.')
args_parser.add_argument('-dset', type = str, default = 'iris2', help = 'Dataset to use for Bayesian logistic regression.')
args_parser.add_argument('-Ns', type = int, default = [10], nargs = '+', help = 'Samples to estimate loss.')
args_parser.add_argument('-N_loss', type = int, default = 15000, help = 'Samples to estimate gradient.') # Careful here!!! Has to be big(ger)!
args_parser.add_argument('-run_cluster', type = int, default = 0, help = '1: true, 0: false.')
args_parser.add_argument('-id', type = int, default = -1, help = 'ID.')
args_parser.add_argument('-seed', type = int, default = 1874, help = 'Random seed to use.')
args_parser.add_argument('-reps', type = int, default = 1, help = 'Number of repetitions.')
args_parser.add_argument('-lr', type = float, default = 0.1, help = 'Learning rate.')
args_parser.add_argument('-alpha', type = float, default = 0., help = 'Alpha.')
run_info = vars(args_parser.parse_args())


dset = run_info['dset']
Ns = run_info['Ns']
N_loss = run_info['N_loss']
lr = run_info['lr']
ID = run_info['id']
alpha = run_info['alpha']
iters = run_info['iters']
run_cluster = run_info['run_cluster'] == 1
seed_orig = run_info['seed']
reps = run_info['reps']

torch.set_num_threads(2)


for N in Ns:
	seed_rep = seed_orig
	print('N', N)
	run_info['N'] = N

	if dset in ['iris2', 'australian']:
		P = LogisticRegression(dset)
	Q = load_Q('diag', P.dim)

	run_info['results'] = {}

	diverged = False
	
	try:
		losses = []
		beta1 = 0.9
		beta2 = 0.999
		eps = 1e-8
		m_mean = 0
		m_scale = 0
		v_mean = 0
		v_scale = 0

		for i in range(iters):
			seed_i = seed_rep + i
			# Info progress
			if i % 250 == 0:
				print(i)
			# Track loss
			if i % 10 == 0:
				losss = loss(Q, P, N_loss, alpha, seed_i).sum()
				losses.append((losss / N_loss).item())
			
			# SGD
			# Compute gradient
			gs, _ = grad(Q, P, N, alpha, seed_i)
			# Optimization step
			Q.mean -= lr * gs[0].mean(dim = 0)
			Q.logdiag -= lr * gs[1].mean(dim = 0)

			# # Adam
			# gs, _ = grad(Q, P, N, alpha, seed_i)
			# grad_mean = gs[0].mean(dim = 0)
			# grad_scale = gs[1].mean(dim = 0)
			# m_mean = beta1 * m_mean + (1. - beta1) * grad_mean
			# m_scale = beta1 * m_scale + (1. - beta1) * grad_scale
			# v_mean = (1 - beta2) * v_mean + beta2 * (grad_mean * grad_mean)
			# v_scale = (1 - beta2) * v_scale + beta2 * (grad_scale * grad_scale)
			# mhat_mean = m_mean / (1 - beta1 ** (i + 1))
			# mhat_scale = m_scale / (1 - beta1 ** (i + 1))
			# vhat_mean = v_mean / (1 - beta2 ** (i + 1))
			# vhat_scale = v_scale / (1 - beta2 ** (i + 1))
			# Q.mean -= lr * mhat_mean / (eps + vhat_mean.sqrt())
			# Q.logdiag -= lr * mhat_scale / (eps + vhat_scale.sqrt())

		mean = Q.mean
		logdiag = Q.logdiag

		run_info['results']['losses'] = losses

	except Exception as e:
		diverged = True
		print('Sth failed!', e)
		print('Sth failed!', file = sys.stderr)
		print(e, file = sys.stderr)

	run_info['results']['diverged'] = diverged

	plt.figure()
	plt.title('Dset: %s, N: %i, alpha: %.3f' % (dset, N, alpha))
	plt.plot(losses, color = 'k')
	plt.ylabel('Loss', fontsize = 20)
	plt.xlabel('Iteration', fontsize = 20)
	plt.yticks(fontsize = 14)
	plt.xticks(fontsize = 14)
	plt.tight_layout()
	plt.show()














