import torch
import torch as tt
import torch.distributions as ttd
from IPython import embed
from timeit import default_timer as timer
from tqdm import tqdm
import numpy as np


def load_Q(d, dim):
	if d == 'diag':
		return DiagGaussian(dim)
	if d == 'diag_nl':
		return DiagGaussian_nolog(dim)
	if d == 'diag_nom':
		return DiagGaussianNoMean(dim)
	if d == 'full':
		return FullGaussian(dim)
	if d == 'diaglr':
		return DiagLRGaussian(dim, rank = 5)
	if d == 'diaghh':
		return DiagHH(dim)
	raise NotImplementedError('Q %s not implemented.' % d)


class Gaussian():
	def __init__(self, dim, name = 'name'):
		self.dim = dim
		self.name = name

	def parameters(self):
		raise NotImplementedError

	def covariance(self):
		raise NotImplementedError

	def make_dist(self, N):
		raise NotImplementedError

	def batchify(self, N):
		raise NotImplementedError

	def sample_rep(self):
		return self.dist.rsample()

	def entropy(self):
		return self.dist.entropy()

	def log_prob(self, z):
		return self.dist.log_prob(z)

	def _get_params(self):
		raise NotImplementedError

	def _transform_params(self, params):
		raise NotImplementedError


class DiagGaussianNoMean(Gaussian):
	def __init__(self, dim, name = 'name'):
		super().__init__(dim, name)
		# self.mean = torch.zeros(self.dim)
		self.logdiag = torch.zeros(self.dim)
		# self.meanb = None
		self.logdiagb = None

	def make_dist(self, N = 1):
		self.batchify(N = N)
		self.dist = ttd.Independent(ttd.Normal(loc = torch.zeros(N, self.dim), scale = self.logdiagb.exp(), validate_args = True), 1)

	def batchify(self, N):
		# mean = self.mean.clone()
		logdiag = self.logdiag.clone()
		# self.meanb = mean.view(1, self.dim).repeat(N, 1).requires_grad_()
		self.logdiagb = logdiag.view(1, self.dim).repeat(N, 1).requires_grad_()

	def parameters(self, orig = False):
		# if orig:
		# 	return [self.mean, self.logdiag]
		# return [self.meanb, self.logdiagb]
		if orig:
			return [self.logdiag]
		return [self.logdiagb]

	def log_prob_frozen(self, Z):
		dist = ttd.Independent(ttd.Normal(loc = torch.zeros(self.dim), scale = self.logdiag.detach().clone().exp(), validate_args = True), 1)
		return dist.log_prob(Z)

	def log_prob(self, Z):
		return self.dist.log_prob(Z)

	def sample_rep_SF(self, N):
		dist = ttd.Independent(ttd.Normal(loc = torch.zeros(self.dim), scale = self.logdiag.detach().clone().exp(), validate_args = True), 1)
		return dist.rsample(N)


class DiagGaussian(Gaussian):
	def __init__(self, dim, name = 'name'):
		super().__init__(dim, name)
		self.mean = torch.zeros(self.dim)
		# self.logdiag = torch.zeros(self.dim)
		self.logdiag = torch.ones(self.dim) * np.log(2)
		# self.logdiag = torch.ones(self.dim) * np.log(np.sqrt(2))
		self.meanb = None
		self.logdiagb = None

	def initialize_linear(self):
		self.mean[-1] = 2.
		self.logdiag[-1] = -2

	def make_dist(self, N = 1):
		self.batchify(N = N)
		self.dist = ttd.Independent(ttd.Normal(loc = self.meanb, scale = self.logdiagb.exp(), validate_args = True), 1)
		# self.dist = ttd.Independent(ttd.Normal(loc = self.meanb, scale = self.logdiagb, validate_args = True), 1)

	def batchify(self, N):
		mean = self.mean.clone()
		logdiag = self.logdiag.clone()
		self.meanb = mean.view(1, self.dim).repeat(N, 1).requires_grad_()
		self.logdiagb = logdiag.view(1, self.dim).repeat(N, 1).requires_grad_()

	def parameters(self, orig = False):
		if orig:
			return [self.mean, self.logdiag]
		return [self.meanb, self.logdiagb]

	def log_prob_frozen(self, Z):
		dist = ttd.Independent(ttd.Normal(loc = self.mean.detach().clone(), scale = self.logdiag.detach().clone().exp(), validate_args = True), 1)
		# dist = ttd.Independent(ttd.Normal(loc = self.meanb.detach().clone(), scale = self.logdiag.detach().clone(), validate_args = True), 1)
		return dist.log_prob(Z)

	# def log_prob(self, Z):
	# 	return self.dist.log_prob(Z)

	# def sample_rep_SF(self, N):
	# 	dist = ttd.Independent(ttd.Normal(loc = self.mean.detach().clone(), scale = self.logdiag.detach().clone().exp(), validate_args = True), 1)
	# 	return dist.rsample(N)




class FullGaussian(Gaussian):
	def __init__(self, dim, name = 'name'):
		super().__init__(dim, name)
		self.mean = torch.zeros(self.dim)
		self.M = torch.eye(self.dim)
		self.meanb = None
		self.Mb = None

	def make_dist(self, N = 1):
		self.batchify(N = N)
		self.dist = ttd.MultivariateNormal(loc = self.meanb, scale_tril = tt.tril(self.Mb), validate_args = True)
		# self.dist = ttd.MultivariateNormal(loc = self.meanb, scale_tril = self.Mb, validate_args = True)

	def batchify(self, N):
		mean = self.mean.clone()
		M = self.M.clone()
		self.meanb = mean.view(1, self.dim).repeat(N, 1).requires_grad_()
		self.Mb = M.view(1, self.dim, self.dim).repeat(N, 1, 1).requires_grad_()

	def parameters(self, orig = False):
		if orig:
			return [self.mean, self.M]
		return [self.meanb, self.Mb]

	def log_prob_frozen(self, Z):
		dist = ttd.MultivariateNormal(loc = self.mean.detach().clone(), scale_tril = self.M.detach().clone(), validate_args = True)
		return dist.log_prob(Z)


class DiagGaussian_nolog(Gaussian):
	def __init__(self, dim, name = 'name'):
		super().__init__(dim, name)
		self.mean = torch.zeros(self.dim)
		self.scale = torch.ones(self.dim)
		self.meanb = None
		self.scaleb = None

	def make_dist(self, N = 1):
		self.batchify(N = N)
		self.dist = ttd.Independent(ttd.Normal(loc = self.meanb, scale = self.scaleb, validate_args = True), 1)

	def batchify(self, N):
		mean = self.mean.clone()
		scale = self.scale.clone()
		self.meanb = mean.view(1, self.dim).repeat(N, 1).requires_grad_()
		self.scaleb = scale.view(1, self.dim).repeat(N, 1).requires_grad_()

	def parameters(self, orig = False):
		if orig:
			return [self.mean, self.scale]
		return [self.meanb, self.scaleb]

	def log_prob_frozen(self, Z):
		dist = ttd.Independent(ttd.Normal(loc = self.mean.detach().clone(), scale = self.scale.detach().clone(), validate_args = True), 1)
		return dist.log_prob(Z)

	# def log_prob(self, Z):
	# 	return self.dist.log_prob(Z)

	# def sample_rep_SF(self, N):
	# 	dist = ttd.Independent(ttd.Normal(loc = self.mean.detach().clone(), scale = self.logdiag.detach().clone().exp(), validate_args = True), 1)
	# 	return dist.rsample(N)