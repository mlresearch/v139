import torch
import torch as tt
import torch.distributions as ttd
import numpy as np
import scipy.stats as sst
import sklearn.datasets
import sklearn.preprocessing
# import pandas as pd




def sample_M(dim):
	M1 = np.array([[1., 1.], [1., -1.]]) / np.sqrt(2)
	M2 = np.diag([5, 1])
	Cov = (M1 @ M2) @ (M2 @ np.transpose(M1))
	M = np.linalg.cholesky(Cov)
	print(M @ np.transpose(M))
	return torch.from_numpy(M).float()


class Gaussian():
	def __init__(self, dim):
		self.dim = dim
		self.name = 'DG'

	def make_dist(self):
		raise NotImplementedError

	def entropy(self):
		return self.dist.entropy()

	def log_prob(self, z):
		return self.dist.log_prob(z)


# class FullGaussian(Gaussian):
# 	def __init__(self, dim):
# 		super().__init__(dim)
# 		self.mean = torch.zeros(self.dim)
# 		self.logdiag = sample_M(self.dim)
# 		self.make_dist()

# 	def make_dist(self):
# 		self.dist = ttd.MultivariateNormal(loc = self.mean, scale_tril = self.logdiag, validate_args = True)


class FullGaussianStruct(Gaussian):
	def __init__(self, dim, m = 0.1, mode = 3):
		super().__init__(dim)
		self.mean = torch.zeros(dim)
		
		if mode == 1:
			self.cov = torch.eye(dim) + (m / 2.) * torch.ones(dim, dim) - (m / 2.) * torch.eye(dim)
			self.cov = torch.from_numpy(np.linalg.inv(self.cov.numpy()))
			# self.cov = torch.eye(dim) * 5 - (m / 2.) * torch.ones(dim, dim) + (m / 2.) * torch.eye(dim)
		if mode == 2:
			self.cov = torch.eye(dim)
			for i in range(dim):
				if i + 1 < dim:
					self.cov[i, i + 1] = m
				if i - 1 >= 0:
					self.cov[i, i - 1] = m
			self.cov[0, dim - 1] = m
			self.cov[dim - 1, 0] = m
		if mode == 3:
			self.cov = torch.eye(dim)
			for i in range(dim):
				for j in range(dim):
					if i == j:
						self.cov[i, j] = 1
					if i > j:
						self.cov[i, j] = np.exp(-min([np.abs(i - j), dim - np.abs(i - j)]))
					if i < j:
						self.cov[i, j] = np.exp(-min([np.abs(i - j), dim - np.abs(j - i)]))
		if mode == 4:
			self.cov = torch.eye(dim) * m
		# print(self.cov)
		# print(np.linalg.inv(self.cov.numpy()))
		# print(np.linalg.inv(self.cov.numpy())[1,2] * dim ** 2)
		# evals, evecs = torch.eig(self.cov, eigenvectors = True)
		# print(evals)
		# print(evecs)
		# exit()

		evals = torch.eig(self.cov, eigenvectors = False)[0]
		for i in range(evals.shape[0]):
			assert evals[i, 0] > 0
		
		self.make_dist()

	def getcov(self):
		return self.cov.detach().clone()

	def make_dist(self):
		self.dist = ttd.MultivariateNormal(loc = self.mean, covariance_matrix = self.cov, validate_args = True)


class DiagGaussian(Gaussian):
	def __init__(self, dim):
		super().__init__(dim)
		self.mean = torch.zeros(self.dim)
		# self.mean = torch.ones(self.dim) * 0.5
		self.logdiag = torch.zeros(self.dim)
		# self.logdiag = torch.ones(self.dim) * np.log(0.5)
		self.make_dist()

	def make_dist(self):
		self.dist = ttd.Independent(ttd.Normal(loc = self.mean, scale = self.logdiag.exp(), validate_args = True), 1)



class LogisticRegression(torch.distributions.Distribution):
	def __init__(self, dset):
		self.name = 'LR%s' % dset
		self.dset = dset
		X, Y = self.loadData(dset)
		self.X = torch.from_numpy(X).float()
		self.Y = torch.from_numpy(Y).float()
		self.dim = self.X.size()[1]
		self.N = self.X.size()[0]
		self.scale_prior = 1.5

	def loadData(self, dset):
		def pad_with_const(X):
			extra = np.ones((X.shape[0],1))
			return np.hstack([extra, X])
		if dset == 'sonar':
			X, Y = sklearn.datasets.load_svmlight_file('./datasets/sonar_scale')
		elif dset == 'madelon':
			X, Y = sklearn.datasets.load_svmlight_file('./datasets/madelon')
		elif dset == 'australian':
			X, Y = sklearn.datasets.load_svmlight_file('./datasets/australian_scale')
			X = X.todense()
			X = X - np.mean(X, axis = 0)
			X = X / np.std(X, axis = 0)
			X = X[:100, :]
			Y = Y[:100]
		elif dset == 'iris2':
			iris = sklearn.datasets.load_iris()
			X, Y = iris.data, iris.target
			a = Y[Y != 2].shape[0]
			X = X[:a, :]
			Y = Y[:a]
			Y[Y == 0] = -1
			X = X - np.mean(X, axis = 0)
			X = X / np.std(X, axis = 0)
		try:
			X = pad_with_const(np.array(X.todense()))
		except:
			X = pad_with_const(X)
		assert(len(Y) == X.shape[0])
		return X, Y

	def name(self):
		return "Logistic" + self.dset

	def logp(self, z):
		return self.log_prob(z)

	def log_prob(self, z, full = None):
		"""
		- Works for z of any size, as long as the last one is dim (which gets killed).
		- If z.size() = (a, b, c, d, dim) then logp.size() = (a, b, c, d).
		"""
		logp = self.logprior(z)
		logp = logp + self.loglikelihood(z)
		return logp

	def logprior_z(self, z):
		return self.logprior(z)

	def logprior(self, z):
		"""
		- Works for z of any size, as long as the last one is dim (which gets killed).
		- If z.size() = (a, b, c, d, dim) then logp.size() = (a, b, c, d).
		- Use as prior standard normal.
		"""
		dist = torch.distributions.Normal(loc = 0, scale = self.scale_prior)
		logp = dist.log_prob(z).sum(-1)
		return logp

	def _logsumexp0(self, A):
		"""
		- Stable way of doing log(1 + exp(A)), elementwise.
		- Works for A of any size.
		"""
		B = torch.zeros(A.size())
		Max = torch.max(A, B)
		return Max + ((B - Max).exp() + (A - Max).exp()).log()

	def loglikelihood(self, z):
		"""
		- Works for z of any size, as long as the last one is dim (which gets killed).
		- If z.size() = (a, b, c, d, dim) then logp.size() = (a, b, c, d).
		"""
		# Fix dimentions for broadcasting
		extra = len(z.size()) - 1
		X = self.X
		Y = self.Y
		if extra != 0:
			X = X.view([X.size()[0]] + [1] * extra + [X.size()[1]])
			Y = Y.view([Y.size()[0]] + [1] * extra)
			z = z.unsqueeze(0)
		# Do rest
		A = X * z
		A = A.sum((-1))
		A = -A * Y
		logp = self._logsumexp0(A)
		logp = -logp.sum(0)
		return logp




class LinearRegression(torch.distributions.Distribution):
	def __init__(self, dset):
		self.name = 'LinR%s' % dset
		self.dset = dset
		X, Y = self.loadData(dset)
		self.X = torch.from_numpy(X).float()
		self.Y = torch.from_numpy(Y).float()
		self.dim = self.X.shape[1] + 1 # For scale
		self.N = self.X.shape[0]
		self.scale_prior = 1.5

	def loadData(self, dset):
		import csv
		def pad_with_const(X):
			extra = np.ones((X.shape[0],1))
			return np.hstack([extra, X])
		if dset == 'powerplant':
			reader = csv.reader(open('./datasets/powerplant.csv', 'rt'), delimiter = ',')
			x = list(reader)
			X = np.array(x).astype("float")	
			Y = X[:, -1]
			X = X[:, :-1]
			X = X[:100, :]
			Y = Y[:100]
		if dset == 'protein':
			reader = csv.reader(open('./datasets/proteintertiary.csv', 'rt'), delimiter = ',')
			x = list(reader)
			X = np.array(x).astype("float")	
			Y = X[:, 0]
			X = X[:, 1:]
			X = X[:100, :]
			Y = Y[:100]
		if dset == 'redwine':
			reader = csv.reader(open('./datasets/winequality-red.csv', 'rt'), delimiter = ';')
			x = list(reader)
			X = np.array(x).astype("float")	
			Y = X[:, -1]
			X = X[:, :-1]
			X = X[:100, :]
			Y = Y[:100]
		
		# Normalize data
		mux = np.mean(X, axis = 0)
		sigmax = np.std(X, axis = 0)
		X = (X - mux) / sigmax
		X = pad_with_const(X)
		muy = np.mean(Y)
		sigmay = np.std(Y)
		Y = (Y - muy) / sigmay
		return X, Y

	def name(self):
		return 'Linear' + self.dset

	def unpack(self, z):
		return z[:, :-1], z[:, -1]

	def log_prob(self, z):
		return self.logprior(z) + self.loglikelihood(z)

	def logprior(self, z):
		# z.shape = (a, dim)
		# Put the same prior on beta and lnsigma
		dist = tt.distributions.Normal(loc = 0, scale = self.scale_prior)
		return dist.log_prob(z).sum(-1)

	def loglikelihood(self, z):
		beta, lnsigma = self.unpack(z)
		# beta.shape = (a, dim - 1)
		# lnsigma.shape = (a)
		# X.shape = (N, dim - 1)
		# Y.shape = (N)
		loc = beta @ self.X.t() # shape = (a, N). Each row contains the results for each sample z against the whole dataset
		scale = lnsigma.exp().unsqueeze(-1) # shape = (a, 1)
		dist = tt.distributions.Normal(loc = loc, scale = scale + 0.001) # parameters (a, N)
		return dist.log_prob(self.Y).sum(-1)



