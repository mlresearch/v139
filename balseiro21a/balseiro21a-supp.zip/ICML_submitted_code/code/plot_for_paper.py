import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

sample_num = 20
directory = "figures/"
terminations = ["exhaustion"]
datasets = ["pub2"]
methods = ["gd"]
colors = ["red", "blue", "black", "green"]
titles = ["Online Gradient Descent", "Multiplicative Weight Updates"]

# Plot Regret
for termination in terminations:
  for j, method in enumerate(methods):
    plt.figure()
    for i, dataset in enumerate(datasets):
      df = pd.read_csv("results"+str(sample_num)+"_"+str(sample_num)+"_"+termination+"_"+dataset+"_"+method+"_lambda00002_ss10_True_off.csv")
      plt.plot((df["T"]), df["Regret"], '-o', label=dataset)
      plt.fill_between(df["T"], df["Regret"]-df["std"]/sample_num*3, df["Regret"]+df["std"]/sample_num*2, alpha=0.5)
    plt.xlabel("T", fontsize=20)
    plt.ylabel("Regret", fontsize=20)
    plt.savefig(directory+method+"_"+"regret.png", dpi=200)
    plt.close()

# Plot Relative Reward
for termination in terminations:
  for j, method in enumerate(methods):
    plt.figure()
    for i, dataset in enumerate(datasets):
      df = pd.read_csv("results"+str(sample_num)+"_"+str(sample_num)+"_"+termination+"_"+dataset+"_"+method+"_lambda00002_ss10_True_off.csv")
      plt.plot((df["T"]), 1-df["Regret"]/df["OPT"], '-o', label=dataset)
    plt.xlabel("T", fontsize=20)
    plt.ylabel("Relative Reward", fontsize=20)
    plt.savefig(directory+method+"_"+"relative_reward.png", dpi=200)
    plt.close()
