import main
import sys
import cvxpy as cp
import numpy as np

"""
Solve the offline primal problem to optimality using cvxpy and mosek, and print the optimal function value.
"""

if __name__ == "__main__":
  if len(sys.argv) == 2:
    data_name = sys.argv[1]

  all_data = main.load_data(data_name)

  A = np.transpose(np.array(all_data.revenue))
  m, T = np.shape(A)
  rho = all_data.rho
  lambd = 0.1
  x = cp.Variable((m, T))

  objective = cp.Maximize(cp.sum(cp.multiply(A,x)) + \
                          lambd * cp.sum(cp.entr(x)) + \
                          lambd * cp.sum(cp.entr(1-cp.sum(x, axis=0))))
  constraints = [x>=0, cp.sum(x, axis=0)<=1, cp.sum(x, axis=1)<= T*rho]

  prob = cp.Problem(objective, constraints)
  result = prob.solve(solver='MOSEK', verbose=True)

  print(prob.value)