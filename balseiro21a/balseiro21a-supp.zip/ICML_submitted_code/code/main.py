import numpy as np
import pandas as pd
import argparse
import sys
from scipy.stats import entropy
import collections

EPS = 1e-9

np.random.seed(121)
np.set_printoptions(precision=3)

class Dataset(object):
  def __init__(self, revenue, rho):
    self.revenue = revenue
    self.rho = rho

def load_data(instance_name):
  """
  Load the data.
  """
  directory = "../adx-alloc-data-2014/"
  revenue_file_name = directory + instance_name + "-sample.txt"
  revenue = np.loadtxt(revenue_file_name, delimiter=",")
  revenue = revenue / np.max(revenue)

  rho_file_name = directory + instance_name + "-ads.txt"
  rho = np.array([])
  with open(rho_file_name) as f:
    lines = f.readlines()
  for line in lines:
    rho = np.append(rho, float(line.split(":")[2][:-4]))
  return Dataset(revenue, rho)

def random_data(all_data, num, size):
  """
  Create an array of num random datasets of the given size from all_data.
  """
  T = len(all_data.revenue)
  datasets = []
  for j in range(num):
    datasets.append(Dataset(all_data.revenue[np.random.randint(T, size=size)],all_data.rho))
  return datasets

def gd_step(current_dual, gradient, eta):
  """
  A sub-gradient descent step.
  """
  next_dual = np.copy(current_dual)
  next_dual -= eta * gradient
  next_dual = next_dual.clip(min=0)
  return next_dual

def ew_step(current_dual, gradient, eta):
  """
  An exponential weight step.
  """
  next_dual = current_dual * np.exp(-eta*gradient)
  return next_dual

def smooth_delivery(satisfaction_index, params):
  """
  The smooth delivery function f of satisfaction index.
  """
  if params.smooth_delivery == "off":
    return 1
  elif params.smooth_delivery == "exp":
    return np.exp(params.smooth_delivery_constant * (satisfaction_index - 1))
  elif params.smooth_delivery == "poly":
    return satisfaction_index**params.smooth_delivery_constant
  elif params.smooth_delivery == "linear":
    return 1 + params.smooth_delivery_constant * (satisfaction_index - 1)

def compute_x(revenue_vector, current_dual, lambd, si, params):
  """
  Compute the optimal primal allocation given the revenue_vector, current_dual
  and lambd. This function avoids overflow in the exponential computation.
  """
  temp = (revenue_vector - smooth_delivery(si, params) * current_dual) / lambd
  max_temp = np.max(temp)
  denominator = np.sum(np.exp(temp-max_temp)) + np.exp(-max_temp)
  x = np.exp(temp-max_temp) / denominator
  return x

def compute_x_with_budget(revenue_vector, current_dual, lambd, remaining_budget, si, params):
  """
  Compute the optimal primal allocation given the revenue_vector, current_dual
  and lambd. Compare to `compute_x`, we do not consider the allocation to those advertiser without remaining budgets.
  """
  indexes = (np.argwhere(remaining_budget >= 1)).flatten()
  x = np.zeros(len(current_dual))
  if len(indexes) != 0:
    revenue_vector_shorten = revenue_vector[indexes]
    current_dual_shorten = current_dual[indexes]
    si_shorten = si[indexes]
    x_shorten = compute_x(revenue_vector_shorten, current_dual_shorten, lambd, si_shorten, params)
    x[indexes] = x_shorten
  return x

def dual_md(data, params):
  """
  Dual mirror descent algorithm. Return the cummulative revenue and the average
  dual solution.
  """
  T = len(data.revenue)
  m = len(data.rho)
  remaining_budget = T * data.rho
  cum_revenue = np.array([0])
  real_revenue = np.array([0])
  extended_rho = np.append(data.rho, 1)
  
  if params.step_size_constant == 0:
    if params.method == "gd":
      eta = 1 / np.sqrt(T)
    elif params.method == "ew":
      eta = 10 / np.sqrt(T)
  else:
    eta = params.step_size_constant / np.sqrt(T)

  if params.method == "gd":
    mirror_step = gd_step
    ini_dual = np.zeros(m)
  elif params.method == "ew":
    mirror_step = ew_step
    ini_dual = 1/np.exp(1)*np.ones(m)
  elif params.method == "mr":
    ini_dual = np.zeros(m)
    cum_ind_revenue = np.zeros(m)
    cum_ind = np.zeros(m)

  cum_ind_cost = np.zeros(m)
  current_dual = np.copy(ini_dual)
  sum_dual = np.copy(ini_dual)

  for t in range(T):
    revenue_vector = data.revenue[t]
    extended_revenue = np.append(revenue_vector, 0)
    si = cum_ind_cost / (t+1) / data.rho

    # Compute the corresponding allocation based on the current dual variable.
    if params.restricted_choice:
      x = compute_x_with_budget(revenue_vector, current_dual, params.lambd, remaining_budget, si, params)
    else:
      x = compute_x(revenue_vector, current_dual, params.lambd, si, params)
    extended_x = np.append(x, 1-np.sum(x)+EPS)
    allocation = np.random.choice(np.arange(0, m+1), p=extended_x)

    if params.verbosity >= 2:
      print x

    if allocation <= m-1 and remaining_budget[allocation] >= 1:
      # Allocate the impression, collect revenue and update budget.
      remaining_budget[allocation] -= 1
      cum_ind_cost[allocation] += 1
      cum_revenue = np.append(cum_revenue, cum_revenue[t] + extended_revenue[allocation] + params.lambd * entropy(extended_x))
      real_revenue = np.append(real_revenue, real_revenue[t] + extended_revenue[allocation])
      if params.method == "mr":
        cum_ind_revenue[allocation] += extended_revenue[allocation]
        cum_ind[allocation] += 1
    else:
      if allocation == m and all(extended_x[:m] <= remaining_budget):
        # No allocation, but collect revenue in entropy.
        cum_revenue = np.append(cum_revenue, cum_revenue[t] + params.lambd * entropy(extended_x))
      else:
        # No allocation, and no revenue.
        cum_revenue = np.append(cum_revenue, cum_revenue[t])
      real_revenue = np.append(real_revenue, real_revenue[t])

    # Updates dual variables based on the method.
    if params.method in ["ew", "gd"]:
      gradient = - x + data.rho
      next_dual = mirror_step(current_dual, gradient, eta)
      current_dual = np.copy(next_dual)
    elif params.method == "mr":
      consumption_set = cum_ind > 0
      current_dual[consumption_set] = cum_ind_revenue[consumption_set] / cum_ind[consumption_set]

    sum_dual += current_dual
    if params.termination == "stopping_time":
      if any(remaining_budget < 1):
        break

  if params.verbosity >= 1: 
    print(cum_revenue[-1], real_revenue[-1], (t+1)*dual_obj(data, sum_dual / (t+1), params.lambd))
  return cum_revenue, real_revenue, sum_dual / (t+1)

def second_randomness(data, params):
  """
  Run multiple random trials for the same dataset, and return the cumulative
  revenue for each trials.
  """
  m = len(data.rho)
  final_revenue = np.zeros(params.num_sec)
  final_real_revenue = np.zeros(params.num_sec)
  sum_ave_dual = np.zeros(m)
  for i in range(params.num_sec):
    revenue, real_revenue, ave_dual = dual_md(data, params)
    # temp, ave_dual = dual_md_det(data, ini_dual, mirror_step, eta, lambd, termination)
    final_revenue[i] = revenue[-1]
    final_real_revenue[i] = real_revenue[-1]
    sum_ave_dual += ave_dual

  return final_revenue, final_real_revenue, sum_ave_dual/params.num_sec

def first_randomness(datasets, params):
  """
  Run multiple trials for random dataset, and return the cumulative
  revenue for each trials.
  """
  revenue_coll = np.array([])
  real_revenue_coll = np.array([])
  dual_coll = np.array([])
  for j in range(params.num_first):
    data = datasets[j]
    final_revenue, final_real_revenue, ave_dual = second_randomness(data, params)
    revenue_coll = np.append(revenue_coll, final_revenue)
    real_revenue_coll = np.append(real_revenue_coll, final_real_revenue)
    dual_coll = np.append(dual_coll, dual_obj(data, ave_dual, params.lambd))

  return revenue_coll, real_revenue_coll, dual_coll 

def dual_obj(data, mu, lambd):
  """
  Compute the dual objective value. This function avoids overflow in the exponential computation.
  """
  T = len(data.revenue)
  extended_revenues = np.append((data.revenue), np.zeros((T,1)), axis=1)
  extended_rho = np.append(data.rho, 1)
  temp = (data.revenue-mu)/lambd
  max_temp = (np.max((data.revenue-mu)/lambd, axis=1))
  return lambd/T * np.sum(np.log(np.exp(-max_temp)+np.sum(np.exp(np.transpose(np.transpose(temp)-max_temp)), axis=1)) + max_temp) + np.inner(mu, data.rho)

def compute_dual_value(data, lambd):
  """
  Return D(\bar{\mu}) by running gd till exhaustion.
  """
  T = len(data.revenue)
  params = Params(num_first=1,
                  num_sec=1,
                  lambd=lambd,
                  method="gd",
                  eta=1/np.sqrt(T),
                  restricted_choice=False,
                  termination="exhaustion")  
  _, daul_solution = dual_md(data, params)
  return dual_obj(data, daul_solution, lambd)

if __name__ == "__main__":
  """
  Run multiple random trials of Algorithm 3 in the main paper for solving the
  proportional matching problems with high entropy, and save the regret to the
  output csv file.
  """
  parser = argparse.ArgumentParser()
  parser.add_argument("--num_first", help="The number of outer random loop.", type=int, default=1)
  parser.add_argument("--num_sec", help="The number of inner random loop.", type=int, default=1)
  parser.add_argument("--lambd", help="The coefficient of regularizer.", type=float, default=0.002)
  parser.add_argument("--data_name", help="The name of the dataset. Must be pub1-pub7.", type=str, default="pub2")
  parser.add_argument("--method", help="The dual update algorithm. Must be `gd` for gradient descent, or `ew` for exponential weight, or `mr` for matching ranker", type=str, choices=["gd", "ew", "mr"], default="gd")
  parser.add_argument("--termination", help="The termination criteria. Must be `stopping_time` for stopping when the remaining budget of one resource is less than 1, or `exhaustion` for using up all resources.", type=str, default="exhaustion")
  parser.add_argument("--restricted_choice", help="Whether to restrict our proportional allocation only to those advertisers with remaining budget >1.", type=bool, default=True)
  parser.add_argument("--step_size_constant", help="The step-size of the algorithm is defined by step_size_constant/sqrt{T}, where T is number of online stEPS. The default value (0) corresponds to step_size_constant=1 for gd, and step_size_constant=10 for ew.", type=float, default=0.0)
  parser.add_argument("--smooth_delivery", help="To attain a smooth delivery and react faster to changes in traffic, we multiple the dual variables by a function of satisfaction indexes (SI), i.e., mu'_j = mu_j * f(SI_j). Must take value `off`, `exp`, `poly`, `linear`", choices=["off", "exp", "poly", "linear"], type=str, default="off")
  parser.add_argument("--smooth_delivery_constant", help="The constant `a` used in the smooth delivery.", type=float, default=1.0)
  parser.add_argument("--verbosity", help="This is for testing only. `verbosity==0`: print nothing (default); `verbosity>=1`: print the output for each run; `verbosity>=2`: print the allocation decision for each iteration.", type=int, default=0)
  args = parser.parse_args()

  Params = collections.namedtuple("Params", ["num_first", "num_sec", "lambd", "step_size_constant", "method", "termination", "restricted_choice", "verbosity", "smooth_delivery", "smooth_delivery_constant"])
  params = Params(num_first=args.num_first,
                  num_sec=args.num_sec,
                  lambd=args.lambd,
                  step_size_constant=args.step_size_constant,
                  method=args.method,
                  termination=args.termination,
                  restricted_choice=args.restricted_choice,
                  smooth_delivery=args.smooth_delivery,
                  smooth_delivery_constant=args.smooth_delivery_constant,
                  verbosity=args.verbosity)

  if params.method not in ["gd", "ew", "mr"]:
    raise Exception("The method needs to be gd or ew.")

  if params.smooth_delivery not in ["off", "exp", "poly", "linear"]:
    raise Exception("The smooth delivery option needs to be `off` or `exp` or `poly` or `linear`.")

  if params.termination != "stopping_time" and params.termination !=  "exhaustion":
    raise Exception("The termination needs to be stopping_time or exhaustion.")

  all_data = load_data(args.data_name)
  m = len(all_data.rho)
  T = len(all_data.revenue)
  target_Ts = np.linspace(100, 10000, num=16, dtype=int)
  # optimal_value = compute_dual_value(all_data, lambd)
  # print optimal_value
  
  rows = []
  columns = ["T", "Reward", "Real_Reward", "std", "OPT", "Regret"]
  for target_T in target_Ts:
    datasets = random_data(all_data, num=params.num_first, size=target_T)
    T = len(datasets[0].revenue)
    if params.step_size_constant == 0:
      if params.method == "gd":
        eta = 1 / np.sqrt(T)
      elif params.method == "ew":
        eta = 10 / np.sqrt(T)
    else:
      eta = params.step_size_constant / np.sqrt(T)
    revenue_coll, real_revenue_coll, dual_coll  = first_randomness(datasets, params)
    ave_revenue = np.average(revenue_coll)
    ave_real_revenue = np.average(real_revenue_coll)
    ave_dual_value = T*np.average(dual_coll)
    std = np.std(revenue_coll)
    rows.append([T, ave_revenue, ave_real_revenue, std, ave_dual_value, ave_dual_value-ave_revenue])
  df = pd.DataFrame(rows, columns=columns)
  df.to_csv("results"+str(args.num_first)+"_"+str(args.num_sec)+"_"+args.termination+"_"+args.data_name+"_"+args.method+"_lambda"+str(params.lambd).replace('.', "")+"_ss"+str(params.step_size_constant).replace('.', "")+"_"+str(args.restricted_choice)+"_"+params.smooth_delivery+".csv", index=False)


