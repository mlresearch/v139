Description of the code for paper "Regularized Online Allocation Problems: Fairness and Beyond".

adx-alloc-data-2014 folder contains the data file generated following the procedure of "Yield Optimization of Display Advertising with Ad Exchange", Management Science. The dataset has 12 advertisers and 100,000 impressions. pub2-ads.txt contains the value of rho for each advertiser. pub2-sample.txt contains the revenue of matching each impression to the corresponding advertiser. We rescale the revenue so that the largest term is 1 in our experiment.

To run the main file
"python main.py --num_first 20 --num_sec 20 --step_size_constant 0.1 --data_name pub2 --method gd --lambd 0.0002 --step_size_constant 1"

The above code runs Algorithm 3 for 400 random trials and generate the csv file containing the average of std of the regret for the 400 random trials.

To reproduce Figure 1 and Figure 2, run:
"python code/plot_figure.py"

In order to compute an estimation of OPT, run
"python code/compute_opt.py" (require mosek license)

Dependency:
Python 2.7.14
pandas                             0.20.3
numpy                              1.16.6
cvxpy                               1.0.25
Mosek                              9.1.12 (require license)
