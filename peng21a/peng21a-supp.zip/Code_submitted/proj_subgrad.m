function [x_hat, time_used] = proj_subgrad(A, y, k, mu, num_iter)
    tic;
    
    [m,n] = size(A);

    x_hat = zeros(n,1);
   
    
    x_best = zeros(n,1); f_best = inf;
    for i = 1:num_iter             
        if i == 1
            x_hat = mu*A'*sgn(y);          
        else
            x_hat = x_hat - mu*A'*sgn(A(:,x_support)*x_hat(x_support,1)-y);          
        end
        
        [~, x_no_support] = mink(abs(x_hat),n-k);
        [~, x_support] = maxk(abs(x_hat),k);
        
        x_hat(x_no_support,1) = 0;
               
        x_hat(x_support,1) = L1(A(:,x_support), y);  
        
        f_hat = norm(A(:,x_support)*x_hat(x_support,1)-y,1);
        if f_hat < f_best
            f_best = f_hat;
            x_best = x_hat;
        end        
    end  
    x_hat = x_best;
    
    time_used = toc;
end

function s = sgn(v)
    s = ones(size(v));
    s(v<0) = -1;
end

function [x_hat] = L1(A, y)
    [~,n] = size(A);

    par.real_valued_flag = true; par.eco_flag = false; par.print_flag = false;

    x_hat = adlpmm(@(x)0,@(x,a)x,...
    @(x)norm(x-y,1),@(x,a)prox_l1(x-y,a)+y,@(x)A*x,@(x)A'*x,...
    1,zeros(n,1),norm(A)^2,par);
end