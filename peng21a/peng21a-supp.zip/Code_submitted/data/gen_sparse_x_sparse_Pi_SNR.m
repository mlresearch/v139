function [y, A, x] = gen_sparse_x_sparse_Pi_SNR(m, n, k, SNR, shuffled_ratio)
    A = randn(m, n);
    x = [randn(k,1); zeros(n-k,1)];
    x = x(randperm(n),1);
    %x = x/norm(x);
    
    
    
    y0 = A*x;
    alpha = int64(shuffled_ratio * m);
    partial_idx = datasample(1:m, alpha, 'Replace', false);
    y1 = y0(partial_idx, 1);
    y0(partial_idx, 1) = y1(randperm(alpha));
    
    
    w_ = randn(m, 1);
    sigma = norm(x)/sqrt(10^(SNR/10));
    w = sigma*w_;
    
    y = y0 + w;
end