library(R.matlab);
library(ggplot2);
library(scales);
library(tikzDevice);
options(tz="CA")
# options(tikzDocumentDeclaration = "\\documentclass[12pt]{article}")
# options(tikzDefaultEngine = 'xetex');
num_repeat = 100;

ks = seq(5,55,5);
num_k = 11;

saving_path = sprintf("../figures/sample_time_complexity_%d.eps", num_repeat);
tex_path = sprintf("../../figures/sample_time_complexity_%d.tex", num_repeat);

n = 2000;
# fn =  sprintf('../results/sample_time_complexity_%d.mat', num_repeat);
fn = sprintf('../results/sample_time_complexity_%d_%d.mat', num_repeat,n);
res = readMat(fn);

Ms = res$Ms[1:num_k,1];
Ts_mean = res$Ts.mean[1:num_k,1];
Ts_std = res$Ts.std[1:num_k,1];
dat = data.frame(ks, Ms, Ts_mean, Ts_std);


myratio = 0.0175;

text_size = element_text(size=rel(0.8));
title_text_size = element_text(size=rel(1.2));
point_size = rel(1);

time_color = "black";
sample_complexity_color = "purple";

coeff = 1000;

tikz(file=tex_path, height=1.3, width=1.75);

p = ggplot(data=dat, mapping=aes(x=ks)) +
  geom_line(mapping=aes(y=Ms, colour="0")) +
  geom_point(mapping=aes(y=Ms, colour="0"), alpha=1, size=point_size, shape=0) +

  geom_line(mapping=aes(y=Ts_mean*coeff, colour="1")) +
  geom_point(mapping=aes(y=Ts_mean*coeff, colour="1"), alpha=1, size=point_size, shape=2) +

  scale_x_continuous(breaks=seq(5, 55, 10),
                     labels=c("$5$","$15$","$25$","$35$","$45$", "$55$"),
                     name="$k$") +

  scale_y_continuous(name="Sample Complexity ($m$)",
                     breaks=seq(0,2000,400),
                     labels=c("$0$","$400$","$800$","$1200$","$1600$","$2000$"),
                     sec.axis = sec_axis(~./coeff, name="Time (in sec.)",
                                         breaks=seq(0,2,0.4),
                                         labels=c("$0$","$0.4$","$0.8$","$1.2$","$1.6$","$2$"))) +

  scale_colour_manual(labels=unname(c("0","1")),
                      values=c(sample_complexity_color,time_color)) +

 # coord_fixed(ratio=myratio) +
  theme(
    axis.text=element_text(face="plain", size=rel(0.75)),
    
    axis.text.y.left=element_text(face="plain", size=rel(0.9), colour=sample_complexity_color),
    axis.title.y.left = element_text(face="plain", size=rel(0.75), colour=sample_complexity_color),
    axis.title.y.right = element_text(face="plain", size=rel(0.75), colour=time_color),
    axis.text.y.right=element_text(face="plain", size=rel(0.9), colour=time_color),
    # axis.ticks = element_blank(),
    # axis.
    # panel.border = element_blank(),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_blank(),
    
  #  panel.border = element_blank(),

    plot.title=element_blank(),
    legend.text.align=0, legend.position="none", legend.title=element_blank())


# save the result
 #ggsave(saving_path, device="pdf");
print(p)
dev.off();
