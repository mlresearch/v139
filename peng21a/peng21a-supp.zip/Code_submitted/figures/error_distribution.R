library(R.matlab);
library(ggplot2);
library(scales);
library(tikzDevice);
options(tz="CA")
options(tikzDocumentDeclaration = "\\documentclass[12pt]{article}")
# options(tikzDefaultEngine = 'xetex');
num_repeat = 100;

saving_path = sprintf("../figures/error_distribution_%d.eps", num_repeat);
tex_path = sprintf("../../figures/error_distribution_%d.tex", num_repeat);

# fn =  sprintf('../results/error_distribution_%d.mat', num_repeat);
n = 2000;
fn = sprintf('../results/sample_time_complexity_%d_%d.mat', num_repeat,n);
res = readMat(fn);

tikz(file=tex_path, height=1.37, width=1.75);

num_intervals = 6


counter = res$counter[1:num_intervals, 5];



group = c("$(-\\infty,10^{-10}]$","$(10^{-10},10^{-8}]$","$(10^{-8},10^{-6}]$","$(10^{-6},10^{-4}]$","$(10^{-4},10^{-2}]$","$(10^{-2},+\\infty)$");

group = factor(group, levels = c("$(-\\infty,10^{-10}]$","$(10^{-10},10^{-8}]$","$(10^{-8},10^{-6}]$","$(10^{-6},10^{-4}]$","$(10^{-4},10^{-2}]$","$(10^{-2},+\\infty)$"));

dat = data.frame(group, counter);

dat$fraction = dat$counter/sum(dat$counter);
dat$ymax = cumsum(dat$fraction);

dat$ymin = c(0,head(dat$ymax,n=-1));

dat$label = paste0(dat$counter);
dat$labelPosition = (dat$ymax + dat$ymin)/2;

print(dat$labelPosition)
print(dat$counter)
# dat$labelPosition[3] = dat$labelPosition[3]-1;

dat$xposition = c(1.8,2.5,1.5,1.8,2.5,1.5);

my_values = c("gray", "mediumpurple", "gold", "steelblue", "tan", "brown1")
  
p = ggplot(dat, aes(ymax=ymax, ymin=ymin,xmax=4,xmin=3,fill=group)) + 
  geom_rect() + 
  geom_text(aes(x=xposition, y=labelPosition, label=label,color=group), size=3.1) + 
  coord_polar(theta="y") + 
  xlim(c(-1, 4)) + 
  theme_void() +
  scale_fill_manual(values=my_values) +
  scale_color_manual(values=my_values) +
#  theme(legend.position = "none") +
  theme(legend.title=element_blank(),
      
        legend.text=element_text(face="plain",size=rel(0.7),margin = margin(l = -5,r=2)),
        legend.key.size = unit(rel(0.5),"line"),
  #      legend.position="top",
        legend.justification="top",
    #    legend.margin=margin(0,0,0,0),
        legend.box.margin=margin(l=-14),
      #  legend.margin = margin(0,-2,0,0),

       # plot.margin=margin(0,-1,0,0)
#        legend.key.spacing.y = unit(0.5,"cm")
       # legend.position=c(1.2,0.5),
       #  legend.margin=margin(-5,0,0,0),
    #    legend.justification = "top"
        )

print(p)
dev.off();