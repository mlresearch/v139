library(R.matlab);
library(ggplot2);
library(scales);
library(tikzDevice);
options(tz="CA")
options(tikzDocumentDeclaration = "\\documentclass[12pt]{article}")
# options(tikzDefaultEngine = 'xetex');
num_repeat = 100;

saving_path = sprintf("../figures/phase_transition_%d.eps", num_repeat);
tex_path = sprintf("../../figures/phase_transition_%d.tex", num_repeat);

m = 1400;
fn = sprintf('../results/phase_transition_%d.mat', num_repeat);
res = readMat(fn);


num_k = 11; num_s = 11;
ks = res$ks[1,1:num_k];
shuffled_ratios = res$shuffled.ratios[1,1:num_s];

es_mean = res$es.mean[1:num_s,1:num_k];

X = rep(ks,each=11);
Y = rep(shuffled_ratios,11);
Z = as.vector(es_mean);


dat = data.frame(X, Y, Z);


tikz(file=tex_path, height=1.35, width=2.0);

color1 = "red";
color2 = "blue";
color3 = "black";

p = ggplot(data=dat, mapping=aes(x=X,y=Y,z=Z)) + 
  geom_tile(aes(fill=Z),size=0.1, color="black") +
  geom_contour(breaks=0.01,color=color1) + 
  geom_contour(breaks=0.1,color=color2) + 
  geom_contour(breaks=0.3,color=color3) + 
#  geom_contour(breaks=c(0.01,0.1,0.3)) + 
  scale_colour_manual(values=c(color1, color2, color3)) +

  scale_x_continuous(name="$k$", 
                     breaks=seq(5, 55, 10),
                     labels=c("$5$","$15$","$25$","$35$","$45$", "$55$")) +
  scale_y_continuous(name="$p/m$",
                    breaks=seq(0.05, 0.55, 0.1),
                    labels=c("$5\\%$","$15\\%$","$25\\%$","$35\\%$","$45\\%$", "$55\\%$")) +
  
  scale_fill_continuous(limits = c(0,0.3), breaks = c(0.01, 0.1, 0.3), 
                        labels=c("\\textcolor{red}{$0.01$}","\\textcolor{blue}{$0.1$}", "\\textcolor{black}{$0.3$}"),
                        low="white", high="black")+#,
#  guide = guide_colourbar(nbin=100, draw.ulim = FALSE, draw.llim = FALSE))

#  guides(fill = guide_colourbar(barwidth = 0.4, barheight = 3))
#  theme_minimal() + 
  theme(
    axis.text=element_text(face="plain", size=rel(0.7)),
    axis.title = element_text(face="plain", size=rel(0.7)),
    axis.title.x = element_text(size=rel(1.4)),
    #    axis.text.y.left=element_text(face="plain", size=rel(0.9), colour=sample_complexity_color),
    #    axis.title.y.left = element_text(face="plain", size=rel(0.75), colour=sample_complexity_color),
    #    axis.title.y.right = element_text(face="plain", size=rel(0.75), colour=time_color),
    #    axis.text.y.right=element_text(face="plain", size=rel(0.9), colour=time_color),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_blank(),
    #axis.ticks=element_line(size=0.4),
    #remove plot background
    plot.background=element_blank(),
    #remove plot border
   
    panel.border=element_blank(),
    
    plot.title=element_blank(),
    legend.key.size = unit(rel(0.5),"line"),
    legend.box.margin=margin(l=-11),
  #  legend.position = "none",
    legend.text.align=0, legend.title=element_blank())
#  theme_void()

print(p)
dev.off();