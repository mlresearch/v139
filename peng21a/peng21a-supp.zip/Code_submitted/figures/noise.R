library(R.matlab);
library(ggplot2);
library(scales);
library(tikzDevice);
options(tz="CA")
options(tikzDocumentDeclaration = "\\documentclass[12pt]{article}")
# options(tikzDefaultEngine = 'xetex');
num_repeat = 100;

saving_path = sprintf("../figures/noise_%d.eps", num_repeat);
tex_path = sprintf("../../figures/noise_%d.tex", num_repeat);

m = 1400;
fn = sprintf('../results/noise_%d_%d.mat', num_repeat,m);
res = readMat(fn);

SNRs = seq(5,55,5);
num_SNR = 11;
es_mean = res$es.mean[1:num_SNR,1];
es_std = res$es.std[1:num_SNR,1];
es_median = res$es.median[1:num_SNR,1];

dat = data.frame(SNRs, es_mean, es_std);
tikz(file=tex_path, height=1.35, width=1.5);

p = ggplot(data=dat, mapping=aes(x=SNRs, y=es_mean)) + 
#    geom_ribbon(aes(ymin=pmax(es_mean-es_std, 0),
#                       ymax=es_mean+es_std),
#                   position=position_dodge(0.005),
#                   alpha=0.2) +
    geom_line(mapping=aes(y=es_mean, colour="0"), color="black") +
    geom_point(position=position_dodge(0.008), size=rel(1), shape=0) +
  
#   scale_y_log10(name="Estimation Error",
#                  breaks=10^(-4:0),
                  # labels=seq(10^(-2), 10^(-1), 1)
#                  labels=trans_format("log10", math_format(10^.x))) + 
  
   scale_y_continuous(name="Estimation Error",
                     #breaks=seq(0,2000,400),
                     #labels=c("$0$","$400$","$800$","$1200$","$1600$","$2000$")
                     ) +
  
   scale_x_continuous(name="SNR (in dB)", 
                      breaks=seq(5, 55, 10),
                      labels=c("$5$","$15$","$25$","$35$","$45$", "$55$")) + 
  
    theme(
    axis.text=element_text(face="plain", size=rel(0.7)),
    axis.title = element_text(face="plain", size=rel(0.7)),
#    axis.text.y.left=element_text(face="plain", size=rel(0.9), colour=sample_complexity_color),
#    axis.title.y.left = element_text(face="plain", size=rel(0.75), colour=sample_complexity_color),
#    axis.title.y.right = element_text(face="plain", size=rel(0.75), colour=time_color),
#    axis.text.y.right=element_text(face="plain", size=rel(0.9), colour=time_color),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_blank(),

    plot.title=element_blank(),
    legend.text.align=0, legend.position="none", legend.title=element_blank())

print(p);
dev.off();


