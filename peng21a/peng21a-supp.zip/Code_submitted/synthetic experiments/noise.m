clear all;

format shortG;

sigma = 0;
shuffled_ratio = 0.2;
k = 25;
m = 1400;
n = 2000;

SNRs = 5:5:55;
num_SNR = length(SNRs);

num_repeat = 100;
mu = 1e-4;
num_iter = 20;

es_mean = zeros(num_SNR,1);
es_std = zeros(num_SNR,1);
es_median = zeros(num_SNR,1);
es_counter = zeros(num_SNR,1);
for i = 1:num_SNR
    SNR = SNRs(i);
    
    es = zeros(num_repeat,1);
    for j=1:num_repeat
        [y, A, x] = gen_sparse_x_sparse_Pi_SNR(m, n, k, SNR, shuffled_ratio);
        [x_hat, time_used] = proj_subgrad(A, y, k, mu, num_iter);
        es(j,1) = norm(x_hat-x)/norm(x);
        if es(j,1) > 0.01
            es_counter(i,1) = es_counter(i,1) + 1;
        end
    end
    es_mean(i,1) = mean(es);
    es_std(i,1) = std(es);
    es_median(i,1) = median(es);
    [i es_median(i,1) es_mean(i,1) es_std(i,1) es_counter(i,1)]
end

fn = sprintf('./results/noise_%d_%d.mat', num_repeat,m);
clear A;


save(fn);


