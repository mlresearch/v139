clear all;

format shortG;

sigma = 0;
shuffled_ratio = 0.2;
success_threshold = 1e-2;

k = 20;
m = 1500;
n = 3000;

num_repeat = 100;

mu = 1e-4;

num_iter = 20;


intervals = [1e-10; 1e-8; 1e-6; 1e-4; 1e-2; 1000000000];
counter = zeros(6,1);

for i=1:num_repeat
    [y, A, x] = gen_sparse_x_sparse_Pi(m, n, k, sigma, shuffled_ratio);
    
    [x_hat, time_used] = proj_subgrad(A, y, k, mu, num_iter);
    e = norm(x_hat-x)/norm(x);
    for j=1:6
        if e <= intervals(j)
            counter(j) = counter(j)+1;
            break;
        end        
    end
    [i counter' e]
end

fn = sprintf('./results/error_distribution_%d_%d_%d.mat', num_repeat,m,n);
clear A;


save(fn);