clear all;
format shortG;

n = 2000;
m = 1400;
SNR = 40;

shuffled_ratios = 0.05:0.05:0.55;
num_s = length(shuffled_ratios);

ks = 5:5:55;
num_k = length(ks);

es_mean = zeros(num_s, num_k);

num_iter = 20;
mu = 1e-4;

num_repeat = 100;

for j = 1:num_k
    k = ks(j);
    for l = 1:num_s
        s = shuffled_ratios(l);
        
        es = zeros(num_repeat, 1);
        for i = 1:num_repeat
            [y, A, x] = gen_sparse_x_sparse_Pi_SNR(m, n, k, SNR, s);
            [x_hat, time_used] = proj_subgrad(A, y, k, mu, num_iter);
            es(i,1) = norm(x_hat-x)/norm(x);
        end
        es_mean(l,j) = mean(es);
        [k s mean(es)]
    end
end
es_mean
clear A;

fn = sprintf('./results/phase_transition_%d.mat', num_repeat);
save(fn)
