format shortG;

sigma = 0;
shuffled_ratio = 0.2;
success_threshold = 1e-2;

num_repeat = 100

mu = 1e-4;

num_iter = 20;

n = 2000;

ks = 5:5:55;

Ms = [];
Js = [];
Ts_mean = [];
Ts_std = [];

intervals = [1e-10; 1e-8; 1e-6; 1e-4; 1e-2; 1000000000];
counter = zeros(6,length(ks));

for q=1:length(ks)
    k = ks(q);
    
    if k == 5
        j = 1;
    else        
        j = ceil(Ms(end)/k);       
    end
    success = 0;
    while ~success
        m = j*k;
        %floor(1.2*m);
        
        time_total = zeros(num_repeat,1);
        es = zeros(num_repeat,1);
        for i=1:num_repeat
            [y, A, x] = gen_sparse_x_sparse_Pi(m, n, k, sigma, shuffled_ratio);
            [x_hat, time_used] = proj_subgrad(A, y, k, mu, num_iter);
            time_total(i,1) = time_used;
            
            e = norm(x_hat-x)/norm(x);    es(i,1) = e;         
            if e > success_threshold
                [size(Ms) e m]
                break;
            end            
        end
        if i == num_repeat && e < success_threshold
            success = 1;        
            
            for e = es'   
                for l=1:6
                    if e <= intervals(l,1)
                        counter(l,q) = counter(l,q)+1;
                        break;
                    end        
                end
            end
            assert(sum(counter(:,q)) == num_repeat);
            Ms = [Ms; m];   
            Ts_mean = [Ts_mean; mean(time_total)];
            Ts_std = [Ts_std; std(time_total)];
        end
        j = j + 1;
    end    
    [Ms'; Ts_mean'; Ts_std']
    counter(:,q)'
end
clear A;

fn = sprintf('./results/sample_time_complexity_%d_%d.mat', num_repeat,n);
save(fn);