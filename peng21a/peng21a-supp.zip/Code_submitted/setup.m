addpath('data');

addpath('libs/fom');
init_fom

addpath('synthetic experiments');

