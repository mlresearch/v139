format shortG
setup


m = 1500;

n = 2000;
k = 25;
sigma = 0;  % noise level
% SNR = 10000000;

shuffled_ratio = 0.2;

mu = 1.5e-4;

num_iter = 20;

[y, A, x] = gen_sparse_x_sparse_Pi(m, n, k, sigma, shuffled_ratio);
%[y, A, x] = gen_sparse_x_sparse_Pi_SNR(m, n, k, SNR, shuffled_ratio);

x_init = zeros(n,1);
tic;
x_hat = proj_subgrad(A, y, k, mu, num_iter);

toc;

norm(x_hat-x)/norm(x)