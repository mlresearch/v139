"""Algorithms for solving performative prediction problems."""
import numpy as np

def two_stage_algo(dgp, num_samples, exploration_std=0.1, oracle=False):
    """Identify performative effects and solve the plug-in ERM problem.

    Arguments:
        dpg:                Instance of data generating process
        num_samples:        Number of samples.
        exploriation_std:   Std of the Gaussian exploration distribution
        oracle:             Whether or not to use ground truth w
    """
    if not oracle:
        # Exploration step
        explore_samples = num_samples // 2
        explore_thetas = exploration_std * np.random.randn(explore_samples, dgp.classifier_dim)
        _, labels = dgp.generate_data(explore_thetas)

        # Identify the performative effect
        # Add a bias term for potentially non-zero mean features.
        model_id_covars = np.hstack([explore_thetas, np.ones((explore_samples, 1))])
        w_est = np.linalg.lstsq(model_id_covars, labels, rcond=None)[0]
        # Drop the bias term
        w_est = w_est[:-1]

    else:
        w_est = dgp.w

    # Optimize performative risk
    # Collect base dataset by playing the zero-classifier
    base_thetas = np.zeros((num_samples // 2, dgp.classifier_dim))
    features, labels = dgp.generate_data(base_thetas)

    # Solve empirical risk minimization procedure
    debiased_features = features - w_est.T
    theta_est = np.linalg.lstsq(debiased_features, labels, rcond=None)[0]

    return theta_est

def flaxman_dfo(dgp, step_sequence, diameter, batch_size=20, delta=1, theta0=None):
    """Model-free DFO algorithm by Flaxman et al."""
    dim = dgp.classifier_dim
    theta = np.zeros((dim, 1)) if theta0 is None else theta0
    thetas = [np.squeeze(np.copy(theta))]
    for step in step_sequence:
        u_vec = np.random.randn(dim, batch_size)
        u_vec /= np.linalg.norm(u_vec, axis=0)
        eval_pts = (theta + delta * u_vec).T 
        noisy_evals = dgp.sample_loss(eval_pts)
        noisy_grads = dim / delta * noisy_evals.T * u_vec
        grad_est = np.mean(noisy_grads, axis=1, keepdims=True)
        theta_new = theta - step * grad_est
        norm = np.linalg.norm(theta_new)
        if norm >= diameter:
            theta_new *= diameter / norm
        theta = theta_new
        thetas.append(np.squeeze(np.copy(theta)))
    return thetas

def shamir_dfo(dgp, step_sequence, batch_size=20, eps_radius=1.):
    """Model-free DFO algorithm for quadratics from Shamir 2013."""
    dim = dgp.classifier_dim
    theta = np.ones((dim, 1))
    thetas = [np.copy(theta)]
    for step in step_sequence:
        rs = np.sign(np.random.uniform(-1, 1, size=(dim, batch_size)))
        eval_pts =( theta + (eps_radius / np.sqrt(dim)) * rs).T
        noisy_evals = dgp.sample_loss(eval_pts)
        noisy_grads = (np.sqrt(dim) / eps_radius) * noisy_evals.T * rs
        grad_est = np.mean(noisy_grads, axis=1, keepdims=True)
        theta -= step * grad_est
        thetas.append(np.copy(theta))
    return thetas

def greedy_rrm(dgp, step_sequence, theta0=None):
    dim = dgp.classifier_dim
    theta = np.zeros((dim, 1)) if theta0 is None else theta0
    thetas = [np.copy(theta)]
    for step in step_sequence:
        grad_est = dgp.sample_gradient(theta, performative=False)
        theta -= step * grad_est
        thetas.append(np.copy(theta))
    return thetas

def greedy_sgd(dgp, n, diameter, k0, c, theta0=None):
    dim = dgp.classifier_dim
    theta = np.zeros(dim) if theta0 is None else theta0
    thetas = [np.copy(theta)]

    for t in range(1, n + 1):
        step = c / (k0 + t)

        grad_est = dgp.sample_gradient(theta)
        theta -= step * grad_est

        # projection step
        norm = np.linalg.norm(theta)
        if norm >= diameter:
            theta *= diameter / norm

        thetas.append(np.copy(theta))

    return theta, dgp.sample_loss(np.array(thetas))

def lazy_sgd(dgp, n, diameter, k0, c, alpha):
    dim = dgp.classifier_dim

    theta = np.zeros(dim)
    thetas = [np.copy(theta)]
    deployed_theta = np.copy(theta)
    k=1
    count= 0
    while True:

        for i in range(1, int(k ** alpha) + 1):
            if count >= n:
                break
            step = c / (i + k0)
            grad_est = dgp.sample_gradient(deployed_theta)
            theta -= step * grad_est

            # projection step
            norm = np.linalg.norm(theta)
            if norm >= diameter:
                theta *= diameter / norm

            count += 1
            thetas.append(np.copy(deployed_theta))

        k += 1
        deployed_theta = np.copy(theta)

        if count >= n:
            break

    return deployed_theta, dgp.sample_loss(np.array(thetas))
