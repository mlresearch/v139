"""Data generating processes for performative prediction."""
from functools import partial

import autograd.numpy as np 
from autograd import grad 
from scipy import optimize
from sklearn.datasets import make_spd_matrix
from data_prep import load_data


class DGP(object):
    """Base class for data generating processes."""
    def __init__(self):
        self._population_gradient = None
        self._sample_gradient = None
    
    def generate_data(self, thetas, seed=None):
        """ Sample a dataset, one point for each classifier theta."""
        raise NotImplementedError

    @property
    def classifier_dim(self):
        raise NotImplementedError

    def sample_loss(self, thetas, datagen_thetas=None):
        """Finite sample loss of theta on D(datagen_theta)."""
        raise NotImplementedError
    
    def population_loss(self, theta):
        """Population level loss."""
        raise NotImplementedError

    def compute_performative_optimum(self):
        """Compute the performative optimum for the population."""
        raise NotImplementedError

    def population_gradient(self, theta):
        """Population loss gradient."""
        if self._population_gradient is None:
            self._population_gradient = grad(self.population_loss)
        return self._population_gradient(theta)

    def sample_gradient(self, theta, performative=False):
        """Finite sample loss gradient, with option to turn off performativity."""
        if self._sample_gradient is None:
            self._sample_gradient = grad(self.sample_loss)
        if performative: 
            return self._sample_gradient(theta)
        return self._sample_gradient(theta, np.copy(theta))


class LinearDGP(DGP):
    """Generate data from a simple structural equation model.
            X ~ N(0, feature_covariance)
            Y ~ < beta, X> + <w, theta> + N(0, label_variance),

        where theta is the classifier parameters.
    """
    def __init__(self, beta=None, w=None, feature_covariance=None,
                 label_variance=1.0, feature_dim=10, norm_w=1.0, seed=None):
        super(LinearDGP, self).__init__()

        rng = np.random.RandomState(seed)
        if beta is None:
            beta = rng.randn(feature_dim, 1)
        if w is None:
            w = rng.randn(feature_dim, 1)
            w = w * norm_w / np.linalg.norm(w)
        if feature_covariance is None:
            feature_covariance = make_spd_matrix(feature_dim, random_state=seed)
            feature_covariance /= 1e2 * np.linalg.norm(feature_covariance)
        
        self.beta = beta
        self.w = w
        self.feature_covariance = feature_covariance
        self.label_variance = label_variance

    @property
    def classifier_dim(self):
        return len(self.w)

    def generate_data(self, thetas, seed=None):
        """ Sample a dataset, one point for each classifier theta.

        Arguments:
            - thetas [num_samples, classifier_dim],
              vector of deployed classifiers.
        """
        rng = np.random.RandomState(seed)
        num_samples, _ = thetas.shape
        features = rng.multivariate_normal(np.zeros(self.classifier_dim),
                                           self.feature_covariance,  num_samples)
        labels = np.dot(features, self.beta) + np.dot(thetas, self.w)
        label_noise = np.sqrt(self.label_variance) * rng.randn(num_samples, 1)
        return features, labels + label_noise

    def sample_loss(self, thetas, datagen_thetas=None, seed=None):
        """Sample the loss for each theta."""
        if datagen_thetas is None:
            datagen_thetas = thetas 
        # HACK to work with autograd
        if self.w.shape[0] != 1:
            if thetas.shape[1] == 1:
                thetas = thetas.T
            if datagen_thetas.shape[1] == 1:
                datagen_thetas = datagen_thetas.T
        features, labels = self.generate_data(datagen_thetas, seed=seed)
        predictions = np.diag(np.dot(features, thetas.T)).reshape(-1, 1)
        return (labels - predictions) ** 2
    
    def population_loss(self, theta):
        nonperf_error = self.beta - theta
        perf_regularizer = np.dot(self.w, self.w.T)

        fit_loss = np.dot(np.dot(nonperf_error.T, self.feature_covariance), nonperf_error)
        perf_penalty = np.dot(theta.T, np.dot(perf_regularizer, theta))

        return (fit_loss + perf_penalty + self.label_variance)[0][0]

    def compute_performative_optimum(self):
        """Directly solves the quadratic optimization problem."""
        pinv = np.linalg.pinv(self.feature_covariance + self.w.dot(self.w.T)) 
        return pinv.dot(self.feature_covariance.dot(self.beta))


class NonLinearDGP(DGP):
    """Juanky's 'mildly' non-linear data generating process.
            X ~ N(0, feature_covariance)
            Y ~ < beta, X> + <w, f(theta)> + N(0, label_variance),
        where the nonlinearity f(theta) is a simple polynomial in
        each coordinate, f_i(theta) = |theta_i| ** degree,
        for a free `degree` parameter.
    """
    def __init__(self, beta=None, w=None, feature_covariance=None,
                 label_variance=1.0, feature_dim=3, degree=1,
                 seed=None):
        super(NonLinearDGP, self).__init__()

        rng = np.random.RandomState(seed)
        if beta is None:
            beta = rng.randn(feature_dim, 1)
        if w is None:
            w = rng.randn(feature_dim, 1)
        if feature_covariance is None:
            feature_covariance = make_spd_matrix(feature_dim, random_state=seed)
            feature_covariance /= 1e2 * np.linalg.norm(feature_covariance)
        
        self.beta = beta
        self.w = w
        self.feature_covariance = feature_covariance
        self.label_variance = label_variance
        self.degree = degree
        self._po = None

    @property
    def classifier_dim(self):
        return len(self.w)

    def generate_data(self, thetas, seed=None):
        """ Sample a dataset, one point for each classifier theta.

        Arguments:
            - thetas [num_samples, classifier_dim], vector of deployed classifiers.
        """
        rng = np.random.RandomState(seed)
        num_samples, _ = thetas.shape
        features = rng.multivariate_normal(np.zeros(self.classifier_dim),
                                           self.feature_covariance,  num_samples)

        # Simple Nonlinear transform of classifier
        nonlinear_thetas = np.sign(thetas) * np.abs(thetas) ** self.degree

        labels = np.dot(features, self.beta) + np.dot(nonlinear_thetas, self.w)
        label_noise = np.sqrt(self.label_variance) * rng.randn(num_samples, 1)
        return features, labels + label_noise

    def sample_loss(self, thetas, datagen_thetas=None, seed=None):
        """Sample the loss for each theta."""
        if datagen_thetas is None:
            datagen_thetas = thetas 
        features, labels = self.generate_data(datagen_thetas, seed=seed)
        predictions = np.diag(np.dot(features, thetas.T)).reshape(-1, 1)
        return (labels - predictions) ** 2
    
    def population_loss(self, theta, num_samples=500):
        """Approximate the population loss with finite samples."""
        repeated_thetas = np.tile(theta, (1, num_samples)) 
        return np.mean(self.sample_loss(repeated_thetas))

    def compute_performative_optimum(self, box=10, eps=0.1, seed=1234):
        """Compute performative optimum via grid search. 
        
        There's no closed-form solution available, so we resort to brute force.
        WARNING: Very memory and time intensive.
        """
        if self._po is not None:
            return self._po

        base_thetas = np.zeros((self.classifier_dim, 500))
        base_features, base_labels = self.generate_data(base_thetas, seed=seed)

        def fast_proxy_risk(theta):
            """Speed up evaluation by avoiding resampling data."""
            theta = theta.reshape((-1, 1))
            nonlinear_theta = np.sign(theta) * np.abs(theta) ** self.degree
            labels = base_labels + np.dot(nonlinear_theta.T, self.w)
            predictions = np.dot(base_features, theta)
            return np.mean((labels - predictions) ** 2)
 
        rranges = [slice(-box, box, eps) for _ in range(self.classifier_dim)]
        optimal = optimize.brute(fast_proxy_risk, rranges)
        optimal = optimal.reshape(-1, 1)
        self._po = optimal
        return self._po

    
class StratClassDGP(DGP):
    """Generate data from a simple structural equation model.
            X ~ N(0, feature_covariance)
            Y ~ < beta, X> + <w, theta> + N(0, label_variance),

        where theta is the classifier parameters.
    """
    def __init__(self, path_to_csv_file, epsilon, strat_features, lam, seed=None):
        X, Y, data = load_data(path_to_csv_file)
        self.features = np.copy(X)
        self.labels = np.copy(Y)
        self.epsilon = epsilon
        self.strat_features = strat_features
        self.num_points = X.shape[0]
        self.input_dim = X.shape[1] 
        self.data = data
        self.lam = lam
        self._sample_gradient = None
        self.update_matrix = -1 * self.epsilon * np.diag([int(x in set(self.strat_features)) for x in range(self.input_dim)])
        
    @property
    def classifier_dim(self):
        return self.input_dim 
    
    def best_response(self, X, thetas):
        raise NotImplementedError

        
    def generate_data(self, thetas, seed=None, population=False):
        """ Sample a dataset, one point for each classifier theta.

        Arguments:
        """
        num_samples, _ = thetas.shape
        ixs = np.random.choice(self.num_points, size=num_samples, replace=not population)
        features = np.copy(self.features[ixs])
        strat_features = self.best_response(features, thetas)
        labels = np.copy(self.labels[ixs])
        
        return strat_features, labels

    def sample_loss(self, thetas):
        """Sample the loss for each theta."""
        X, Y = self.generate_data(thetas, population=False)
        preds = np.sum(thetas * X, axis=1)
        t1 = -1.0 * (Y * preds) + np.log(1 + np.exp(preds))
        t2 = self.lam / 2.0 * np.square(np.linalg.norm(thetas[:,:-1],axis=1))
        return t1 + t2
    
    def sample_gradient(self, theta):
        x, y = self.generate_data(np.array(theta).reshape(1,-1))
        x = x.flatten()
        y = y.item()
        theta = np.copy(theta).flatten()
        expdot = np.exp(np.dot(x, theta))
        return -y * x + expdot / (1 + expdot) * x + self.lam * np.concatenate((theta[:-1], [0]))

    
    def population_loss(self, theta):
        thetas = np.array([theta,]*self.num_points)
        X, Y = self.generate_data(thetas, population=True)
        t1 =  np.mean(-1.0 * np.multiply(Y, X @ theta) + np.log(1 + np.exp(X @ theta)))
        t2 = self.lam / 2.0 * np.linalg.norm(theta[:-1])**2
        return t1 + t2
    
    def population_accuracy(self, theta):
        thetas = np.array([theta,]*self.num_points)
        X, Y = self.generate_data(thetas, population=True)
        return np.mean((np.dot(X, theta) > 0).astype(np.float32) == Y)

    def compute_performative_optimum(self):
        raise NotImplementedError


class StratClassLinearDGP(StratClassDGP):
    
    def best_response(self, X, thetas):
        return np.copy(X) + np.dot(thetas, self.update_matrix)  
    
class StratClassNonLinearDGP(StratClassDGP):
    
    def best_response(self, X, thetas):
    
        n = X.shape[0]
        X_strat = np.copy(X)
        
        for i in range(n):
            # check if you already have a favorable classification, if so do nothing
            if np.dot(X[i], thetas[i]) < 0:
                pass
            else:
                # check if there is a feasible best response
                X_strat[i, self.strat_features] += -self.epsilon * thetas[i, self.strat_features]
                if np.dot(X_strat[i], thetas[i]) < 0:
                    pass
                else:
                    X_strat[i, self.strat_features] += self.epsilon * thetas[i, self.strat_features]

        return X_strat

    

    
