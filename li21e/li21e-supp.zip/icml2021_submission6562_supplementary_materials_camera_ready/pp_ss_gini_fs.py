from Compiler.types import *
from Compiler.library import *
from Compiler import ml
from Compiler.util import is_zero, tree_reduce
from Compiler import util

# use sfix as main secret data type and set its precision.
sfix.set_precision(16,32)
print_float_precision(20)

class PP_SS_GINI_FS():
    def __init__(self):
        pass

    def matmul(self,mat1,mat2):
        new_rows = mat1.sizes[0]
        new_cols = mat2.sizes[0]
        feature_len = mat1.sizes[1]

        new_mat = Matrix(new_rows,new_cols,sfix)

        @for_range_parallel(32,new_rows)
        def _(i):
            @for_range(new_cols)
            def _(j):
                new_mat[i][j] = sfix.dot_product(mat1[i],mat2[j])

        return new_mat

    def argmin(self,x,max_val):
        min_value = Array(1,sfix)
        min_value.assign_all(max_val)

        min_index = Array(1,sfix)
        min_index.assign_all(-1)

        @for_range_parallel(32,x.length)
        def _(i):
            comp = x[i].__lt__(min_value[0])
            min_value[0] += comp * (x[i] - min_value[0])
            min_index[0] += comp * (i - min_index[0])
        
        return min_index[0]
    
    def valmin(self,x,max_val):
        min_value = Array(1,sfix)
        min_value.assign_all(max_val)

        @for_range_parallel(32,x.length)
        def _(i):
            comp = x[i].__lt__(min_value[0])
            min_value[0] += comp * (x[i] - min_value[0])
        
        return min_value[0]
    
    def build_feature_label_pairs(self,X,label_class_matrix,feature_index,inst_len):
        data_column = Array(inst_len,sfix)
        label_column = Array(inst_len,sfix)

        @for_range(inst_len)
        def _(i):
            data_column[i] = X[i][feature_index]
            label_column[i] = label_class_matrix[i][0]
        
        return data_column, label_column
    
    def cond_swap_with_bit(self, b, x, y):
        bx = b * x
        by = b * y
        return bx + y - by, x - bx + by
    
    def cond_swap(self, x, y):
        b = x < y
        x_new, y_new = self.cond_swap_with_bit(b, x, y)
        return b, x_new, y_new

    # Copied from https://github.com/n1v0lg/strees (they modified from loopy_odd_even_merge_sort in library.py of MP-SPDZ)
    # Using sorting network from Secure training of decision trees with continuous attributes of Mark Abspoel and Daniel Escudero and Nikolaj Volgushev
    # The paper is published on PoPETS 2021 (https://petsymposium.org/2021/)
    # Abspoel, M., Escudero, D., and Volgushev, N. Secure train-ing of decision trees with continuous attributes. InPro-ceedings on Privacy Enhancing Technologies (PoPETs),pp. 167–187, 2021.
    def odd_even_merge_sort(self, keys, values, sorted_length=1, n_parallel=32):
        l = sorted_length
        num_keys = len(keys)
        while l < num_keys:
            l *= 2
            k = 1
            while k < l:
                k *= 2
                n_outer = num_keys // l
                n_inner = l // k
                n_innermost = 1 if k == 2 else k // 2 - 1

                @for_range_parallel(n_parallel // n_innermost // n_inner, n_outer)
                def loop(i):
                    @for_range_parallel(n_parallel // n_innermost, n_inner)
                    def inner(j):
                        base = i * l + j
                        step = l // k
                        if k == 2:
                            outer_comp_bit, keys[base], keys[base + step] = self.cond_swap(
                                keys[base], keys[base + step])
                            values[base], values[base + step] = self.cond_swap_with_bit(
                                outer_comp_bit, values[base], values[base + step])
                        else:
                            @for_range_parallel(n_parallel, n_innermost)
                            def f(i_inner):
                                m1 = step + i_inner * 2 * step
                                m2 = m1 + base
                                inner_comp_bit, keys[m2], keys[m2 + step] = self.cond_swap(
                                    keys[m2], keys[m2 + step])
                                values[m2], values[m2 + step] = self.cond_swap_with_bit(
                                    inner_comp_bit, values[m2], values[m2 + step])

    # Alternative for Protocol 2: Secure GINI Score of a Feature based on sorting network
    def cal_sort_split_gini(self,X,label_class_matrix,feature_index,inst_len,max_val,class_num):
        print_ln("feature_index: %s", feature_index)
        # sort the feature
        start_timer(4)
        data_column, label_column = self.build_feature_label_pairs(X,label_class_matrix,feature_index,inst_len)
        stop_timer(4)
        
        start_timer(5)
        self.odd_even_merge_sort(data_column,label_column)
        stop_timer(5)
        
        start_timer(6)
        feature_gini_scores = Array(inst_len,sfix)
        feature_gini_scores.assign_all(max_val)

        # compute a gini score for all n - 1 thresholds
        @for_range_opt(inst_len - 2)
        def _(i):
            left_total_count = i + 1
            right_total_count = inst_len - left_total_count

            left_counts = Array(class_num,sfix)
            right_counts = Array(class_num,sfix)

            left_counts.assign_all(0)
            right_counts.assign_all(0)

            left_sub_total = Array(1,sfix)
            right_sub_total = Array(1,sfix)

            left_sub_total.assign_all(0)
            right_sub_total.assign_all(0)

            @for_range_opt(i + 1)
            def _(j):
                @for_range_opt(class_num - 1)
                def _(k):
                    left_counts[k] += label_class_matrix[j][k]
                    left_sub_total[0] += label_class_matrix[j][k]
            
            left_counts[class_num - 1] = left_total_count - left_sub_total[0]

            @for_range_opt(inst_len - left_total_count)
            def _(j):
                @for_range_opt(class_num - 1)
                def _(k):
                    right_counts[k] += label_class_matrix[i + 1 + j][k]
                    right_sub_total[0] += label_class_matrix[i + 1 + j][k]
            
            right_counts[class_num - 1] = right_total_count - right_sub_total[0]

            left_score = left_total_count - sfix.dot_product(left_counts,left_counts).mul(1 / left_total_count)
            right_score = right_total_count - sfix.dot_product(right_counts,right_counts).mul(1 / right_total_count)

            temp_feature_gini_score = left_score + right_score

            feature_gini_scores[i] = temp_feature_gini_score
        
        feature_gini_score = self.valmin(feature_gini_scores,max_val)
        stop_timer(6)

        return feature_gini_score
                        

    # Protocol 1: Secure Filter based Feature Selection
    def filter_based_feature_selection(self, X, ss_ginis_arr, raw_features_len, selected_features_len, max_val):
        # initialize relevant variables
        selected_features_indices_arr = Array(selected_features_len,sfix)
        selected_features_indices_arr.assign_all(-1)

        transformation_mat = Matrix(selected_features_len,raw_features_len,sfix)

        start_timer(7)
        # selection
        # Protocol 1, Line 1-8
        @for_range_opt(selected_features_len)
        def _(i):
            selected_features_indices_arr[i] = self.argmin(ss_ginis_arr,max_val)
            
            @for_range_parallel(32,raw_features_len)
            def _(j):
                flag_k = selected_features_indices_arr[i].__eq__(j)
                transformation_mat[i][j] = flag_k
                ss_ginis_arr[j] += flag_k * (max_val - ss_ginis_arr[j])

            #print_ln('selected_feature: %s', selected_features_indices_arr[i].reveal())
        stop_timer(7)
            
        # Protocol 1, Line 9
        start_timer(8)
        selected_X = self.matmul(X,transformation_mat)
        stop_timer(8)

        return selected_X,selected_features_indices_arr
    
    # Protocol 3: Secure Filter-based Feature Selection
    def feature_selection_by_sort_split_gini(self, X, label_class_matrix, inst_len, raw_features_len, selected_features_len, max_val, class_num=2):
        # calculate sort split gini scores for all features
        # Protocol 3, Line 1-3
        start_timer(2)
        ss_ginis_arr = Array(raw_features_len,sfix)
        ss_ginis_arr.assign_all(0)

        @for_range_opt(raw_features_len)
        def _(i):
            ss_ginis_arr[i] = self.cal_sort_split_gini(X,label_class_matrix,i,inst_len,max_val,class_num)
        stop_timer(2)

        # Protocol 3, Line 4
        start_timer(3)
        selected_X,selected_features_indices_arr = self.filter_based_feature_selection(X,ss_ginis_arr,raw_features_len,selected_features_len,max_val)
        stop_timer(3)
        
        return selected_X,selected_features_indices_arr
    
    # K-fold testing
    def k_fold_fs(self,X,label_class_matrix,selected_features_len,fold,max_val,class_num=2):
        #sizes
        inst_len = X.sizes[0]
        raw_features_len = X.sizes[1]
        fold_size = round(inst_len / fold)
        sub_train_len = inst_len - fold_size

        results = Matrix(fold,selected_features_len,sfix)
        
        @for_range_opt(fold)
        def _(i):
            print_ln('fold: %s',i.reveal())
            left_bound = i * fold_size
            potential_right_bound = left_bound + fold_size
            right_comp = potential_right_bound.__lt__(inst_len)
            right_bound = right_comp * potential_right_bound + (1 - right_comp) * inst_len

            @if_e(i < fold - 1)
            def _():
                sub_train_X_mat = Matrix(sub_train_len,raw_features_len,sfix)
                sub_label_class_matrix = Matrix(sub_train_len,class_num - 1,sfix)

                @for_range_opt(left_bound)
                def _(j):
                    sub_train_X_mat[j] = X[j]
                    sub_label_class_matrix[j] = label_class_matrix[j]
                
                @for_range_opt(inst_len - right_bound)
                def _(j):
                    sub_train_X_mat[j+left_bound] = X[j+right_bound]
                    sub_label_class_matrix[j+left_bound] = label_class_matrix[j+right_bound]

                start_timer(1)
                selected_X,selected_features_indices_arr = \
                self.feature_selection_by_sort_split_gini(sub_train_X_mat,sub_label_class_matrix,sub_train_X_mat.sizes[0],raw_features_len,selected_features_len,max_val,class_num)
                stop_timer(1)

                results[i] = selected_features_indices_arr
            @else_
            def _():
                sub_train_X_mat = Matrix(sub_train_len + fold_size * fold - inst_len,raw_features_len,sfix)
                sub_label_class_matrix = Matrix(sub_train_len,class_num - 1,sfix)

                @for_range_opt(left_bound)
                def _(j):
                    sub_train_X_mat[j] = X[j]
                    sub_label_class_matrix[j] = label_class_matrix[j]

                start_timer(1)
                selected_X,selected_features_indices_arr = \
                self.feature_selection_by_sort_split_gini(sub_train_X_mat,sub_label_class_matrix,sub_train_X_mat.sizes[0],raw_features_len,selected_features_len,max_val,class_num)
                stop_timer(1)

                results[i] = selected_features_indices_arr

        return results