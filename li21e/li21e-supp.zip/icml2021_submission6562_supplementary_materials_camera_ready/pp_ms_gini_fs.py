from Compiler.types import *
from Compiler.library import *
from Compiler import ml
from Compiler.util import is_zero, tree_reduce
from Compiler import util

# use sfix as main secret data type and set its precision.
sfix.set_precision(16,32)
print_float_precision(20)

class PP_MS_GINI_FS():
    def __init__(self):
        pass     

    def matmul(self,mat1,mat2):
        new_rows = mat1.sizes[0]
        new_cols = mat2.sizes[0]
        feature_len = mat1.sizes[1]

        new_mat = Matrix(new_rows,new_cols,sfix)

        @for_range_parallel(32,new_rows)
        def _(i):
            @for_range(new_cols)
            def _(j):
                new_mat[i][j] = sfix.dot_product(mat1[i],mat2[j])

        return new_mat

    # Protocol 2: Secure MS-GINI Score of a Feature
    def cal_mean_split_gini(self, X, label_class_matrix, feature_index, inst_len, one_over_inst_len,class_num=2):
        # calculate mean of feature
        # Protocol 2, Line 1
        start_timer(4)
        temp_sum = Array(1,sfix)
        temp_sum.assign_all(0)
        @for_range_opt(inst_len)
        def _(i):
            temp_sum[0] += X[i][feature_index]
        feature_mean = temp_sum[0].mul(one_over_inst_len)
        stop_timer(4)

        #print_ln('%s feature_mean: %s',feature_index,feature_mean.reveal())

        # Protocol 2, Line 2-14
        start_timer(5)
        # initialize counters
        gt_count = Array(1,sfix)
        gt_sub_count = Array(class_num,sfix)
        lt_sub_count = Array(class_num,sfix)

        gt_count.assign_all(0)
        gt_sub_count.assign_all(0)
        lt_sub_count.assign_all(0)

        # calculate counters
        @for_range_opt(inst_len)
        def _(i):
            flag_s = feature_mean.__lt__(X[i][feature_index])
            gt_count[0] = gt_count[0] + flag_s

            @for_range(class_num - 1)
            def _(j):
                flag_m = flag_s * label_class_matrix[i][j]
                gt_sub_count[j] += flag_m
                lt_sub_count[j] += label_class_matrix[i][j] - flag_m

        lt_count = inst_len - gt_count[0]

        @for_range_parallel(32,class_num - 1)
        def _(i):
            lt_sub_count[class_num - 1] += lt_sub_count[i]
            gt_sub_count[class_num - 1] += gt_sub_count[i]

        lt_sub_count[class_num - 1] = lt_count - lt_sub_count[class_num - 1]
        gt_sub_count[class_num - 1] = gt_count[0] - gt_sub_count[class_num - 1]
        stop_timer(5)

        # Protocol 2, Line 15-16
        start_timer(6)
        # calculate scores of subsets    
        lt_score = lt_count - sfix.dot_product(lt_sub_count,lt_sub_count) / lt_count
        gt_score = gt_count[0] - sfix.dot_product(gt_sub_count,gt_sub_count) / gt_count[0]

        # calculate ms gini score of feature
        # Protocol 2, Line 17
        feature_ms_gini = gt_score + lt_score

        #print_ln('ms_gini: %s\n', feature_ms_gini.reveal())
        stop_timer(6)

        return feature_ms_gini
    
    def argmin(self,x,max_val):
        min_value = Array(1,sfix)
        min_value.assign_all(max_val)

        min_index = Array(1,sfix)
        min_index.assign_all(-1)

        @for_range_parallel(32,x.length)
        def _(i):
            comp = x[i].__lt__(min_value[0])
            min_value[0] += comp * (x[i] - min_value[0])
            min_index[0] += comp * (i - min_index[0])
        
        return min_index[0]

    # Protocol 1: Secure Filter based Feature Selection
    def filter_based_feature_selection(self, X, ms_ginis_arr, raw_features_len, selected_features_len, max_val):
        # initialize relevant variables
        selected_features_indices_arr = Array(selected_features_len,sfix)
        selected_features_indices_arr.assign_all(-1)

        transformation_mat = Matrix(selected_features_len,raw_features_len,sfix)

        start_timer(7)
        # selection
        # Protocol 1, Line 1-8
        @for_range_opt(selected_features_len)
        def _(i):
            selected_features_indices_arr[i] = self.argmin(ms_ginis_arr,max_val)
            
            @for_range_parallel(32,raw_features_len)
            def _(j):
                flag_k = selected_features_indices_arr[i].__eq__(j)
                transformation_mat[i][j] = flag_k
                ms_ginis_arr[j] += flag_k * (max_val - ms_ginis_arr[j])

            #print_ln('selected_feature: %s', selected_features_indices_arr[i].reveal())
        stop_timer(7)
            
        # Protocol 1, Line 9
        start_timer(8)
        selected_X = self.matmul(X,transformation_mat)
        stop_timer(8)

        return selected_X,selected_features_indices_arr
    
    # Protocol 3: Secure Filter-based Feature Selection with MS-GINI
    def feature_selection_by_mean_split_gini(self, X, label_class_matrix, inst_len, raw_features_len, selected_features_len, max_val, class_num=2):
        # calculate ms gini scores for all features
        # Protocol 3, Line 1-3
        start_timer(2)
        ms_ginis_arr = Array(raw_features_len,sfix)
        ms_ginis_arr.assign_all(0)
        one_over_inst_len = 1 / inst_len
        @for_range_opt(raw_features_len)
        def _(i):
            ms_ginis_arr[i] = self.cal_mean_split_gini(X,label_class_matrix,i,inst_len,one_over_inst_len,class_num)
        stop_timer(2)

        # Protocol 3, Line 4
        start_timer(3)
        selected_X,selected_features_indices_arr = self.filter_based_feature_selection(X,ms_ginis_arr,raw_features_len,selected_features_len,max_val)
        stop_timer(3)
        
        return selected_X,selected_features_indices_arr

    # K-fold testing
    def k_fold_fs(self,X,label_class_matrix,selected_features_len,fold,max_val,class_num=2):
        #sizes
        inst_len = X.sizes[0]
        raw_features_len = X.sizes[1]
        fold_size = round(inst_len / fold)
        sub_train_len = inst_len - fold_size

        results = Matrix(fold,selected_features_len,sfix)
        
        @for_range_opt(fold)
        def _(i):
            print_ln('fold: %s',i.reveal())
            left_bound = i * fold_size
            potential_right_bound = left_bound + fold_size
            right_comp = potential_right_bound.__lt__(inst_len)
            right_bound = right_comp * potential_right_bound + (1 - right_comp) * inst_len

            @if_e(i < fold - 1)
            def _():
                sub_train_X_mat = Matrix(sub_train_len,raw_features_len,sfix)
                sub_label_class_matrix = Matrix(sub_train_len,class_num - 1,sfix)

                @for_range_opt(left_bound)
                def _(j):
                    sub_train_X_mat[j] = X[j]
                    sub_label_class_matrix[j] = label_class_matrix[j]
                
                @for_range_opt(inst_len - right_bound)
                def _(j):
                    sub_train_X_mat[j+left_bound] = X[j+right_bound]
                    sub_label_class_matrix[j+left_bound] = label_class_matrix[j+right_bound]

                start_timer(1)
                selected_X,selected_features_indices_arr = \
                self.feature_selection_by_mean_split_gini(sub_train_X_mat,sub_label_class_matrix,sub_train_X_mat.sizes[0],raw_features_len,selected_features_len,max_val,class_num)
                stop_timer(1)

                results[i] = selected_features_indices_arr
            @else_
            def _():
                sub_train_X_mat = Matrix(sub_train_len + fold_size * fold - inst_len,raw_features_len,sfix)
                sub_label_class_matrix = Matrix(sub_train_len,class_num - 1,sfix)

                @for_range_opt(left_bound)
                def _(j):
                    sub_train_X_mat[j] = X[j]
                    sub_label_class_matrix[j] = label_class_matrix[j]

                start_timer(1)
                selected_X,selected_features_indices_arr = \
                self.feature_selection_by_mean_split_gini(sub_train_X_mat,sub_label_class_matrix,sub_train_X_mat.sizes[0],raw_features_len,selected_features_len,max_val,class_num)
                stop_timer(1)

                results[i] = selected_features_indices_arr

        return results