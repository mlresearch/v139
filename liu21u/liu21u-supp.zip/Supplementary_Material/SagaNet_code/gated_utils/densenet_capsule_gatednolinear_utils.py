from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

import os
from keras import layers, backend, engine, models
from keras.layers.convolutional import Deconv2D, Conv2D, \
    MaxPooling2D
from keras.layers.core import Lambda, Reshape
from keras.initializers import he_uniform, he_normal
from keras import utils as keras_utils
from keras.applications import imagenet_utils
from Capsule_Keras import Capsule, squash
import keras.backend as K
from keras.activations import sigmoid

preprocess_input = imagenet_utils.preprocess_input



class Padding2D(layers.Layer):

    def __init__(self, output_dim, padding=None, mode='SYMMETRIC',
                 name=None,
                 data_format="channels_last", **kwargs):
        self.output_dim = output_dim
        self.data_format = data_format
        self.padding = padding
        self.mode = mode
        self.name = name
        super(Padding2D, self).__init__(**kwargs)

    def build(self, input_shape):
        super(Padding2D, self).build(input_shape)

    def call(self, inputs, **kwargs):
        pad = None
        if self.data_format is "channels_last":
            # (batch, depth, rows, cols, channels)
            pad = [[0, 0]] + [[i, i] for i in self.padding] + [[0, 0]]
        elif self.data_format is "channels_first":
            # (batch, channels, depth, rows, cols)
            pad = [[0, 0], [0, 0]] + [[i, i] for i in self.padding]

        if K.backend() == "tensorflow":
            import tensorflow as tf
            paddings = tf.constant(pad)
            out = tf.pad(inputs, paddings,
                         mode=self.mode, name=self.name)
        else:
            raise Exception("Backend " + K.backend() + "not implemented")
        return out

    def compute_output_shape(self, input_shape):
        return (input_shape[0], self.output_dim)


def gen_conv(x, cnum, ksize, stride=1, rate=1, name='gated_conv',
             kernel_regularizer=None,
             padding='SAME', activation=layers.ELU, training=True):
    """Define conv for generator.

    Args:
        x: Input.
        cnum: Channel number.
        ksize: Kernel size.
        Stride: Convolution stride.
        Rate: Rate for or dilated conv.
        name: Name of layers.
        padding: Default to SYMMETRIC.
        activation: Activation function after convolution.
        training: If current graph is for training or inference, used for bn.

    Returns:
        tf.Tensor: output

    """
    assert padding in ['SYMMETRIC', 'SAME', 'REFELECT']
    if padding == 'SYMMETRIC' or padding == 'REFELECT':
        p = int(rate * (ksize - 1) / 2)
        # x = tf.pad(x, [[0,0], [p, p], [p, p], [0,0]], mode=padding)
        out_dim = K.int_shape(x)[-1]
        sym_ref_pad_layer = Padding2D(output_dim=out_dim,
                                      padding=[p, p],
                                      mode=padding,
                                      name=name + '_pad')
        x = sym_ref_pad_layer(x)
        padding = 'VALID'
    # x = tf.layers.conv2d(
    #     x, cnum, ksize, stride, dilation_rate=rate,
    #     activation=None, padding=padding, name=name)
    xy = layers.Conv2D(filters=cnum * 2,
                       kernel_size=ksize,
                       strides=stride,
                       use_bias=False,
                       dilation_rate=rate,
                       kernel_initializer=he_normal(seed=7),
                       kernel_regularizer=kernel_regularizer,
                       activation=None,
                       padding=padding,
                       name=name + '_conv')(x)
    if activation is None:  # the last layer
        # conv for output
        return x
    # x, y = tf.split(x, num_or_size_splits=2, axis=3)
    x = Lambda(lambda xxx: K.slice(xxx, (0, 0, 0, 0),
                                   (-1, -1, -1, cnum)),
               name=name + '_lambdax')(xy)
    y = Lambda(lambda xxx: K.slice(xxx, (0, 0, 0, cnum),
                                   (-1, -1, -1, cnum)),
               name=name + 'lambday')(xy)
    # x = activation(name=name + '_act1')(x)
    # y = tf.nn.sigmoid(y)
    # y = sigmoid(y)
    y = layers.Activation(activation='sigmoid', name=name + '_act2')(y)
    # x = x * y
    x = layers.multiply([x, y], name=name + 'multi')
    return x


def gen_deconv(x, cnum, ksize, kernel_regularizer=None,
               name='upsample', padding='SAME', training=True):
    """Define deconv for generator.
    The deconv is defined to be a x2 resize_nearest_neighbor operation with
    additional gen_conv operation.

    Args:
        x: Input.
        cnum: Channel number.
        name: Name of layers.
        training: If current graph is for training or inference, used for bn.

    Returns:
        tf.Tensor: output

    """
    # x = resize(x, func=tf.image.resize_nearest_neighbor)
    x = layers.UpSampling2D(size=(2, 2), interpolation='nearest',
                            name=name + '_upsample')(x)
    x = gen_conv(
        x, cnum=cnum, ksize=ksize, stride=1,
        name=name + '_conv', padding=padding,
        kernel_regularizer=kernel_regularizer,
        training=training)
    return x


def dense_block(x, blocks, name):
    """A dense block.

    # Arguments
        x: input tensor.
        blocks: integer, the number of building blocks.
        name: string, block label.

    # Returns
        output tensor for the block.
    """
    for i in range(blocks):
        x = conv_block(x, growth_rate=32,
                       name=name + '_block' + str(i + 1))
    return x


def transition_block(x, reduction, name, kernel_regularizer=None):
    """A transition block.

    # Arguments
        x: input tensor.
        reduction: float, compression rate at transition layers.
        name: string, block label.

    # Returns
        output tensor for the block.
    """
    bn_axis = 3 if backend.image_data_format() == 'channels_last' else 1
    x = layers.BatchNormalization(axis=bn_axis, epsilon=1.001e-5,
                                  name=name + '_bn')(x)
    # x = layers.Activation('relu', name=name + '_relu')(x)
    # x = layers.Conv2D(filters=int(backend.int_shape(x)[bn_axis] * reduction),
    #                   kernel_size=1,
    #                   use_bias=False,
    #                   kernel_regularizer=kernel_regularizer,
    #                   name=name + '_conv')(x)
    x = gen_conv(x=x, cnum=int(backend.int_shape(x)[bn_axis] * reduction),
                 kernel_regularizer=kernel_regularizer,
                 ksize=1,
                 stride=1,
                 name=name + '_gated_conv')
    x = layers.AveragePooling2D(2, strides=2, name=name + '_pool')(x)
    return x


def conv_block(x, growth_rate, name, kernel_regularizer=None, dropout_p=0.):
    """A building block for a dense block.

    # Arguments
        x: input tensor.
        growth_rate: float, growth rate at dense layers.
        name: string, block label.

    # Returns
        Output tensor for the block.
    """
    bn_axis = 3 if backend.image_data_format() == 'channels_last' else 1
    x1 = layers.BatchNormalization(axis=bn_axis,
                                   epsilon=1.001e-5,
                                   name=name + '_0_bn')(x)
    # x1 = layers.Activation('relu', name=name + '_0_relu')(x1)
    # x1 = layers.Conv2D(filters=4 * growth_rate,
    #                    kernel_size=1,
    #                    use_bias=False,
    #                    kernel_regularizer=kernel_regularizer,
    #                    name=name + '_1_conv')(x1)
    x1 = gen_conv(x=x1, cnum=4 * growth_rate, ksize=1,
                  stride=1,
                  kernel_regularizer=kernel_regularizer,
                  name=name + '_gated_conv0')
    x1 = layers.BatchNormalization(axis=bn_axis, epsilon=1.001e-5,
                                   name=name + '_1_bn')(x1)
    # x1 = layers.Activation('relu', name=name + '_1_relu')(x1)
    # x1 = layers.Conv2D(growth_rate, 3,
    #                    padding='same',
    #                    use_bias=False,
    #                    kernel_regularizer=kernel_regularizer,
    #                    name=name + '_2_conv')(x1)
    x1 = gen_conv(x=x1, cnum=growth_rate, ksize=3,
                  stride=1,
                  kernel_regularizer=kernel_regularizer,
                  name=name + '_gated_conv1')
    if dropout_p != 0.:
        x1 = layers.Dropout(dropout_p, name=name + 'drop')(x1)
    # x = layers.Concatenate(axis=bn_axis, name=name + '_concat')([x, x1])
    return x1


def TransitionUp(skip_connection, block_to_upsample,
                 n_filters_keep, name, kernel_regularizer=None):
    """
    Performs upsampling on block_to_upsample by a factor 2 and concatenates it with the skip_connection """

    # Upsample
    bn_axis = 3 if backend.image_data_format() == 'channels_last' else 1
    if len(block_to_upsample) > 1:
        l = layers.Concatenate(axis=bn_axis,
                               name=name + '_concat0')(block_to_upsample)
    else:
        l = block_to_upsample[0]
    # l = Deconv2D(n_filters_keep, kernel_size=3, strides=2,
    #              padding='same',
    #              kernel_regularizer=kernel_regularizer,
    #              activation='linear')(l)
    l = gen_deconv(l, cnum=n_filters_keep, ksize=3, padding='SAME',
                   kernel_regularizer=kernel_regularizer,
                   name=name + "_gendeconv")
    # Concatenate with skip connection
    l = layers.Concatenate(axis=bn_axis,
                           name=name + '_concat1')([l, skip_connection])

    return l


def gated_DenseNet_func(blocks,
                        # capsule_num_1,
                        # dim_capsule_1,
                        # capsule_num_2,
                        # dim_capsule_2,
                        include_top=True,
                        weights='imagenet',
                        finetune_flag=True,
                        input_tensor=None,
                        input_shape=None,
                        kernel_regularizer=None,
                        dropout_p=0.,
                        pooling=None,
                        classes=1000):
    """Instantiates the DenseNet architecture.

    Optionally loads weights pre-trained on ImageNet.
    Note that the data format convention used by the model is
    the one specified in your Keras config at `~/.keras/keras.json`.

    # Arguments
        blocks: numbers of building blocks for the four dense layers.
        include_top: whether to include the fully-connected
            layer at the top of the network.
        weights: one of `None` (random initialization),
              'imagenet' (pre-training on ImageNet),
              or the path to the weights file to be loaded.
        input_tensor: optional Keras tensor
            (i.e. output of `layers.Input()`)d
            to use as image input for the model.
        input_shape: optional shape tuple, only to be specified
            if `include_top` is False (otherwise the input shape
            has to be `(224, 224, 3)` (with `channels_last` data format)
            or `(3, 224, 224)` (with `channels_first` data format).
            It should have exactly 3 inputs channels.
        pooling: optional pooling mode for feature extraction
            when `include_top` is `False`.
            - `None` means that the output of the model will be
                the 4D tensor output of the
                last convolutional layer.
            - `avg` means that global average pooling
                will be applied to the output of the
                last convolutional layer, and thus
                the output of the model will be a 2D tensor.
            - `max` means that global max pooling will
                be applied.
        classes: optional number of classes to classify images
            into, only to be specified if `include_top` is True, and
            if no `weights` argument is specified.

    # Returns
        A Keras model instance.

    # Raises
        ValueError: in case of invalid argument for `weights`,
            or invalid input shape.
    """
    # Determine proper input shape
    input_shape = _obtain_input_shape(input_shape,
                                      default_size=224,
                                      min_size=221,
                                      data_format=backend.image_data_format(),
                                      require_flatten=include_top,
                                      weights=weights)
    if input_tensor is None:
        img_input = layers.Input(shape=input_shape)
    else:
        if not backend.is_keras_tensor(input_tensor):
            img_input = layers.Input(tensor=input_tensor, shape=input_shape)
        else:
            img_input = input_tensor

    n_layers_per_block = [1, 1, 2, 2, 3, 2, 2, 1, 1]
    n_pool = 4
    growth_rate = 32
    name = 'fc_dense'
    n_filters = 64

    bn_axis = 3 if backend.image_data_format() == 'channels_last' else 1

    #####################
    # First Convolution #
    #####################
    # x = layers.ZeroPadding2D(padding=((3, 3), (3, 3)))(img_input)
    # x = layers.Conv2D(n_filters, 7, strides=2, padding='same',
    #                   kernel_regularizer=kernel_regularizer,
    #                   use_bias=False, name='conv1/conv')(img_input)
    x = gen_conv(img_input, cnum=n_filters, ksize=5, stride=2,
                 padding='SAME', kernel_regularizer=kernel_regularizer,
                 name='conv1/conv')
    x = layers.BatchNormalization(
        axis=bn_axis, epsilon=1.001e-5, name='conv1/bn')(x)
    # x = layers.Activation('relu', name='conv1/relu')(x)
    x = layers.ELU(name='conv1/elu')(x)
    # x = layers.ZeroPadding2D(padding=((1, 1), (1, 1)))(x)
    # x = layers.MaxPooling2D(3, strides=2, name='pool1')(x)

    #####################
    # Downsampling path #
    #####################
    skip_connection_list = []
    stack = x
    for i in range(n_pool):
        # Dense Block
        for j in range(n_layers_per_block[i]):
            # Compute new feature maps
            l = conv_block(stack, growth_rate=growth_rate,
                           kernel_regularizer=kernel_regularizer,
                           dropout_p=dropout_p,
                           name=name + '_block' + str(i) + '_' + str(j))
            # And stack it : the Tiramisu is growing
            stack = \
                layers.Concatenate(axis=bn_axis,
                                   name=name + '_concat' +
                                        str(i) + '_' + str(j))([stack, l])
            n_filters += growth_rate
        # At the end of the dense block, the current stack is stored
        # in the skip_connections list
        skip_connection_list.append(stack)

        # if i < n_pool - 1:
        # Transition Down
        stack = \
            transition_block(stack, reduction=0.5,
                             name=name + 'pool' + str(i))
    skip_connection_list = skip_connection_list[::-1]

    stack = layers.BatchNormalization(
        axis=bn_axis, epsilon=1.001e-5, name=name + 'bn')(stack)

    feature1 = stack
    #####################
    #     Bottleneck    #
    #####################

    # We store now the output of the next dense block in a list.
    #  We will only upsample these new feature maps
    block_to_upsample = []

    # Dense Block
    for j in range(n_layers_per_block[n_pool]):
        l = conv_block(stack, growth_rate=growth_rate,
                       kernel_regularizer=kernel_regularizer,
                       dropout_p=dropout_p,
                       name=name + '_neck_block' + str(j))
        block_to_upsample.append(l)
        stack = \
            layers.Concatenate(axis=bn_axis,
                               name=name + '_neck_concat' + str(j))([stack, l])
    # feature2 = layers.Concatenate(axis=bn_axis,
    #                               name=name + '_concat')(block_to_upsample)

    #######################
    #   Upsampling path   #
    #######################

    for i in range(n_pool):
        # Transition Up ( Upsampling + concatenation with the skip connection)
        n_filters_keep = growth_rate * n_layers_per_block[n_pool + i]
        stack = TransitionUp(skip_connection_list[i],
                             block_to_upsample, n_filters_keep,
                             name=name + '_transup' + str(i))

        # Dense Block
        block_to_upsample = []
        for j in range(n_layers_per_block[n_pool + i + 1]):
            l = conv_block(stack, growth_rate=growth_rate,
                           kernel_regularizer=kernel_regularizer,
                           dropout_p=dropout_p,
                           name=name + '_dec_block' +
                                str(i) + '_' + str(j))
            block_to_upsample.append(l)
            stack = layers.Concatenate(axis=bn_axis,
                                       name=name + '_dec_concat' +
                                            str(i) + '_' + str(j))([stack, l])

    #####################
    #    Final Layer    #
    #####################

    # rec_x = Deconv2D(filters=3, kernel_size=3, strides=2, padding='same',
    #                  kernel_regularizer=kernel_regularizer,
    #                  name='last_conv', activation='softmax')(stack)
    rec_x = gen_deconv(stack, cnum=3, ksize=3, padding='SAME',
                       kernel_regularizer=kernel_regularizer,
                       name=name + 'last_deconv')
    rec_x = layers.Activation(activation='softmax', name='gated_autoenc')(rec_x)

    # model = models.Model(inputs=img_input, outputs=feature1)
    # ae_model = models.Model(inputs=img_input, outputs=rec_x,
    #                         name='gated_autoenc')

    return feature1, rec_x


def gated_DenseNet(blocks,
                   # capsule_num_1,
                   # dim_capsule_1,
                   # capsule_num_2,
                   # dim_capsule_2,
                   include_top=True,
                   weights='imagenet',
                   finetune_flag=True,
                   input_tensor=None,
                   input_shape=None,
                   kernel_regularizer=None,
                   dropout_p=0.,
                   pooling=None,
                   classes=1000):
    """Instantiates the DenseNet architecture.

    Optionally loads weights pre-trained on ImageNet.
    Note that the data format convention used by the model is
    the one specified in your Keras config at `~/.keras/keras.json`.

    # Arguments
        blocks: numbers of building blocks for the four dense layers.
        include_top: whether to include the fully-connected
            layer at the top of the network.
        weights: one of `None` (random initialization),
              'imagenet' (pre-training on ImageNet),
              or the path to the weights file to be loaded.
        input_tensor: optional Keras tensor
            (i.e. output of `layers.Input()`)d
            to use as image input for the model.
        input_shape: optional shape tuple, only to be specified
            if `include_top` is False (otherwise the input shape
            has to be `(224, 224, 3)` (with `channels_last` data format)
            or `(3, 224, 224)` (with `channels_first` data format).
            It should have exactly 3 inputs channels.
        pooling: optional pooling mode for feature extraction
            when `include_top` is `False`.
            - `None` means that the output of the model will be
                the 4D tensor output of the
                last convolutional layer.
            - `avg` means that global average pooling
                will be applied to the output of the
                last convolutional layer, and thus
                the output of the model will be a 2D tensor.
            - `max` means that global max pooling will
                be applied.
        classes: optional number of classes to classify images
            into, only to be specified if `include_top` is True, and
            if no `weights` argument is specified.

    # Returns
        A Keras model instance.

    # Raises
        ValueError: in case of invalid argument for `weights`,
            or invalid input shape.
    """
    # Determine proper input shape
    input_shape = _obtain_input_shape(input_shape,
                                      default_size=224,
                                      min_size=221,
                                      data_format=backend.image_data_format(),
                                      require_flatten=include_top,
                                      weights=weights)
    if input_tensor is None:
        img_input = layers.Input(shape=input_shape)
    else:
        if not backend.is_keras_tensor(input_tensor):
            img_input = layers.Input(tensor=input_tensor, shape=input_shape)
        else:
            img_input = input_tensor

    n_layers_per_block = [1, 1, 2, 2, 3, 2, 2, 1, 1]
    n_pool = 4
    growth_rate = 32
    name = 'fc_dense'
    n_filters = 64

    bn_axis = 3 if backend.image_data_format() == 'channels_last' else 1

    #####################
    # First Convolution #
    #####################
    # x = layers.ZeroPadding2D(padding=((3, 3), (3, 3)))(img_input)
    # x = layers.Conv2D(n_filters, 7, strides=2, padding='same',
    #                   kernel_regularizer=kernel_regularizer,
    #                   use_bias=False, name='conv1/conv')(img_input)
    x = gen_conv(img_input, cnum=n_filters, ksize=5, stride=2,
                 padding='SAME', kernel_regularizer=kernel_regularizer,
                 name='conv1/conv')
    x = layers.BatchNormalization(
        axis=bn_axis, epsilon=1.001e-5, name='conv1/bn')(x)
    # x = layers.Activation('relu', name='conv1/relu')(x)
    x = layers.ELU(name='conv1/elu')(x)
    # x = layers.ZeroPadding2D(padding=((1, 1), (1, 1)))(x)
    # x = layers.MaxPooling2D(3, strides=2, name='pool1')(x)

    #####################
    # Downsampling path #
    #####################
    skip_connection_list = []
    stack = x
    for i in range(n_pool):
        # Dense Block
        for j in range(n_layers_per_block[i]):
            # Compute new feature maps
            l = conv_block(stack, growth_rate=growth_rate,
                           kernel_regularizer=kernel_regularizer,
                           dropout_p=dropout_p,
                           name=name + '_block' + str(i) + '_' + str(j))
            # And stack it : the Tiramisu is growing
            stack = \
                layers.Concatenate(axis=bn_axis,
                                   name=name + '_concat' +
                                        str(i) + '_' + str(j))([stack, l])
            n_filters += growth_rate
        # At the end of the dense block, the current stack is stored
        # in the skip_connections list
        skip_connection_list.append(stack)

        # if i < n_pool - 1:
        # Transition Down
        stack = \
            transition_block(stack, reduction=0.5,
                             name=name + 'pool' + str(i))
    skip_connection_list = skip_connection_list[::-1]

    stack = layers.BatchNormalization(
        axis=bn_axis, epsilon=1.001e-5, name=name + 'bn')(stack)

    #####################
    #     Capsule Output    #
    #####################
    ########################## conv_f prepare ############################
    # conv_f = stack
    # fetch_num = 2
    # assert fetch_num <= n_pool
    # for fetch_i in range(fetch_num):
    #     fetch_idx = fetch_i + 1
    #     ff = \
    #         layers.AveragePooling2D(pool_size=(2 * (fetch_idx), 2 * (fetch_idx)))\
    #             (skip_connection_list[fetch_i])
    #     conv_f = \
    #         layers.Concatenate(axis=-1,
    #                            name=name + '_preconcat_' + str(fetch_i))\
    #             ([conv_f, ff])
    # ########################## Primary CapLayer ##########################
    #
    # pri_capsule = Conv2D(filters=capsule_num_1 * dim_capsule_1,
    #                      kernel_size=(1, 1), strides=(1, 1), padding='same',
    #                      name='primarycap_conv2d')(conv_f)
    # pri_capsule = Reshape((-1, dim_capsule_1))(pri_capsule)
    # pri_capsule = Lambda(squash, name='primarycap_squash')(pri_capsule)
    # ########################### Capsule ################################
    # capsule = Capsule(num_capsule=capsule_num_2,
    #                   dim_capsule=dim_capsule_2,
    #                   routings=3, share_weights=True)(pri_capsule)
    # output_f = Lambda(lambda x: K.sqrt(K.sum(K.square(x), 2)),
    #                        output_shape=(capsule_num_2,))(capsule)  # Length
    # feature1 = output_f
    feature1 = stack
    #####################
    #     Bottleneck    #
    #####################

    # We store now the output of the next dense block in a list.
    #  We will only upsample these new feature maps
    block_to_upsample = []

    # Dense Block
    for j in range(n_layers_per_block[n_pool]):
        l = conv_block(stack, growth_rate=growth_rate,
                       kernel_regularizer=kernel_regularizer,
                       dropout_p=dropout_p,
                       name=name + '_neck_block' + str(j))
        block_to_upsample.append(l)
        stack = \
            layers.Concatenate(axis=bn_axis,
                               name=name + '_neck_concat' + str(j))([stack, l])
    # feature2 = layers.Concatenate(axis=bn_axis,
    #                               name=name + '_concat')(block_to_upsample)

    #######################
    #   Upsampling path   #
    #######################

    for i in range(n_pool):
        # Transition Up ( Upsampling + concatenation with the skip connection)
        n_filters_keep = growth_rate * n_layers_per_block[n_pool + i]
        stack = TransitionUp(skip_connection_list[i],
                             block_to_upsample, n_filters_keep,
                             name=name + '_transup' + str(i))

        # Dense Block
        block_to_upsample = []
        for j in range(n_layers_per_block[n_pool + i + 1]):
            l = conv_block(stack, growth_rate=growth_rate,
                           kernel_regularizer=kernel_regularizer,
                           dropout_p=dropout_p,
                           name=name + '_dec_block' +
                                str(i) + '_' + str(j))
            block_to_upsample.append(l)
            stack = layers.Concatenate(axis=bn_axis,
                                       name=name + '_dec_concat' +
                                            str(i) + '_' + str(j))([stack, l])

    #####################
    #    Final Layer    #
    #####################

    # rec_x = Deconv2D(filters=3, kernel_size=3, strides=2, padding='same',
    #                  kernel_regularizer=kernel_regularizer,
    #                  name='last_conv', activation='softmax')(stack)
    rec_x = gen_deconv(stack, cnum=3, ksize=3, padding='SAME',
                       kernel_regularizer=kernel_regularizer,
                       name=name + 'last_deconv')
    rec_x = layers.Activation(activation='softmax', name='softmax')(rec_x)

    model = models.Model(inputs=img_input, outputs=feature1)
    ae_model = models.Model(inputs=img_input, outputs=rec_x,
                            name='gated_autoenc')

    return model, ae_model


# def DenseNet121(include_top=True,
#                 weights='imagenet',
#                 finetune_flag=True,
#                 input_tensor=None,
#                 input_shape=None,
#                 pooling=None,
#                 classes=1000):
#     return DenseNet([6, 12, 24, 16],
#                     include_top, weights, finetune_flag,
#                     input_tensor, input_shape,
#                     pooling, classes)
#
#
# def DenseNet169(include_top=True,
#                 weights='imagenet',
#                 finetune_flag=True,
#                 input_tensor=None,
#                 input_shape=None,
#                 pooling=None,
#                 classes=1000):
#     return DenseNet([6, 12, 32, 32],
#                     include_top, weights, finetune_flag,
#                     input_tensor, input_shape,
#                     pooling, classes)
#
#
# def DenseNet201(include_top=True,
#                 weights='imagenet',
#                 finetune_flag=True,
#                 input_tensor=None,
#                 input_shape=None,
#                 pooling=None,
#                 classes=1000):
#     return DenseNet([6, 12, 48, 32],
#                     include_top, weights, finetune_flag,
#                     input_tensor, input_shape,
#                     pooling, classes)


def preprocess_input(x, data_format=None):
    """Preprocesses a numpy array encoding a batch of images.

    # Arguments
        x: a 3D or 4D numpy array consists of RGB values within [0, 255].
        data_format: data format of the image tensor.

    # Returns
        Preprocessed array.
    """
    return imagenet_utils.preprocess_input(x, data_format, mode='torch')


#
# setattr(DenseNet121, '__doc__', DenseNet.__doc__)
# setattr(DenseNet169, '__doc__', DenseNet.__doc__)
# setattr(DenseNet201, '__doc__', DenseNet.__doc__)

import warnings


def _obtain_input_shape(input_shape,
                        default_size,
                        min_size,
                        data_format,
                        require_flatten,
                        weights=None):
    """Internal utility to compute/validate a model's input shape.

    # Arguments
        input_shape: Either None (will return the default network input shape),
            or a user-provided shape to be validated.
        default_size: Default input width/height for the model.
        min_size: Minimum input width/height accepted by the model.
        data_format: Image data format to use.
        require_flatten: Whether the model is expected to
            be linked to a classifier via a Flatten layer.
        weights: One of `None` (random initialization)
            or 'imagenet' (pre-training on ImageNet).
            If weights='imagenet' input channels must be equal to 3.

    # Returns
        An integer shape tuple (may include None entries).

    # Raises
        ValueError: In case of invalid argument values.
    """
    if weights != 'imagenet' and input_shape and len(input_shape) == 3:
        if data_format == 'channels_first':
            if input_shape[0] not in {1, 3}:
                warnings.warn(
                    'This model usually expects 1 or 3 input channels. '
                    'However, it was passed an input_shape with ' +
                    str(input_shape[0]) + ' input channels.')
            default_shape = (input_shape[0], default_size, default_size)
        else:
            if input_shape[-1] not in {1, 3, 6, 9}:
                warnings.warn(
                    'This model usually expects 1 or 3 input channels. '
                    'However, it was passed an input_shape with ' +
                    str(input_shape[-1]) + ' input channels.')
            default_shape = (default_size, default_size, input_shape[-1])
    else:
        if data_format == 'channels_first':
            default_shape = (3, default_size, default_size)
        else:
            default_shape = (default_size, default_size, 3)
    if weights == 'imagenet' and require_flatten:
        if input_shape is not None:
            if input_shape != default_shape:
                raise ValueError('When setting`include_top=True` '
                                 'and loading `imagenet` weights, '
                                 '`input_shape` should be ' +
                                 str(default_shape) + '.')
        return default_shape
    if input_shape:
        if data_format == 'channels_first':
            if input_shape is not None:
                if len(input_shape) != 3:
                    raise ValueError(
                        '`input_shape` must be a tuple of three integers.')
                if input_shape[0] != 3 and weights == 'imagenet':
                    raise ValueError('The input must have 3 channels; got '
                                     '`input_shape=' + str(input_shape) + '`')
                if ((input_shape[1] is not None and input_shape[
                    1] < min_size) or
                        (input_shape[2] is not None and input_shape[
                            2] < min_size)):
                    raise ValueError('Input size must be at least ' +
                                     str(min_size) + 'x' + str(min_size) +
                                     '; got `input_shape=' +
                                     str(input_shape) + '`')
        else:
            if input_shape is not None:
                if len(input_shape) != 3:
                    raise ValueError(
                        '`input_shape` must be a tuple of three integers.')
                if input_shape[-1] != 3 and weights == 'imagenet':
                    raise ValueError('The input must have 3 channels; got '
                                     '`input_shape=' + str(input_shape) + '`')
                if ((input_shape[0] is not None and input_shape[
                    0] < min_size) or
                        (input_shape[1] is not None and input_shape[
                            1] < min_size)):
                    raise ValueError('Input size must be at least ' +
                                     str(min_size) + 'x' + str(min_size) +
                                     '; got `input_shape=' +
                                     str(input_shape) + '`')
    else:
        if require_flatten:
            input_shape = default_shape
        else:
            if data_format == 'channels_first':
                input_shape = (3, None, None)
            else:
                input_shape = (None, None, 3)
    if require_flatten:
        if None in input_shape:
            raise ValueError('If `include_top` is True, '
                             'you should specify a static `input_shape`. '
                             'Got `input_shape=' + str(input_shape) + '`')
    return input_shape
