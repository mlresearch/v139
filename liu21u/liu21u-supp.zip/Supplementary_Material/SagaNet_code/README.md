# SagaNet: A Small Sample Gated Network for Pediatric Cancer Diagnosis



### A brief description
A delicate classification model for small sample pathological datasets.

### Requirements
Python3.6 \
tensorflow-gpu==2.1.0 \
Keras==2.3.1 \
GPU Nvidia RTX 2080Ti \
Please see requirement.txt for other packages. 

### Usage

1 Download the BreakHist dataset from https://web.inf.ufpr.br/vri/databases/breast-cancer-histopathological-database-breakhis/.

2 Perform image processing following the order in data_process/README.txt on the BreakHist dataset。

3 run saga_hinge_gated_reconst_mask.py