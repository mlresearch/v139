import tensorflow as tf
import os
os.environ['CUDA_VISIBLE_DEVICES'] = "3"
print(tf.config.list_physical_devices('GPU'))