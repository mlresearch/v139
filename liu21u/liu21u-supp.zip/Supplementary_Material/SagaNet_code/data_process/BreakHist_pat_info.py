import os
import json
import re

data_home_dir = ''
sv_dir = os.path.join(data_home_dir, 'BreakHist_Split')
if not os.path.exists(sv_dir):
    os.mkdir(sv_dir)
sv_pat_lst_dict_path = os.path.join(sv_dir, 'pat_lst_dict.json')
source_dir = os.path.join(data_home_dir, 'BreakHist', '40X')

cls_lst = ['Benign', 'Malignant']
cls_dict = {}
cls_rev_dict = {}
sub_cls_pat_lst_dict = {}
pat_im_num_dict = {}
for cls_i in cls_lst:
    cls_dir = os.path.join(source_dir, cls_i)
    sub_cls_lst = os.listdir(cls_dir)
    cls_dict[cls_i] = sub_cls_lst
    for sub_cls_i in sub_cls_lst:
        cls_rev_dict[sub_cls_i] = cls_i
        sub_cls_dir = os.path.join(cls_dir, sub_cls_i)
        im_nm_lst = os.listdir(sub_cls_dir)
        sub_pat_lst = []
        last_pat_id = None
        for im_nm_i in im_nm_lst:
            ind_lst = [re_g.start() for re_g in re.finditer('-', im_nm_i)]
            ind_s = im_nm_i.find('_') + 1
            ind_e = ind_lst[2]
            pat_id = im_nm_i[ind_s: ind_e]
            if pat_id not in sub_pat_lst:
                sub_pat_lst.append(pat_id)
                pat_im_num_dict[pat_id] = 1
            else:
                pat_im_num_dict[pat_id] += 1
        sub_cls_pat_lst_dict[sub_cls_i] = sub_pat_lst

sv_lst = [cls_dict, cls_rev_dict, sub_cls_pat_lst_dict, pat_im_num_dict]
with open(sv_pat_lst_dict_path, 'w') as json_f:
    json.dump(sv_lst, json_f, indent=2)
