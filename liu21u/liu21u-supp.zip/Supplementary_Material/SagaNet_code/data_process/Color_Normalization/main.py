import os
# import numpy as np
# import matplotlib.pyplot as plt
# import spams
# import cv2
import utils
from vahadane import vahadane
# from sklearn.manifold import TSNE
import shutil
import imghdr
from PIL import Image
import time
timestr = time.strftime("%Y%m%d-%H%M%S")
print(timestr)
# %load_ext autoreload
# %autoreload 2
# %matplotlib inline

target_home_dir = '../..'
TARGET_PATH = os.path.join(target_home_dir, 'target', 'UD-P15-603-027.png')
source_home_dir = ''
SOURCE_DIR = os.path.join(source_home_dir, 'BreakHist')
RESULT_DIR = os.path.join(source_home_dir, 'BreakHist_ClrNorm_Vahadane')
if not os.path.exists(RESULT_DIR):
    os.mkdir(RESULT_DIR)
txt_file_path = os.path.join(RESULT_DIR, 'README_code.txt')
txt_f = open(txt_file_path, 'w')
target_image = utils.read_image(TARGET_PATH)
c_str = 'target image size: ' + str(target_image.shape)
print(c_str)
txt_f.write(c_str)
vhd = vahadane(LAMBDA1=0.01, LAMBDA2=0.01, THRESH=0.9,
               fast_mode=1, getH_mode=0, ITER=50)
vhd.fast_mode = 0
vhd.getH_mode = 0
Wt, Ht = vhd.stain_separate(target_image)
vhd.fast_mode = 1
vhd.getH_mode = 0
# vhd.show_config()
config_str = vhd.output_config_str()
txt_f.write(config_str)
txt_f.close()
target_lst = [RESULT_DIR]
test_lst = []
for dirName, subdirList, fileList in os.walk(SOURCE_DIR):
    test_lst.append(dirName)
    cur_target_path = target_lst.pop(-1)
    print(cur_target_path)
    cur_lst = subdirList.copy()
    cur_lst.reverse()
    for sub_dir in cur_lst:
        sub_target_dir = os.path.join(cur_target_path, sub_dir)
        if not os.path.exists(sub_target_dir):
            os.mkdir(sub_target_dir)
        target_lst.append(sub_target_dir)
    for file_i in fileList:
        print(file_i)
        file_path = os.path.join(dirName, file_i)
        sv_file_path = os.path.join(cur_target_path, file_i)
        im_format = imghdr.what(file_path)
        if im_format in ['jpg', 'png', 'tiff']:
            sv_file_path = sv_file_path[:-4] + '.png'
            source_image = utils.read_image(file_path)
            Ws, Hs = vhd.stain_separate(source_image)
            img = vhd.SPCN(source_image, Ws, Hs, Wt, Ht)
            img = Image.fromarray(img)
            assert img.mode == 'RGB'
            img.save(sv_file_path)
            img.close()
        elif im_format is None:
            shutil.copy(file_path, sv_file_path)
        else:
            print('Unknown format.')
print('finish')