# import cv2
from PIL import Image
import numpy as np


def read_image(path):
    img = Image.open(path)
    img = img.convert('RGB')
    assert img.mode == 'RGB'
    img = np.array(img)
    p = np.percentile(img, 90)
    img = np.clip(img * 255.0 / p, 0, 255).astype(np.uint8)
    return img
