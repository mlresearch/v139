import os
os.environ['CUDA_VISIBLE_DEVICES'] = "1"
import time

# import cv2
from PIL import Image
import numpy as np
from numpy.random import seed
seed(1)
from skimage import segmentation

import torch
import torch.nn as nn
import json
import shutil
import imghdr

# import string


class Args(object):
    train_epoch = 2 ** 6
    mod_dim1 = 64  #
    mod_dim2 = 32
    gpu_id = 1

    min_label_num = 7
    # if the label number small than it, break loop
    max_label_num = 7
    # if the label number small than it, start to show result image.

def detect_red_white_black(r, g, b):
    white_threshold = 180.
    red_threshold = 40.
    black_threshold = 50.
    # white_bool = False
    # red_bool = False
    # black_bool = False
    detect_bool = False
    if np.mean(np.array([r, g, b])) >= white_threshold:
        detect_bool = True
    elif r - (int(g) + int(b)) / 2. >= red_threshold:
        detect_bool = True
    elif np.mean(np.array([r, g, b])) <= black_threshold:
        detect_bool = True
    return detect_bool

class MyNet(nn.Module):
    def __init__(self, inp_dim, mod_dim1, mod_dim2):
        super(MyNet, self).__init__()

        self.seq = nn.Sequential(
            nn.Conv2d(inp_dim, mod_dim1, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(mod_dim1),
            nn.ReLU(inplace=True),

            nn.Conv2d(mod_dim1, mod_dim2, kernel_size=1, stride=1, padding=0),
            nn.BatchNorm2d(mod_dim2),
            nn.ReLU(inplace=True),

            nn.Conv2d(mod_dim2, mod_dim1, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(mod_dim1),
            nn.ReLU(inplace=True),

            nn.Conv2d(mod_dim1, mod_dim2, kernel_size=1, stride=1, padding=0),
            nn.BatchNorm2d(mod_dim2),
        )

    def forward(self, x):
        return self.seq(x)

# def is_bad_region(color_avg, color_std):
#     if np.mean(color_avg) < 78. or \
#             np.mean(color_avg) >= 185. or \
#             np.abs(np.mean(color_avg[1:])
#                    - color_avg[0]) >= 37. or \
#             color_std < 35.:
#         return True
#     else:
#         return False
#np.abs(np.mean(color_avg[1:])
                   # - color_avg[0]) >= 50. or \
def is_bad_region(color_avg, color_std):
    if np.mean(color_avg) < 40. or \
            np.mean(color_avg) >= 230. or \
            color_std < 7.:
        return True
    else:
        return False

def run_one_im(im_path):
    start_time0 = time.time()
    ######################### Configuration #################################
    args = Args()
    # torch.cuda.manual_seed_all(1943)
    torch.manual_seed(1943)
    np.random.seed(1943)
    os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu_id)  # choose GPU:0
    mask_info = {}
    im = Image.open(im_path)
    im = np.array(im)

    '''segmentation ML'''
    seg_map = segmentation.felzenszwalb(im, scale=32,
                                        sigma=0.5, min_size=64)
    # seg_map = segmentation.slic(im, n_segments=10000,
    #                             compactness=100, start_label=1)
    seg_map = seg_map.flatten()
    seg_lab = [np.where(seg_map == u_label)[0]
               for u_label in np.unique(seg_map)]

    '''train init'''
    device = torch.device("cuda" if torch.cuda.is_available() else 'cpu')
    tensor = im.transpose((2, 0, 1))  # HWC to CHW
    tensor = tensor.astype(np.float32) / 255.0
    tensor = tensor[np.newaxis, :, :, :]  # 1CHW
    tensor = torch.from_numpy(tensor).to(device)

    ############################ Model ###########################
    model = \
        MyNet(inp_dim=3, mod_dim1=args.mod_dim1,
              mod_dim2=args.mod_dim2).to(device)
    # model = MyNet(inp_dim=3, mod_dim1=args.mod_dim1,
    # mod_dim2=args.mod_dim2)
    criterion = torch.nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(),
                                lr=5e-2, momentum=0.9)
    # optimizer = torch.optim.RMSprop(model.parameters(),
    # lr=1e-1, momentum=0.0)

    image_flatten = im.reshape((-1, 3))
    color_avg = np.random.randint(255, size=(args.max_label_num, 3))
    color_std = np.random.randint(10, size=(args.max_label_num, 3))
    color_std_mean = np.random.randint(10, size=(args.max_label_num,))
    cell_lb_lst = None
    cell_color_lst = None
    show = im
    pure_mask = None
    un_label_lst = []
    lb_counts = None
    all_counts = None

    '''train loop'''
    start_time1 = time.time()
    model.train()
    for batch_idx in range(args.train_epoch):
        '''forward'''
        optimizer.zero_grad()
        output = model(tensor)[0]
        output = output.permute(1, 2, 0).view(-1, args.mod_dim2)
        target = torch.argmax(output, 1)
        im_target = target.data.cpu().numpy()
        # im_target = target.numpy()

        '''refine'''
        for inds in seg_lab:
            u_labels, hist = np.unique(im_target[inds],
                                       return_counts=True)
            im_target[inds] = u_labels[np.argmax(hist)]

        '''backward'''
        target = torch.from_numpy(im_target)
        target = target.to(device)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()

        '''show image'''
        un_label, lab_inverse, lb_counts = np.unique(im_target,
                                                     return_inverse=True,
                                                     return_counts=True)
        if un_label.tolist() not in un_label_lst:
            un_label_lst.append(un_label.tolist())
        if un_label.shape[0] < args.max_label_num or \
                batch_idx == args.train_epoch - 1:  # update show
            img_flatten = image_flatten.copy()
            pure_mask = image_flatten.copy()
            if len(color_avg) != un_label.shape[0]:
                color_avg = [np.mean(img_flatten[im_target == label],
                                     axis=0, dtype=np.int)
                             for label in un_label]
                color_std = [np.std(img_flatten[im_target == label],
                                    axis=0, dtype=np.float)
                             for label in un_label]
                color_std_mean = np.mean(color_std, axis=-1)
            # cell_lb = np.argmin(np.mean(color_avg, axis=-1))
            # cell_color = color_avg[cell_lb]
            sort_idx = np.argsort(np.mean(color_avg, axis=-1))
            cell_lb_idx = 0
            lb_num = 0
            ################# make sure the 1st lb ####################
            cell_lb_lst = None
            cell_color_lst = None
            cur_color_avg = color_avg[sort_idx[cell_lb_idx]]
            cur_color_std = color_std_mean[sort_idx[cell_lb_idx]]
            while is_bad_region(cur_color_avg, cur_color_std):  # bad region
                cell_lb_idx += 1
                cur_color_avg = color_avg[sort_idx[cell_lb_idx]]
                cur_color_std = color_std_mean[sort_idx[cell_lb_idx]]
                assert cell_lb_idx < len(sort_idx)
            cell_lb_lst = [sort_idx[cell_lb_idx]]
            cell_color_lst = [color_avg[cell_lb_lst[lb_num]]]
            all_counts = lb_counts[cell_lb_lst[lb_num]]
            lb_num += 1

            ################## Add more lbs #########################
            while all_counts < 200000:
                cell_lb_idx += 1
                if cell_lb_idx >= len(sort_idx):
                    break
                cur_color_avg = color_avg[sort_idx[cell_lb_idx]]
                cur_color_std = color_std_mean[sort_idx[cell_lb_idx]]
                if is_bad_region(cur_color_avg, cur_color_std):  # bad region
                    continue
                cell_lb_lst.append(sort_idx[cell_lb_idx])
                cell_color_lst.append(cur_color_avg)
                all_counts += lb_counts[cell_lb_lst[lb_num]]
                lb_num += 1

            for lab_id, color in enumerate(color_avg):
                if lab_id not in cell_lb_lst:
                    img_flatten[lab_inverse == lab_id] = \
                        np.array([0, 255, 0])
                    pure_mask[lab_inverse == lab_id] = \
                        np.array([255, 255, 255]) # white
                else:
                    pure_mask[lab_inverse == lab_id] = np.array([0, 0, 0])
                # img_flatten[lab_inverse == lab_id] = color
            show = img_flatten.reshape(im.shape)
            pure_mask = pure_mask.reshape(im.shape)
        # cv2.imshow("seg_pt", show)
            if all_counts < 150000:
                print('valid pixels not enough')
            # else:
            #     print('enough')
        # cv2.waitKey(1)
        if 'loss' not in mask_info.keys():
            mask_info['loss'] = [loss.item()]
        else:
            mask_info['loss'].append(loss.item())
        # print('Loss:', batch_idx, loss.item())
        if len(un_label) < args.min_label_num:
            break

    '''save'''
    time0 = time.time() - start_time0
    time1 = time.time() - start_time1
    mask_info['lb_counts'] = str(lb_counts)
    mask_info['all_counts'] = str(all_counts)
    mask_info['color_avg'] = str(color_avg[0])
    mask_info['cell_lb_lst'] = str(cell_lb_lst)
    mask_info['cell_color_lst'] = str(cell_color_lst)
    mask_info['whole_time'] = str(time0)
    mask_info['train_time'] = str(time1)
    # print('color_avg: ' + str(color_avg))
    # print('cell id: ' + str(cell_id))
    # print('cell color: ' + str(cell_color))
    # print('PyTorchInit: %.2f\nTimeUsed: %.2f' % (time0, time1))
    return mask_info, show, pure_mask




if __name__ == '__main__':
    ################################ Image Paths ###############################
    data_root = ''
    ori_data_dir = os.path.join(data_root, 'BreakHist_ClrNorm_Vahadane')
    save_im_mask_dir = os.path.join(data_root, 'BreakHist_IMask_orisize')
    save_pure_mask_dir = os.path.join(data_root, 'BreakHist_PMask_orisize')
    if not os.path.exists(save_im_mask_dir):
        os.mkdir(save_im_mask_dir)
    if not os.path.exists(save_pure_mask_dir):
        os.mkdir(save_pure_mask_dir)
    imask_txt_f_path = os.path.join(save_im_mask_dir, 'README_code.txt')
    pmask_txt_f_path = os.path.join(save_pure_mask_dir, 'README_code.txt')
    imask_txt_f = open(imask_txt_f_path, 'w')
    pmask_txt_f = open(pmask_txt_f_path, 'w')
    imask_txt_f.write('source file: ' + ori_data_dir)
    pmask_txt_f.write('source file: ' + ori_data_dir)
    imask_txt_f.write('im_size: 700 * 460')
    pmask_txt_f.write('im_size: 700 * 460')
    cfn = os.path.basename(__file__)
    imask_txt_f.write('py file: ' + cfn)
    pmask_txt_f.write('py file: ' + cfn)
    imask_txt_f.close()
    pmask_txt_f.close()

    imask_target_lst = [save_im_mask_dir]
    pmask_target_lst = [save_pure_mask_dir]
    test_lst = []
    if_continue = False
    for dirName, subdirList, fileList in os.walk(ori_data_dir):
        test_lst.append(dirName)
        imask_cur_target_path = imask_target_lst.pop(-1)
        pmask_cur_target_path = pmask_target_lst.pop(-1)
        print(imask_cur_target_path)
        cur_lst = subdirList.copy()
        cur_lst.reverse()
        for sub_dir in cur_lst:
            imask_sub_target_dir = os.path.join(imask_cur_target_path, sub_dir)
            if not os.path.exists(imask_sub_target_dir):
                os.mkdir(imask_sub_target_dir)
            imask_target_lst.append(imask_sub_target_dir)
            pmask_sub_target_dir = os.path.join(pmask_cur_target_path, sub_dir)
            if not os.path.exists(pmask_sub_target_dir):
                os.mkdir(pmask_sub_target_dir)
            pmask_target_lst.append(pmask_sub_target_dir)
        continue_fn = 'SOB_M_DC-14-17901-40-022.png'
        for file_i in fileList:
            if continue_fn != None and if_continue == False and \
                    file_i != continue_fn:
                continue
            elif continue_fn != None and if_continue == False and \
                    file_i == continue_fn:
                if_continue = True
            print(file_i)
            file_path = os.path.join(dirName, file_i)
            imask_sv_file_path = os.path.join(imask_cur_target_path, file_i)
            pmask_sv_file_path = os.path.join(pmask_cur_target_path, file_i)
            im_format = imghdr.what(file_path)
            if im_format in ['jpg', 'png', 'tiff']:
                imask_sv_file_path = imask_sv_file_path[:-4] + '.png'
                pmask_sv_file_path = pmask_sv_file_path[:-4] + '.png'
                mask_info, im_mask, pure_mask = run_one_im(file_path)
                # source_image = source_image.convert('RGB')
                im_mask = Image.fromarray(im_mask)
                pure_mask = Image.fromarray(pure_mask)
                assert im_mask.mode == 'RGB'
                im_mask.save(imask_sv_file_path)
                pure_mask.save(pmask_sv_file_path)
                im_mask.close()
                pure_mask.close()
            elif im_format is None:
                shutil.copy(file_path, imask_sv_file_path)
                shutil.copy(file_path, pmask_sv_file_path)
            else:
                print('Unknown format.')
    print('finish')