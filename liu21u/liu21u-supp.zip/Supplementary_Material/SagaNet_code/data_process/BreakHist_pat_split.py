import os
import json
import random

random.seed(1)
trail_ch = 2
trail_lst = [5, 10, 20]
trail_num = trail_lst[trail_ch]
data_home_dir = ''
sv_dir = os.path.join(data_home_dir, 'BreakHist_Split')
if not os.path.exists(sv_dir):
    os.mkdir(sv_dir)
pat_lst_dict_path = os.path.join(sv_dir, 'pat_lst_dict.json')
pat_split_dict_path = os.path.join(sv_dir, 'pat_split_dict_' +
                                   str(trail_num) + '.json')
with open(pat_lst_dict_path, 'r') as json_f:
    cls_dict, _, sub_cls_pat_lst_dict, pat_im_num_dict = json.load(json_f)
sub_cls_lst = sub_cls_pat_lst_dict.keys()
sub_cls_im_num_dict = {}
split_ratio = 0.3

sub_cls_split_dict = {}
for sub_cls_i in sub_cls_lst:
    print(sub_cls_i)
    cur_pat_lst = sub_cls_pat_lst_dict[sub_cls_i]
    sub_im_num = 0
    sub_im_num_lst = []
    for pat_i in cur_pat_lst:
        im_num = pat_im_num_dict[pat_i]
        sub_im_num += im_num
        sub_im_num_lst.append(im_num)
    sub_cls_im_num_dict[sub_cls_i] = sub_im_num
    cur_thres = sub_im_num * split_ratio
    sub_cls_split = []
    for trail_i in range(trail_num):
        print('trail_i: ' + str(trail_i))
        cur_im_sum = 0
        cur_lst = cur_pat_lst.copy()
        slt_pat_lst = []
        slt_im_num_lst = []
        while cur_im_sum < cur_thres and cur_lst != []:
            r_pat = cur_lst.pop(random.randrange(len(cur_lst)))
            r_im_num = pat_im_num_dict[r_pat]
            if cur_im_sum + r_im_num > cur_thres:
                continue
            else:
                cur_im_sum += r_im_num
                slt_pat_lst.append(r_pat)
                slt_im_num_lst.append(r_im_num)
        train_pat_lst = list(set(cur_pat_lst) - set(slt_pat_lst))
        train_im_num_lst = [pat_im_num_dict[pat_ii] for pat_ii in train_pat_lst]
        sub_cls_split.append([slt_pat_lst, train_pat_lst,
                              slt_im_num_lst, train_im_num_lst,
                              cur_im_sum])
    sub_cls_split_dict[sub_cls_i] = sub_cls_split
with open(pat_split_dict_path, 'w') as json_f:
    json.dump(sub_cls_split_dict, json_f, indent=2)
