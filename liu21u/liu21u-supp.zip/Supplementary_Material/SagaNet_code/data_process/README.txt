Data process order:
1 Color Normalization
2 Mask Generating
3 Resize
4 Rotate
5 Inpaint
