#! -*- coding: utf-8 -*-
from keras import activations
from keras import backend as K
from keras.engine.topology import Layer

def squash(x, axis=-1):
    s_squared_norm = K.sum(K.square(x), axis, keepdims=True) + K.epsilon()
    scale = K.sqrt(s_squared_norm)/ (0.5 + s_squared_norm)
    return scale * x


#define our own softmax function instead of K.softmax
def softmax(x, axis=-1):
    ex = K.exp(x - K.max(x, axis=axis, keepdims=True))
    return ex/K.sum(ex, axis=axis, keepdims=True)


#A Capsule Implement with Pure Keras
class Hinge_Layer(Layer):
    def __init__(self, class_num,
                 weight_initializer='glorot_uniform',
                 activation='squash', **kwargs):
        super(Hinge_Layer, self).__init__(**kwargs)
        self.weight_initializer = weight_initializer
        self.class_num = class_num
        if activation == 'squash':
            self.activation = squash
        else:
            self.activation = activations.get(activation)

    def build(self, input_shape):
        super(Hinge_Layer, self).build(input_shape)
        k_num = int(input_shape[-2])
        self.ch_num = int(input_shape[-1])
        self.W = self.add_weight(name='capsule_kernel',
                                 shape=(1, k_num, self.class_num),
                                 initializer='glorot_uniform',
                                 trainable=True)

    # def call(self, inputs, **kwargs):
    def call(self, inputs, **kwargs):
        # inputs shape: (batch_num, red_size * red_size, ch_num)
        class_f = K.permute_dimensions(inputs, (0, 2, 1))
        class_f = K.conv1d(class_f, self.W)
        class_f = K.permute_dimensions(class_f, (0, 2, 1))
        return self.activation(class_f)

    def compute_output_shape(self, input_shape):
        return (None, self.class_num, self.ch_num)
