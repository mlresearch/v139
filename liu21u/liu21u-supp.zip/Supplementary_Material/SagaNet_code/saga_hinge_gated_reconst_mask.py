import os

os.environ['CUDA_VISIBLE_DEVICES'] = "4"
import gc
import tensorflow as tf
from numpy.random import seed
seed(1)
tf.random.set_seed(1)
# tf.set_random_seed(1)
import keras.backend as K
from keras.losses import mean_squared_error

from keras.layers import Conv2D, Input, Lambda, Concatenate, \
    MaxPool2D, UpSampling2D, Dense, Dropout, Flatten, Reshape, concatenate
from keras.models import Model, load_model
from keras.optimizers import SGD, Adam
from keras.callbacks import Callback
from keras.callbacks import ModelCheckpoint, EarlyStopping
from keras.preprocessing.image import image
from keras.regularizers import Regularizer

from im_data_generator import im_list_generator
from hinge_utils import *
from gated_utils.densenet_capsule_gatednolinear_utils \
    import gen_conv, gated_DenseNet_func

import matplotlib
import pandas as pd

matplotlib.use('Agg')
import cv2
from PIL import Image
import PIL.Image as pil
import matplotlib.pyplot as plt
import numpy as np
import random

import json
import datetime

SEED = random.seed(0)
def multi_gpu_model(model, gpus):
  if isinstance(gpus, (list, tuple)):
    num_gpus = len(gpus)
    target_gpu_ids = gpus
  else:
    num_gpus = gpus
    target_gpu_ids = range(num_gpus)

  def get_slice(data, i, parts):
    shape = tf.shape(data)
    batch_size = shape[:1]
    input_shape = shape[1:]
    step = batch_size // parts
    if i == num_gpus - 1:
      size = batch_size - step * i
    else:
      size = step
    size = tf.concat([size, input_shape], axis=0)
    stride = tf.concat([step, input_shape * 0], axis=0)
    start = stride * i
    return tf.slice(data, start, size)

  all_outputs = []
  for i in range(len(model.outputs)):
    all_outputs.append([])

  # Place a copy of the model on each GPU,
  # each getting a slice of the inputs.
  for i, gpu_id in enumerate(target_gpu_ids):
    with tf.device('/gpu:%d' % gpu_id):
      with tf.name_scope('replica_%d' % gpu_id):
        inputs = []
        # Retrieve a slice of the input.
        for x in model.inputs:
          input_shape = tuple(x.get_shape().as_list())[1:]
          slice_i = Lambda(get_slice,
                           output_shape=input_shape,
                           arguments={'i': i,
                                      'parts': num_gpus})(x)
          inputs.append(slice_i)

        # Apply model on slice
        # (creating a model replica on the target device).
        outputs = model(inputs)
        if not isinstance(outputs, list):
          outputs = [outputs]

        # Save the outputs for merging back together later.
        for o in range(len(outputs)):
          all_outputs[o].append(outputs[o])

  # Merge outputs on CPU.
  with tf.device('/cpu:0'):
    merged = []
    for name, outputs in zip(model.output_names, all_outputs):
      merged.append(concatenate(outputs,
                                axis=0, name=name))
    return Model(model.inputs, merged)

L_3 = np.array([1, 2, 1])
E_3 = np.array([-1, 0, 1])
S_3 = np.array([-1, 2, -1])

L_5 = np.array([1, 4, 6, 4, 1])
E_5 = np.array([-1, -2, 0, 2, 1])
S_5 = np.array([-1, 0, 2, 0, -1])
W_5 = np.array([-1, 2, 0, 2, -1])
R_5 = np.array([1, -4, 0, -4, 1])

class MaskReg(Regularizer):
    """Regularizer for L1 and L2 regularization.

    # Arguments
        l1: Float; L1 regularization factor.
        l2: Float; L2 regularization factor.
    """

    def __init__(self, kernel):
        self.kernel = kernel

    def __call__(self, x):
        regularization = 0.
        regularization = K.sum(K.square(x - self.kernel))
        return regularization

    def get_config(self):
        return {'kernel': self.kernel}

class LR_tracker(Callback):
    def __init__(self, decay_epoch_num, dec_ratio):
        super(Callback, self).__init__()
        self.epoch_lr_lst = []
        self.decay_epoch_num = decay_epoch_num
        self.dec_ratio = dec_ratio

    def on_epoch_end(self, epoch, logs=None):
        if not hasattr(self.model.optimizer, 'lr'):
            raise ValueError('Optimizer must have a "lr" attribute.')
        cur_lr = float(K.get_value(self.model.optimizer.lr))
        self.epoch_lr_lst.append(cur_lr)
        if epoch % self.decay_epoch_num == 0 and epoch != 0:
            update_time = epoch / self.decay_epoch_num
            # new_lr = cur_lr * (0.5 ** update_time)
            new_lr = cur_lr * self.dec_ratio
            K.set_value(self.model.optimizer.lr, new_lr)
            print('\nEpoch %05d: LearningRateScheduler setting learning '
                  'rate to %s.' % (epoch + 1, new_lr))

class texture_autoencoder_classifier():
    def __init__(self, dataset_ch, df_split_name, image_dir_lst,
                 weight_dir_name, exp_dir_name,
                 test_mode=False, Split_train=True, split_idx=None):
        # super(texture_autoencoder_classifier, self). \
        #     __init__(df_split_name,
        #              image_dir_lst,
        #              weight_dir_name, exp_dir_name)
        ####################### Configuration #######################
        assert dataset_ch in [0, 1, 2]
        if dataset_ch == 0:
            self.data_root_dir = ''
            self.split_dir_nm = ''
        elif dataset_ch == 1:
            self.data_root_dir = \
                ''
            self.split_dir_nm = 'BreakHist_Split'
        elif dataset_ch == 2:
            self.data_root_dir = \
                ''
            self.split_dir_nm = ''
        self.unlb_data_dir = \
            os.path.join(self.data_root_dir,
                         'NO_FILE')
        lst_len = len(image_dir_lst)
        self.ori_lb_data_dir_lst = []
        for lst_i in range(lst_len):
            cur_dir = \
            os.path.join(self.data_root_dir,
                         image_dir_lst[lst_i])
            self.ori_lb_data_dir_lst.append(cur_dir)
        self.spli_idx = None
        if Split_train:
            self.df_data_dir = \
                os.path.join(self.data_root_dir, self.split_dir_nm,
                             df_split_name)
            self.split_idx = split_idx

        self.semi_save_dir = \
            os.path.join(self.data_root_dir,
                         'semi_weights')
        if not os.path.exists(self.semi_save_dir) and not test_mode:
            os.mkdir(self.semi_save_dir)
        self.save_pretrain_dir = \
            os.path.join(self.semi_save_dir,
                         'pretrain_weights')
        self.save_pretrain_weight_dir = \
            os.path.join(self.save_pretrain_dir, weight_dir_name)
        self.final_save_enc_path = \
            os.path.join(self.save_pretrain_weight_dir,
                         'pretrain_final_whl_enc.h5')
        self.final_save_ae_path = \
            os.path.join(self.save_pretrain_weight_dir,
                         'pretrain_final_whl_ae.h5')
        self.best_load_ae_path = \
            os.path.join(self.save_pretrain_dir, 'weights_190521'
                                                 'pretrain_best_ae.h5')
        self.pretrain_recon_im_path = \
            os.path.join(self.save_pretrain_weight_dir,
                         'pretrain_reconst_im.jpg')
        if not os.path.exists(self.save_pretrain_dir) and not test_mode:
            os.mkdir(self.save_pretrain_dir)
        if not os.path.exists(self.save_pretrain_weight_dir) and not test_mode:
            os.mkdir(self.save_pretrain_weight_dir)

        self.save_finetune_dir = \
            os.path.join(self.semi_save_dir,
                         'finetune_weights')
        self.save_finetune_weight_dir = \
            os.path.join(self.save_finetune_dir, weight_dir_name)
        self.save_finetune_weight_exp_dir = \
            os.path.join(self.save_finetune_weight_dir, exp_dir_name)
        self.best_save_classifier_path = \
            os.path.join(self.save_finetune_weight_exp_dir,
                         'finetune_best_classifier.h5')
        self.final_save_classifier_path = \
            os.path.join(self.save_finetune_weight_exp_dir,
                         'finetune_final_classifier.h5')
        self.save_acc_curve_im_path = \
            os.path.join(self.save_finetune_weight_exp_dir,
                         'finetune_acc_curve_im.jpg')
        self.save_cond_txt_path = \
            os.path.join(self.save_finetune_weight_exp_dir,
                         'finetune_condition.txt')
        self.save_pred_json_path = \
            os.path.join(self.save_finetune_weight_exp_dir,
                         'finetune_test_pred.json')
        self.save_epoch_list_json_path = \
            os.path.join(self.save_finetune_weight_exp_dir,
                         'finetune_epoch_list.json')
        self.save_loss_curve_im_path = \
            os.path.join(self.save_finetune_weight_exp_dir,
                         'finetune_loss_curve_im.jpg')
        self.save_lr_curve_im_path = \
            os.path.join(self.save_finetune_weight_exp_dir,
                         'finetune_lr_curve_im.jpg')
        self.recon_im_path = \
            os.path.join(self.save_finetune_weight_exp_dir,
                         'reconst_test_im.jpg')
        if not os.path.exists(self.save_finetune_dir) and not test_mode:
            os.mkdir(self.save_finetune_dir)
        if not os.path.exists(self.save_finetune_weight_dir) and not test_mode:
            os.mkdir(self.save_finetune_weight_dir)
        if not os.path.exists(self.save_finetune_weight_exp_dir) and not test_mode:
            os.mkdir(self.save_finetune_weight_exp_dir)

        self.im_res_size = 224
        self.input_size = (self.im_res_size, self.im_res_size, 9)
        self.class_num = 2
        self.pretrain_epoch_num = 10
        self.finetune_epoch_num = 50
        self.train_bth_size = 20
        # self.kernel_regularizer=l2(0.01)
        # self.dropout_p=0.2
        self.kernel_regularizer = None
        self.dropout_p = 0.

        self.epoch_list = []
        ####################### Data Generators #######################
        if not test_mode:
            if with_pretrain == True:
                self.pretrain_train_gen, self.pretrain_valid_gen = \
                    self.prepare_data(islabeled=False,
                                      data_dir_lst=[self.unlb_data_dir],
                                      df_dir=None,
                                      train_bth_size=32,
                                      valid_batch_size=32)
            else:
                self.pretrain_train_gen = None
                self.pretrain_valid_gen = None
            self.finetune_train_gen, self.finetune_valid_gen = \
                self.prepare_data(islabeled=True,
                                  data_dir_lst=self.ori_lb_data_dir_lst,
                                  df_dir=self.df_data_dir,
                                  train_bth_size=self.train_bth_size,
                                  valid_batch_size=10)
        self.test_generator = None
        ####################### Pretrain Model #######################
        # self.kernel0 = self.create_kernel(L_5, E_5) # 2
        # self.kernel1 = self.create_kernel(S_5, R_5) # 0
        # self.kernel2 = self.create_kernel(E_5, E_5) # 1
        self.kernel0 = self.create_kernel(L_5, E_5)  # 2
        self.kernel1 = self.create_kernel(L_5, E_5)  # 2
        self.kernel2 = self.create_kernel(S_5, R_5)  # 0

        self.ch_num_list = [3, 128, 256, 512, 1024]

        self.build_models()
        # sgd_opt = SGD(lr=0.0005, decay=0.5, momentum=.85, nesterov=True)
        # adam_opt = Adam(lr=5e-5, decay=1e-6)
        # adadelta_opt = Adadelta(lr=1e-3)
        # cur_lr = 0.0005
        # self.ae_densemodel.compile(loss=self.reconstruct_loss,
        #                            optimizer=adam_opt)
        # for enc in self.encs_list:
        #     enc.compile(loss='mean_squared_logarithmic_error',
        #                 optimizer = sgd_opt)

        # self.graph = tf.get_default_graph()
        # self.session = K.get_session()

    def rgb2hsv(self, image):
        # For HSV, Hue range is [0,360],
        # Saturation range is [0,1] and Value range is [0,255]
        arr_image = np.array(image, dtype=np.float32)
        hsv_image = cv2.cvtColor(arr_image, cv2.COLOR_RGB2HSV)
        hsv_image[:, :, 0] = hsv_image[:, :, 0] / 360.
        hsv_image[:, :, 1] = hsv_image[:, :, 1] / 1.
        hsv_image[:, :, 2] = hsv_image[:, :, 2] / 255.
        # hsv_image[:, :, 0] = (hsv_image[:, :, 0] -180.) / 180.
        # hsv_image[:, :, 1] = (hsv_image[:, :, 1] - 0.5) / 0.5
        # hsv_image[:, :, 2] = (hsv_image[:, :, 2] - 127.5) / 127.5
        # return Image.fromarray(hsv_image.astype('uint8'))  # TO DEBUG
        return hsv_image

    def rgb2lab(self, image):
        # For LAB, Hue range is [0,100],
        # Saturation range is [-128,127] and Value range is [-128,127]
        arr_image = np.array(image, dtype=np.float32)
        lab_image = cv2.cvtColor(arr_image / 255., cv2.COLOR_RGB2LAB)
        lab_image[:, :, 0] = lab_image[:, :, 0] / 100.
        lab_image[:, :, 1] = (lab_image[:, :, 1] + 128) / 255.
        lab_image[:, :, 2] = (lab_image[:, :, 2] + 128.) / 255.
        return lab_image

    def uniform_color(self, image):
        imm = np.array(image, dtype=np.float32)
        rgb_mean = np.array([180, 150, 180])
        im_rgb_mean = np.mean(imm, axis=(0, 1), keepdims=True)
        imm = imm - im_rgb_mean
        imm += rgb_mean
        imm = np.clip(imm, 0, 255)
        imm = imm / 255.
        return imm
    def color2gray(self, image):
        imm = np.array(image, dtype=np.float32)
        imm = cv2.cvtColor(imm, cv2.COLOR_RGB2GRAY)
        im_mean = np.mean(imm, axis=(0, 1), keepdims=True)
        imm = imm - im_mean
        # im += rgb_mean
        imm += 150
        imm = np.clip(imm, 0, 255.)
        imm = np.expand_dims(imm, axis=-1)
        imm = np.concatenate([imm, imm, imm], axis=-1)
        return imm

    def prepare_data(self, islabeled,
                     data_dir_lst, df_dir,
                     train_bth_size, valid_batch_size):
        if islabeled == True:
            cur_class_mode = 'categorical'
        else:
            cur_class_mode = None
        df_train_path = os.path.join(df_dir, 'train.csv')
        # valid_dir = os.path.join(data_dir, 'valid')
        df_valid_path = os.path.join(df_dir, 'test.csv')
        #df_valid_path = os.path.join(df_dir, 'test.csv')
        df_train = pd.read_csv(df_train_path)
        df_valid = pd.read_csv(df_valid_path)
        # No Data augmentation
        if with_lab:
            train_datagen = \
                im_list_generator(preprocessing_function=self.rgb2lab,
                                   horizontal_flip=True)
            validation_datagen = \
                im_list_generator(preprocessing_function=self.rgb2lab,
                                   horizontal_flip=True)
        else:
            train_datagen = im_list_generator(rescale=1. / 255,
                                               horizontal_flip=True)
            validation_datagen = im_list_generator(rescale=1. / 255,
                                                    horizontal_flip=True)
            # train_datagen = ImageDataGenerator(
            #     preprocessing_function=self.color2gray)
            # validation_datagen = ImageDataGenerator(
            #     preprocessing_function=self.color2gray)

        # Data Generator for Training data
        train_generator = train_datagen.flow_from_dataframe(
            dataframe=df_train,
            directory_lst=data_dir_lst,
            x_col='fn',
            y_col='lbs',
            target_size=(self.im_res_size,
                         self.im_res_size),
            batch_size=train_bth_size,
            class_mode=cur_class_mode,
            shuffle=True,
            seed=SEED)

        # Data Generator for Validation data
        validation_generator = \
            validation_datagen.flow_from_dataframe(
                dataframe=df_valid,
                directory_lst=data_dir_lst,
                x_col='fn',
                y_col='lbs',
                target_size=(self.im_res_size,
                             self.im_res_size),
                batch_size=valid_batch_size,
                class_mode=cur_class_mode,
                shuffle=False,
                seed=SEED)
        # aaa = train_generator.next()
        return train_generator, validation_generator  # TO DEBUG

    def create_kernel(self, ele1, ele2):
        a = np.dot(np.expand_dims(ele1, axis=1),
                   np.expand_dims(ele2, axis=0))
        b = np.dot(np.expand_dims(ele2, axis=1),
                   np.expand_dims(ele1, axis=0))
        c = (a + b) / 2.
        c_sum = np.sum(np.abs(c), axis=(0, 1)) + 1e-8
        c = c / c_sum
        # c_max = np.max(np.abs(c), axis=(0, 1)) + 1e-8
        # c = c / c_max
        c = np.expand_dims(c, axis=-1)  # tf order
        c = np.expand_dims(c, axis=-1)
        return c  # TO DEBUG

    def mask_reg(self, kernel):
        return MaskReg(kernel)

    def build_models(self):
        # with tf.device('/cpu:0'):
        # input_shape = (self.im_res_size, self.im_res_size, 9)
        aes_list = []
        encs_list = []
        ############################ Layer 0 ###########################
        self.input_im = Input(shape=self.input_size)
        input_ch0 = Lambda(lambda x: K.expand_dims(x[:, :, :, 0],
                                                   axis=-1))(self.input_im)
        input_ch1 = Lambda(lambda x: K.expand_dims(x[:, :, :, 1],
                                                   axis=-1))(self.input_im)
        input_ch2 = Lambda(lambda x: K.expand_dims(x[:, :, :, 2],
                                                   axis=-1))(self.input_im)
        if with_flex:
            mask0 = self.mask_reg(self.kernel0)
            mask1 = self.mask_reg(self.kernel1)
            mask2 = self.mask_reg(self.kernel2)
        else:
            mask0 = None
            mask1 = None
            mask2 = None

        self.k0_layer = \
            Conv2D(filters=1,
                   kernel_size=5,
                   padding='same',
                   kernel_regularizer=mask0,
                   kernel_initializer=lambda shape,
                                             dtype=None: self.kernel0,
                   name='kernel0_layer')
        self.k1_layer = \
            Conv2D(filters=1,
                   kernel_size=5,
                   padding='same',
                   kernel_regularizer=mask1,
                   kernel_initializer=lambda shape,
                                             dtype=None: self.kernel1,
                   name='kernel1_layer')
        self.k2_layer = \
            Conv2D(filters=1,
                   kernel_size=5,
                   padding='same',
                   kernel_regularizer=mask2,
                   kernel_initializer=lambda shape,
                                             dtype=None: self.kernel2,
                   name='kernel2_layer')
        self.k0_layer.trainable = False
        self.k1_layer.trainable = False
        self.k2_layer.trainable = False
        f_0 = self.k0_layer(input_ch0)
        f_1 = self.k1_layer(input_ch1)
        f_2 = self.k2_layer(input_ch2)
        texture_im = Concatenate(axis=3)([f_0, f_1, f_2])

        if with_texture:
            input_t = texture_im
        else:
            input_t = self.input_im
        self.conv_f, self.reconst_im = \
            gated_DenseNet_func(
                blocks=[1, 1, 2, 2],  # meaningless
                # capsule_num_1=16,
                # dim_capsule_1=16,
                # capsule_num_2=self.class_num,
                # dim_capsule_2=32,
                weights=None,  #
                finetune_flag=False,
                include_top=False,  #
                kernel_regularizer=self.kernel_regularizer,  #
                dropout_p=self.dropout_p,  #
                input_shape=self.input_size,  #
            input_tensor=input_t)  #

        # Enable all the layers
        # for layer in self.densenet_model.layers:
        #     layer.trainable = True
        # Check the trainable status of the individual layers
        # for layer in self.densenet_model.layers:
        #     print(layer, layer.trainable)

        # if with_texture:
        #     self.conv_f = self.densenet_model(texture_im)
        #     self.reconst_im = self.ae_densemodel(texture_im)
        # else:
        #     self.conv_f = self.densenet_model(self.input_im)
        #     self.reconst_im = self.ae_densemodel(self.input_im)
        ############################ Classifier #######################
        # self.conv_f = Conv2D(filters=16, kernel_size=(1, 1))(self.conv_f)
        self.conv_f = gen_conv(self.conv_f, cnum=16, ksize=1)
        ch_num = int(self.conv_f.shape[-1])
        out_f = Reshape((-1, ch_num))(self.conv_f)
        out_f = Hinge_Layer(class_num=self.class_num)(out_f)
        self.output_f = Lambda(lambda x: K.sqrt(K.sum(K.square(x), 2)),
                               output_shape=(self.class_num,),
                               name='length_layer')(out_f)  # Length
        # self.cls_model = Model(inputs=self.input_im,
        #                        outputs=self.output_f)
        # self.cls_model.summary()
        ############################ Auto-encoder #######################
        self.autoenc_model = Model(inputs=self.input_im,
                                   outputs=[self.output_f,
                                            self.reconst_im])
        if os.environ['CUDA_VISIBLE_DEVICES'] != "":
            gpus_lst = eval(os.environ['CUDA_VISIBLE_DEVICES'])
            if str(type(gpus_lst)) == '<class \'tuple\'>':
                gpu_num = len(gpus_lst)  # stringg length
                if gpu_num > 1:
                    self.autoenc_model = multi_gpu_model(self.autoenc_model,
                                                     gpus=gpus_lst)

        # self.autoenc_model.summary()
    #
    # def __getattribute__(self, attrname):
    #     '''Override load and save methods to be used from the serial-model. The
    #     serial-model holds references to the weights in the multi-gpu model.
    #     '''
    #     # return Model.__getattribute__(self, attrname)
    #     if 'load' in attrname or 'save' in attrname:
    #         return getattr(self.autoenc_model, attrname)
    #
    #     return super(texture_autoencoder_classifier, self).\
    #         __getattribute__(attrname)

    def double_gen(self, train_or_valid='train'):
        if train_or_valid == 'train':
            ori_gen = self.pretrain_train_gen
        elif train_or_valid == 'valid':
            ori_gen = self.pretrain_valid_gen
        else:
            ori_gen = None
        while True:
            ims = ori_gen.next()
            im = ims[0]
            mask = ims[1]
            ones_im = np.ones_like(im)
            im = im * (1 - mask)
            input_im = np.concatenate([im, ones_im, ones_im * mask], axis=-1)
            yield [input_im, ims]
    # def reconstruct_loss(self, construct_im, ims):
    #     im = ims[0]
    #     mask = ims[1]
    #     masked_im = im * (1 - mask)
    #     masked_con = construct_im * (1 - mask)
    #     loss = mean_squared_error(y_true=masked_im,
    #                               y_pred=masked_con)
    #     im_h_w = im.shape[0]
    #
    #     return loss
    def pretrain(self):  # Stacked Autoencoder
        best_save_path = os.path.join(self.save_pretrain_weight_dir,
                                      'pretrain_best_ae.h5')
        checkpointer = ModelCheckpoint(best_save_path,
                                       verbose=1, save_best_only=True)
        # checkpointer = AltModelCheckpoint(best_save_path,
        #                                verbose=1, save_best_only=True)
        whl_train_gen = self.double_gen(train_or_valid='train')
        whl_valid_gen = self.double_gen(train_or_valid='valid')
        print('training whl auto-encoder')
        history = self.ae_densemodel.fit_generator(
            generator=whl_train_gen,
            steps_per_epoch=self.pretrain_train_gen.samples /
                            self.pretrain_train_gen.batch_size,
            epochs=self.pretrain_epoch_num, callbacks=[checkpointer],
            validation_data=whl_valid_gen,
            validation_steps=self.pretrain_valid_gen.samples /
                             self.pretrain_valid_gen.batch_size,
            verbose=1)
        # if layer_num == 0:
        #     break
        print('debug')
        pass  # TO DEBUG

    def save_pretrain_final_model(self):
        self.densenet_model.save(self.final_save_enc_path)
        self.ae_densemodel.save(self.final_save_ae_path)

    def load_pretrain(self):
        self.ae_densemodel.load_weights(self.best_load_ae_path)

    def hsv2rgb(self, im):
        im = np.clip(im, a_min=-1., a_max=1.)
        # im[:, :, 0] = im[:, :, 0] * 360.
        # im[:, :, 1] = im[:, :, 1] * 1.
        # im[:, :, 2] = im[:, :, 2] * 255.
        im[:, :, 0] = im[:, :, 0] * 180. + 180.
        im[:, :, 1] = im[:, :, 1] * 0.5 + 0.5
        im[:, :, 2] = im[:, :, 2] * 127.5 + 127.5
        im = cv2.cvtColor(im, cv2.COLOR_HSV2RGB)
        return im  # TO DEBUG

    def lab2rgb(self, im):
        # For LAB, Hue range is [0,100],
        # Saturation range is [-128,127] and Value range is [-128,127]
        im = np.clip(im, a_min=0., a_max=1.)
        # im[:, :, 0] = im[:, :, 0] * 360.
        # im[:, :, 1] = im[:, :, 1] * 1.
        # im[:, :, 2] = im[:, :, 2] * 255.
        # im[:, :, 0] = im[:, :, 0] * 100.
        # im[:, :, 1] = im[:, :, 1] * 255. - 128.
        # im[:, :, 2] = im[:, :, 2] * 255. - 128.
        im1 = im * 128.
        im1 = cv2.cvtColor(im1, cv2.COLOR_LAB2RGB)
        im1 = im1 * 255.

        return im1  # TO DEBUG

    def finetune_generator(self, train_or_valid='train'):
        if train_or_valid == 'train':
            ori_gen = self.finetune_train_gen
        elif train_or_valid == 'valid':
            ori_gen = self.finetune_valid_gen
        else:
            ori_gen = None
        while True:
            ims, lbs = ori_gen.next()
            im = ims[0]
            mask = ims[1]
            ones_im = np.ones_like(im)
            im = im * (1 - mask)
            input_im = np.concatenate([im, ones_im, ones_im * mask], axis=-1)
            # yield ims, lbs
            yield input_im, lbs

    def finetune_generator_for_reconst(self, train_or_valid='train'):
        if train_or_valid == 'train':
            ori_gen = self.finetune_train_gen
        elif train_or_valid == 'valid':
            ori_gen = self.finetune_valid_gen
        else:
            ori_gen = None
        while True:
            ims, lbs = ori_gen.next()
            im = ims[0]
            mask = ims[1]
            ones_im = np.ones_like(im)
            im = im * (1 - mask)
            input_im = np.concatenate([im, ones_im, ones_im * mask], axis=-1)
            im_and_mask = np.concatenate([im, mask], axis=-1)
            # yield ims, lbs
            yield input_im, [lbs, im_and_mask]

    def capsule_hinge_loss(self, y_true, y_pred):
        alpha = 0.5
        # h_loss = y_true * K.relu(0.9 - y_pred) ** 2 + \
        #          alpha * (1 - y_true) * K.relu(y_pred - 0.1) ** 2
        h_loss = y_true * K.square(K.maximum(0., 0.9 - y_pred)) + \
                 alpha * (1 - y_true) * K.square(K.maximum(0., y_pred - 0.1))
        h_loss = K.mean(K.sum(h_loss, 1))
        return h_loss

    def reconst_loss(self, y_true, y_pred):
        im = K.slice(y_true, (0, 0, 0, 0), (-1, -1, -1, 3))
        mask = K.slice(y_true, (0, 0, 0, 3), (-1, -1, -1, 3))
        masked_im = im * (1 - mask)
        masked_con = y_pred * (1 - mask)
        reconst_loss = mean_squared_error(y_true=masked_im,
                                          y_pred=masked_con)
        return reconst_loss

    def finetune_train_autoenc(self, with_pretrain):
        print('training classifier')
        checkpointer = ModelCheckpoint(self.best_save_classifier_path,
                                       monitor='val_length_layer_loss',
                                       verbose=1,
                                       save_best_only=True)
        early_stopping = EarlyStopping(monitor='val_length_layer_loss',
                                       patience=10)
        finetune_train_genn = \
            self.finetune_generator_for_reconst(train_or_valid='train')
        finetune_valid_genn = \
            self.finetune_generator_for_reconst(train_or_valid='valid')
        whl_acc = []
        whl_val_acc = []
        whl_loss = []
        whl_val_loss = []
        dec_lr = 5e-6   # 1e-6
        stage_num = 1
        per_epochs = 100
        dec_ratio = 0.7
        decay_epoch_num = 30
        lr_tracker = LR_tracker(decay_epoch_num=decay_epoch_num,
                                dec_ratio=dec_ratio)
        capsule_hinge_loss_weight = 0.5
        reconst_loss_weight = 0.5
        for i in range(stage_num):
            print('Stage %d/%d:' % ((i + 1), stage_num))
            if with_flex:
                if i >= 7:
                    self.k0_layer.trainable = True
                    self.k1_layer.trainable = True
                    self.k2_layer.trainable = True
                    dec_lr = 1e-8

            # adam_opt = Adam(lr=dec_lr, decay=1e-6)
            adam_opt = Adam(lr=dec_lr, decay=1e-6,
                            beta_1=0.5, beta_2=0.999)
            sgd_opt = SGD(lr=dec_lr, decay=1e-6)
            print('current lr: ' + str(dec_lr))

            self.autoenc_model.compile(loss=[self.capsule_hinge_loss,
                                             self.reconst_loss],
                                       loss_weights=[capsule_hinge_loss_weight,
                                                     reconst_loss_weight],
                                       optimizer=adam_opt,
                                       # metrics={'length_layer': ['acc',
                                       #          self.capsule_hinge_loss],
                                       #          'gated_autoenc': self.reconst_loss},
                                       metrics={'length_layer': 'acc'})
            history = self.autoenc_model.fit_generator(
                generator=finetune_train_genn,
                steps_per_epoch=self.finetune_train_gen.samples /
                                self.finetune_train_gen.batch_size,
                epochs=per_epochs,
                callbacks=[early_stopping, lr_tracker],
                # callbacks=[early_stopping, checkpointer],
                validation_data=finetune_valid_genn,
                validation_steps=self.finetune_valid_gen.samples /
                                 self.finetune_valid_gen.batch_size,
                verbose=1
                #use_multiprocessing=True
            )
            # Plot the accuracy and loss curves
            acc = history.history['length_layer_acc']
            val_acc = history.history['val_length_layer_acc']
            loss = history.history['loss']
            val_loss = history.history['val_loss']

            whl_acc += acc
            whl_val_acc += val_acc
            whl_loss += loss
            whl_val_loss += val_loss
            dec_lr *= dec_ratio


        epochs = range(len(whl_acc))
        if with_pretrain:
            param_num = self.ae_densemodel.count_params()
        else:
            param_num = self.autoenc_model.count_params()

        plt.figure()
        plt.plot(epochs, whl_acc, 'b', label='Training acc')
        plt.plot(epochs, whl_val_acc, 'r', label='Validation acc')
        plt.title('Training and validation accuracy')
        plt.legend()

        plt.show()
        plt.savefig(self.save_acc_curve_im_path)
        # plt.close()

        plt.clf()
        plt.plot(epochs, whl_loss, 'b', label='Training loss')
        plt.plot(epochs, whl_val_loss, 'r', label='Validation loss')
        plt.title('Training and validation loss')
        plt.legend()

        plt.show()
        plt.savefig(self.save_loss_curve_im_path)

        epoch_lr_lst = lr_tracker.epoch_lr_lst
        plt.clf()
        plt.plot(epochs, epoch_lr_lst, 'b', label='Training lr')
        plt.title('Training lr')
        plt.legend()

        plt.show()
        plt.savefig(self.save_lr_curve_im_path)
        plt.close('all')

        txt_file = open(self.save_cond_txt_path, 'w')
        txt_file.write('data name: %s' % str(self.df_data_dir))
        txt_file.write('\n')
        txt_file.write('param_num: %s' % str(param_num))
        txt_file.write('\n')
        txt_file.write('dec lr: %s' % str(dec_lr))
        txt_file.write('\n')
        txt_file.write('dec ratio: %s' % str(dec_ratio))
        txt_file.write('\n')
        txt_file.write('capsule_hinge_loss_weight: %s'
                       % str(capsule_hinge_loss_weight))
        txt_file.write('\n')
        txt_file.write('reconst_loss_weight: %s'
                       % str(reconst_loss_weight))
        txt_file.write('\n')
        txt_file.write('decay_epoch_num: %s' % str(decay_epoch_num))
        txt_file.write('\n')
        txt_file.write('stage num: %s' % str(stage_num))
        txt_file.write('\n')
        txt_file.write('per epoch: %s' % str(per_epochs))
        txt_file.write('\n')
        txt_file.write('train_bth_size: %s' % str(self.train_bth_size))
        txt_file.write('\n')
        txt_file.write('with pretrain: %s' % str(with_pretrain))
        txt_file.write('\n')
        txt_file.close()

        whl_acc = list(map(float, whl_acc))
        self.epoch_list = [whl_loss, whl_acc, whl_val_loss, whl_val_acc]
        with open(self.save_epoch_list_json_path, 'w') as json_file:
            json.dump(self.epoch_list, json_file, indent=2)

        pass  # DEBUG
    def save_finetune_final_model(self):
        self.autoenc_model.save(filepath=self.final_save_classifier_path)
        pass  # DEBUG

    def finetune_test_generator(self):
        while True:
            ims, lbs = self.test_generator.next()
            im = ims[0]
            mask = ims[1]
            ones_im = np.ones_like(im)
            im = im * (1 - mask)
            input_im = np.concatenate([im, ones_im, ones_im * mask], axis=-1)
            im_and_mask = np.concatenate([im, mask], axis=-1)
            # yield ims, lbs
            yield input_im, [lbs, im_and_mask]

    def test_finetune_acc_for_split(self):
        # test_dir = os.path.join(self.lb_data_dir, 'test')
        # case_split_path = os.path.join(self.data_root_dir,
        #                                case_split_nm)
        # with open(case_split_path, 'r') as json_file:
        #     case_split = json.load(json_file)
        test_df_path = os.path.join(self.df_data_dir, 'test.csv')
        #test_df_path = os.path.join(self.df_data_dir, 'valid.csv')
        test_df = pd.read_csv(test_df_path)
        test_bth_size = 10
        # No Data augmentation
        if with_lab:
            test_datagen = \
                im_list_generator(preprocessing_function=self.rgb2lab)
        else:
            test_datagen = im_list_generator(rescale=1. / 255)

        self.test_generator = test_datagen.flow_from_dataframe(
            dataframe=test_df,
            directory_lst=self.ori_lb_data_dir_lst,
            x_col='fn',
            y_col='lbs',
            target_size=(self.im_res_size,
                         self.im_res_size),
            batch_size=test_bth_size,
            class_mode='categorical',
            shuffle=False,
            seed=SEED)
        # probs = self.classifier.predict_generator(generator=test_generator)
        test_genn = self.finetune_test_generator()
        loss, length_layer_loss, gated_autoenc_loss,\
        length_layer_acc = \
            self.autoenc_model.evaluate_generator(generator=test_genn,
                                              steps=self.test_generator.samples
                                                    / self.test_generator.batch_size)
        print('loss: ' + str(loss))
        print('length_layer_loss: ' + str(length_layer_loss))
        print('gated_autoenc_loss: ' + str(gated_autoenc_loss))
        print('length_layer_acc: ' + str(length_layer_acc))
        txt_file = open(self.save_cond_txt_path, 'a')
        txt_file.write('loss: %s' % str(loss))
        txt_file.write('\n')
        txt_file.write('length_layer_loss: %s' % str(length_layer_loss))
        txt_file.write('\n')
        txt_file.write('gated_autoenc_loss: %s' % str(gated_autoenc_loss))
        txt_file.write('\n')
        txt_file.write('length_layer_acc: %s' % str(length_layer_acc))
        txt_file.write('\n')
        txt_file.close()
        # case_split[self.split_idx].append([loss, length_layer_loss,
        #                                    gated_autoenc_loss,
        #                                    length_layer_acc])
        cur_loss_lst = [loss, length_layer_loss,
                        gated_autoenc_loss,
                        length_layer_acc]

        test_filenames = self.test_generator.filenames
        test_times = int(self.test_generator.samples /
                         self.test_generator.batch_size)
        whole_lbs = []
        whole_pred = []
        whole_lbs_lb = []
        whole_pred_lb = []
        judge_list = []
        fn_isright = []
        self.test_generator.reset()
        for test_i in range(test_times):
            assert self.test_generator.batch_index == test_i
            filenames_i = test_filenames[test_i * test_bth_size:
            (test_i + 1) * test_bth_size]
            batch_idx = self.test_generator.batch_index
            ims_i, lbs_i = self.test_generator.next()
            im_i = ims_i[0]
            mask_i = ims_i[1]
            ones_im_i = np.ones_like(im_i)
            im_i = im_i * (1 - mask_i)
            input_im_i = np.concatenate([im_i, ones_im_i,
                                       ones_im_i * mask_i], axis=-1)
            pred_i, pred_reconst_i = \
            self.autoenc_model.predict(input_im_i)
            lbs_i_lb = np.argmax(lbs_i, axis=-1)
            pred_i_lb = np.argmax(pred_i, axis=-1)
            if test_i == 0:
                whole_lbs = lbs_i
                whole_pred = pred_i
                whole_lbs_lb = lbs_i_lb
                whole_pred_lb = pred_i_lb
            else:
                whole_lbs = \
                    np.concatenate([lbs_i, whole_lbs], axis=0)
                whole_pred = \
                    np.concatenate([pred_i, whole_pred], axis=0)
                whole_lbs_lb = \
                    np.concatenate([lbs_i_lb, whole_lbs_lb], axis=0)
                whole_pred_lb = \
                    np.concatenate([pred_i_lb, whole_pred_lb], axis=0)
            for i in range(len(lbs_i_lb)):
                if lbs_i_lb[i] == pred_i_lb[i]:
                    fn_isright.append([filenames_i[i], True])
                    judge_list.append(True)
                else:
                    fn_isright.append([filenames_i[i], False])
                    judge_list.append(False)
        # case_split[self.split_idx].append(fn_isright)
        # json_inside = [test_filenames, whole_lbs.tolist(), whole_pred.tolist(),
        #                whole_lbs_lb.tolist(), whole_pred_lb.tolist(), judge_list]
        json_inside = [[loss, length_layer_loss,
                        gated_autoenc_loss,
                        length_layer_acc],
                       fn_isright]
        with open(self.save_pred_json_path, 'w') as json_file:
            json.dump(json_inside, json_file, indent=2)
        return loss, length_layer_acc, cur_loss_lst

    def test_autoenc_reconstruction_for_split(self):
        ############### Prepare Generator ##########################
        # test_dir = os.path.join(self.lb_data_dir, 'test')
        # case_split_path = os.path.join(self.data_root_dir,
        #                                case_split_nm)
        # with open(case_split_path, 'r') as json_file:
        #     case_split = json.load(json_file)
        test_df_path = os.path.join(self.df_data_dir, 'test.csv')
        #test_df_path = os.path.join(self.df_data_dir, 'valid.csv')
        test_df = pd.read_csv(test_df_path)
        test_bth_size = 4
        # No Data augmentation
        if with_lab:
            test_datagen = \
                im_list_generator(preprocessing_function=self.rgb2lab)
        else:
            test_datagen = im_list_generator(rescale=1. / 255)

        self.test_generator = test_datagen.flow_from_dataframe(
            dataframe=test_df,
            directory_lst=self.ori_lb_data_dir_lst,
            x_col='fn',
            y_col='lbs',
            target_size=(self.im_res_size,
                         self.im_res_size),
            batch_size=test_bth_size,
            class_mode='categorical',
            shuffle=False,
            seed=SEED)
        # probs = self.classifier.predict_generator(generator=test_generator)
        ims, lbs = self.test_generator.next()
        ims_true = ims[0]
        mask_true = ims[1]
        ones_im = np.ones_like(ims_true)
        im = ims_true * (1 - mask_true)
        input_im = np.concatenate([im, ones_im, ones_im * mask_true], axis=-1)
        ####################### Test Reconst #######################

        # ims_for_test must be an array, whose num is row_num * col_num
        test_num = input_im.shape[0]
        row_num = 2
        col_num = int(test_num / row_num)
        _, recon_ims = self.autoenc_model.predict(input_im)
        show_ims = np.zeros(shape=(row_num * 2 * self.im_res_size,
                                   col_num * self.im_res_size, 3))
        for row_i in range(row_num):
            for col_i in range(col_num):
                im_i = row_i * col_num + col_i
                im = ims_true[im_i]
                # im = imresize(im, size=(self.im_res_size,
                #                         self.im_res_size))
                show_ims[row_i * 2 * self.im_res_size:
                         (row_i * 2 + 1) * self.im_res_size,
                col_i * self.im_res_size:
                (col_i + 1) * self.im_res_size, :] = im * 255.
                recon_im = recon_ims[im_i]
                if with_lab:
                    recon_im = self.lab2rgb(recon_im)
                else:
                    recon_im = recon_im * 255.
                show_ims[(row_i * 2 + 1) * self.im_res_size:
                         (row_i * 2 + 2) * self.im_res_size,
                col_i * self.im_res_size:
                (col_i + 1) * self.im_res_size, :] = recon_im

        # imsave(name=self.recon_im_path, arr=show_ims)
        show_ims = pil.fromarray(show_ims.astype(np.uint8))
        show_ims.save(self.recon_im_path)
        show_ims.close()
        pass  # TO DEBUG

    def test_finetune_acc_with_weights(self, weights_path):
        test_df_path = os.path.join(self.df_data_dir, 'test,csv')
        test_df = pd.read_csv(test_df_path)
        test_bth_size = 100
        # No Data augmentation
        self.autoenc_model.load_weights(weights_path)
        test_datagen = \
            im_list_generator(preprocessing_function=self.rgb2lab)
        self.test_generator = test_datagen.flow_from_dataframe(
            dataframe=test_df,
            directory_lst=self.ori_lb_data_dir_lst,
            target_size=(self.im_res_size,
                         self.im_res_size),
            batch_size=test_bth_size,
            class_mode='categorical',
            shuffle=False,
            seed=SEED)
        test_genn = self.finetune_test_generator()
        # probs = self.classifier.predict_generator(generator=test_generator)
        loss, acc = \
            self.autoenc_model.evaluate_generator(generator=test_genn,
                                              steps=self.test_generator.samples
                                                    / self.test_generator.batch_size)
        print('loss: ' + str(loss))
        print('acc: ' + str(acc))

    def test_finetune_acc_with_weights_to_res(self, weights_path,
                                       result_save_dir,
                                       loss_acc_json_name,
                                       test_dir):
        save_loss_acc_path = os.path.join(result_save_dir,
                                          loss_acc_json_name)
        test_bth_size = 100
        # No Data augmentation
        self.autoenc_model.load_weights(weights_path)
        test_datagen = \
            im_list_generator(rescale=1. / 255)
        test_generator = test_datagen.flow_from_directory(
            test_dir,
            target_size=(self.im_res_size,
                         self.im_res_size),
            batch_size=test_bth_size,
            class_mode='categorical',
            shuffle=False,
            seed=SEED)
        # probs = self.cls_model.predict_generator(generator=test_generator)
        loss, acc = \
            self.autoenc_model.evaluate_generator(generator=test_generator,
                                              steps=test_generator.samples
                                                    / test_generator.batch_size)
        print('loss: ' + str(loss))
        print('acc: ' + str(acc))
        with open(save_loss_acc_path, 'w') as json_file:
            json.dump([loss, acc], json_file, indent=2)

    # def test_finetune_acc_with_weights_for_one(self, weights_path,
    #                                    test_path):
    #     im = imread(test_path)
    #     im = imresize(im, size=(self.im_res_size,
    #                             self.im_res_size))
    #     im = im / 255.
    #     im = np.expand_dims(im, axis=0)
    #     self.autoenc_model.load_weights(weights_path)
    #     probs = self.autoenc_model.predict(x=im)
    #     # print('probs: ' + str(probs))
    #     return probs

    def visualize_heatmap_with_weights_to_res(self, weights_path,
                                              result_im_save_dir,
                                              test_im_dir, true_label,
                                              visual_num=16):
        if not os.path.exists(result_im_save_dir):
            os.mkdir(result_im_save_dir)
        #################### model part ########################
        grads = K.gradients(self.output_f,
                            self.conv_f)[0]
        pooled_grads = K.mean(grads, axis=(0, 1, 2))
        func = K.function([self.input_im],
                          [pooled_grads, self.conv_f[0]])
        conv_f_dim = self.conv_f.shape[-1]
        ################### test images ########################
        ori_im_list = os.listdir(test_im_dir)  # belong to a single class
        ori_im_list = ori_im_list[: visual_num]
        for im_name in ori_im_list:
            im_path = os.path.join(test_im_dir, im_name)
            ################### preprocess #####################
            im = image.load_img(im_path,
                                target_size=(self.im_res_size,
                                             self.im_res_size))
            x = image.img_to_array(im)
            x = np.expand_dims(x, axis=0)
            x = x / 255.
            #################### predict label #################
            pred_prob, _ = self.autoenc_model.predict(x)
            pred_lb = np.argmax(pred_prob)
            if pred_lb == true_label:
                pre_str = 'right'
            else:
                pre_str = 'wrong'
            save_im_name = pre_str + '_' + im_name
            save_im_path = os.path.join(result_im_save_dir, save_im_name)
            #################### compute heatmap ###############
            pooled_grads_val, conv_f_val = func([x])
            for dim_i in range(conv_f_dim):
                conv_f_val[:, :, dim_i] *= pooled_grads_val[dim_i]
            heatmap = np.mean(conv_f_val, axis=-1)
            ########## heatmap postprocess ########
            heatmap = np.maximum(heatmap, 0)
            heatmap /= np.max(heatmap)
            ##################### overlap heatmap & im ##########
            im = cv2.imread(im_path)
            im = cv2.cvtColor(im, cv2.COLOR_RGB2GRAY)
            heatmap = cv2.resize(heatmap,
                                 (im.shape[1], im.shape[0]))
            heatmap = np.uint8(255 * heatmap)
            heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
            superimposed_im = heatmap * 0.4 + im
            cv2.imwrite(save_im_path, superimposed_im)

def main_run(dataset_ch, rand_ch, mag_ch, im_ch, continue_for=None):
    rand_lst = [5, 10, 20]
    mag_lst = ['40X', '100X', '200X', '400X']
    dataset_lst = ['SRBCT', 'BreakHist', 'IICBU']
    im_lst = ['Normal', 'ClrNrm', 'MaskInp']
    rand_num = rand_lst[rand_ch]
    mag_nm = mag_lst[mag_ch]
    im_stat = im_lst[im_ch]
    dataset_nm = dataset_lst[dataset_ch]
    str_cond = ""
    str_cond2 = ""
    IF_CONTINUE = False
    assert dataset_ch in [0, 1, 2]
    if dataset_ch == 0:
        rand_num = 30
        suffix_str = dataset_nm + '_' + str(rand_num) + 'exp'
    elif dataset_ch == 1:
        suffix_str = dataset_nm + '_' + im_stat + '_' + \
                     mag_nm + '_' + str(rand_num) + 'exp'
    elif dataset_ch == 2:
        suffix_str = dataset_nm + '_' + im_stat + '_' + \
                     str(rand_num) + 'exp'
    print(suffix_str)
    if IF_CONTINUE and mag_ch == continue_for:
        weight_dir_name = 'gated_hinge_reconst_BreakHist_' \
                          'MaskInp_200X_20exp_2021-01-04'
        start_exp_i = 12
    else:
        if save_time_weight:
            weight_dir_name = 'gated_hinge_reconst_' + \
                              suffix_str + '_' + \
                              str(datatime)

        else:
            weight_dir_name = 'gated_hinge_reconst_' + dataset_nm + '_' + \
                              str(rand_num) + 'exp_current'
        start_exp_i = 0
    # weight_dir_name = 'weights_10exp_without_lab_with_texture_with_pretrain_with_flex_2019-06-05'
    if dataset_ch == 0:
        df_dir_nm = '191127_' + str(rand_num) + '_csv_splits_2400'
        # case_split_nm = '191118_' + str(rand_num) + '_case_split.json'
        image_dir_lst = ['200102_SRCT_im_mask_inpaint_Rotate224',
                         '200102_SRCT_pure_mask_Rotate224']
    elif dataset_ch == 1:  # 201215_40X_5_csv_splits
        df_dir_nm = '201215_' + str(mag_nm) + '_' + \
                    str(rand_num) + '_csv_splits'
        image_dir_lst = ['201218_BreakHist_IMask_Inpaint_f',
                        '201218_BreakHist_PMask_Inpaint_f']
    elif dataset_ch == 2:  # 201226_5_csv_splits
        df_dir_nm = '201226_' + str(rand_num) + '_csv_splits'
        image_dir_lst = ['201224_IICBU_IMask_Inpaint_f',
                        '201224_IICBU_PMask_Inpaint_f']
    case_split_test = []
    for exp_i in range(start_exp_i, rand_num):
        print('exp_i: ' + str(exp_i))
        exp_dir_name = 'exp_' + str(exp_i)
        df_split_name = os.path.join(df_dir_nm,
                                     'split_' + str(exp_i))
        # exp_case_split = None
        semi_model = \
            texture_autoencoder_classifier(dataset_ch=dataset_ch,
                                           df_split_name=df_split_name,
                                           image_dir_lst=image_dir_lst,
                                           weight_dir_name=weight_dir_name,
                                           exp_dir_name=exp_dir_name,
                                           test_mode=False,
                                           Split_train=split_train,
                                           split_idx=exp_i)
        if with_pretrain == True:
            semi_model.pretrain()
            # semi_model.test_pretrain_reconstruction()
            semi_model.save_pretrain_final_model()
        # semi_model.load_pretrain()
        semi_model.finetune_train_autoenc(with_pretrain=with_pretrain)
        semi_model.save_finetune_final_model()
        if split_train:
            exp_loss, exp_acc, exp_case_split = \
                semi_model.test_finetune_acc_for_split()
            semi_model.test_autoenc_reconstruction_for_split()
        else:
            exp_loss, exp_acc = \
                semi_model.test_finetune_acc()
        K.clear_session()
        gc.collect()
        del semi_model

    if dataset_ch == 0:
        data_root_dir = '/Datasets/ewings_NBUD'
    elif dataset_ch == 1:
        data_root_dir = \
            '/Datasets/histology/BreakHist'
    elif dataset_ch == 2:
        data_root_dir = \
            ''
    semi_save_dir = \
        os.path.join(data_root_dir,
                     'semi_weights')
    save_finetune_dir = \
        os.path.join(semi_save_dir,
                     'finetune_weights')
    save_finetune_weight_dir = \
        os.path.join(save_finetune_dir, weight_dir_name)
    exp_lst = os.listdir(save_finetune_weight_dir)
    exp_loss_list = []
    exp_cls_loss_lst = []
    exp_autoenc_loss_lst = []
    exp_acc_list = []
    for exp_nm in exp_lst:
        exp_dir = os.path.join(save_finetune_weight_dir,
                               exp_nm)
        pred_lst_path = os.path.join(exp_dir,
                                     'finetune_test_pred.json')
        if not os.path.exists(pred_lst_path):
            continue
        with open(pred_lst_path, 'r') as json_file:
            pred_lst = json.load(json_file)
            pred_lst = pred_lst[0]
            exp_loss = pred_lst[0]
            exp_cls_loss = pred_lst[1]
            exp_autoenc_loss = pred_lst[2]
            exp_cls_acc = pred_lst[3]
            exp_loss_list.append(exp_loss)
            exp_cls_loss_lst.append(exp_cls_loss)
            exp_autoenc_loss_lst.append(exp_autoenc_loss)
            exp_acc_list.append(exp_cls_acc)

        # if split_train:
        #     case_split_test.append(exp_case_split)

    loss_mean = np.mean(exp_loss_list, axis=0)
    cls_loss_mean = np.mean(exp_cls_loss_lst, axis=0)
    autoenc_loss_mean = np.mean(exp_autoenc_loss_lst, axis=0)
    acc_mean = np.mean(exp_acc_list, axis=0)

    loss_std = np.std(exp_loss_list, axis=0)
    cls_loss_std = np.std(exp_cls_loss_lst, axis=0)
    autoenc_loss_std = np.std(exp_autoenc_loss_lst, axis=0)
    acc_std = np.std(exp_acc_list, axis=0)
    exp_loss_acc_list = [exp_loss_list,
                         exp_cls_loss_lst,
                         exp_autoenc_loss_lst,
                         exp_acc_list]
    loss_acc_mean_std_list = [loss_mean, loss_std,
                              cls_loss_mean, cls_loss_std,
                              autoenc_loss_mean, autoenc_loss_std,
                              acc_mean, acc_std]
    save_exp_loss_acc_json_path = \
        os.path.join(save_finetune_weight_dir, 'exp_loss_acc_list.json')
    save_exp_loss_acc_mean_std_txt_path = \
        os.path.join(save_finetune_weight_dir, 'exp_loss_acc_mean_std_list.json')
    save_case_split_test_path = \
            os.path.join(save_finetune_weight_dir, 'case_split_test_list.json')

    with open(save_exp_loss_acc_json_path, 'w') as json_file:
        json.dump(exp_loss_acc_list, json_file, indent=2)

    with open(save_exp_loss_acc_mean_std_txt_path, 'w') as json_file:
        json.dump(loss_acc_mean_std_list, json_file, indent=2)

    rm_f_path = os.path.join(save_finetune_weight_dir, 'README.txt')
    rm_f = open(rm_f_path, 'w')
    cfn = os.path.basename(__file__)
    rm_f.write('Generated by python file: ' + cfn + '\n')
    rm_f.write(str(exp_loss_acc_list) + '\n')
    rm_f.write(str(loss_acc_mean_std_list) + '\n')
    rm_f.close()
    print('stay')

with_lab = False
with_texture = False
with_flex = False
with_pretrain = False
save_time_weight = True
with_test_mode = True
split_train = True
if __name__ == '__main__':
################################ Train Multiple Splits #############################
    datatime = datetime.datetime.now().strftime("%Y-%m-%d")
    dataset_ch = 1
    rand_ch = 2
    im_ch = 2
    continue_for = 2
    for mag_i in range(3, 4):
        mag_ch = mag_i
        main_run(dataset_ch, rand_ch, mag_ch, im_ch, continue_for)