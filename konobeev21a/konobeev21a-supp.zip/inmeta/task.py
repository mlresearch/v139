""" Code to create synthetic meta-learning tasks. """
from abc import ABC, abstractmethod
from collections import namedtuple
from itertools import starmap
import matplotlib.pyplot as plt
import numpy as np
from scipy.linalg import block_diag
from sklearn.model_selection import train_test_split


Samples = namedtuple("Samples", ["features", "labels"])
MetaSplit = namedtuple("MetaSplit", ["train", "adaptation", "test"])


def adaptation_test_split(features, labels, adaptation_size):
  """ Performs adaptation-test split on data. """
  adaptation = []
  test = []
  for i in range(features.shape[0]):
    split = train_test_split(features[i], labels[i], shuffle=False,
                             train_size=adaptation_size)
    adaptation.append(split[::2])
    test.append(split[1::2])
  adaptation = list(map(np.asarray, zip(*adaptation)))
  test = list(map(np.asarray, zip(*test)))
  return Samples(*adaptation), Samples(*test)


def train_adaptation_test_split(features, labels,
                                train_tasks_size, adaptation_size):
  """ Performs train-adaptation-test split on data. """
  split = train_test_split(features, labels, shuffle=False,
                           train_size=train_tasks_size)
  train = split[::2]
  adaptation, test = adaptation_test_split(*split[1::2], adaptation_size)
  return MetaSplit(*starmap(Samples, (train, adaptation, test)))


def subset_samples(features, labels, ntasks=None, task_size=None):
  """ Returns subset of features & labels wih ntasks and task_size. """
  if ntasks is not None:
    features, labels = features[:ntasks], labels[:ntasks]
  if task_size is not None:
    features = np.asarray([X[:task_size] for X in features])
    labels = np.asarray([y[:task_size] for y in labels])
  return Samples(features, labels)


class DataRunner:
  """ Subsets train data with elements from spaces. """
  def __init__(self, meta_split, ntasks_space=None, task_size_space=None):
    if ntasks_space is None and task_size_space is None:
      raise ValueError("at least one of ntasks_space, task_size_space "
                       "should not be None")
    ntasks = meta_split.train.features.shape[0]
    task_size = min(task_data.shape[0]
                    for task_data in meta_split.train.features)
    if (ntasks_space is not None and ntasks < ntasks_space[-1]
        or task_size_space is not None and task_size < task_size_space[-1]):
      error_msg = (f"meta_split has ntasks={ntasks} and minimum "
                   f"task_size={task_size} however spaces require ")
      if ntasks_space is not None:
        error_msg += f"at least {ntasks_space[-1]} ntasks "
        if task_size is not None:
          error_msg += "and "
      if task_size_space is not None:
        error_msg += f"at least {task_size_space[-1]} task_size "
      error_msg += "per task"
      raise ValueError(error_msg)
    self.split = meta_split
    self.ntasks_space = ntasks_space
    self.task_size_space = task_size_space

  def run_ntasks(self, task_size=None):
    """ Runs through ntasks space. """
    if self.ntasks_space is None:
      raise ValueError("ntasks_space was set to None at initialization, "
                       "no iteration possible")
    for ntasks in self.ntasks_space:
      train = subset_samples(*self.split.train, ntasks, task_size)
      yield MetaSplit(*starmap(
          Samples, (train, self.split.adaptation, self.split.test)))

  def run_task_sizes(self, ntasks=None):
    """ Runs through task size space. """
    if self.task_size_space is None:
      raise ValueError("task_size_space was set to None at initialization, "
                       "no iteration possible")
    for task_size in self.task_size_space:
      train = subset_samples(*self.split.train, ntasks, task_size)
      yield MetaSplit(*starmap(
          Samples, (train, self.split.adaptation, self.split.test)))


class LinearModelSampler(ABC):
  """ Samples features and labels with linear model. """
  def __init__(self, param_mean, param_var, task_var):
    if param_mean.ndim != 1:
      raise ValueError("param_mean is expected to have 1 dimension, got "
                       f"param_mean.ndim={param_mean.ndim}")
    self.param_mean = param_mean
    self.dim = self.param_mean.shape[0]
    if param_var.shape != (self.dim, self.dim):
      raise ValueError("param_var is expected to have shape "
                       f"({self.dim}, {self.dim}), got shape {param_var.shape}")
    self.param_var = param_var
    self.task_var = task_var
    self.weight_history = []

  def sample_weights(self, ntasks):
    """ Samples weights for specified number of tasks."""
    new_weights = np.random.multivariate_normal(
        self.param_mean, self.param_var, size=ntasks)
    self.weight_history.append(new_weights)
    return new_weights

  @abstractmethod
  def sample_features(self, ntasks, task_size):
    """ Samples features. """

  def compute_labels(self, features, weights=None):
    """ Computes labels for given features. """
    weights = weights if weights is not None else self.weight_history[-1]
    return (features * weights[:, None, :]).sum(-1)

  def add_noise(self, labels):
    """ Adds nois to the labels. """
    ntasks, task_size = labels.shape
    return labels + np.random.normal(scale=np.sqrt(self.task_var),
                                     size=(ntasks, task_size))

  def sample(self, ntasks, task_size):
    """ Samples and returns features and labels. """
    features = self.sample_features(ntasks, task_size)
    weights = self.sample_weights(ntasks)
    labels = self.compute_labels(features, weights=weights)
    labels = self.add_noise(labels)
    return Samples(features, labels)

  def get_meta_split(self, train_dims, num_test_tasks,
                     adaptation_size, test_size):
    """ Samples features, labels and creates meta-split. """
    train = self.sample(*train_dims)
    features, labels = self.sample(num_test_tasks, adaptation_size + test_size)
    adapt = Samples(features[:, :adaptation_size], labels[:, :adaptation_size])
    test = Samples(features[:, -test_size:], labels[:, -test_size:])
    return MetaSplit(train, adapt, test)


def sample_spherical(npoints, dim=3):
  """ Uniformly samples points on a sphere. """
  vec = np.random.randn(npoints, dim)
  vec /= np.linalg.norm(vec, axis=1, keepdims=True)
  return vec


class SphericalFeaturesLinearModelSampler(LinearModelSampler):
  """ Samples features from a sphere. """
  def sample_features(self, ntasks, task_size):
    features = sample_spherical(ntasks * task_size, self.dim)
    return np.reshape(features, (ntasks, task_size, self.dim))


class GaussianFeaturesLinearModelSampler(LinearModelSampler):
  """ Samples features from normal distribution. """
  def sample_features(self, ntasks, task_size):
    features = np.random.randn(ntasks * task_size, self.dim)
    return np.reshape(features, (ntasks, task_size, self.dim))


# pylint: disable=invalid-name
def fourier_features(xs, period, dim):
  """ Creates Fourier basis features for the given xs. """
  assert dim % 2 == 1, dim
  assert xs.ndim == 1, xs.shape
  xs = xs[:, None]
  num_funcs = (dim - 1) // 2
  js = np.arange(1, num_funcs + 1)[None]
  cosines = np.cos(2 * np.pi * js * xs / period)
  sines = np.sin(2 * np.pi * js * xs / period)
  return np.concatenate([np.ones((xs.shape[0], 1)),
                         cosines, sines], axis=-1).astype(np.float32)
# pylint: enable=invalid-name

def param_var_fourier(bias_var, cos_var, sin_var):
  """ Returns covariance matrix for Fourier features. """
  return block_diag(np.array([[bias_var]]).astype(np.float),
                    cos_var, sin_var)


class FourierFeaturesLinearModelSampler(LinearModelSampler):
  """ Samples fourier features for points a line segment. """
  def __init__(self, param_mean, param_var, task_var, xlim=(-5, 5)):
    super().__init__(param_mean, param_var, task_var)
    self.xlim = xlim
    self.period = self.xlim[1] - self.xlim[0]
    self.xs = None
    self.sample_history = {"xs": [], "features": [], "labels": []}

  def append_history(self, **kwargs):
    """ Appends new samples to sample history. """
    for key in self.sample_history:
      self.sample_history[key].append(kwargs[key])

  def sample_features(self, ntasks, task_size):
    xs = np.random.uniform(*self.xlim, size=ntasks * task_size)
    self.xs = np.reshape(xs, (ntasks, task_size))
    features = fourier_features(xs, self.period, self.dim)
    return np.reshape(features, (ntasks, task_size, self.dim))

  def sample(self, ntasks, task_size):
    sample = super().sample(ntasks, task_size)
    self.append_history(xs=self.xs, features=sample.features,
                        labels=sample.labels)
    return sample

  def xs_features(self, history_index, task_index, sample_indices=None):
    """ Returns sorted xs and features. """
    xs = self.sample_history["xs"][history_index][task_index]
    features = self.sample_history["features"][history_index][task_index]
    if sample_indices is not None:
      xs, features = xs[sample_indices], features[sample_indices]
    sort_idx = np.argsort(xs)
    return xs[sort_idx], features[sort_idx]

  def scatter_samples(self, history_index, task_index,
                      sample_indices=None, **kwargs):
    """ Plots specified samples. """
    xs = self.sample_history["xs"][history_index][task_index]
    labels = self.sample_history["labels"][history_index][task_index]
    if sample_indices is not None:
      xs, labels = xs[sample_indices], labels[sample_indices]
    sort_idx = np.argsort(xs)
    return plt.scatter(xs[sort_idx], labels[sort_idx], **kwargs)

  def true_plot(self, history_index, task_index, **kwargs):
    """ Plots true function in specified samples. """
    xs = np.linspace(*self.xlim)
    features = fourier_features(xs, self.period, self.dim)
    weights = self.weight_history[history_index][task_index]
    labels = np.squeeze(self.compute_labels(features[None], weights[None]), 0)
    return plt.plot(xs, labels, **kwargs)

  def plot(self, history_index, task_index, sample_indices=None, **kwargs):
    """ Plots specified samples along with true function. """
    line, = self.true_plot(history_index, task_index, **kwargs)
    if "color" not in kwargs:
      kwargs["color"] = line.get_color()
    scatter = self.scatter_samples(history_index, task_index,
                                   sample_indices, **kwargs)
    return line, scatter


def shuffle_together(*arrays):
  """ Shuffles a bunch of arrays along the zeroth axis in the same way. """
  indices = np.random.permutation(arrays[0].shape[0])
  for arr in arrays:
    arr[:] = arr[indices]

def shuffle_samples(features, labels, outer=True, inner=True):
  """ Shuffles meta-learning features and labels. """
  if outer:
    shuffle_together(features, labels)
  if inner:
    for i in range(features.shape[0]):
      shuffle_together(features[i], labels[i])
