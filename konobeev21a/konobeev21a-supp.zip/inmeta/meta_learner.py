""" Implements meta-learning algorithm for linear regression. """
from abc import ABC, abstractmethod
from collections import defaultdict
import warnings
from jax import grad
from jax.config import config
import jax.numpy as jnp
import numpy as np
from scipy.linalg import block_diag
from scipy.optimize import minimize
from scipy.stats import loguniform, multivariate_normal
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import RandomizedSearchCV, train_test_split
from skopt import BayesSearchCV
import skopt.space
from inmeta.task import Samples
config.update("jax_enable_x64", True)


def asobjects(arr):
  """ Converts ndarray to 1d array of np.object type. """
  arr = np.asarray(arr)
  objs = np.empty(arr.shape[0], np.object)
  objs[:] = list(arr)
  return objs


def asarray(arr):
  """ Casts array of objects to ndarray. """
  return np.asarray(list(arr))


# Functions that would act on arrays of np.objects
# This is a way of adding broadcasting for these functions.
matmul = np.frompyfunc(np.matmul, 2, 1)
transpose = np.frompyfunc(np.transpose, 1, 1)
diag = np.frompyfunc(np.diag, 1, 1)
mean = np.frompyfunc(np.mean, 1, 1)


def arg_cast_float32(fun):
  """ Casts inputs to the function from float64 to float32. """
  def wrapped(*args, **kwargs):
    def cast(data):
      if isinstance(data, np.ndarray) and data.dtype == np.float64:
        data = data.astype(np.float32)
      return data
    return fun(*[cast(arg) for arg in args],
               **{key: cast(val) for key, val in kwargs.items()})
  return wrapped


def add_constant_feature(features):
  """ Adds constant feature to each task. """
  single_task = features.ndim == 2
  if single_task:
    features = asobjects([features])
  features = np.asarray([np.concatenate([X, np.ones((X.shape[0], 1))], 1)
                         for X in features])
  return features[0] if single_task else features


def fit_param_mean(features, labels, param_var, task_var):
  """ Estimate mean of parameter distribution. """
  ntasks, task_size, dim = features.shape
  # pylint: disable=invalid-name
  X = jnp.asarray(block_diag(*features))
  param_var_tasks = jnp.kron(jnp.eye(ntasks), param_var)
  marginal_var = (X @ param_var_tasks @ X.T
                  + task_var * jnp.eye(ntasks * task_size))
  features_stack = jnp.reshape(features, (ntasks * task_size, dim))
  labels_stack = jnp.reshape(labels, ntasks * task_size)
  param_mean = jnp.linalg.solve(
      features_stack.T @ jnp.linalg.solve(marginal_var, features_stack),
      features_stack.T @ jnp.linalg.solve(marginal_var, labels_stack))
  return param_mean


def fit_param_mean_broadcast(features, labels, param_var, task_var):
  """ Estimate parameter distribution mean w/ broadcasting (a bit slower). """
  _, task_size, _ = features.shape
  features_transpose = np.transpose(features, (0, 2, 1))
  marginal_var = (features @ param_var @ features_transpose
                  + task_var * jnp.eye(task_size))
  param_mean = jnp.linalg.solve(
      (features_transpose
       @ jnp.linalg.solve(marginal_var, features)).sum(0),
      (features_transpose
       @ jnp.linalg.solve(marginal_var, labels[..., None])).sum(0)
  ).squeeze(-1)
  return param_mean


def fit_all_tasks(features, labels, param_mean, param_var, task_var):
  """ Estimates and returns weights for all tasks. """
  features, labels = asobjects(features), asobjects(labels)
  feature_correlations = asarray(matmul(transpose(features), features))
  features_labels = asarray(matmul(transpose(features), labels))
  dim = feature_correlations.shape[-1]

  scales = task_var * jnp.eye(dim) + param_var[None] @ feature_correlations
  weights = jnp.linalg.solve(
      scales, (task_var * param_mean[..., None]
               + param_var[None] @ features_labels[..., None]))
  return jnp.squeeze(weights, -1)


# pylint: disable=too-many-arguments
def fit_task(features, labels, param_mean, param_var, task_var):
  """ Performs task adaptation and returns the estimated weights. """
  param_var_inv = jnp.linalg.inv(param_var)
  posterior_var = jnp.linalg.inv(
      param_var_inv + 1 / task_var * features.T @ features)

  weights = (posterior_var
             @ (param_var_inv @ param_mean
                + 1 / task_var * features.T @ labels))
  return weights
# pylint: enable=too-many-arguments


class BaseMetaLearner(ABC):
  """ Base class for all meta-learners. """

  @abstractmethod
  def fit(self, features, labels):
    """ Performs meta-learning. """

  @abstractmethod
  def predict(self, features, labels, test_features):
    """ Performs adaption and return predictions on test_features. """


class PosteriorMeanMetaLearner(BaseMetaLearner):
  """ Computes predictions by computing dot product with posterior mean. """
  def __init__(self, param_mean=None, param_var=None, task_var=None):
    self.param_mean = param_mean
    self.param_var = param_var
    self.task_var = task_var

  def predict(self, features, labels, test_features):
    single_task = features.ndim == 2
    adapt_fn = fit_task if single_task else fit_all_tasks
    weights = np.asarray(adapt_fn(features, labels, self.param_mean,
                                  self.param_var, self.task_var))
    if single_task:
      return test_features @ weights
    preds = matmul(asobjects(test_features), asobjects(weights))
    if test_features.dtype != np.object:
      return asarray(preds)
    return preds


class MergeTrainAdaptWrapper(BaseMetaLearner):
  def __init__(self, learner):
    self.learner = learner
    self.fit_features = None
    self.fit_labels = None

  def fit(self, features, labels):
    self.fit_features = asobjects(features)
    self.fit_labels = asobjects(labels)
    return self

  def predict(self, features, labels, test_features):
    single_task = features.ndim == 2
    if single_task:
      features, labels = asobjects([features]), asobjects([labels])
      test_features = asobjects([test_features])
    preds = []
    for i, (task_features, task_labels) in enumerate(zip(features, labels)):
      train_features = np.concatenate(
          [self.fit_features, asobjects([task_features])], 0)
      train_labels = np.concatenate(
          [self.fit_labels, asobjects([task_labels])], 0)
      self.learner.fit(train_features, train_labels)
      preds.append(self.learner.predict(task_features, task_labels,
                                        test_features[i]))
    preds = (asobjects(preds) if test_features.dtype == np.object
             else np.asarray(preds))
    if single_task:
      preds = preds[0]
    return preds


class MetaLearnerCov(PosteriorMeanMetaLearner):
  """ Linear regression meta-learning algorithm. """
  def __init__(self, param_var, task_var):
    super().__init__(param_var=param_var, task_var=task_var)

  def fit(self, features, labels):
    """ Performs meta-learning and fine-tunes for the specified task. """
    self.param_mean = np.asarray(
        fit_param_mean(features, labels, self.param_var, self.task_var))
    return self


def best_fit_error(cov, features, labels):
  """ Returns best fit error for given covariance structure. """
  ltmat, log_task_var = cov[:-1], cov[-1]
  dim = features.shape[-1]
  ltmat = jnp.reshape(ltmat, (dim, dim))
  ltmask = jnp.arange(dim) >= jnp.arange(dim)[:, None]
  ltmat = ltmask * ltmat
  param_var = ltmat @ ltmat.T
  task_var = jnp.exp(log_task_var)

  param_mean = fit_param_mean(features, labels, param_var, task_var)
  weights = fit_all_tasks(features, labels, param_mean, param_var, task_var)
  preds = jnp.asarray(block_diag(*features)) @ jnp.reshape(weights, -1)
  return jnp.mean(jnp.square(preds - jnp.ravel(labels)))

def normalize_features(features):
  """ Normalizes the features to have zero mean and std = 1. """
  return ((features - np.mean(features, -1, keepdims=True))
          / np.std(features, -1, keepdims=True))


class HeuristicMetaLearner(BaseMetaLearner):
  """ Linear regression meta-learning with unknown covariance structure. """
  def __init__(self, normalize=False, tol=1e-6):
    self.normalize = normalize
    self.tol = tol
    self.meta_learner_cov = None
    self.opt_results = []

  def fit(self, features, labels):
    """ Performs learning and fine-tunes for the specified task. """
    assert features.ndim == 3 and labels.ndim == 2,\
        (features.shape, labels.shape)
    if self.normalize:
      features = normalize_features(features)
    dim = features.shape[-1]
    ltmat = np.eye(dim).flatten()
    log_task_var = np.asarray([0.])
    # pylint: disable=invalid-name
    x0 = np.concatenate([ltmat.flatten(), log_task_var], 0)

    optres = minimize(
        best_fit_error, x0=x0,
        args=(features, labels), jac=grad(best_fit_error), tol=self.tol)
    self.opt_results.append(optres)
    ltmat, log_task_var = optres.x[:-1], optres.x[-1]
    ltmat = np.reshape(ltmat, (dim, dim))
    param_var = ltmat @ ltmat.T
    task_var = np.exp(log_task_var)

    self.meta_learner_cov = MetaLearnerCov(param_var, task_var)
    self.meta_learner_cov.fit(features, labels)
    return self

  def predict(self, features, labels, test_features):
    return self.meta_learner_cov.predict(features, labels, test_features)


class MomentMatchingMetaLearner(PosteriorMeanMetaLearner):
  """ Moment matching meta-learning. """
  def __init__(self, regularization_coef=0.):
    super().__init__()
    self.regularization_coef = regularization_coef

  def fit(self, features, labels):
    ntasks = features.shape[0]
    # pylint: disable=invalid-name
    X = block_diag(*features)
    y = np.concatenate(labels, 0)

    correlation_matrix = X.T @ X
    correlation_matrix += (self.regularization_coef
                           * np.eye(correlation_matrix.shape[0]))
    weights = np.linalg.solve(correlation_matrix, X.T @ y)
    self.task_var = np.mean(y * (y - X @ weights))

    dim = X.shape[-1] // ntasks
    weights = np.reshape(weights, (ntasks, dim))
    cov_weights = np.cov(weights, rowvar=False)
    self.param_var = (
        cov_weights - self.task_var * np.linalg.inv(X.T @ X).reshape(
            (ntasks, dim, ntasks, dim)).mean((0, 2)))
    # pylint: enable=invalid-name

    self.param_mean = np.mean(weights, 0)
    return self


class EMMetaLearner(PosteriorMeanMetaLearner):
  """ Meta-learner that tunes model parameters with EM-algorithm. """
  def __init__(self, max_iter=1000, tol=1e-6, fit_intercept=False):
    super().__init__()
    self.max_iter = max_iter
    self.tol = tol
    self.fit_intercept = fit_intercept
    self.fit_history = defaultdict(list)

  def estep(self, feature_correlations, features_labels):
    """ E-step of the EM-algorithm. """
    dim = feature_correlations.shape[-1]
    scales = (self.task_var * np.eye(dim)
              + self.param_var[None] @ feature_correlations)
    posterior_means = np.linalg.solve(
        scales, (self.task_var * self.param_mean[..., None]
                 + self.param_var[None] @ features_labels[..., None]))
    posterior_means = np.squeeze(posterior_means, -1)
    posterior_vars = self.task_var * np.linalg.inv(
        self.task_var * np.eye(dim) + self.param_var @ feature_correlations
    ) @ self.param_var
    return posterior_means, posterior_vars

  def mstep(self, features, labels, posterior_means, posterior_vars):
    """ M-step of the EM-algorithm. """
    mean_deltas = posterior_means - self.param_mean
    self.param_var = (
        posterior_vars.mean(0)
        + np.mean(mean_deltas[:, :, None] @ mean_deltas[:, None], 0))
    self.param_mean = np.mean(posterior_means, 0)

    posterior_means = asobjects(posterior_means)
    posterior_vars = asobjects(posterior_vars)
    self.task_var = np.mean(mean(
        np.square(labels - matmul(features, posterior_means))
        + diag(matmul(matmul(features, posterior_vars), transpose(features)))
    ))
    return self.param_mean, self.param_var, self.task_var

  def log_likelihood(self, features, labels):
    """ Computes log-likelihood of the data under current parameters. """
    param_mean, param_var, task_var = \
        self.param_mean, self.param_var, self.task_var
    return np.sum([
        multivariate_normal.logpdf(
            y, X @ param_mean,
            X @ param_var @ X.T + task_var * np.eye(X.shape[0])
        )
        for X, y in zip(features, labels)
    ])

  def em_algorithm(self, features, labels):
    """ Implements EM-algorithm for finding probabilistic model parameters. """
    feature_correlations = np.asarray([X.T @ X for X in features])
    features_labels = np.asarray([X.T @ y for X, y in zip(features, labels)])
    features, labels = map(asobjects, (features, labels))

    dim = feature_correlations.shape[-1]
    self.param_mean, self.param_var, self.task_var\
        = [np.zeros(dim), np.eye(dim), 1.]
    self.fit_history["tols"].append([])

    for i in range(self.max_iter):
      posterior_means, posterior_vars = self.estep(feature_correlations,
                                                   features_labels)
      oldparams = [self.param_mean, self.param_var, self.task_var]
      params = self.mstep(features, labels, posterior_means, posterior_vars)
      tol = max(np.max(np.abs(p - oldp) / np.maximum(1e-8, np.abs(oldp)))
                for p, oldp in zip(params, oldparams))
      self.fit_history["tols"][-1].append(tol)
      if tol < self.tol:
        break

    self.fit_history["niters"].append(i)
    self.fit_history["params"].append(params)
    return params

  def fit(self, features, labels):
    if self.fit_intercept:
      features = add_constant_feature(features)
    self.em_algorithm(features, labels)
    return self

  def predict(self, features, labels, test_features):
    if self.fit_intercept:
      features, test_features = map(add_constant_feature,
                                    (features, test_features))
    return super().predict(features, labels, test_features)


class BiasedRegressionMetaLearner(BaseMetaLearner):
  """ Linear regression with regularization to best train weights. """
  def __init__(self, reg_coef=1., nsplits=5,
               adaptation_size=None, fit_intercept=False):
    self.reg_coef = reg_coef
    self.nsplits = nsplits
    self.adaptation_size = adaptation_size
    self.linreg = LinearRegression(fit_intercept=False)
    self.fit_intercept = fit_intercept
    self.weights = None

  def get_params(self, deep=True):
    """ Returns dictionary with hyper parameters of the estimator. """
    _ = deep
    return dict(reg_coef=self.reg_coef,
                nsplits=self.nsplits,
                adaptation_size=self.adaptation_size)

  def set_params(self, **params):
    """ Sets parameters of the estimator. """
    if "reg_coef" in params:
      self.reg_coef = params.pop("reg_coef")
    if "nsplits" in params:
      self.nsplits = params.pop("nsplits")
    if "adaptation_size" in params:
      self.adaptation_size = params.pop("adaptation_size")
    if params:
      raise ValueError(f"unknown params: {list(params.keys())}")
    return self

  def fit(self, features, labels):
    if self.fit_intercept:
      features = add_constant_feature(features)
    features = np.concatenate(features, 0)
    labels = np.concatenate(labels, 0)
    self.linreg.fit(features, labels)

  def adapt(self, features, labels):
    """ Adapts the regressor to given task(s). """
    if features.ndim == 2:
      features = np.asarray([features])
      labels = np.asarray([labels])
    features, labels = map(asobjects, (features, labels))

    multitask_weights = self.linreg.coef_
    dim = multitask_weights.shape[0]
    correlations = (matmul(transpose(features), features)
                    + self.reg_coef * asobjects(np.eye(dim)[None]))
    targets = (matmul(transpose(features), labels)
               + self.reg_coef * asobjects(multitask_weights[None]))
    solve = np.frompyfunc(np.linalg.solve, 2, 1)
    self.weights = solve(correlations, targets)

  def predict(self, features, labels, test_features):
    if self.fit_intercept:
      features, test_features = map(add_constant_feature,
                                    (features, test_features))
    self.adapt(features, labels)
    preds = matmul(asobjects([test_features] if features.ndim == 2
                             else test_features), self.weights)
    if test_features.dtype != np.object:
      preds = asarray(preds)
    return preds[0] if features.ndim == 2 else preds

  def score(self, features, labels, adaptation_size=None):
    """ Computes score of this estimator. """
    if adaptation_size is None:
      adaptation_size = self.adaptation_size
    if adaptation_size is None:
      raise ValueError("adaptation size must be specified either during "
                       "construction or when calling score method")
    mean_error = 0.
    for task_features, task_labels in zip(features, labels):
      for split in range(1, self.nsplits + 1):
        train_size = min(adaptation_size, task_features.shape[0] - 1)
        adapt_test = train_test_split(task_features, task_labels,
                                      train_size=train_size)
        adapt, test = Samples(*adapt_test[::2]), Samples(*adapt_test[1::2])
        preds = self.predict(*adapt, test.features)
        mean_error += (
            np.mean(np.square(test.labels - preds)) / split
            - mean_error / split)
    return -mean_error


class SearchMetaLearner(BaseMetaLearner):
  """ Meta-learner with some hyperparameter searching. """
  def __init__(self, learner, search_wrapper, **search_kwargs):
    self.learner = learner
    self.search_wrapper = search_wrapper
    self.search_kwargs = search_kwargs
    self.search_learner = None

  def fit(self, features, labels):
    self.search_learner = self.search_wrapper(
        self.learner, **self.search_kwargs)
    self.search_learner.fit(features, labels)

  def predict(self, features, labels, test_features):
    return self.search_learner.best_estimator_.predict(
        features, labels, test_features)


# shift interval a little to include zero.
# pylint: disable=invalid-name,too-few-public-methods
class loguniform_with_shift:
  def __init__(self, left, right, shift=1e-6):
    self.shift = shift
    self.dist = loguniform(left + shift, right + shift)

  def rvs(self, size=1, random_state=None):
    return self.dist.rvs(size=size, random_state=random_state) - self.shift
# pylint: enable=invalid-name


class RandomizedSearchBiasedRegression(SearchMetaLearner):
  """ Randomized search meta-learner. """
  def __init__(self, adaptation_size, interval=(0., 100.),
               nsplits=10, n_jobs=3, **search_kwargs):
    search_kwargs["n_iter"] = search_kwargs.get("n_iter", 50)
    search_kwargs["cv"] = search_kwargs.get("cv", 10)
    learner = BiasedRegressionMetaLearner(nsplits=nsplits,
                                          adaptation_size=adaptation_size)
    reg_coef_dist = loguniform_with_shift(*interval)
    super().__init__(learner, RandomizedSearchCV,
                     param_distributions={"reg_coef": reg_coef_dist},
                     n_jobs=n_jobs, **search_kwargs)


class SkoptSearchBiasedRegression(SearchMetaLearner):
  """ Searches for regularization coefficient in biased learner using skopt. """
  def __init__(self, adaptation_size, interval=(0., 100.),
               nsplits=5, n_jobs=3, **search_kwargs):
    learner = BiasedRegressionMetaLearner(nsplits=nsplits,
                                          adaptation_size=adaptation_size)
    spaces = {"reg_coef": skopt.space.Real(*interval)}
    super().__init__(learner, BayesSearchCV, search_spaces=spaces,
                     n_jobs=n_jobs, **search_kwargs)

  def fit(self, features, labels):
    with warnings.catch_warnings():
      warnings.simplefilter("once", UserWarning)
      return super().fit(features, labels)


class RepresentationMetaLearner(BiasedRegressionMetaLearner):
  """ Moment Matching representation learner as in Tripuraneni et al. """
  def __init__(self, rank=None):
    super().__init__(reg_coef=0.)
    self.rank = rank
    self.projection = None

  def fit(self, features, labels):
    features = np.concatenate(features, 0)
    labels = np.concatenate(labels, 0)
    ndim = features.shape[-1]
    num_samples = features.shape[0]
    features_labels = labels[..., None] * features / np.sqrt(num_samples)
    projection, _, _ = np.linalg.svd(features_labels.T @ features_labels,
                                     hermitian=True)
    rank = ndim // 2 if not self.rank else self.rank
    self.projection = projection[:, :rank]
    self.linreg.coef_ = np.zeros(self.projection.shape[-1])
    return self

  def predict(self, features, labels, test_features):
    if features.ndim == 2:
      features = features @ self.projection
      test_features = test_features @ self.projection
    else:
      features = np.asarray([X @ self.projection for X in features])
      test_features = np.asarray([X @ self.projection for X in test_features])
    return super().predict(features, labels, test_features)


class OracleRepresentationMetaLearner(RepresentationMetaLearner):
  """ Representation meta-learner from true parameter covariance matrix. """
  def __init__(self, param_var, rank=None, tol=1e-8):
    super().__init__()
    # pylint: disable=invalid-name
    u, s, _ = np.linalg.svd(param_var, hermitian=True)
    subspace_mask = s > tol if rank is None else np.arange(s.shape[0]) < rank
    u, s = u[..., subspace_mask], s[subspace_mask]
    self.projection = u * np.sqrt(s)[..., None, :]
    # pylint: enable=invalid-name
    self.linreg.coef_ = np.zeros(self.projection.shape[-1])

  def fit(self, features, labels):
    _ = features, labels
    return self


class EMProjectionEstimate(EMMetaLearner):
  """ Projection estimate with EM meta-learner. """
  def __init__(self, rank=None, **kwargs):
    super().__init__(**kwargs)
    self.rank = rank

  @property
  def projection(self):
    return OracleRepresentationMetaLearner(self.param_var, self.rank).projection


class MultitaskLearner(BaseMetaLearner):
  """ Multitask learner that wraps a single task learner. """
  def __init__(self, learner):
    self.learner = learner

  def fit(self, features, labels):
    features = np.concatenate(features, 0)
    labels = np.concatenate(labels, 0)
    self.learner.fit(features, labels)
    return self

  def predict(self, features, labels, test_features):
    if features.ndim == 2:
      return self.learner.predict(test_features)
    return np.asarray([self.learner.predict(X) for X in test_features])


class SingleTaskLearner(BaseMetaLearner):
  """ Learner on a single task that behaves like a meta-learner. """
  def __init__(self, learner):
    self.learner = learner

  def fit(self, features, labels):
    return self

  def predict(self, features, labels, test_features):
    if features.ndim == 2:
      self.learner.fit(features, labels)
      return self.learner.predict(test_features)
    result = []
    for i in range(features.shape[0]):
      self.learner.fit(features[i], labels[i])
      result.append(self.learner.predict(test_features[i]))
    return np.asarray(result)
