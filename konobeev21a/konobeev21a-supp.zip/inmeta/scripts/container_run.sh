CONTAINER_NAME=$1
ARGS=("$@")
unset 'ARGS[0]'


gcloud compute instances create-with-container ${CONTAINER_NAME} \
    --machine-type=e2-standard-2 \
    --container-restart-policy=never \
    --container-image=gcr.io/meta-theory/inmeta \
    ${ARGS[@]}

sleep 20


DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
gcloud compute scp $DIR/attach.sh $CONTAINER_NAME:~ > /dev/null
