""" Module to work with gcloud. """
from functools import partial
import os
import subprocess
import threading


class GCloudContainer:
  """ Represents docker container running on gcloud. """
  def __init__(self, name, capture_output=False):
    self.name = name
    self.subprocess_run_fn = partial(subprocess.run,
                                     capture_output=capture_output, check=True)

  def __call__(self, cmd):
    """ Runs the comand as subprocess. """
    return self.subprocess_run_fn(cmd)

  def launch(self, host_path, mount_path, *args, **kwargs):
    """ Create gcloud instances and launches container on it. """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    cmd = ["bash", f"{script_dir}/container_run.sh", self.name,
           ("--container-mount-host-path="
            f"host-path={host_path},mount-path={mount_path}")]
    for val in args:
      cmd.append(f"--container-arg={val}")
    for key, val in kwargs.items():
      cmd.extend([f"--container-arg=--{key}", f"--container-arg={val}"])
    self(cmd)

  def attach(self):
    """ Runs attach script on instance. """
    cmd = ["gcloud", "compute", "ssh", self.name, "--", "bash attach.sh"]
    self(cmd)

  def copy_files(self, src, dst, recurse=True):
    """ Copies files from instance. """
    cmd = ["gcloud", "compute", "scp"]
    if recurse:
      cmd.append("--recurse")
    cmd.extend([f"{self.name}:{src}", dst])
    self(cmd)

  def delete_instance(self):
    """ Deletes the instance. """
    return self(["gcloud", "compute", "instances", "delete", "-q", self.name])


def run_worker(index, factory, logdir, *args, **kwargs):
  """ Runs worker through gcloud container. """
  container = GCloudContainer(f"w{index:02d}", capture_output=index > 0)
  container_logdir = os.path.join("host", logdir, container.name)
  login = os.getlogin()
  container.launch(f"/home/{login}", "/home/host", factory, *args,
                   logdir=container_logdir, **kwargs)
  container.attach()
  # Join '*' to the src path of src to ensure that only the content is copied
  # to logdir.
  container.copy_files(os.path.join(logdir, '*'), logdir)
  container.delete_instance()


def run_batch(num_instances, factory, logdir, *args, **kwargs):
  """ Runs a batch of workers. """
  threads = []
  for worker_index in range(num_instances):
    worker_args = (worker_index, factory, logdir) + args
    worker_thread = threading.Thread(target=run_worker,
                                     args=worker_args, kwargs=kwargs)
    worker_thread.start()
    threads.append(worker_thread)
  for worker_thread in threads:
    worker_thread.join()
