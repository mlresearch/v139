while [ ! $(docker container ps -qaf ancestor=gcr.io/meta-theory/inmeta) ]; do
    sleep 3
done
CONTAINER_ID=$(docker container ps -qaf ancestor=gcr.io/meta-theory/inmeta)

sleep 5

if [ $(docker container inspect -f '{{.State.Status}}' ${CONTAINER_ID}) \
        == 'running' ]; then
    docker attach ${CONTAINER_ID}
fi
