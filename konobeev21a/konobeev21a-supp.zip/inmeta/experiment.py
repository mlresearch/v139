""" Helpful utilities to run experiments. """
from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass, field, fields
import math
import re
import os
import pickle
from typing import Union, List
import matplotlib.pyplot as plt
import numpy as np
import scipy.linalg
from tqdm.auto import tqdm
from inmeta.plot import plot_median_quantiles, set_figure_settings


def mse(labels, preds):
  """ Computes mean squared error between labels and predictions. """
  def _has_valid_shape(arr):
    return arr.ndim in {1, 2}
  if not _has_valid_shape(labels):
    raise ValueError(f"labels have invalid shape, labels.shape={labels.shape}")
  if not _has_valid_shape(preds):
    raise ValueError(f"preds have invalid shape, preds.shape={preds.shape}")
  if labels.shape != preds.shape:
    raise ValueError("labels and preds must have the same shapes, got "
                     f"preds.shape={preds.shape}, labels.shape={labels.shape}")
  def _size(arr):
    return np.concatenate(arr, 0).size if arr.dtype == np.object else arr.size
  if _size(labels) != _size(preds):
    raise ValueError("labels and preds must have the same number of elements "
                     f"got size(labels)={_size(labels)}, "
                     f"size(preds)={_size(preds)}")

  mean = np.frompyfunc(np.mean, 1, 1)
  return np.mean(mean(np.square(labels - preds)))


def sin_distance(projection, estimate):
  """ Computes sine distance between true projection and its estimate. """
  def check_ndim(name, arr):
    if arr.ndim != 2:
      raise ValueError(f"{name} has invalid number of dimensions, "
                       "expected 2, got {arr.ndim}")
  check_ndim("projection", projection)
  check_ndim("estimate", estimate)
  if projection.shape != estimate.shape:
    raise ValueError("the shapes of projection and estimate must match, "
                     f"got projection.shape={projection.shape} "
                     f"estimate.shape={estimate.shape}")
  projection, estimate = map(scipy.linalg.orth, (projection, estimate))
  _, singular_values, _ = np.linalg.svd(projection.T @ estimate)
  cos_similarity = min(singular_values)
  dist = math.sqrt(1 - cos_similarity * cos_similarity)
  return dist


def load(fname):
  """ Loads instance from a file. """
  with open(fname, "rb") as readfile:
    return pickle.load(readfile)

def dump(obj, fname):
  """ Saves object to a file. """
  with open(fname, "wb") as writefile:
    pickle.dump(obj, writefile)


@dataclass
class Results:
  """ Data class holding the results of an experiment. """
  error_mean: Union[List[np.ndarray], np.ndarray] = field(default_factory=list)
  sin_distance:\
      Union[List[np.ndarray], np.ndarray] = field(default_factory=list)

  @classmethod
  def batch(cls, results_iter):
    """ Returns new batched results object. """
    batched = cls()
    for res in results_iter:
      batched.append(res)
    for instance_field in fields(batched):
      field_name = instance_field.name
      if not any(filter(None, getattr(batched, field_name))):
        setattr(batched, field_name, None)
    return batched

  def append(self, other: Results) -> None:
    """ Appends results from other to this instance. """
    invalid_fields = [(f.name, type(getattr(self, f.name)))
                      for f in fields(self)
                      if not isinstance(getattr(self, f.name), list)]
    if invalid_fields:
      raise ValueError("the following field-type pairs are invalid: "
                       f"{invalid_fields}; expected all fields "
                       "to have type list")
    for instance_field in fields(self):
      field_name = instance_field.name
      getattr(self, field_name).append(getattr(other, field_name))


def plot_results(xs, results, plot_fn, figsize=None,
                 **figure_settings):
  """ Plots the results from the results dictionary. """
  fig = plt.figure(figsize=figsize)
  for key in sorted(results.keys()):
    error_mean_specified = results[key].error_mean is not None
    sin_distance_specified = results[key].sin_distance is not None
    if error_mean_specified == sin_distance_specified:
      raise ValueError("exactly one of error_mean and sin_distance "
                       "in the results should be set, got "
                       f"key={key}, results[key]={results[key]}")
    ys = (results[key].error_mean if error_mean_specified
          else results[key].sin_distance)
    plot_fn(xs, ys, label=key)
  set_figure_settings(**figure_settings)
  return fig


def fig_save_show(fig, fname=None, show=False):
  """ Saves and/or shows the figure. """
  if fname is not None:
    fig.savefig(fname)
  if show:
    fig.show()
    plt.waitforbuttonpress()


class ExpPlotter:
  """ Plots experiment. """
  def __init__(self, experiment, default_plot_fn):
    self.exp = experiment
    self.default_plot_fn = default_plot_fn

  def plot_ntasks(self, fname=None, show=False,
                  plot_fn=None, **figure_settings):
    """ Plots ntasks results. """
    if self.exp.ntasks_results is None:
      raise ValueError("ntasks_results do not exist, "
                       "call experiment.run_tasks method to create")
    plot_fn = plot_fn if plot_fn else self.default_plot_fn
    figure_settings["xlabel"] = figure_settings.get("xlabel", r"$n$")
    figure_settings["ylabel"] = figure_settings.get("ylabel", "Test loss")
    fig = plot_results(self.exp.ntasks_space, self.exp.ntasks_results,
                       plot_fn=plot_fn, **figure_settings)
    fig_save_show(fig, fname, show)
    return fig

  def plot_task_sizes(self, fname=None, show=False,
                      plot_fn=None, **figure_settings):
    """ Plots task_size results. """
    if self.exp.task_size_results is None:
      raise ValueError("task_size results do not exist, "
                       "call experiment.run_task_size method to create")
    figure_settings["xlabel"] = figure_settings.get("xlabel", r"$m$")
    figure_settings["ylabel"] = figure_settings.get("ylabel", "Test loss")
    plot_fn = plot_fn if plot_fn else self.default_plot_fn
    fig = plot_results(self.exp.task_size_space,
                       self.exp.task_size_results,
                       plot_fn=plot_fn, **figure_settings)
    fig_save_show(fig, fname, show)
    return fig

  def plot(self, fname_prefix=None, show=False,
           plot_fn=plt.semilogy, **figure_settings):
    """ Plots ntasks and task_size results. """
    plot_fn = plot_fn if plot_fn else self.default_plot_fn
    ntasks_fname, task_size_fname = None, None
    if fname_prefix is not None:
      ntasks_fname = fname_prefix + "_ntasks.png"
      task_size_fname = fname_prefix + "_task_size.png"

    ntasks_fig, task_size_fig = None, None
    if self.exp.ntasks_space is not None:
      ntasks_fig = self.plot_ntasks(fname=ntasks_fname,
                                    show=False, plot_fn=plot_fn,
                                    **figure_settings)
    if self.exp.task_size_space is not None:
      task_size_fig = self.plot_task_sizes(fname=task_size_fname,
                                           show=False, plot_fn=plot_fn,
                                           **figure_settings)
    if show:
      num_figures = 0
      if ntasks_fig is not None:
        ntasks_fig.show()
        num_figures += 1
      if task_size_fig is not None:
        task_size_fig.show()
        num_figures += 1
      # wait on all figures
      for _ in range(num_figures):
        plt.waitforbuttonpress()
    return ntasks_fig, task_size_fig


class ExpPlotterWrapper:
  """ For objects that intend to wrap ExpPlotter. """
  def __init__(self, plotter):
    self.plotter = plotter

  def plot_ntasks(self, fname=None, show=False,
                  plot_fn=None, **figure_settings):
    """ Plots ntasks results. """
    return self.plotter.plot_ntasks(fname, show, plot_fn, **figure_settings)

  def plot_task_sizes(self, fname=None, show=False,
                      plot_fn=None, **figure_settings):
    """ Plots task size results. """
    return self.plotter.plot_task_sizes(fname, show, plot_fn, **figure_settings)

  def plot(self, fname_prefix=None, show=False,
           plot_fn=None, **figure_settings):
    """ Plots ntasks and task size results. """
    return self.plotter.plot(fname_prefix, show, plot_fn, **figure_settings)


class Experiment(ExpPlotterWrapper):
  """ Class to run experiments. """
  def __init__(self, source, runner, learners):
    self.source = source
    self.runner = runner
    self.learners = learners
    self.ntasks_results = None
    self.task_size_results = None
    super().__init__(ExpPlotter(self, plt.semilogy))

  @property
  def ntasks_space(self):
    """ Number of tasks space. """
    return self.runner.ntasks_space

  @property
  def task_size_space(self):
    """ Task size space. """
    return self.runner.task_size_space

  def run_data_iter(self, data_iter, expected_length):
    """ Runs using data iterable. """
    results = defaultdict(Results)
    for (train, adapt, test) in tqdm(data_iter, total=expected_length):
      for key, learner in self.learners.items():
        learner.fit(*train)
        preds = learner.predict(*adapt, test.features)
        new_results = Results(mse(test.labels, preds), None)
        results[key].append(new_results)
    for key in results:
      results[key].sin_distance = None
    return results

  def run_ntasks(self, task_size=None):
    """ Runs experiment with varying number of tasks. """
    self.ntasks_results = self.run_data_iter(self.runner.run_ntasks(task_size),
                                             self.runner.ntasks_space.size)
    return self.ntasks_results

  def run_task_sizes(self, ntasks=None):
    """ Runs experiment with varying task sizes. """
    self.task_size_results = self.run_data_iter(
        self.runner.run_task_sizes(ntasks),
        self.runner.task_size_space.size)
    return self.task_size_results

  def run(self, *, ntasks_default=None, task_size_default=None):
    """ Runs both ntasks and task size experiments. """
    if self.runner.ntasks_space is not None:
      self.ntasks_results = self.run_ntasks(task_size_default)
    if self.runner.task_size_space is not None:
      self.task_size_results = self.run_task_sizes(ntasks_default)
    return self.ntasks_results, self.task_size_results


class SubspaceExperiment(Experiment):
  """ Subspace estimation experiment. """
  def __init__(self, source, runner, learners):
    if "oracle-representation" not in learners:
      raise ValueError("learners must learner with key "
                       "'oracle-representation', "
                       f"got learners.keys={learners.keys()}" )
    self.oracle = learners.pop("oracle-representation")
    super().__init__(source, runner, learners)

  def run_data_iter(self, data_iter, expected_length):
    results = defaultdict(Results)
    for (train, _, _) in tqdm(data_iter, total=expected_length):
      for key, learner in self.learners.items():
        learner.fit(*train)
        dist = sin_distance(self.oracle.projection, learner.projection)
        new_result = Results(None, dist)
        results[key].append(new_result)
    for key in results:
      results[key].error_mean = None
    return results


class BatchedExperiment(ExpPlotterWrapper):
  """ Combines multiple experiments into one. """
  def __init__(self, experiments):
    self.experiments = experiments

    def _check_runner_spaces(spaces, space_name):
      spaces = [s for s in spaces if s is not None]
      if spaces and len(spaces) != len(self.experiments):
        raise ValueError("Either all or none of runner spaces must be None "
                         f"got {space_name} has {len(spaces)} None spaces "
                         f"out of {len(experiments)} experiments")
      for i in range(1, len(spaces)):
        if not np.all(spaces[i] == spaces[i - 1]):
          raise ValueError("All runners must have the same spaces, "
                           f"got runner {space_name} have different values "
                           f"for indices {i-1} and {i}: "
                           f"{spaces[i-1]}; {spaces[i]}")
      return spaces[0] if spaces else None

    def _batch_results(results, results_name):
      results = [r for r in results if r is not None]
      if results and len(results) != len(self.experiments):
        raise ValueError("Either all or none of runner results must be None "
                         f"got {results_name} has {len(results)} None results "
                         f"out of {len(experiments)} experiments")
      if not results:
        return None
      keys = set(results[0])
      for i, res in enumerate(results):
        if set(res) != keys:
          raise ValueError(f"results[0] and results[{i}] have different keys "
                           f"keys of results[0] are {keys}; "
                           f"and of results[{i}] are {set(res)}")
      return defaultdict(Results, {
          k: Results.batch([res[k] for res in results])
          for k in keys
      })

    self.ntasks_space = _check_runner_spaces(
        [exp.ntasks_space for exp in self.experiments], "ntasks_space")
    self.ntasks_results = _batch_results(
        [exp.ntasks_results for exp in self.experiments], "ntasks_results")

    self.task_size_space = _check_runner_spaces(
        [exp.task_size_space for exp in self.experiments],
        "task_size_space")
    self.task_size_results = _batch_results(
        [exp.task_size_results for exp in self.experiments],
        "task_size_results")
    super().__init__(ExpPlotter(self, plot_median_quantiles))

  @classmethod
  def from_files(cls, fnames):
    """ Creates batched experiment by loading experiments from file. """
    return cls([load(f) for f in fnames])

  @classmethod
  def from_logdir(cls, logdir, dir_regex=r"w\d?\d",
                  fname="exp.pickle", batch_size=30):
    """ Creates batched experiment by loading from log directory. """
    fnames = [
        os.path.join(logdir, dirname, fname)
        for dirname in os.listdir(logdir)
        if (re.match(dir_regex, dirname)
            and os.path.isdir(os.path.join(logdir, dirname)))
    ]
    if batch_size is not None and len(fnames) != batch_size:
      raise ValueError(f"Found onlye {len(fnames)} files, while "
                       f"{batch_size} was expected")
    return cls.from_files(fnames)
