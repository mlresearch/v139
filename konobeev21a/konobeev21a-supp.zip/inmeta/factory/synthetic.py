""" Synthetic experiment factory. """
import numpy as np
from inmeta.experiment import SubspaceExperiment
from inmeta.factory.factory import Factory, create_space
from inmeta.meta_learner import (
    EMProjectionEstimate,
    OracleRepresentationMetaLearner,
    RepresentationMetaLearner,
)
from inmeta.task import (
    SphericalFeaturesLinearModelSampler,
    FourierFeaturesLinearModelSampler,
    GaussianFeaturesLinearModelSampler,
    DataRunner)


def sample_cov(dim, low_rank=False):
  """ Samples random covariance matrix. """
  if not low_rank:
    ltmat = np.tril(np.random.randn(dim, dim))
    return ltmat @ ltmat.T + np.random.random() * np.eye(dim)
  samples = np.random.randn(dim, int(.5 * dim))
  return samples @ samples.T


class SyntheticExpFactory(Factory):
  """ Synthetic data experiment factory. """

  @staticmethod
  def get_parser_defaults(args_type=None):
    if args_type not in {"spherical", "fourier"}:
      raise ValueError(f"invalid value of args_type={args_type} "
                       "allowed values are 'spherical', 'fourier'")
    ndim = 42 if args_type == "spherical" else 11
    space = ((10, 100, 20) if args_type == "fourier" else (20, 200, 20))
    return {
        "sampler-type": dict(default=args_type, choices=[args_type]),
        "ndim": ndim,
        "ntasks-space": dict(type=float, nargs=3, default=space),
        "task-size-space": dict(type=float, nargs=3, default=space),
        "use-linspace": dict(action="store_false", dest="use_logspace"),
        "low-rank": dict(action="store_true"),
        "adaptation-size": 10,
        "num-test-tasks": 100,
        "test-task-size": 100,
        "biased-regression-nsplits": 10,
        "biased-regression-cv": 10,
        **Factory.get_enable_disable_defaults(),
    }

  def make_data_source(self, **kwargs):
    """ Constructs and returns sampler. """
    with self.custom_kwargs(**kwargs):
      ndim = self.get_arg("ndim")
      low_rank = self.get_arg("low_rank")
      param_mean = self.get_arg_default("param_mean", np.zeros(ndim))
      param_var = self.get_arg_default("param_var", sample_cov(ndim, low_rank))
      task_var = self.get_arg_default("task_var", 1)

      sampler_type = self.get_arg("sampler_type")
      sampler_class = {
          "spherical": SphericalFeaturesLinearModelSampler,
          "fourier": FourierFeaturesLinearModelSampler}[sampler_type]
      sampler = sampler_class(param_mean, param_var, task_var)
      return sampler

  def make_data_runner(self, **kwargs):
    with self.custom_kwargs(**kwargs):
      sampler = self.get_or_make("data_source")

      ntasks_space = create_space(
          *self.get_arg("ntasks_space"),
          logspace=self.get_arg_default("use_logspace", True))
      task_size_space = create_space(
          *self.get_arg("task_size_space"),
          logspace=self.get_arg_default("use_logspace", True))

      train_dims = ntasks_space[-1], task_size_space[-1]
      num_test_tasks = self.get_arg("num_test_tasks")
      adaptation_size = self.get_arg("adaptation_size")
      test_task_size = self.get_arg("test_task_size")
      meta_split = sampler.get_meta_split(train_dims, num_test_tasks,
                                          adaptation_size, test_task_size)
      runner = DataRunner(meta_split, ntasks_space, task_size_space)
      return runner


class FourierExpFactory(SyntheticExpFactory):
  @staticmethod
  def get_parser_defaults(args_type=None):
    _ = args_type
    return SyntheticExpFactory.get_parser_defaults(args_type="fourier")


class SphericalExpFactory(SyntheticExpFactory):
  @staticmethod
  def get_parser_defaults(args_type=None):
    _ = args_type
    return SyntheticExpFactory.get_parser_defaults(args_type="spherical")


class SubspaceExpFactory(Factory):
  """ Subspace experiment factory. """
  @staticmethod
  def get_parser_defaults(args_type=None):
    _ = args_type
    return {
        "ntasks-space": dict(type=int, nargs=3, default=(100, 6400, 7)),
        "task-size": 5,
        "ndim": 100,
        "rank": 5,
        "task-var": 1.,
        "use-linspace": dict(action="store_false", dest="use_logspace"),
        "enable-learners": dict(nargs="+", default=["em", "representation"]),
    }

  def make_data_source(self, **kwargs):
    with self.custom_kwargs(**kwargs):
      ndim, rank = self.get_arg_list("ndim", "rank")
      param_mean = self.get_arg_default("param_mean", np.zeros(ndim))
      param_var = self.get_arg_default("param_var", None)
      if param_var is None:
        projection = self.get_arg_default("projection", None)
        if projection is None:
          projection = np.linalg.svd(np.random.randn(ndim, rank))[0][:, :rank]
        param_var = 1 / rank * np.eye(rank)
        param_var = projection @ param_var @ projection.T

      task_var = self.get_arg("task_var")
      return GaussianFeaturesLinearModelSampler(param_mean, param_var, task_var)

  def make_data_runner(self, **kwargs):
    with self.custom_kwargs(**kwargs):
      sampler = self.get_or_make("data_source")
      ntasks_space = create_space(*self.get_arg("ntasks_space"),
                                  self.get_arg_default("use_logspace", True))

      train_dims = ntasks_space[-1], self.get_arg("task_size")
      split = sampler.get_meta_split(train_dims, num_test_tasks=0,
                                     adaptation_size=0, test_size=0)
      return DataRunner(split, ntasks_space)

  def make_learners(self, **kwargs):
    with self.custom_kwargs(**kwargs):
      source = self.get_arg("data_source")
      param_var = source.param_var
      rank = self.get_arg("rank")
      learners = {
          "em": EMProjectionEstimate(rank=rank),
          "representation": RepresentationMetaLearner(rank=rank),
          "oracle-representation": OracleRepresentationMetaLearner(param_var),
      }
      learners = {key: val for key, val in learners.items()
                  if key in (self.get_arg("enable_learners")
                             + ["oracle-representation"])}
      return learners

  def make_exp(self, **kwargs):
    with self.custom_kwargs(**kwargs):
      source = self.get_or_make("data_source")
      runner = self.get_or_make("data_runner", data_source=source)
      learners = self.get_or_make("learners", data_source=source)
      exp = SubspaceExperiment(source, runner, learners)
      return exp
