""" School dataset factory. """
from functools import partial
import numpy as np
from scipy.io import loadmat
from sklearn.preprocessing import normalize
from inmeta.factory.factory import Factory, create_space
from inmeta.meta_learner import add_constant_feature as add_constant_feature_fn
from inmeta.task import (train_adaptation_test_split, shuffle_samples,
                         DataRunner)


def normalize_meta_dataset_features(features):
  """ Normalizes features. """
  task_sizes = [task_features.shape[0] for task_features in features]
  features = np.concatenate(features, 0)
  features = normalize(features)
  split_sizes = np.cumsum(task_sizes)[:-1]
  return np.asarray(np.split(features, split_sizes))


# pylint: disable=redefined-outer-name
def school_preprocessor(features, labels, normalize=True,
                        add_constant_feature=True, shuffle=True):
  """ School data preprocessor. """
  if normalize:
    features = normalize_meta_dataset_features(features)
  if add_constant_feature:
    features = add_constant_feature_fn(features)
  if shuffle:
    shuffle_samples(features, labels)
  return features, labels
# pylint: enable=redefined-outer-name


def load_school_split(fname="data/schoolData.mat",
                      preprocessor=school_preprocessor,
                      train_tasks_size=100, adaptation_size=0.8):
  """ Loads school data and creates a split for it. """
  if not (fname.endswith(".mat") or fname.endswith(".npz")):
    raise ValueError("expected to have file name with extension .mat or .npz, "
                     f"got file name '{fname}'")
  if fname.endswith(".mat"):
    data = loadmat(fname)
    features, labels = map(np.squeeze, (data["X"], data["Y"]))
    for i, (task_features, task_labels) in enumerate(zip(features, labels)):
      features[i] = task_features.T
      labels[i] = np.squeeze(task_labels, 1)
  else:
    npzfile = np.load(fname, allow_pickle=True)
    features, labels = npzfile["features"], npzfile["labels"]
  features, labels = preprocessor(features, labels)
  return train_adaptation_test_split(features, labels,
                                     train_tasks_size=train_tasks_size,
                                     adaptation_size=adaptation_size)


class SchoolExpFactory(Factory):
  """ School data experiment. """
  @staticmethod
  def get_parser_defaults(args_type=None):
    return {
        "data-file": "data/school.npz",
        "train-tasks-size": 100,
        "adaptation-size": 0.8,
        "ntasks-space": dict(type=float, nargs=3, default=(10, 100, 20)),
        "use-linspace": dict(action="store_false", dest="use_logspace"),
        "biased-regression-nsplits": 10,
        "biased-regression-cv": 10,
        **Factory.get_enable_disable_defaults(),
    }

  def make_data_source(self, **kwargs):
    with self.custom_kwargs(**kwargs):
      partial_kwargs = dict(
          fname=self.get_arg("data_file"),
          train_tasks_size=self.get_arg("train_tasks_size")
      )
      adaptation_size = self.get_arg_default("adaptation_size")
      if adaptation_size is not None:
        partial_kwargs["adaptation_size"] = adaptation_size
      source = partial(load_school_split, **partial_kwargs)
      return source

  def make_data_runner(self, **kwargs):
    with self.custom_kwargs(**kwargs):
      data_source = self.get_or_make("data_source")
      split = data_source()
      ntasks_space = create_space(*self.get_arg("ntasks_space"),
                                  self.get_arg_default("use_logspace", True))
      return DataRunner(split, ntasks_space)
