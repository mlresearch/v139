""" Code to construct different objects. """
from abc import ABC, abstractmethod
from argparse import ArgumentParser
from contextlib import contextmanager
import numpy as np
from sklearn.linear_model import RidgeCV
from inmeta.experiment import Experiment
from inmeta.meta_learner import (
    MetaLearnerCov,
    HeuristicMetaLearner,
    MomentMatchingMetaLearner,
    EMMetaLearner,
    RandomizedSearchBiasedRegression,
    RepresentationMetaLearner,
    OracleRepresentationMetaLearner,
    MultitaskLearner,
    SingleTaskLearner,
    MergeTrainAdaptWrapper,
)


def get_defaults_parser(args, base_parser=None):
  """ Creates argument parser from dictionary. """
  if base_parser is None:
    base_parser = ArgumentParser()
  for key, val in args.items():
    if isinstance(val, dict):
      base_parser.add_argument(f"--{key}", **val)
    else:
      base_parser.add_argument(f"--{key}", type=type(val), default=val)
  return base_parser


def create_space(start, stop, num, logspace=True):
  """ Creates space from given arguments. """
  spacefn = np.linspace
  if logspace:
    spacefn = np.geomspace
  return spacefn(start, stop, int(num)).round(0).astype(np.int)


class Factory(ABC):
  """ Factory to construct experiments. """
  def __init__(self, *, unused_kwargs=None, **kwargs):
    self.kwargs = kwargs
    self.allowed_unused_kwargs = set(unused_kwargs) if unused_kwargs else set()
    self.unused_kwargs = set(self.kwargs)

  @classmethod
  def get_enable_disable_defaults(cls):
    """ Returns defaults for enabling and disabling learners arguments. """
    return {
        "enable-learners": dict(
            nargs='+', default=["em", "biased-regression",
                                "meta-learner-cov",
                                "oracle-representation",
                                "linreg-all", "linreg-task"]),
        "disable-learners": dict(nargs='*', default=[])
    }

  @staticmethod
  @abstractmethod
  def get_parser_defaults(args_type=None):
    """ Returns default argument dictionary for argument parsing. """
    return {}.get(args_type, {})

  @classmethod
  def get_kwargs(cls, args_type=None):
    """ Returns dictionary of keyword arguments. """
    dummy_parser = get_defaults_parser(cls.get_parser_defaults(args_type))
    args = dummy_parser.parse_args([])
    return vars(args)

  @classmethod
  def from_default_kwargs(cls, args_type=None, unused_kwargs=None, **kwargs):
    """ Creates instance with default keyword arguments. """
    default_kwargs = cls.get_kwargs(args_type)
    default_kwargs.update(kwargs)
    return cls(unused_kwargs=unused_kwargs, **default_kwargs)

  @classmethod
  def from_args(cls, args_type=None, unused_kwargs=None, args=None):
    """ Creates factory after parsing command line arguments. """
    defaults = cls.get_parser_defaults(args_type)
    parser = get_defaults_parser(defaults)
    args = parser.parse_args(args)
    return cls(unused_kwargs=unused_kwargs, **vars(args))

  def has_arg(self, name):
    """ Returns bool indicating whether the factory has argument with name. """
    result = name in self.kwargs
    self.unused_kwargs.discard(name)
    return result

  def get_arg(self, name):
    """ Returns argument value. """
    result = self.kwargs[name]
    self.unused_kwargs.discard(name)
    return result

  def get_arg_default(self, name, default=None):
    """ Returns argument value or default if it was not specified. """
    result = self.kwargs.get(name, default)
    self.unused_kwargs.discard(name)
    return result

  def get_arg_list(self, *names):
    """ Returns list of argument values. """
    return [self.get_arg(name) for name in names]

  def get_arg_dict(self, *names, check_exists=True):
    """ Returns dictionary of arguments. """
    return {name: self.get_arg(name) for name in names
            if not check_exists or self.has_arg(name)}

  def set_arg(self, **kwargs):
    """ Sets value of keyword argument. """
    for name, val in kwargs.items():
      self.kwargs[name] = val

  @contextmanager
  def custom_kwargs(self, **kwargs):
    """ Custom keyword arguments context. """
    init_kwargs = self.kwargs
    custom_kwargs = set(kwargs)
    self.unused_kwargs |= custom_kwargs
    self.kwargs = {name: kwargs[name] if name in kwargs else self.kwargs[name]
                   for name in set(self.kwargs) | custom_kwargs}
    try:
      yield
    finally:
      if custom_kwargs & self.unused_kwargs:
        raise ValueError("following custom kwargs were not used: "
                         f"{custom_kwargs & self.unused_kwargs}")
      self.kwargs = init_kwargs

  def get_or_make(self, name, **kwargs):
    """ Returns arg under name from kwargs or creates it. """
    with self.custom_kwargs(**kwargs):
      if self.has_arg(name):
        return self.get_arg(name)
      return getattr(self, "make_" + name)()

  @abstractmethod
  def make_data_source(self, **kwargs):
    """ Creates and returns data source. """

  @abstractmethod
  def make_data_runner(self, **kwargs):
    """ Creates and returns data runner. """

  def make_learners(self, **kwargs):
    """ Creates and returns dictionary of learners. """
    with self.custom_kwargs(**kwargs):
      biased_regression_kwargs = dict(
          adaptation_size=self.get_arg("adaptation_size"),
          nsplits=self.get_arg("biased_regression_nsplits"),
          cv=self.get_arg("biased_regression_cv"),
      )
      learners = {
          "heuristic": HeuristicMetaLearner(),
          "moment-matching": MomentMatchingMetaLearner(),
          "em": EMMetaLearner(),
          "inf-em": MergeTrainAdaptWrapper(EMMetaLearner()),
          "biased-regression": RandomizedSearchBiasedRegression(
              **biased_regression_kwargs),
          "linreg-all": MultitaskLearner(RidgeCV(fit_intercept=False)),
          "inf-linreg-all": MergeTrainAdaptWrapper(
              MultitaskLearner(RidgeCV(fit_intercept=False))),
          "linreg-task": SingleTaskLearner(RidgeCV(fit_intercept=False)),
      }
      source = self.get_arg("data_source")
      param_var = getattr(source, "param_var", None)
      task_var = getattr(source, "task_var", None)
      if param_var is not None and task_var is not None:
        learners["meta-learner-cov"] = MetaLearnerCov(param_var, task_var)
      low_rank = self.get_arg_default("low_rank", False)
      if low_rank:
        learners["representation"] = RepresentationMetaLearner()
      if low_rank and param_var is not None:
        learners["oracle-representation"] = \
            OracleRepresentationMetaLearner(param_var)
      enabled_learners = (set(self.get_arg_default("enable_learners"))
                          if self.get_arg_default("enable_learners")
                          is not None else None)
      if enabled_learners is None:
        enabled_learners = set(learners.keys())
      disabled_learners = set(self.get_arg_default("disable_learners", []))
      if disabled_learners - set(learners.keys()):
        raise ValueError("unknown --disable-learners values: "
                         f"{disabled_learners - set(learners.keys())}")
      return {key: learner for key, learner in learners.items()
              if key in enabled_learners - disabled_learners}

  def make_exp(self, **kwargs):
    """ Creates and returns experiment object. """
    with self.custom_kwargs(**kwargs):
      source = self.get_or_make("data_source")
      runner = self.get_or_make("data_runner", data_source=source)
      learners = self.get_or_make("learners", data_source=source)
      exp = Experiment(source, runner, learners)
      return exp

  def make(self, check_kwargs=True, **kwargs):
    """ Creates and returns experiment. """
    with self.custom_kwargs(**kwargs):
      exp = self.make_exp()
      if check_kwargs and self.unused_kwargs - self.allowed_unused_kwargs:
        raise ValueError(
            "constructing target object does not use all keyword arguments, "
            "unused keyword arguments are: "
            f"{self.unused_kwargs - self.allowed_unused_kwargs};"
            "if this is expected, consider adding them to unused_kwargs "
            "during factory construction or passing "
            "`check_kwargs=False` to this method.")
    return exp
