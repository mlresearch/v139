from distutils.core import setup

setup(
    name="inmeta",
    version="0.1dev",
    description="Instance Dependent Analysis of Meta-Learning",
    author="Mikhail Konobeev",
    author_email="konobeev.michael@gmail.com",
    license="MIT",
    packages=["inmeta"],
    scripts=["inmeta/scripts/inmeta"],
    install_requires=[
        "numpy==1.18.4",
        "scipy",
        "jaxlib",
        "jax",
        "matplotlib",
        "tqdm",
        "scikit-optimize==0.7.4",
        "scikit-learn==0.23.1",
    ],
    long_description=(
        'Code for paper '
        '"A Distribution-Dependent Analysis of Meta-Learning"')
)
