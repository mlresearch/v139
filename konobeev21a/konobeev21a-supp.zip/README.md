## Code for paper "A Distribution-Dependent Analysis of Meta-Learning"

#### Installation and running instructions:

First, install the package:
```
pip install -e .
```

To run single Fourier experiment (takes about 5-10 minutes):
```
inmeta fourier --logdir logdir/fourier.00 --figure-name-prefix fourier
```
To run Fourier low rank experiment (takes about 5-10 minutes):
```
inmeta fourier --logdir logdir/fourier.low-rank \
  --figure-name-prefix fourier-low-rank
```
To run subspace estimation experiment (takes about 4 hours):
```
inmeta subspace --logdir logdir/subspace --figure-name-prefix subspace
```
To run single spherical experiment (takes about 45 minutes):
```
inmeta spherical --logdir logdir/spherical.00 --figure-name-prefix spherical
```
To run school dataset experiment (takes about 15 minutes):
```
inmeta school --logdir logdir/school.00 --figure-name-prefix school
```

To get error bars we make 30 independent runs simultaneously using
google cloud.  Upload the container under some tag, e.g.
`gcr.io/meta-theory/inmeta` (the tag could be different but that
requires modifications to `inmeta/scripts/*.sh`):
```
gcloud builds submit . --tag gcr.io/meta-theory/inmeta
```
Run the script similar to how it is done for single experiment but adding
`--num-instances` flag:
```
inmeta fourier --logdir logdir/gcloud/fourier.icml --num-instances 30
```
The results could be loaded and viewed as done in
the `notebooks/paper.ipynb` notebook.
