from .train import main
