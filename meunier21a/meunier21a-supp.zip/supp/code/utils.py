import numpy as np
from scipy.special import softmax, logsumexp
from torch import nn
import torch

mean_0 = [0, 0]
mean_10 = [3, 0]
mean_11 = [-3, 0]
cov = np.eye(2)
x_lim = (-7, 7)
y_lim = (-7, 7)


def simulate_uniform(n):
    rho = np.sqrt(np.random.uniform(size=n))
    theta = 2 * np.pi * np.random.uniform(size=n)
    x = rho * np.cos(theta)
    y = rho * np.sin(theta)
    a = np.zeros((n, 2))
    a[:, 0] = x
    a[:, 1] = y
    return a


def compute_risk_adv(w, b, X, y, epsilon):
    return np.mean(((X.dot(w.T) + b).T * y).T <= +epsilon * np.linalg.norm(w, axis=1), axis=0)


def compute_sup(lbda, u, ws, bs, x, y, epsilon):
    X = x + epsilon * u
    u = ((X.dot(ws.T) + bs).T * y).T <= 0
    a = u.dot(lbda)
    adv_index = np.argmax(a)
    return a[adv_index], u[adv_index]


def compute_sup_regularized(lbda, u, ws, bs, x, y, epsilon, eta):
    X = x + epsilon * u
    losses = ((X.dot(ws.T) + bs).T * y).T <= 0
    a = losses.dot(lbda)
    softmaxes = softmax(a / eta)
    grad = np.dot(softmaxes, losses / eta)

    return eta * logsumexp(a / eta), grad


def simulate_data(p, n):
    n_0 = np.random.binomial(n, p)
    n_1 = n - n_0
    Y = np.ones(n)
    Y[:n_0] = -1

    data_0 = np.random.multivariate_normal(mean_0, cov, n_0)

    n_10 = np.random.binomial(n_1, 1 / 2)
    n_11 = n_1 - n_10
    data_10 = np.random.multivariate_normal(mean_10, cov, n_10)
    data_11 = np.random.multivariate_normal(mean_11, cov, n_11)
    data_1 = np.concatenate([data_10, data_11])

    X = np.concatenate([data_0, data_1])
    return X, Y


def classifiers(num, symmetrized=True):
    x1s = np.random.uniform(x_lim[0], x_lim[1], num)
    y1s = np.random.uniform(y_lim[0], y_lim[1], num)

    x2s = np.random.uniform(x_lim[0], x_lim[1], num)
    y2s = np.random.uniform(y_lim[0], y_lim[1], num)

    ds = np.zeros((num, 2))
    ds[:, 0] = x2s - x1s
    ds[:, 1] = y2s - y1s
    ws = np.zeros(np.shape(ds))
    ws[:, 0] = -ds[:, 1]
    ws[:, 1] = ds[:, 0]
    bs = -(ws[:, 0] * x1s + ws[:, 1] * y1s)
    if symmetrized:
        ws = np.concatenate([ws, -ws])
        bs = np.concatenate([bs, -bs])
    return ws, bs


def projection_simplex_sort(v, z=1):
    n_features = v.shape[0]
    u = np.sort(v)[::-1]
    cssv = np.cumsum(u) - z
    ind = np.arange(n_features) + 1
    cond = u - cssv / ind > 0
    rho = ind[cond][-1]
    theta = cssv[cond][-1] / float(rho)
    w = np.maximum(v - theta, 0)
    return w


def compute_risk(X, Y, lbda, u, ws, bs, epsilon, reg=-1):
    n_samples = len(X)
    if epsilon == 0:
        u = np.zeros((1, 2))
    global_adv_loss = 0
    grads = []
    for x, y in zip(X, Y):
        if reg < 0:
            adv_loss, grad = compute_sup(
                lbda, u, ws, bs, x, y, epsilon)
        else:
            adv_loss, grad = compute_sup_regularized(
                lbda, u, ws, bs, x, y, epsilon, reg)
        global_adv_loss += adv_loss
        grads.append(grad)

    global_adv_loss /= n_samples
    grad_avg = np.array(grads).mean(axis=0)
    return global_adv_loss, grad_avg


class Normalize(nn.Module):
    def __init__(self, mean, std):
        super(Normalize, self).__init__()
        self.mean = torch.Tensor(mean)
        self.std = torch.Tensor(std)

    def forward(self, x):
        return (x - self.mean.type_as(x)[None, :, None, None]) / self.std.type_as(x)[None, :, None, None]


class NormalizedModel(nn.Module):
    def __init__(self, model, mean, std):
        super(NormalizedModel, self).__init__()
        self.model = model
        self.normalize = Normalize(mean, std)

    def forward(self, x):
        return self.model(self.normalize(x))


class MixedModel(nn.Module):
    def __init__(self, models, lbda):
        super(MixedModel, self).__init__()
        self.models = torch.nn.ModuleList(models)
        self.lbda = lbda

    def forward(self, x):
        ii = np.random.choice(np.arange(len(self.lbda)), p=self.lbda)
        return self.models[ii](x)


class DLRLoss(nn.Module):
    def __init__(self):
        super(DLRLoss, self).__init__()

    def forward(self, x, y):
        x_sorted, ind_sorted = x.sort(dim=1)
        ind = (ind_sorted[:, -1] == y).float()

        u = -(x[np.arange(x.shape[0]), y] - x_sorted[:, -2] * ind - x_sorted[:, -1] * (1. - ind)) / (
                x_sorted[:, -1] - x_sorted[:, -3] + 1e-12)
        return u.mean()


class Smooth01Loss(nn.Module):
    def __init__(self, K):
        super(Smooth01Loss, self).__init__()
        self.K = K

    def forward(self, x, y):
        x_sorted, ind_sorted = x.sort(dim=1)
        ind = (ind_sorted[:, -1] == y).float()

        u = -(x[np.arange(x.shape[0]), y] - x_sorted[:, -2] * ind - x_sorted[:, -1] * (1. - ind))
        u = torch.nn.functional.sigmoid(u / self.K)
        return u.mean()


def lr_lambda(epoch):
    lr = 0.1
    if epoch < 30:
        return lr
    elif epoch < 90:
        return lr / 10
    else:
        return lr / 100
