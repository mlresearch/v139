import numpy as np
from utils import *
import matplotlib.pyplot as plt


class naive_problem:
    def __init__(self, n_samples_train, n_samples_test, n_classifiers_candidates, n_classifiers, epsilon,
                 nb_iter=10000, lr=2., seed=12):
        self.seed = seed
        self.n_samples_train = n_samples_train
        self.n_samples_test = n_samples_test
        self.n_classifiers_candidates = n_classifiers_candidates
        self.n_classifiers = n_classifiers
        self.epsilon = epsilon
        self.nb_iter = nb_iter
        self.lr = lr

    def __call__(self, result_file="results.txt"):
        np.random.seed(self.seed)
        X, Y = simulate_data(1 / 2, self.n_samples_train)
        X_out, Y_out = simulate_data(1 / 2, self.n_samples_test)

        ws, bs = classifiers(int(self.n_classifiers_candidates / 2))

        risk_insample = compute_risk_adv(ws, bs, X, Y, 0.)
        best_classifiers = np.argsort(risk_insample)[:self.n_classifiers]

        ws = ws[best_classifiers]
        bs = bs[best_classifiers]

        adv_risk_insample = compute_risk_adv(ws, bs, X, Y, self.epsilon)
        risk_insample = compute_risk_adv(ws, bs, X, Y, 0.)
        opt_classifier = np.argmin(adv_risk_insample)

        risk_nat_det_in = risk_insample[opt_classifier]
        risk_adv_det_in = adv_risk_insample[opt_classifier]

        risk_outsample = compute_risk_adv(ws, bs, X_out, Y_out, 0.)
        adv_risk_outsample = compute_risk_adv(ws, bs, X_out, Y_out, self.epsilon)

        risk_nat_det_out = risk_outsample[opt_classifier]
        risk_adv_det_out = adv_risk_outsample[opt_classifier]

        u = simulate_uniform(1000)
        lbda = np.ones(self.n_classifiers) / self.n_classifiers

        losses_in = []

        for i in range(self.nb_iter):
            adv_loss, grad_avg = compute_risk(X, Y, lbda, u, ws, bs, self.epsilon)
            losses_in.append(adv_loss)

            lbda -= self.lr / (i + 1) ** 0.5 * (grad_avg)
            lbda = projection_simplex_sort(lbda)

        losses_in = np.array(losses_in)
        plt.figure()
        plt.plot(losses_in)
        plt.show()

        np.savetxt(f"training_adv_losses_{self.epsilon}", losses_in)

        risk_nat_rand_in, _ = compute_risk(X, Y, lbda, u, ws, bs, 0.)
        risk_adv_rand_in, _ = compute_risk(X, Y, lbda, u, ws, bs, self.epsilon)
        risk_nat_rand_out, _ = compute_risk(X_out, Y_out, lbda, u, ws, bs, 0.)
        risk_adv_rand_out, _ = compute_risk(X_out, Y_out, lbda, u, ws, bs, self.epsilon)

        with open(result_file, 'a') as f:
            f.write(f"{self.epsilon} {risk_adv_det_in} {risk_adv_rand_in} {risk_nat_det_in} {risk_nat_rand_in} "
                    f"{risk_adv_det_out} {risk_adv_rand_out} {risk_nat_det_out} {risk_nat_rand_out}\n")

        print(f"epsilon={self.epsilon}, nb_iter = {self.nb_iter}")
        print()
        print(f"In sample adversarial determinstic risk: {risk_adv_det_in}")
        print(f"In sample adversarial randomized risk: {risk_adv_rand_in}")
        print(f"In sample natural determinstic risk: {risk_nat_det_in}")
        print(f"In sample natural randomized risk: {risk_nat_rand_in}")

        print()
        print(f"Out sample adversarial determinstic risk: {risk_adv_det_out}")
        print(f"Out sample adversarial randomized risk: {risk_adv_rand_out}")
        print(f"Out sample natural determinstic risk: {risk_nat_det_out}")
        print(f"Out sample natural randomized risk: {risk_nat_rand_out}")


if __name__ == "__main__":
    problem = naive_problem(100, 100, 100, 20, 3., nb_iter=1000, lr=2., seed=12)
    problem()

