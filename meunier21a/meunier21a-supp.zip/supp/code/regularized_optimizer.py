import numpy as np
from utils import *
import matplotlib.pyplot as plt
import torch




class toy_example:
    def __init__(self, n_samples_train, n_samples_test, n_classifiers_candidates, n_classifiers, epsilon,
                 nb_iter=10000, lr=2., reg=1e-8, seed=12):
        self.seed = seed
        self.n_samples_train = n_samples_train
        self.n_samples_test = n_samples_test
        self.n_classifiers_candidates = n_classifiers_candidates
        self.n_classifiers = n_classifiers
        self.epsilon = epsilon
        self.nb_iter = nb_iter
        self.lr = lr
        self.reg = reg

    def __call__(self, result_file="results.txt"):
        np.random.seed(self.seed)
        X, Y = simulate_data(1 / 2, self.n_samples_train)
        X_out, Y_out = simulate_data(1 / 2, self.n_samples_test)

        ws, bs = classifiers(int(self.n_classifiers_candidates / 2))

        risk_insample = compute_risk_adv(ws, bs, X, Y, 0.)
        ind_correct = risk_insample < 0.4
        #trisk_insample = risk_insample[ind_correct]
        ws = ws[ind_correct][:self.n_classifiers]
        bs = bs[ind_correct][:self.n_classifiers]
        # print(len(risk_insample))
        # best_classifiers = np.argsort(risk_insample)[:self.n_classifiers]
        # print(len(best_classifiers))
        # ws = ws[best_classifiers]
        # bs = bs[best_classifiers]

        adv_risk_insample = compute_risk_adv(ws, bs, X, Y, self.epsilon)
        risk_insample = compute_risk_adv(ws, bs, X, Y, 0.)
        opt_classifier = np.argmin(adv_risk_insample)

        risk_nat_det_in = risk_insample[opt_classifier]
        risk_adv_det_in = adv_risk_insample[opt_classifier]

        risk_outsample = compute_risk_adv(ws, bs, X_out, Y_out, 0.)
        adv_risk_outsample = compute_risk_adv(ws, bs, X_out, Y_out, self.epsilon)

        risk_nat_det_out = risk_outsample[opt_classifier]
        risk_adv_det_out = adv_risk_outsample[opt_classifier]

        u2 = simulate_uniform(1000)

        lbda = np.ones(self.n_classifiers) / self.n_classifiers

        losses_in = []
        # grads = []
        # grads_th = []
        best_adv_loss, _ = compute_risk(X, Y, lbda, u2, ws, bs, self.epsilon, reg=self.reg)
        if True:
            adv_loss, grad_avg = compute_risk(X, Y, lbda, u2, ws, bs, self.epsilon, reg=self.reg)
            while adv_loss >= best_adv_loss:
                lbda_test = projection_simplex_sort(lbda - self.lr * grad_avg)
                adv_loss, grad_avg = compute_risk(X, Y, lbda_test, u2, ws, bs, self.epsilon, reg=self.reg)
                self.lr /= 2
            self.lr *= 2
        print(f"Learning rate = {self.lr}")
        for i in range(self.nb_iter):
            u = simulate_uniform(1000)
            _, grad_avg = compute_risk(X, Y, lbda, u, ws, bs, self.epsilon, reg=self.reg)
            adv_loss, _ = compute_risk(X, Y, lbda, u2, ws, bs, self.epsilon, reg=-1)
            # grads.append(grad_avg)
            # grads_th.append(grad_avg_th)

            losses_in.append(adv_loss)
            if adv_loss < best_adv_loss:
                best_lbda = np.copy(lbda)
                best_adv_loss = adv_loss

            if self.reg < 0.:
                lbda -= np.sqrt(4 / self.nb_iter) * (grad_avg)
            else:
                lbda -= self.lr * (grad_avg)
            lbda = projection_simplex_sort(lbda)

        losses_in = np.array(losses_in)
        plt.figure()
        plt.plot(losses_in, label=f"reg={self.reg}")
        plt.legend()
        plt.show()

        state_dict = {"losses": losses_in, "reg": self.reg,
                      #"grad_th": np.array(grads_th), "grads": np.array(grads)
                      }
        torch.save(state_dict, f"losses_bis/comparison_reg_{self.reg}.pth")
        u = simulate_uniform(10000)

        risk_nat_rand_in, _ = compute_risk(X, Y, best_lbda, u, ws, bs, 0.)
        risk_adv_rand_in, _ = compute_risk(X, Y, best_lbda, u, ws, bs, self.epsilon)
        risk_nat_rand_out, _ = compute_risk(X_out, Y_out, best_lbda, u, ws, bs, 0.)
        risk_adv_rand_out, _ = compute_risk(X_out, Y_out, best_lbda, u, ws, bs, self.epsilon)

        state_dict = {"losses": losses_in, "reg": self.reg, "risk_adv": risk_adv_rand_in}
        torch.save(state_dict, f"losses_new/comparison_reg_{self.reg}.pth")
        with open(result_file, 'a') as f:
            f.write(f"{self.epsilon} {risk_adv_det_in} {risk_adv_rand_in} {risk_nat_det_in} {risk_nat_rand_in} "
                    f"{risk_adv_det_out} {risk_adv_rand_out} {risk_nat_det_out} {risk_nat_rand_out}\n")

        print(f"epsilon={self.epsilon}, nb_iter = {self.nb_iter}, regularization = {self.reg}")
        print()
        print(f"In sample adversarial determinstic risk: {risk_adv_det_in}")
        print(f"In sample adversarial randomized risk: {risk_adv_rand_in}")
        print(f"In sample natural determinstic risk: {risk_nat_det_in}")
        print(f"In sample natural randomized risk: {risk_nat_rand_in}")

        print()
        print(f"Out sample adversarial determinstic risk: {risk_adv_det_out}")
        print(f"Out sample adversarial randomized risk: {risk_adv_rand_out}")
        print(f"Out sample natural determinstic risk: {risk_nat_det_out}")
        print(f"Out sample natural randomized risk: {risk_nat_rand_out}")


if __name__ == "__main__":
    # problem = toy_example(n_samples_train=100,
    #                       n_samples_test=100,
    #                       n_classifiers_candidates=1000,
    #                       n_classifiers=10,
    #                       epsilon=3.,
    #                       nb_iter=1000,
    #                       lr=10.,
    #                       reg=1e-4,
    #                       seed=12)
    # problem()

    problem = toy_example(n_samples_train=1000,
                          n_samples_test=1000,
                          n_classifiers_candidates=100,
                          n_classifiers=10,
                          epsilon=0.5,
                          nb_iter=1000,
                          lr=10.,
                          reg=-1,
                          seed=12)
    problem()
