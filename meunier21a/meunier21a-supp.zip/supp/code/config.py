from typing import NamedTuple
from typing import List as List


class ClusterConfig(NamedTuple):
    dist_backend: str
    dist_url: str
    num_nodes: int
    num_gpus_per_node: int


class TrainerConfig(NamedTuple):
    epochs: int
    batch_per_gpu: int
    save_folder: str
    models: List[str]
    reg: float
    eps_attack: float
    iter_attack: int
    n_restarts: int
    loss: str
    result_file: str
    lr_reg: float
    attack: str
    ckpt_run: str
    dataset: str
