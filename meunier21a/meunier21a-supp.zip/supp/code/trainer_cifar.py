import os
import submitit
from config import *
from torch import optim, nn
import attr
import torch.backends.cudnn as cudnn
from typing import List as List
from typing import Tuple as Tuple
from typing import Any as Any
import time
from auto_attack import *
from scipy.special import softmax
from torch import distributed
from models import *
from pgd_attack import *
from trades import *

dict_models = {
    "ResNet18": ResNet18,
    "PreActResNet18": PreActResNet18,
    "GoogLeNet": GoogLeNet,
    "SimpleDLA": SimpleDLA,
    "DenseNet121": DenseNet121,
    "WideResNet28x10": WideResNet28x10,
    "WideResNet34x20": WideResNet34x20
}


@attr.s(auto_attribs=True)
class TrainerState:
    """
    Contains the state of the Trainer.
    It can be saved to checkpoint the training and loaded to resume it.
    """

    epoch: int
    models: nn.ModuleList
    optimizer: List[optim.Optimizer]
    lr_scheduler: List[torch.optim.lr_scheduler._LRScheduler]
    lbda: np.array
    best_acc_adv: float

    def save(self, filename: str) -> None:
        data = attr.asdict(self)
        # store only the state dict
        data[f"models"] = self.models.state_dict()
        data[f"optimizer"] = []
        data[f"lr_scheduler"] = []

        for opt in self.optimizer:
            data[f"optimizer"].append(opt.state_dict())

        for lr_s in self.lr_scheduler:
            data[f"lr_scheduler"].append(lr_s.state_dict())
        data[f"lbda"] = self.lbda
        data[f"epoch"] = self.epoch
        data["best_acc_adv"] = self.best_acc_adv
        torch.save(data, filename)

    @classmethod
    def load(cls, filename: str, default: "TrainerState", gpu: int) -> "TrainerState":
        data = torch.load(filename, map_location=lambda storage, loc: storage.cuda(gpu))
        # We need this default to load the state dict
        models = default.models
        models.load_state_dict(data[f"models"])
        data[f"models"] = models
        for k, opt in enumerate(default.optimizer):
            opt.load_state_dict(data[f"optimizer"][k])
            data[f"optimizer"][k] = opt

        for k, lr_s in enumerate(default.lr_scheduler):
            lr_s.load_state_dict(data[f"lr_scheduler"][k])
            data[f"lr_scheduler"][k] = lr_s
        return cls(**data)


class Trainer:
    def __init__(self, train_cfg: TrainerConfig, cluster_cfg: ClusterConfig):
        self._train_cfg = train_cfg
        self._cluster_cfg = cluster_cfg
        self.n_classifiers = len(self._train_cfg.models)

    def __call__(self):
        cudnn.benchmark = True
        # setup process group
        job_env = submitit.JobEnvironment()
        torch.cuda.set_device(job_env.local_rank)
        distributed.init_process_group(
            backend=self._cluster_cfg.dist_backend,
            init_method=self._cluster_cfg.dist_url,
            world_size=job_env.num_tasks,
            rank=job_env.global_rank,
        )

        print(f"Process group: {job_env.num_tasks} tasks, rank: {job_env.global_rank}")

        print("Create data loaders", flush=True)

        transform = transforms.Compose([transforms.RandomCrop(32, padding=4),
                                        transforms.RandomHorizontalFlip(),
                                        transforms.ToTensor()])
        if self._train_cfg.dataset == "CIFAR10":
            train_set = datasets.CIFAR10("data/cifar10", train=True,
                                         download=True, transform=transform)
            num_classes = 10
        else:
            train_set = datasets.CIFAR100("data/cifar100", train=True,
                                          download=True, transform=transform)
            num_classes = 100

        train_sampler = torch.utils.data.distributed.DistributedSampler(
            train_set, num_replicas=job_env.num_tasks, rank=job_env.global_rank
        )

        self._train_loader = torch.utils.data.DataLoader(
            train_set,
            batch_size=int(self._train_cfg.batch_per_gpu),
            num_workers=int(80 * self._cluster_cfg.num_nodes / self._cluster_cfg.num_gpus_per_node),
            sampler=train_sampler
        )

        transform = transforms.Compose([transforms.ToTensor()])

        if self._train_cfg.dataset == "CIFAR10":
            test_set = datasets.CIFAR10("data/cifar10", train=False,
                                        download=True, transform=transform)
        else:
            test_set = datasets.CIFAR100("data/cifar100", train=False,
                                         download=True, transform=transform)

        test_sampler = torch.utils.data.distributed.DistributedSampler(
            test_set, num_replicas=job_env.num_tasks, rank=job_env.global_rank
        )

        self._test_loader = torch.utils.data.DataLoader(
            test_set,
            batch_size=int(self._train_cfg.batch_per_gpu),
            num_workers=int(80 * self._cluster_cfg.num_nodes / self._cluster_cfg.num_gpus_per_node),
            sampler=test_sampler,
        )
        print(f"Total batch_size: {self._train_cfg.batch_per_gpu * job_env.num_tasks}", flush=True)

        print("Create distributed model", flush=True)

        models = nn.ModuleList([NormalizedModel(dict_models[model](num_classes=num_classes),
                                                mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]) for model in
                                self._train_cfg.models])
        for i in range(self.n_classifiers):
            models[i].cuda(job_env.local_rank)
            # models[i] = torch.nn.SyncBatchNorm.convert_sync_batchnorm(models[i])
            models[i].train()
            models[i] = torch.nn.parallel.DistributedDataParallel(models[i], device_ids=[job_env.local_rank],
                                                                  output_device=job_env.local_rank, broadcast_buffers=False)
        models = nn.ModuleList(models)

        optimizer = [optim.SGD(models[k].parameters(),
                               lr=max(0.1 * self._train_cfg.batch_per_gpu *
                                      job_env.num_tasks / 256, 0.1),
                               momentum=0.9, weight_decay=5e-4) for k in range(self.n_classifiers)]

        n_epochs_model = int(self._train_cfg.epochs / self.n_classifiers)
        lr_scheduler = [torch.optim.lr_scheduler.MultiStepLR(optimizer[k],
                                                             [int(n_epochs_model / 2),
                                                              int(3 * n_epochs_model / 4)],
                                                             gamma=0.1) for k in
                        range(self.n_classifiers)]

        lbda = np.ones(self.n_classifiers) / self.n_classifiers

        self._state = TrainerState(epoch=0, models=models, optimizer=optimizer,
                                   lr_scheduler=lr_scheduler, lbda=lbda, best_acc_adv=-1)
        if self._train_cfg.ckpt_run is None:
            self.ckpt_run = str(job_env.job_id)
        else:
            self.ckpt_run = self._train_cfg.ckpt_run
        checkpoint_fn = os.path.join(self._train_cfg.save_folder, self.ckpt_run, "checkpoint.pth")
        if os.path.isfile(checkpoint_fn):
            print(f"Load existing checkpoint from {checkpoint_fn}", flush=True)
            self._state = TrainerState.load(
                checkpoint_fn, default=self._state, gpu=job_env.local_rank)
        criterion = nn.CrossEntropyLoss(reduction='mean').cuda(job_env.local_rank)
        criterion_kl = nn.KLDivLoss(size_average=False).cuda(job_env.local_rank)

        # Start from the loaded epoch
        start_epoch = self._state.epoch
        if self._train_cfg.attack == "APGD":
            adversary = APGDAttack(self._state.models, n_iter=self._train_cfg.iter_attack, norm='Linf',
                                   eps=self._train_cfg.eps_attack, loss=self._train_cfg.loss, rho=.75, verbose=False)
            adversary_ent = APGDAttack(self._state.models, n_iter=3, norm='Linf',
                                       eps=self._train_cfg.eps_attack, loss=self._train_cfg.loss, rho=.75,
                                       verbose=False)

        elif self._train_cfg.attack == "PGD":
            eps_iter = 2. * self._train_cfg.eps_attack / self._train_cfg.iter_attack
            adversary = PGDAttack(self._state.models, eps=self._train_cfg.eps_attack,
                                  nb_iter=self._train_cfg.iter_attack, eps_iter=eps_iter, rand_init=True,
                                  clip_min=0., clip_max=1., ord=np.inf, targeted=False)
            eps_iter = 2. * self._train_cfg.eps_attack / 3.
            adversary_ent = PGDAttack(self._state.models, eps=self._train_cfg.eps_attack,
                                      nb_iter=3, eps_iter=eps_iter, rand_init=True,
                                      clip_min=0., clip_max=1., ord=np.inf, targeted=False)
        elif self._train_cfg.attack == "TRADES":
            eps_iter = 2. * self._train_cfg.eps_attack / self._train_cfg.iter_attack
            adversary = TRADESAttack(self._state.models, eps=self._train_cfg.eps_attack,
                                     nb_iter=self._train_cfg.iter_attack, eps_iter=eps_iter,
                                     clip_min=0., clip_max=1.)
            eps_iter = 2. * self._train_cfg.eps_attack / 3.
            adversary_ent = PGDAttack(self._state.models, eps=self._train_cfg.eps_attack,
                                      nb_iter=3, eps_iter=eps_iter, rand_init=True,
                                      clip_min=0., clip_max=1., ord=np.inf, targeted=False)
            trades_loss = TradesLoss(self._state.models, 6.)
        print(f"Attack caracteristics : epsilon = {self._train_cfg.eps_attack}, iters = {self._train_cfg.iter_attack},"
              f"n_restarts = {self._train_cfg.n_restarts}")
        print(f"Regularization : {self._train_cfg.reg}")
        print(f"Models: {self._train_cfg.models}")
        print(f"Number of epochs per model:{int(self._train_cfg.epochs / self.n_classifiers)}")
        print_freq = 10

        n_update_models = int(50 * 1024 / (self._train_cfg.batch_per_gpu * job_env.num_tasks))
        if self.n_classifiers > 1:
            m = 25
            period = n_update_models * self.n_classifiers + 1

        else:
            m = 0
            period = n_update_models

        t = 0
        acc_adv = -1
        order = torch.IntTensor([0] * self.n_classifiers).cuda(job_env.local_rank,
                                                               non_blocking=True)
        for epoch in range(start_epoch, self._train_cfg.epochs):
            lrs = []
            for k in range(self.n_classifiers):
                self._state.lr_scheduler[k].step(int(epoch / self.n_classifiers))
                for param_group in self._state.optimizer[k].param_groups:
                    lrs.append(param_group['lr'])
            print(f"Start epoch {epoch}, learning rates = {lrs}", flush=True)

            self._state.epoch = epoch
            for i, data in enumerate(self._train_loader):
                inputs, labels = data
                inputs = inputs.cuda(job_env.local_rank, non_blocking=True)
                labels = labels.cuda(job_env.local_rank, non_blocking=True)
                batch_size = len(labels)

                if (t % period == 0) and (job_env.global_rank == 0):
                    order = np.arange(self.n_classifiers)
                    np.random.shuffle(order)
                    order = torch.IntTensor(order).cuda(job_env.local_rank, non_blocking=True)

                if (t % period == 0):
                    distributed.broadcast(order, src=0)
                    order_np = order.cpu().numpy()
                    print(f"Order = {order_np}")
                torch.autograd.set_detect_anomaly(True)
                if (t % period) < n_update_models * self.n_classifiers:
                    k = int((t % period) / n_update_models)
                    i = order_np[k]
                    self._state.models.eval()
                    with torch.no_grad():
                        robust_acc_ex, inputs_adv, _ = adversary.perturb(inputs, labels, self._state.lbda,
                                                                         n_restarts=self._train_cfg.n_restarts,
                                                                         restart_all=False)
                    inputs_adv = torch.autograd.Variable(inputs_adv, requires_grad=False)
                    inputs = torch.autograd.Variable(inputs, requires_grad=False)
                    self._state.models.train()
                    self._state.optimizer[i].zero_grad()
                    if self._train_cfg.attack == "TRADES":
                        logits = self._state.models[i](inputs)
                        loss_natural = criterion(logits, labels)

                        loss_robust = (1.0 / batch_size)*criterion_kl(F.log_softmax(self._state.models[i](inputs_adv), dim=1),
                                                                      F.softmax(self._state.models[i](inputs), dim=1))

                        # loss = loss_robust
                        # trades_loss(inputs, inputs_adv, labels, i)
                        loss = loss_natural+6.*loss_robust
                    else:
                        outputs = self._state.models[i](inputs_adv)
                        loss = criterion(outputs, labels)
                    loss.backward()
                    self._state.optimizer[i].step()
                else:
                    self._state.lbda = np.ones(self.n_classifiers) / self.n_classifiers
                    self._state.models.eval()
                    if self._train_cfg.reg < 0.:
                        for _ in range(m):
                            with torch.no_grad():
                                robust_acc, _, acc_per_model = adversary.perturb(inputs, labels, self._state.lbda,
                                                                                 n_restarts=self._train_cfg.n_restarts,
                                                                                 restart_all=False)

                            placeholder = torch.zeros_like(acc_per_model).cuda(
                                job_env.local_rank, non_blocking=True)
                            acc_per_model_list = [placeholder] * job_env.num_tasks
                            distributed.all_gather(
                                acc_per_model_list, acc_per_model.cuda(job_env.local_rank))
                            acc_per_model = torch.cat(acc_per_model_list, dim=0)

                            grad_lbda = 1. - acc_per_model.mean(dim=0).cpu().numpy()
                            self._state.lbda = self._state.lbda - \
                                np.sqrt(4. / m) * grad_lbda  # todo: learning rate
                            self._state.lbda = projection_simplex_sort(self._state.lbda)
                    else:
                        for _ in range(m):
                            with torch.no_grad():
                                robust_acc, _, acc_per_model = adversary_ent.perturb(inputs, labels, self._state.lbda,
                                                                                     n_restarts=5, restart_all=True)

                            placeholder = torch.zeros_like(acc_per_model).cuda(
                                job_env.local_rank, non_blocking=True)
                            acc_per_model_list = [placeholder] * job_env.num_tasks
                            distributed.all_gather(
                                acc_per_model_list, acc_per_model.cuda(job_env.local_rank))
                            acc_per_model = torch.cat(acc_per_model_list, dim=1)
                            placeholder = torch.zeros_like(robust_acc).cuda(
                                job_env.local_rank, non_blocking=True)
                            robust_acc_list = [placeholder] * job_env.num_tasks
                            distributed.all_gather(
                                robust_acc_list, robust_acc.cuda(job_env.local_rank))
                            robust_acc = torch.cat(robust_acc_list, dim=1)

                            acc_per_model = 1. - acc_per_model.cpu().numpy()
                            acc_per_model = acc_per_model.transpose(2, 0, 1)
                            robust_acc = (1. - robust_acc.cpu().numpy()) / self._train_cfg.reg
                            ss = softmax(robust_acc, axis=0)
                            grad_lbda = (ss * acc_per_model)
                            grad_lbda = grad_lbda.sum(axis=1)
                            grad_lbda = grad_lbda.mean(axis=1)

                            self._state.lbda = self._state.lbda - self._train_cfg.lr_reg * grad_lbda  # todo: learning rate
                            self._state.lbda = projection_simplex_sort(self._state.lbda)
                    print(f"grad_lbda = {grad_lbda}")
                    print(f"lbda = {self._state.lbda}")
                if i % print_freq == print_freq - 1:
                    print(
                        f"[{epoch}, {i}] last loss: {loss.item()}, last robust acc = {robust_acc_ex.mean()},"
                        f"last lambda = {self._state.lbda}",
                        flush=True)

                t += 1

            # Checkpoint only on the master
            if (job_env.global_rank == 0):
                self.checkpoint(rm_init=False)
            if ((epoch % self.n_classifiers) == 0):
                acc, acc_adv = self._eval()
            if (job_env.global_rank == 0) and (acc_adv > self._state.best_acc_adv):
                save_dir = os.path.join(self._train_cfg.save_folder, self.ckpt_run)
                self._state.best_acc_adv = acc_adv

                self._state.save(os.path.join(save_dir, "best.pth"))

        if job_env.global_rank == 0:
            save_dir = os.path.join(self._train_cfg.save_folder, self.ckpt_run)
            self._state.save(os.path.join(save_dir, "last.pth"))

    def checkpoint(self, rm_init=True, name="checkpoint.pth") -> submitit.helpers.DelayedSubmission:
        # will be called by submitit in case of preemption
        job_env = submitit.JobEnvironment()
        save_dir = os.path.join(self._train_cfg.save_folder, self.ckpt_run)
        os.makedirs(save_dir, exist_ok=True)
        self._state.save(os.path.join(save_dir, name))

        # Trick here: when the job will be requeue, we will use the same init file
        # but it must not exist when we initialize the process group
        # so we delete it, but only when this method is called by submitit for requeue
        if rm_init:
            os.remove(self._cluster_cfg.dist_url[7:])  # remove file:// at the beginning
        # This allow to remove any non-pickable part of the Trainer instance.
        empty_trainer = Trainer(self._train_cfg, self._cluster_cfg)
        return submitit.helpers.DelayedSubmission(empty_trainer)

    def _eval(self) -> Tuple[Any, Any]:
        print("Start evaluation of the model", flush=True)
        job_env = submitit.JobEnvironment()

        total = 0

        self._state.models.eval()
        # adversary = APGDAttack(self._state.models, n_iter=100,
        #                        norm='Linf', eps=self._train_cfg.eps_attack,
        #                        loss=self._train_cfg.loss, rho=.75, verbose=False)

        eps_iter = 2. * self._train_cfg.eps_attack / 20
        adversary = PGDAttack(self._state.models, eps=self._train_cfg.eps_attack,
                              nb_iter=20, eps_iter=eps_iter, rand_init=True,
                              clip_min=0., clip_max=1., ord=np.inf, targeted=False)
        # compute natural accuracy
        correct = torch.zeros(self.n_classifiers).cuda(job_env.local_rank)
        correct_adv = torch.zeros(self.n_classifiers).cuda(job_env.local_rank)

        with torch.no_grad():
            for data in self._test_loader:
                images, labels = data
                images = images.cuda(job_env.local_rank, non_blocking=True)
                labels = labels.cuda(job_env.local_rank, non_blocking=True)
                total += labels.size(0)
                for k, l in enumerate(self._state.lbda):
                    outputs = self._state.models[k](images)
                    _, predicted = torch.max(outputs.data, 1)
                    correct[k] += (predicted == labels).cuda(job_env.local_rank).sum().item()

                robust_acc, _, acc_per_model = adversary.perturb(images, labels, self._state.lbda,
                                                                 n_restarts=1)
                correct_adv += acc_per_model.cuda(job_env.local_rank).sum(dim=0)

        distributed.all_reduce(correct, op=torch.distributed.ReduceOp.SUM)
        distributed.all_reduce(correct_adv, op=torch.distributed.ReduceOp.SUM)

        total = torch.Tensor([total]).cuda(job_env.local_rank)
        distributed.all_reduce(total, op=torch.distributed.ReduceOp.SUM)
        acc = (correct / total).cpu().numpy()
        acc_adv = (correct_adv / total).cpu().numpy()

        print(f"Accuracy per model of the network on the 10000 test images: {acc}", flush=True)
        print(
            f"Adversarial accuracy per model of the network on the 10000 test images: {acc_adv}", flush=True)
        acc = acc.dot(self._state.lbda)
        acc_adv = acc_adv.dot(self._state.lbda)

        print(f"Accuracy of the network on the 10000 test images: {acc:.1%}", flush=True)
        print(
            f"Adversarial accuracy of the network on the 10000 test images: {acc_adv:.1%}", flush=True)
        if (job_env.global_rank == 0):
            with open(self._train_cfg.result_file, 'a') as f:
                f.write(f"{self._train_cfg.eps_attack} {self.n_classifiers} {self._state.epoch} "
                        f"{acc_adv} {acc}\n")

        return acc, acc_adv

    def _big_eval(self, model_path: str, eval_file: str) -> None:
        print("Start evaluation of the model", flush=True)
        job_env = submitit.JobEnvironment()
        torch.cuda.set_device(job_env.local_rank)
        distributed.init_process_group(
            backend=self._cluster_cfg.dist_backend,
            init_method=self._cluster_cfg.dist_url,
            world_size=job_env.num_tasks,
            rank=job_env.global_rank,
        )

        transform = transforms.Compose([transforms.ToTensor()])
        if self._train_cfg.dataset == "CIFAR10":
            test_set = datasets.CIFAR10("data/cifar10", train=False,
                                        download=True, transform=transform)
            num_classes = 10
        else:
            test_set = datasets.CIFAR100("data/cifar100", train=False,
                                         download=True, transform=transform)
            num_classes = 100

        test_sampler = torch.utils.data.distributed.DistributedSampler(
            test_set, num_replicas=job_env.num_tasks, rank=job_env.global_rank
        )
        test_loader = torch.utils.data.DataLoader(
            test_set,
            batch_size=int(self._train_cfg.batch_per_gpu),
            num_workers=int(80 * self._cluster_cfg.num_nodes / self._cluster_cfg.num_gpus_per_node),
            sampler=test_sampler,
        )

        models_best = nn.ModuleList(
            [NormalizedModel(dict_models[model](num_classes=num_classes), mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]) for model in
             self._train_cfg.models])

        for i in range(self.n_classifiers):
            models_best[i].cuda(job_env.local_rank)
            models_best[i] = torch.nn.parallel.DistributedDataParallel(models_best[i], device_ids=[job_env.local_rank],
                                                                       output_device=job_env.local_rank)
        models_best = nn.ModuleList(models_best)

        data = torch.load(model_path, map_location=lambda storage,
                          loc: storage.cuda(job_env.local_rank))
        models_best.load_state_dict(data[f"models"])
        models_best.eval()

        lbda = data["lbda"]
        epoch = data[f"epoch"]
        print(torch.cuda.get_device_name(0))
        print(f"lambda ={lbda}")
        print(f"epoch = {epoch}")
        adversary_ce = APGDAttack(models_best, n_iter=5,
                                  norm='Linf', eps=self._train_cfg.eps_attack,
                                  loss="ce", rho=.75, verbose=False)

        adversary_dlr = APGDAttack(models_best, n_iter=5,
                                   norm='Linf', eps=self._train_cfg.eps_attack,
                                   loss="dlr", rho=.75, verbose=False)
        total = 0
        correct = torch.zeros(self.n_classifiers).cuda(job_env.local_rank)
        correct_ce = torch.zeros(self.n_classifiers).cuda(job_env.local_rank)
        correct_dlr = torch.zeros(self.n_classifiers).cuda(job_env.local_rank)
        correct_all = torch.zeros(self.n_classifiers).cuda(job_env.local_rank)
        t0 = time.time()

        with torch.no_grad():
            for i, data in enumerate(test_loader):
                images, labels = data
                images = images.cuda(job_env.local_rank, non_blocking=True)
                labels = labels.cuda(job_env.local_rank, non_blocking=True)
                total += labels.size(0)
                for k, l in enumerate(lbda):
                    outputs = models_best[k](images)
                    _, predicted = torch.max(outputs.data, 1)
                    correct[k] += (predicted == labels).cuda(job_env.local_rank).sum().item()

                _, _, acc_per_model_ce = adversary_ce.perturb(images, labels, lbda, n_restarts=2)
                _, _, acc_per_model_dlr = adversary_dlr.perturb(images, labels, lbda, n_restarts=2)

                acc_per_model_all = acc_per_model_ce * acc_per_model_dlr
                correct_ce += acc_per_model_ce.cuda(job_env.local_rank).sum(dim=0)
                correct_dlr += acc_per_model_dlr.cuda(job_env.local_rank).sum(dim=0)
                correct_all += acc_per_model_all.cuda(job_env.local_rank).sum(dim=0)
                print(f"batch {i} done")

        distributed.all_reduce(correct, op=torch.distributed.ReduceOp.SUM)
        distributed.all_reduce(correct_ce, op=torch.distributed.ReduceOp.SUM)
        distributed.all_reduce(correct_dlr, op=torch.distributed.ReduceOp.SUM)
        distributed.all_reduce(correct_all, op=torch.distributed.ReduceOp.SUM)

        total = torch.Tensor([total]).cuda(job_env.local_rank)
        distributed.all_reduce(total, op=torch.distributed.ReduceOp.SUM)

        acc = (correct / total).cpu().numpy()
        acc_ce = (correct_ce / total).cpu().numpy()
        acc_dlr = (correct_dlr / total).cpu().numpy()
        acc_all = (correct_all / total).cpu().numpy()

        acc = acc.dot(lbda)
        acc_ce = acc_ce.dot(lbda)
        acc_dlr = acc_dlr.dot(lbda)
        acc_all = acc_all.dot(lbda)
        print(f"Accuracy of the network on the 10000 test images: {acc:.1%}", flush=True)
        print(
            f"Adversarial CE accuracy of the network on the 10000 test images: {acc_ce:.1%}", flush=True)
        print(
            f"Adversarial DLR accuracy of the network on the 10000 test images: {acc_dlr:.1%}", flush=True)
        print(
            f"Adversarial ALL accuracy of the network on the 10000 test images: {acc_all:.1%}", flush=True)
        print(f"time: {time.time()-t0}")

        if (job_env.global_rank == 0):
            with open(eval_file, 'a') as f:
                f.write(f"{model_path} {epoch} {acc} {acc_ce} {acc_dlr} {acc_all}\n")

        # lr_scheduler = [torch.optim.lr_scheduler.CosineAnnealingLR(
        #     optimizer[k],
        #     T_max=int(self._train_cfg.epochs / self.n_classifiers)) for k in range(self.n_classifiers)]
